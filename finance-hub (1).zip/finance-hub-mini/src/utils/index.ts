/** 格式化日期 */
export function formatDate(date: string | number | Date, fmt = 'YYYY-MM-DD'): string {
  const d = new Date(date)
  const map: Record<string, number> = {
    YYYY: d.getFullYear(),
    MM: d.getMonth() + 1,
    DD: d.getDate(),
    HH: d.getHours(),
    mm: d.getMinutes(),
    ss: d.getSeconds(),
  }
  return fmt.replace(/YYYY|MM|DD|HH|mm|ss/g, (m) =>
    String(map[m]).padStart(2, '0')
  )
}

/** 格式化涨跌幅 */
export function formatChange(val: number | null | undefined): string {
  if (val == null) return '--'
  const sign = val > 0 ? '+' : ''
  return `${sign}${val.toFixed(2)}%`
}

/** 格式化价格 */
export function formatPrice(val: number | null | undefined): string {
  if (val == null) return '--'
  return val.toFixed(2)
}

/** 涨跌颜色 */
export function changeColor(val: number | null | undefined): string {
  if (val == null || val === 0) return '#999'
  return val > 0 ? '#ef4444' : '#22c55e'
}

/** 格式化大数字 (万/亿) */
export function formatLargeNumber(num: number | null | undefined): string {
  if (num == null) return '--'
  if (Math.abs(num) >= 1e8) return `${(num / 1e8).toFixed(2)}亿`
  if (Math.abs(num) >= 1e4) return `${(num / 1e4).toFixed(2)}万`
  return num.toFixed(2)
}

/** 截断文本 */
export function truncate(text: string, len: number): string {
  if (!text) return ''
  return text.length > len ? text.slice(0, len) + '...' : text
}
