import Taro from '@tarojs/taro'

// ============================================================
// API 请求层 - 对接现有后端 tRPC API
// ============================================================
// 部署后需替换为实际后端地址，例如：
// https://your-domain.manus.space
const BASE_URL = 'https://3000-iiemaiorogohuwpg6kmjf-9a74184d.us1.manus.computer'

/** 通用请求封装 */
async function request<T>(url: string, options: Taro.request.Option & { showError?: boolean } = {} as any): Promise<T> {
  const token = Taro.getStorageSync('token') || ''
  const res = await Taro.request({
    url: `${BASE_URL}${url}`,
    header: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...((options as any).header || {}),
    },
    ...options,
  })
  if (res.statusCode >= 200 && res.statusCode < 300) {
    return res.data as T
  }
  if (options.showError !== false) {
    Taro.showToast({ title: '请求失败', icon: 'none' })
  }
  throw new Error(`Request failed: ${res.statusCode}`)
}

// ============================================================
// tRPC 查询封装
// ============================================================
// tRPC 使用 superjson 序列化，但小程序端我们直接用 JSON
// 查询参数通过 URL 的 input 参数传递

/** tRPC 查询 (GET) */
export async function trpcQuery<T>(
  path: string,
  input?: any
): Promise<T> {
  let url = `/api/trpc/${path}`
  if (input !== undefined) {
    const encoded = encodeURIComponent(JSON.stringify({ json: input }))
    url += `?input=${encoded}`
  }
  const res = await request<any>(url, { method: 'GET' } as any)
  // tRPC 返回格式: { result: { data: { json: ... } } }
  if (res?.result?.data?.json !== undefined) {
    return res.result.data.json
  }
  if (res?.result?.data !== undefined) {
    return res.result.data
  }
  return res
}

/** tRPC 批量查询 (GET) */
export async function trpcBatchQuery<T extends any[]>(
  queries: { path: string; input?: any }[]
): Promise<T> {
  const paths = queries.map((q) => q.path).join(',')
  const inputObj: Record<string, any> = {}
  queries.forEach((q, i) => {
    inputObj[String(i)] = q.input !== undefined ? { json: q.input } : { json: null, meta: { values: ['undefined'] } }
  })
  const encoded = encodeURIComponent(JSON.stringify(inputObj))
  const url = `/api/trpc/${paths}?batch=1&input=${encoded}`
  const res = await request<any[]>(url, { method: 'GET' } as any)
  return res.map((r: any) => r?.result?.data?.json ?? r?.result?.data ?? null) as T
}

/** tRPC 变更 (POST) */
export async function trpcMutate<T>(
  path: string,
  input?: any
): Promise<T> {
  const url = `/api/trpc/${path}`
  const res = await request<any>(url, {
    method: 'POST',
    data: input !== undefined ? { json: input } : { json: null },
  } as any)
  if (res?.result?.data?.json !== undefined) {
    return res.result.data.json
  }
  if (res?.result?.data !== undefined) {
    return res.result.data
  }
  return res
}

export { BASE_URL, request }
