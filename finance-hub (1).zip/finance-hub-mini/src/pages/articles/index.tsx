import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow, useReachBottom } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatDate, truncate } from '../../utils'
import './index.scss'

const CATEGORIES = ['全部', '宏观', '股票', '基金', '债券', '期货', '外汇', '加密货币']

export default function ArticlesPage() {
  const [articles, setArticles] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [category, setCategory] = useState('全部')

  useDidShow(() => {
    loadData(1, true)
  })

  async function loadData(p: number, reset = false) {
    if (!reset && !hasMore) return
    setLoading(true)
    try {
      const input: any = { page: p, limit: 20, status: 'published' }
      if (category !== '全部') input.category = category
      const res = await trpcQuery<any>('article.list', input)
      const data = res?.data || res || []
      if (reset) {
        setArticles(data)
      } else {
        setArticles((prev) => [...prev, ...data])
      }
      setHasMore(data.length >= 20)
      setPage(p)
    } catch (e) {
      console.error('加载资讯失败', e)
    }
    setLoading(false)
  }

  useReachBottom(() => {
    if (hasMore && !loading) {
      loadData(page + 1)
    }
  })

  function switchCategory(cat: string) {
    setCategory(cat)
    setPage(1)
    setHasMore(true)
    loadData(1, true)
  }

  return (
    <View className='articles-page'>
      {/* 分类标签 */}
      <ScrollView scrollX className='cat-scroll'>
        <View className='cat-list'>
          {CATEGORIES.map((cat) => (
            <View
              key={cat}
              className={`cat-item ${category === cat ? 'cat-active' : ''}`}
              onClick={() => switchCategory(cat)}
            >
              <Text>{cat}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <ScrollView scrollY className='list-content'>
        {articles.map((item) => (
          <View
            key={item.id}
            className='article-card'
            onClick={() => Taro.navigateTo({ url: `/pages/articleDetail/index?id=${item.id}` })}
          >
            <View className='article-body'>
              <Text className='article-title'>{item.title}</Text>
              <Text className='article-summary'>{truncate(item.summary || item.content || '', 60)}</Text>
              <View className='article-footer'>
                <Text className='article-tag'>{item.category || '资讯'}</Text>
                <Text className='article-author'>{item.author || '编辑部'}</Text>
                <Text className='article-time'>{formatDate(item.createdAt)}</Text>
              </View>
            </View>
          </View>
        ))}
        {loading && <View className='loading-center'><Text>加载中...</Text></View>}
        {!loading && !hasMore && articles.length > 0 && (
          <View className='loading-center'><Text>已加载全部</Text></View>
        )}
        {!loading && articles.length === 0 && (
          <View className='empty-state'><Text>暂无资讯</Text></View>
        )}
      </ScrollView>
    </View>
  )
}
