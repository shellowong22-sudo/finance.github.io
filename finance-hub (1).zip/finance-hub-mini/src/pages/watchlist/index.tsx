import { View, Text, ScrollView, Input } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState, useCallback } from 'react'
import { trpcQuery, trpcMutate } from '../../utils/request'
import { formatPrice, formatChange, changeColor, formatLargeNumber } from '../../utils'
import './index.scss'

interface WatchItem {
  id: number
  symbol: string
  name: string
  market: string
  price: number | null
  changePercent: number | null
  volume: number | null
}

interface PortfolioStats {
  avgChange: number
  upCount: number
  downCount: number
  flatCount: number
  total: number
  trend30d: number[]
}

interface PriceAlert {
  id: number
  symbol: string
  name: string
  alertType: string
  threshold: number
  triggered: boolean
}

export default function WatchlistPage() {
  const [watchlist, setWatchlist] = useState<WatchItem[]>([])
  const [stats, setStats] = useState<PortfolioStats | null>(null)
  const [alerts, setAlerts] = useState<PriceAlert[]>([])
  const [loading, setLoading] = useState(true)
  const [showSearch, setShowSearch] = useState(false)
  const [searchKey, setSearchKey] = useState('')
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [showAlertForm, setShowAlertForm] = useState(false)
  const [alertSymbol, setAlertSymbol] = useState('')
  const [alertType, setAlertType] = useState('price_upper')
  const [alertThreshold, setAlertThreshold] = useState('')
  const [tab, setTab] = useState<'list' | 'alerts'>('list')

  useDidShow(() => {
    loadData()
  })

  async function loadData() {
    setLoading(true)
    try {
      const [wl, st, al] = await Promise.all([
        trpcQuery<any>('quant.watchlist.list'),
        trpcQuery<any>('quant.watchlist.portfolioStats'),
        trpcQuery<any>('quant.alerts.list'),
      ])
      setWatchlist(wl || [])
      setStats(st || null)
      setAlerts(al || [])
    } catch (e) {
      console.error('加载自选股失败', e)
    }
    setLoading(false)
  }

  async function searchAssets() {
    if (!searchKey.trim()) return
    try {
      const res = await trpcQuery<any>('quant.market.search', { keyword: searchKey })
      setSearchResults(res || [])
    } catch (e) {
      Taro.showToast({ title: '搜索失败', icon: 'none' })
    }
  }

  async function addToWatchlist(symbol: string) {
    try {
      await trpcMutate('quant.watchlist.add', { symbol })
      Taro.showToast({ title: '已添加', icon: 'success' })
      setShowSearch(false)
      setSearchKey('')
      setSearchResults([])
      loadData()
    } catch (e) {
      Taro.showToast({ title: '添加失败', icon: 'none' })
    }
  }

  async function removeFromWatchlist(id: number) {
    try {
      await trpcMutate('quant.watchlist.remove', { id })
      Taro.showToast({ title: '已删除', icon: 'success' })
      loadData()
    } catch (e) {
      Taro.showToast({ title: '删除失败', icon: 'none' })
    }
  }

  async function createAlert() {
    if (!alertSymbol || !alertThreshold) {
      Taro.showToast({ title: '请填写完整', icon: 'none' })
      return
    }
    try {
      await trpcMutate('quant.alerts.create', {
        symbol: alertSymbol,
        alertType: alertType,
        threshold: parseFloat(alertThreshold),
      })
      Taro.showToast({ title: '预警已创建', icon: 'success' })
      setShowAlertForm(false)
      setAlertSymbol('')
      setAlertThreshold('')
      loadData()
    } catch (e) {
      Taro.showToast({ title: '创建失败', icon: 'none' })
    }
  }

  async function deleteAlert(id: number) {
    try {
      await trpcMutate('quant.alerts.delete', { id })
      Taro.showToast({ title: '已删除', icon: 'success' })
      loadData()
    } catch (e) {
      Taro.showToast({ title: '删除失败', icon: 'none' })
    }
  }

  const alertTypeLabels: Record<string, string> = {
    price_upper: '价格上限',
    price_lower: '价格下限',
    rise_percent: '涨幅超过',
    fall_percent: '跌幅超过',
  }

  return (
    <View className='watchlist-page'>
      {/* 顶部标签 */}
      <View className='page-tabs'>
        <View className={`ptab ${tab === 'list' ? 'ptab-active' : ''}`} onClick={() => setTab('list')}>
          <Text>自选股</Text>
        </View>
        <View className={`ptab ${tab === 'alerts' ? 'ptab-active' : ''}`} onClick={() => setTab('alerts')}>
          <Text>价格预警</Text>
        </View>
        <View className='ptab-actions'>
          {tab === 'list' ? (
            <View className='add-btn' onClick={() => setShowSearch(true)}>
              <Text className='add-btn-text'>+ 添加</Text>
            </View>
          ) : (
            <View className='add-btn' onClick={() => setShowAlertForm(true)}>
              <Text className='add-btn-text'>+ 预警</Text>
            </View>
          )}
        </View>
      </View>

      <ScrollView scrollY className='content'>
        {tab === 'list' ? (
          <>
            {/* 组合统计卡片 */}
            {stats && (
              <View className='stats-card'>
                <View className='stats-header'>
                  <Text className='stats-title'>组合概览</Text>
                  <Text className='stats-count'>{stats.total}只</Text>
                </View>
                <View className='stats-row'>
                  <View className='stat-item'>
                    <Text className='stat-value' style={{ color: changeColor(stats.avgChange) }}>
                      {formatChange(stats.avgChange)}
                    </Text>
                    <Text className='stat-label'>平均涨跌</Text>
                  </View>
                  <View className='stat-item'>
                    <Text className='stat-value text-up'>{stats.upCount}</Text>
                    <Text className='stat-label'>上涨</Text>
                  </View>
                  <View className='stat-item'>
                    <Text className='stat-value text-down'>{stats.downCount}</Text>
                    <Text className='stat-label'>下跌</Text>
                  </View>
                  <View className='stat-item'>
                    <Text className='stat-value text-flat'>{stats.flatCount}</Text>
                    <Text className='stat-label'>持平</Text>
                  </View>
                </View>
                {/* 涨跌分布进度条 */}
                <View className='dist-bar'>
                  <View className='dist-up' style={{ width: `${(stats.upCount / Math.max(stats.total, 1)) * 100}%` }} />
                  <View className='dist-flat' style={{ width: `${(stats.flatCount / Math.max(stats.total, 1)) * 100}%` }} />
                  <View className='dist-down' style={{ width: `${(stats.downCount / Math.max(stats.total, 1)) * 100}%` }} />
                </View>
              </View>
            )}

            {/* 自选股列表 */}
            {loading ? (
              <View className='loading-center'><Text>加载中...</Text></View>
            ) : watchlist.length === 0 ? (
              <View className='empty-state'>
                <Text style={{ fontSize: '48px', marginBottom: '16px' }}>⭐</Text>
                <Text>暂无自选股</Text>
                <Text style={{ fontSize: '24px', color: '#999', marginTop: '8px' }}>点击右上角添加</Text>
              </View>
            ) : (
              watchlist.map((item) => (
                <View key={item.id} className='stock-row'>
                  <View className='stock-info'>
                    <Text className='stock-name'>{item.name}</Text>
                    <Text className='stock-symbol'>{item.symbol}</Text>
                  </View>
                  <Text className='stock-price' style={{ color: changeColor(item.changePercent) }}>
                    {formatPrice(item.price)}
                  </Text>
                  <View
                    className='stock-change'
                    style={{ backgroundColor: (item.changePercent ?? 0) >= 0 ? '#ef4444' : '#22c55e' }}
                  >
                    <Text className='stock-change-text'>{formatChange(item.changePercent)}</Text>
                  </View>
                  <View className='stock-delete' onClick={() => removeFromWatchlist(item.id)}>
                    <Text className='delete-icon'>✕</Text>
                  </View>
                </View>
              ))
            )}
          </>
        ) : (
          <>
            {/* 价格预警列表 */}
            {alerts.length === 0 ? (
              <View className='empty-state'>
                <Text style={{ fontSize: '48px', marginBottom: '16px' }}>🔔</Text>
                <Text>暂无价格预警</Text>
              </View>
            ) : (
              alerts.map((item) => (
                <View key={item.id} className='alert-row'>
                  <View className='alert-info'>
                    <Text className='alert-name'>{item.name || item.symbol}</Text>
                    <Text className='alert-detail'>
                      {alertTypeLabels[item.alertType] || item.alertType}: {item.threshold}
                    </Text>
                  </View>
                  <View className={`alert-status ${item.triggered ? 'triggered' : ''}`}>
                    <Text>{item.triggered ? '已触发' : '监控中'}</Text>
                  </View>
                  <View className='stock-delete' onClick={() => deleteAlert(item.id)}>
                    <Text className='delete-icon'>✕</Text>
                  </View>
                </View>
              ))
            )}
          </>
        )}
      </ScrollView>

      {/* 搜索弹窗 */}
      {showSearch && (
        <View className='modal-overlay' onClick={() => setShowSearch(false)}>
          <View className='modal-content' onClick={(e) => e.stopPropagation()}>
            <Text className='modal-title'>搜索品种</Text>
            <View className='search-bar'>
              <Input
                className='search-input'
                placeholder='输入代码或名称'
                value={searchKey}
                onInput={(e) => setSearchKey(e.detail.value)}
                onConfirm={searchAssets}
              />
              <View className='search-btn' onClick={searchAssets}>
                <Text className='search-btn-text'>搜索</Text>
              </View>
            </View>
            <ScrollView scrollY style={{ maxHeight: '400px' }}>
              {searchResults.map((item) => (
                <View key={item.symbol} className='search-result-item' onClick={() => addToWatchlist(item.symbol)}>
                  <View>
                    <Text className='result-name'>{item.name}</Text>
                    <Text className='result-symbol'>{item.symbol}</Text>
                  </View>
                  <Text className='result-add'>+ 添加</Text>
                </View>
              ))}
            </ScrollView>
          </View>
        </View>
      )}

      {/* 预警创建弹窗 */}
      {showAlertForm && (
        <View className='modal-overlay' onClick={() => setShowAlertForm(false)}>
          <View className='modal-content' onClick={(e) => e.stopPropagation()}>
            <Text className='modal-title'>创建价格预警</Text>
            <View className='form-group'>
              <Text className='form-label'>品种代码</Text>
              <Input
                className='form-input'
                placeholder='如 AAPL, 600519.SS'
                value={alertSymbol}
                onInput={(e) => setAlertSymbol(e.detail.value)}
              />
            </View>
            <View className='form-group'>
              <Text className='form-label'>预警类型</Text>
              <View className='alert-types'>
                {Object.entries(alertTypeLabels).map(([key, label]) => (
                  <View
                    key={key}
                    className={`alert-type-btn ${alertType === key ? 'alert-type-active' : ''}`}
                    onClick={() => setAlertType(key)}
                  >
                    <Text>{label}</Text>
                  </View>
                ))}
              </View>
            </View>
            <View className='form-group'>
              <Text className='form-label'>阈值</Text>
              <Input
                className='form-input'
                type='digit'
                placeholder={alertType.includes('percent') ? '如 5 (表示5%)' : '如 150.00'}
                value={alertThreshold}
                onInput={(e) => setAlertThreshold(e.detail.value)}
              />
            </View>
            <View className='form-actions'>
              <View className='btn-cancel' onClick={() => setShowAlertForm(false)}>
                <Text>取消</Text>
              </View>
              <View className='btn-confirm' onClick={createAlert}>
                <Text style={{ color: '#fff' }}>创建</Text>
              </View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
