import { View, Text, ScrollView, Canvas } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState, useCallback } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatPrice, formatChange, changeColor, formatLargeNumber } from '../../utils'
import './index.scss'

interface IndexData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  volume?: number
  sparkline?: number[]
}

interface MarketAsset {
  id: number
  symbol: string
  name: string
  market: string
  price: number | null
  changePercent: number | null
  volume: number | null
  high: number | null
  low: number | null
  open: number | null
}

const MARKET_TABS = [
  { key: 'index', label: '大盘指数' },
  { key: 'stock_cn', label: 'A股' },
  { key: 'stock_us', label: '美股' },
  { key: 'stock_hk', label: '港股' },
  { key: 'crypto', label: '加密货币' },
  { key: 'forex', label: '外汇' },
  { key: 'fund', label: '基金' },
  { key: 'bond', label: '债券' },
]

export default function MarketPage() {
  const [tab, setTab] = useState('index')
  const [indices, setIndices] = useState<IndexData[]>([])
  const [assets, setAssets] = useState<MarketAsset[]>([])
  const [loading, setLoading] = useState(true)

  useDidShow(() => {
    loadData(tab)
  })

  const loadData = useCallback(async (currentTab: string) => {
    setLoading(true)
    try {
      if (currentTab === 'index') {
        const data = await trpcQuery<any>('quant.market.majorIndices')
        setIndices(data || [])
      } else {
        const data = await trpcQuery<any>('quant.market.assetList', { market: currentTab })
        setAssets(data || [])
      }
    } catch (e) {
      console.error('加载行情数据失败', e)
    }
    setLoading(false)
  }, [])

  function switchTab(key: string) {
    setTab(key)
    loadData(key)
  }

  function renderSparkline(data: number[] | undefined, change: number) {
    if (!data || data.length < 2) return null
    const min = Math.min(...data)
    const max = Math.max(...data)
    const range = max - min || 1
    const w = 120
    const h = 40
    const color = change >= 0 ? '#ef4444' : '#22c55e'

    const points = data.map((v, i) => {
      const x = (i / (data.length - 1)) * w
      const y = h - ((v - min) / range) * h
      return `${x},${y}`
    }).join(' ')

    return (
      <View className='sparkline-container'>
        <View style={{ width: `${w}px`, height: `${h}px`, position: 'relative' }}>
          {/* 使用SVG模拟 - 小程序中用View绘制 */}
          <View className='sparkline-line' style={{
            background: `linear-gradient(to right, ${color}40, ${color}10)`,
            height: `${h}px`,
            borderRadius: '4px',
          }}>
            {data.map((v, i) => {
              const x = (i / (data.length - 1)) * 100
              const y = ((v - min) / range) * 100
              return (
                <View
                  key={i}
                  className='sparkline-dot'
                  style={{
                    left: `${x}%`,
                    bottom: `${y}%`,
                    backgroundColor: color,
                  }}
                />
              )
            })}
          </View>
        </View>
      </View>
    )
  }

  return (
    <View className='market-page'>
      {/* 市场分类标签 */}
      <ScrollView scrollX className='tab-scroll'>
        <View className='tab-list'>
          {MARKET_TABS.map((t) => (
            <View
              key={t.key}
              className={`tab-item ${tab === t.key ? 'tab-active' : ''}`}
              onClick={() => switchTab(t.key)}
            >
              <Text className='tab-text'>{t.label}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <ScrollView scrollY className='content-scroll'>
        {loading ? (
          <View className='loading-center'><Text>加载中...</Text></View>
        ) : tab === 'index' ? (
          /* 大盘指数卡片 */
          <View className='index-grid'>
            {indices.map((item) => (
              <View key={item.symbol} className='index-card'>
                <Text className='index-name'>{item.name}</Text>
                <Text className='index-price' style={{ color: changeColor(item.changePercent) }}>
                  {formatPrice(item.price)}
                </Text>
                <View className='index-change-row'>
                  <Text style={{ color: changeColor(item.changePercent), fontSize: '24px' }}>
                    {formatChange(item.changePercent)}
                  </Text>
                </View>
                {renderSparkline(item.sparkline, item.changePercent)}
              </View>
            ))}
          </View>
        ) : (
          /* 品种列表 */
          <View className='asset-list'>
            <View className='list-header'>
              <Text className='col-name'>名称</Text>
              <Text className='col-price'>最新价</Text>
              <Text className='col-change'>涨跌幅</Text>
            </View>
            {assets.map((item) => (
              <View key={item.id} className='asset-row'>
                <View className='col-name'>
                  <Text className='asset-name'>{item.name}</Text>
                  <Text className='asset-symbol'>{item.symbol}</Text>
                </View>
                <Text className='col-price' style={{ color: changeColor(item.changePercent) }}>
                  {formatPrice(item.price)}
                </Text>
                <View
                  className='change-badge'
                  style={{ backgroundColor: (item.changePercent ?? 0) >= 0 ? '#ef4444' : '#22c55e' }}
                >
                  <Text className='change-text'>{formatChange(item.changePercent)}</Text>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  )
}
