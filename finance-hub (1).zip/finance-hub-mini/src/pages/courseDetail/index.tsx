import { View, Text, ScrollView, RichText } from '@tarojs/components'
import Taro, { useRouter, useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatDate } from '../../utils'
import './index.scss'

export default function CourseDetailPage() {
  const router = useRouter()
  const [course, setCourse] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useDidShow(() => {
    const id = router.params.id
    if (id) loadCourse(Number(id))
  })

  async function loadCourse(id: number) {
    setLoading(true)
    try {
      const data = await trpcQuery<any>('course.detail', { id })
      setCourse(data)
      Taro.setNavigationBarTitle({ title: data?.title || '课程详情' })
    } catch (e) {
      Taro.showToast({ title: '加载失败', icon: 'none' })
    }
    setLoading(false)
  }

  if (loading) return <View className='loading-center'><Text>加载中...</Text></View>
  if (!course) return <View className='empty-state'><Text>课程不存在</Text></View>

  const levelColors: Record<string, string> = {
    '入门': '#22c55e',
    '进阶': '#f59e0b',
    '高级': '#ef4444',
  }

  return (
    <ScrollView scrollY className='detail-page'>
      <View className='detail-header'>
        <View className='course-badges'>
          <Text
            className='level-badge'
            style={{ color: levelColors[course.level] || '#0c2340', backgroundColor: `${levelColors[course.level] || '#0c2340'}15` }}
          >
            {course.level || '入门'}
          </Text>
          {course.lessonCount && <Text className='lesson-count'>{course.lessonCount}课时</Text>}
        </View>
        <Text className='detail-title'>{course.title}</Text>
        <View className='detail-meta'>
          <Text className='meta-instructor'>{course.instructor || '讲师'}</Text>
          <Text className='meta-date'>{formatDate(course.createdAt)}</Text>
        </View>
      </View>
      {course.description && (
        <View className='desc-box'>
          <Text className='desc-label'>课程简介</Text>
          <Text className='desc-text'>{course.description}</Text>
        </View>
      )}
      <View className='detail-content'>
        <Text className='content-label'>课程内容</Text>
        <RichText nodes={course.content || ''} />
      </View>
    </ScrollView>
  )
}
