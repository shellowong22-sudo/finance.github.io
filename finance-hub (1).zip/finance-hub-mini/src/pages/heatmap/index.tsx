import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatChange, changeColor } from '../../utils'
import './index.scss'

interface SectorData {
  sector: string
  avgChange: number
  stockCount: number
  topGainers?: { name: string; changePercent: number }[]
  topLosers?: { name: string; changePercent: number }[]
}

// 颜色映射：涨跌幅 -> 背景色
function heatColor(val: number): string {
  if (val >= 5) return '#b91c1c'
  if (val >= 3) return '#dc2626'
  if (val >= 1) return '#ef4444'
  if (val > 0) return '#f87171'
  if (val === 0) return '#9ca3af'
  if (val > -1) return '#4ade80'
  if (val > -3) return '#22c55e'
  if (val > -5) return '#16a34a'
  return '#15803d'
}

function heatTextColor(val: number): string {
  if (Math.abs(val) >= 1) return '#fff'
  return '#333'
}

export default function HeatmapPage() {
  const [sectors, setSectors] = useState<SectorData[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedSector, setExpandedSector] = useState<string | null>(null)
  const [sectorStocks, setSectorStocks] = useState<any[]>([])
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  useDidShow(() => {
    loadData()
  })

  async function loadData() {
    setLoading(true)
    try {
      const data = await trpcQuery<any>('quant.market.sectorHeatmap')
      setSectors(data || [])
    } catch (e) {
      console.error('加载板块数据失败', e)
    }
    setLoading(false)
  }

  async function toggleSector(sector: string) {
    if (expandedSector === sector) {
      setExpandedSector(null)
      setSectorStocks([])
      return
    }
    setExpandedSector(sector)
    try {
      const data = await trpcQuery<any>('quant.market.sectorStocks', { sector })
      setSectorStocks(data || [])
    } catch (e) {
      setSectorStocks([])
    }
  }

  // 按涨跌幅排序
  const sorted = [...sectors].sort((a, b) => b.avgChange - a.avgChange)

  return (
    <View className='heatmap-page'>
      <View className='page-header'>
        <Text className='page-title'>板块热力图</Text>
        <View className='view-toggle'>
          <View
            className={`toggle-btn ${viewMode === 'grid' ? 'toggle-active' : ''}`}
            onClick={() => setViewMode('grid')}
          >
            <Text>网格</Text>
          </View>
          <View
            className={`toggle-btn ${viewMode === 'list' ? 'toggle-active' : ''}`}
            onClick={() => setViewMode('list')}
          >
            <Text>列表</Text>
          </View>
        </View>
      </View>

      <ScrollView scrollY className='content'>
        {loading ? (
          <View className='loading-center'><Text>加载中...</Text></View>
        ) : viewMode === 'grid' ? (
          /* 网格热力图 */
          <View className='heat-grid'>
            {sorted.map((item) => (
              <View key={item.sector}>
                <View
                  className='heat-cell'
                  style={{
                    backgroundColor: heatColor(item.avgChange),
                    color: heatTextColor(item.avgChange),
                  }}
                  onClick={() => toggleSector(item.sector)}
                >
                  <Text className='cell-name'>{item.sector}</Text>
                  <Text className='cell-change'>{formatChange(item.avgChange)}</Text>
                  <Text className='cell-count'>{item.stockCount}只</Text>
                </View>
                {/* 展开个股列表 */}
                {expandedSector === item.sector && (
                  <View className='sector-detail'>
                    {sectorStocks.length === 0 ? (
                      <Text className='detail-empty'>暂无个股数据</Text>
                    ) : (
                      sectorStocks.map((stock, i) => (
                        <View key={i} className='stock-mini-row'>
                          <Text className='mini-name'>{stock.name}</Text>
                          <Text className='mini-price' style={{ color: changeColor(stock.changePercent) }}>
                            {stock.price?.toFixed(2) || '--'}
                          </Text>
                          <Text className='mini-change' style={{ color: changeColor(stock.changePercent) }}>
                            {formatChange(stock.changePercent)}
                          </Text>
                        </View>
                      ))
                    )}
                  </View>
                )}
              </View>
            ))}
          </View>
        ) : (
          /* 列表视图 */
          <View className='sector-list'>
            {sorted.map((item, i) => (
              <View key={item.sector}>
                <View className='sector-row' onClick={() => toggleSector(item.sector)}>
                  <Text className='sector-rank'>{i + 1}</Text>
                  <Text className='sector-name'>{item.sector}</Text>
                  <Text className='sector-count'>{item.stockCount}只</Text>
                  <View
                    className='sector-badge'
                    style={{ backgroundColor: item.avgChange >= 0 ? '#ef4444' : '#22c55e' }}
                  >
                    <Text className='badge-text'>{formatChange(item.avgChange)}</Text>
                  </View>
                  <Text className='expand-arrow'>{expandedSector === item.sector ? '▲' : '▼'}</Text>
                </View>
                {expandedSector === item.sector && (
                  <View className='sector-detail-list'>
                    {sectorStocks.map((stock, j) => (
                      <View key={j} className='detail-stock-row'>
                        <Text className='detail-name'>{stock.name}</Text>
                        <Text style={{ color: changeColor(stock.changePercent), fontSize: '26px' }}>
                          {stock.price?.toFixed(2) || '--'}
                        </Text>
                        <Text style={{ color: changeColor(stock.changePercent), fontSize: '24px' }}>
                          {formatChange(stock.changePercent)}
                        </Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  )
}
