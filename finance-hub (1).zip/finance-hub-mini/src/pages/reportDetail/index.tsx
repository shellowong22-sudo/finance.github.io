import { View, Text, ScrollView, RichText } from '@tarojs/components'
import Taro, { useRouter, useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatDate } from '../../utils'
import './index.scss'

export default function ReportDetailPage() {
  const router = useRouter()
  const [report, setReport] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useDidShow(() => {
    const id = router.params.id
    if (id) loadReport(Number(id))
  })

  async function loadReport(id: number) {
    setLoading(true)
    try {
      const data = await trpcQuery<any>('report.detail', { id })
      setReport(data)
      Taro.setNavigationBarTitle({ title: data?.title || '研报详情' })
    } catch (e) {
      Taro.showToast({ title: '加载失败', icon: 'none' })
    }
    setLoading(false)
  }

  if (loading) return <View className='loading-center'><Text>加载中...</Text></View>
  if (!report) return <View className='empty-state'><Text>研报不存在</Text></View>

  return (
    <ScrollView scrollY className='detail-page'>
      <View className='detail-header'>
        <View className='report-badges'>
          <Text className='badge-inst'>{report.institution || '机构'}</Text>
          {report.rating && <Text className='badge-rating'>评级: {report.rating}</Text>}
        </View>
        <Text className='detail-title'>{report.title}</Text>
        <View className='detail-meta'>
          <Text className='meta-author'>{report.author || '分析师'}</Text>
          <Text className='meta-date'>{formatDate(report.createdAt, 'YYYY-MM-DD HH:mm')}</Text>
        </View>
      </View>
      {report.summary && (
        <View className='summary-box'>
          <Text className='summary-label'>摘要</Text>
          <Text className='summary-text'>{report.summary}</Text>
        </View>
      )}
      <View className='detail-content'>
        <RichText nodes={report.content || ''} />
      </View>
    </ScrollView>
  )
}
