import { View, Text, ScrollView, RichText } from '@tarojs/components'
import Taro, { useRouter, useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatDate } from '../../utils'
import './index.scss'

export default function ArticleDetailPage() {
  const router = useRouter()
  const [article, setArticle] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useDidShow(() => {
    const id = router.params.id
    if (id) loadArticle(Number(id))
  })

  async function loadArticle(id: number) {
    setLoading(true)
    try {
      const data = await trpcQuery<any>('article.detail', { id })
      setArticle(data)
      Taro.setNavigationBarTitle({ title: data?.title || '资讯详情' })
    } catch (e) {
      Taro.showToast({ title: '加载失败', icon: 'none' })
    }
    setLoading(false)
  }

  if (loading) {
    return <View className='loading-center'><Text>加载中...</Text></View>
  }

  if (!article) {
    return <View className='empty-state'><Text>文章不存在</Text></View>
  }

  return (
    <ScrollView scrollY className='detail-page'>
      <View className='detail-header'>
        <Text className='detail-title'>{article.title}</Text>
        <View className='detail-meta'>
          <Text className='meta-tag'>{article.category || '资讯'}</Text>
          <Text className='meta-author'>{article.author || '编辑部'}</Text>
          <Text className='meta-date'>{formatDate(article.createdAt, 'YYYY-MM-DD HH:mm')}</Text>
        </View>
      </View>
      <View className='detail-content'>
        <RichText nodes={article.content || ''} />
      </View>
    </ScrollView>
  )
}
