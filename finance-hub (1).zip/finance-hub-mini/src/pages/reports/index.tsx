import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow, useReachBottom } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatDate, truncate } from '../../utils'
import './index.scss'

export default function ReportsPage() {
  const [reports, setReports] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)

  useDidShow(() => {
    loadData(1, true)
  })

  async function loadData(p: number, reset = false) {
    if (!reset && !hasMore) return
    setLoading(true)
    try {
      const res = await trpcQuery<any>('report.list', { page: p, limit: 20 })
      const data = res?.data || res || []
      if (reset) {
        setReports(data)
      } else {
        setReports((prev) => [...prev, ...data])
      }
      setHasMore(data.length >= 20)
      setPage(p)
    } catch (e) {
      console.error('加载研报失败', e)
    }
    setLoading(false)
  }

  useReachBottom(() => {
    if (hasMore && !loading) loadData(page + 1)
  })

  return (
    <View className='reports-page'>
      <ScrollView scrollY className='list-content'>
        {reports.map((item) => (
          <View
            key={item.id}
            className='report-card'
            onClick={() => Taro.navigateTo({ url: `/pages/reportDetail/index?id=${item.id}` })}
          >
            <View className='report-badge-row'>
              <Text className='report-badge'>{item.institution || '机构研报'}</Text>
              {item.rating && <Text className='report-rating'>评级: {item.rating}</Text>}
            </View>
            <Text className='report-title'>{item.title}</Text>
            <Text className='report-summary'>{truncate(item.summary || '', 80)}</Text>
            <View className='report-footer'>
              <Text className='report-author'>{item.author || '分析师'}</Text>
              <Text className='report-date'>{formatDate(item.createdAt)}</Text>
            </View>
          </View>
        ))}
        {loading && <View className='loading-center'><Text>加载中...</Text></View>}
        {!loading && !hasMore && reports.length > 0 && (
          <View className='loading-center'><Text>已加载全部</Text></View>
        )}
        {!loading && reports.length === 0 && (
          <View className='empty-state'>
            <Text style={{ fontSize: '48px', marginBottom: '16px' }}>📊</Text>
            <Text>暂无研报</Text>
          </View>
        )}
      </ScrollView>
    </View>
  )
}
