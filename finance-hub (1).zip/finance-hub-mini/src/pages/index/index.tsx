import { View, Text, ScrollView, Image } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcBatchQuery, trpcQuery } from '../../utils/request'
import { formatDate, formatChange, changeColor, truncate } from '../../utils'
import './index.scss'

export default function Index() {
  const [articles, setArticles] = useState<any[]>([])
  const [reports, setReports] = useState<any[]>([])
  const [courses, setCourses] = useState<any[]>([])
  const [health, setHealth] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useDidShow(() => {
    loadData()
  })

  async function loadData() {
    setLoading(true)
    try {
      const [articlesRes, reportsRes, coursesRes] = await trpcBatchQuery<any[]>([
        { path: 'article.list', input: { page: 1, limit: 6, status: 'published' } },
        { path: 'report.list', input: { page: 1, limit: 4 } },
        { path: 'course.list', input: { page: 1, limit: 4 } },
      ])
      setArticles(articlesRes?.data || [])
      setReports(reportsRes?.data || [])
      setCourses(coursesRes?.data || [])
    } catch (e) {
      console.error('加载首页数据失败', e)
    }
    try {
      const h = await trpcQuery('quant.market.systemHealth')
      setHealth(h)
    } catch (e) { /* ignore */ }
    setLoading(false)
  }

  return (
    <ScrollView scrollY className='page'>
      {/* 顶部Banner */}
      <View className='banner'>
        <Text className='banner-badge'>专业 · 合规 · 智能</Text>
        <Text className='banner-title'>金融综合服务平台</Text>
        <Text className='banner-desc'>资讯 · 研报 · 课程 · AI智能分析</Text>
      </View>

      {/* 快捷入口 */}
      <View className='quick-nav'>
        <View className='nav-item' onClick={() => Taro.navigateTo({ url: '/pages/articles/index' })}>
          <View className='nav-icon nav-icon-article'>📰</View>
          <Text className='nav-label'>资讯</Text>
        </View>
        <View className='nav-item' onClick={() => Taro.navigateTo({ url: '/pages/reports/index' })}>
          <View className='nav-icon nav-icon-report'>📊</View>
          <Text className='nav-label'>研报</Text>
        </View>
        <View className='nav-item' onClick={() => Taro.navigateTo({ url: '/pages/courses/index' })}>
          <View className='nav-icon nav-icon-course'>📚</View>
          <Text className='nav-label'>课程</Text>
        </View>
        <View className='nav-item' onClick={() => Taro.navigateTo({ url: '/pages/watchlist/index' })}>
          <View className='nav-icon nav-icon-watch'>⭐</View>
          <Text className='nav-label'>自选股</Text>
        </View>
        <View className='nav-item' onClick={() => Taro.navigateTo({ url: '/pages/heatmap/index' })}>
          <View className='nav-icon nav-icon-heat'>🔥</View>
          <Text className='nav-label'>热力图</Text>
        </View>
      </View>

      {/* 系统健康状态 */}
      {health && (
        <View className='card health-card'>
          <View className='health-header'>
            <View className={`health-dot ${health.dataFreshness === '实时' ? 'dot-green' : health.dataFreshness === '较新' ? 'dot-orange' : 'dot-red'}`} />
            <Text className='health-title'>行情数据状态</Text>
            <Text className='health-status'>{health.dataFreshness}</Text>
          </View>
          <View className='health-info'>
            <Text className='health-label'>监控品种: {health.totalSymbols}个</Text>
            <Text className='health-label'>退避级别: {health.backoffLevel}</Text>
          </View>
        </View>
      )}

      {/* 最新资讯 */}
      <View className='section'>
        <View className='section-header'>
          <Text className='section-title'>最新资讯</Text>
          <Text className='section-more' onClick={() => Taro.navigateTo({ url: '/pages/articles/index' })}>查看更多 ›</Text>
        </View>
        {loading ? (
          <View className='loading-center'><Text>加载中...</Text></View>
        ) : articles.length === 0 ? (
          <View className='empty-state'><Text>暂无资讯</Text></View>
        ) : (
          articles.slice(0, 4).map((item) => (
            <View
              key={item.id}
              className='article-item'
              onClick={() => Taro.navigateTo({ url: `/pages/articleDetail/index?id=${item.id}` })}
            >
              <View className='article-content'>
                <Text className='article-title'>{truncate(item.title, 30)}</Text>
                <View className='article-meta'>
                  <Text className='tag'>{item.category || '资讯'}</Text>
                  <Text className='article-date'>{formatDate(item.createdAt)}</Text>
                </View>
              </View>
            </View>
          ))
        )}
      </View>

      {/* 热门研报 */}
      <View className='section'>
        <View className='section-header'>
          <Text className='section-title'>热门研报</Text>
          <Text className='section-more' onClick={() => Taro.navigateTo({ url: '/pages/reports/index' })}>查看更多 ›</Text>
        </View>
        {reports.slice(0, 3).map((item) => (
          <View
            key={item.id}
            className='report-item'
            onClick={() => Taro.navigateTo({ url: `/pages/reportDetail/index?id=${item.id}` })}
          >
            <Text className='report-title'>{truncate(item.title, 28)}</Text>
            <View className='report-meta'>
              <Text className='tag'>{item.institution || '机构'}</Text>
              <Text className='report-date'>{formatDate(item.createdAt)}</Text>
            </View>
          </View>
        ))}
      </View>

      {/* 精品课程 */}
      <View className='section'>
        <View className='section-header'>
          <Text className='section-title'>精品课程</Text>
          <Text className='section-more' onClick={() => Taro.navigateTo({ url: '/pages/courses/index' })}>查看更多 ›</Text>
        </View>
        <ScrollView scrollX className='course-scroll'>
          {courses.map((item) => (
            <View
              key={item.id}
              className='course-card'
              onClick={() => Taro.navigateTo({ url: `/pages/courseDetail/index?id=${item.id}` })}
            >
              <View className='course-level'>{item.level || '入门'}</View>
              <Text className='course-title'>{truncate(item.title, 16)}</Text>
              <Text className='course-desc'>{truncate(item.description || '', 24)}</Text>
            </View>
          ))}
        </ScrollView>
      </View>
    </ScrollView>
  )
}
