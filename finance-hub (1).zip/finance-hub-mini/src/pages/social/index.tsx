import { View, Text, ScrollView, Textarea, Input } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery, trpcMutate } from '../../utils/request'
import { formatDate, truncate } from '../../utils'
import './index.scss'

interface Post {
  id: number
  content: string
  author: string
  authorAvatar?: string
  likeCount: number
  commentCount: number
  createdAt: string
  liked?: boolean
}

export default function SocialPage() {
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [showCompose, setShowCompose] = useState(false)
  const [newContent, setNewContent] = useState('')

  useDidShow(() => {
    loadPosts()
  })

  async function loadPosts() {
    setLoading(true)
    try {
      const res = await trpcQuery<any>('social.posts.list', { page: 1, limit: 30 })
      setPosts(res?.data || res || [])
    } catch (e) {
      // 社区功能可能未实现，显示占位内容
      setPosts([
        {
          id: 1,
          content: '今天A股表现不错，上证指数突破3200点，大家怎么看后市？',
          author: '投资达人',
          likeCount: 42,
          commentCount: 15,
          createdAt: new Date().toISOString(),
        },
        {
          id: 2,
          content: '新能源板块持续走强，宁德时代、比亚迪领涨。看好新能源长期趋势。',
          author: '价值投资者',
          likeCount: 28,
          commentCount: 8,
          createdAt: new Date().toISOString(),
        },
        {
          id: 3,
          content: '美联储加息预期降温，黄金价格创新高。建议适当配置黄金ETF。',
          author: '宏观分析师',
          likeCount: 35,
          commentCount: 12,
          createdAt: new Date().toISOString(),
        },
        {
          id: 4,
          content: 'AI概念股今天集体回调，但长期看好人工智能赛道。逢低布局是好策略。',
          author: '科技猎手',
          likeCount: 19,
          commentCount: 6,
          createdAt: new Date().toISOString(),
        },
      ])
    }
    setLoading(false)
  }

  async function publishPost() {
    if (!newContent.trim()) {
      Taro.showToast({ title: '请输入内容', icon: 'none' })
      return
    }
    try {
      await trpcMutate('social.posts.create', { content: newContent })
      Taro.showToast({ title: '发布成功', icon: 'success' })
      setShowCompose(false)
      setNewContent('')
      loadPosts()
    } catch (e) {
      Taro.showToast({ title: '功能开发中', icon: 'none' })
      setShowCompose(false)
    }
  }

  async function likePost(id: number) {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === id
          ? { ...p, liked: !p.liked, likeCount: p.liked ? p.likeCount - 1 : p.likeCount + 1 }
          : p
      )
    )
  }

  return (
    <View className='social-page'>
      <ScrollView scrollY className='feed'>
        {/* 发帖入口 */}
        <View className='compose-entry' onClick={() => setShowCompose(true)}>
          <Text className='compose-placeholder'>分享你的投资观点...</Text>
          <Text className='compose-btn'>发布</Text>
        </View>

        {loading ? (
          <View className='loading-center'><Text>加载中...</Text></View>
        ) : (
          posts.map((post) => (
            <View key={post.id} className='post-card'>
              <View className='post-header'>
                <View className='post-avatar'>
                  <Text>{post.author?.[0] || '用'}</Text>
                </View>
                <View className='post-author-info'>
                  <Text className='post-author'>{post.author}</Text>
                  <Text className='post-time'>{formatDate(post.createdAt, 'MM-DD HH:mm')}</Text>
                </View>
              </View>
              <Text className='post-content'>{post.content}</Text>
              <View className='post-actions'>
                <View
                  className={`action-btn ${post.liked ? 'action-liked' : ''}`}
                  onClick={() => likePost(post.id)}
                >
                  <Text>{post.liked ? '❤️' : '🤍'} {post.likeCount}</Text>
                </View>
                <View className='action-btn'>
                  <Text>💬 {post.commentCount}</Text>
                </View>
                <View className='action-btn'>
                  <Text>🔗 分享</Text>
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      {/* 发帖弹窗 */}
      {showCompose && (
        <View className='modal-overlay' onClick={() => setShowCompose(false)}>
          <View className='modal-content' onClick={(e) => e.stopPropagation()}>
            <View className='compose-header'>
              <Text className='compose-cancel' onClick={() => setShowCompose(false)}>取消</Text>
              <Text className='compose-title'>发布观点</Text>
              <Text className='compose-submit' onClick={publishPost}>发布</Text>
            </View>
            <Textarea
              className='compose-textarea'
              placeholder='分享你的投资观点、市场分析...'
              value={newContent}
              onInput={(e) => setNewContent(e.detail.value)}
              maxlength={500}
              autoFocus
            />
            <Text className='compose-count'>{newContent.length}/500</Text>
          </View>
        </View>
      )}
    </View>
  )
}
