import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery, trpcMutate } from '../../utils/request'
import './index.scss'

interface UserInfo {
  name: string
  avatar?: string
  openId?: string
}

interface MemoryItem {
  id: number
  memoryType: string
  content: string
}

const MENU_ITEMS = [
  { icon: '⭐', label: '我的自选', page: '/pages/watchlist/index' },
  { icon: '🔔', label: '价格预警', page: '/pages/watchlist/index' },
  { icon: '📊', label: '板块热力图', page: '/pages/heatmap/index' },
  { icon: '📰', label: '我的收藏', page: '' },
  { icon: '🧠', label: 'AI记忆管理', page: '' },
  { icon: '⚙️', label: '设置', page: '' },
]

const MEMORY_LABELS: Record<string, string> = {
  risk_tolerance: '风险偏好',
  investment_style: '投资风格',
  interested_sectors: '关注板块',
  holding_period: '持仓周期',
  focus_assets: '关注资产',
}

export default function ProfilePage() {
  const [user, setUser] = useState<UserInfo | null>(null)
  const [memories, setMemories] = useState<MemoryItem[]>([])
  const [showMemory, setShowMemory] = useState(false)
  const [watchCount, setWatchCount] = useState(0)
  const [alertCount, setAlertCount] = useState(0)

  useDidShow(() => {
    loadProfile()
  })

  async function loadProfile() {
    try {
      const me = await trpcQuery<any>('auth.me')
      setUser(me)
    } catch (e) {
      setUser({ name: '未登录' })
    }
    try {
      const wl = await trpcQuery<any>('quant.watchlist.list')
      setWatchCount(wl?.length || 0)
    } catch (e) { /* ignore */ }
    try {
      const al = await trpcQuery<any>('quant.alerts.list')
      setAlertCount(al?.length || 0)
    } catch (e) { /* ignore */ }
  }

  async function loadMemories() {
    try {
      const res = await trpcQuery<any>('ai.memory.list')
      setMemories(res || [])
    } catch (e) {
      setMemories([])
    }
    setShowMemory(true)
  }

  async function deleteMemory(id: number) {
    try {
      await trpcMutate('ai.memory.delete', { id })
      setMemories((prev) => prev.filter((m) => m.id !== id))
      Taro.showToast({ title: '已删除', icon: 'success' })
    } catch (e) {
      Taro.showToast({ title: '删除失败', icon: 'none' })
    }
  }

  function handleMenuClick(item: typeof MENU_ITEMS[0]) {
    if (item.label === 'AI记忆管理') {
      loadMemories()
      return
    }
    if (item.page) {
      Taro.navigateTo({ url: item.page })
    } else {
      Taro.showToast({ title: '功能开发中', icon: 'none' })
    }
  }

  return (
    <ScrollView scrollY className='profile-page'>
      {/* 用户信息卡片 */}
      <View className='user-card'>
        <View className='user-avatar'>
          <Text className='avatar-text'>{user?.name?.[0] || '用'}</Text>
        </View>
        <Text className='user-name'>{user?.name || '未登录'}</Text>
        <View className='user-stats'>
          <View className='stat-box'>
            <Text className='stat-num'>{watchCount}</Text>
            <Text className='stat-desc'>自选股</Text>
          </View>
          <View className='stat-divider' />
          <View className='stat-box'>
            <Text className='stat-num'>{alertCount}</Text>
            <Text className='stat-desc'>预警</Text>
          </View>
          <View className='stat-divider' />
          <View className='stat-box'>
            <Text className='stat-num'>{memories.length || 0}</Text>
            <Text className='stat-desc'>AI记忆</Text>
          </View>
        </View>
      </View>

      {/* 功能菜单 */}
      <View className='menu-card'>
        {MENU_ITEMS.map((item) => (
          <View key={item.label} className='menu-item' onClick={() => handleMenuClick(item)}>
            <Text className='menu-icon'>{item.icon}</Text>
            <Text className='menu-label'>{item.label}</Text>
            <Text className='menu-arrow'>›</Text>
          </View>
        ))}
      </View>

      {/* 关于 */}
      <View className='about-card'>
        <Text className='about-title'>金融综合服务平台</Text>
        <Text className='about-desc'>版本 1.0.0 · Powered by Taro</Text>
        <Text className='about-desc'>专业 · 合规 · 智能</Text>
      </View>

      {/* AI记忆管理弹窗 */}
      {showMemory && (
        <View className='modal-overlay' onClick={() => setShowMemory(false)}>
          <View className='modal-content' onClick={(e) => e.stopPropagation()}>
            <Text className='modal-title'>AI记忆管理</Text>
            <Text className='modal-desc'>小融会记住你的偏好，提供更个性化的服务</Text>
            <ScrollView scrollY style={{ maxHeight: '60vh' }}>
              {memories.length === 0 ? (
                <View className='empty-state'>
                  <Text>暂无记忆</Text>
                  <Text style={{ fontSize: '24px', color: '#999', marginTop: '8px' }}>
                    与AI助手对话后会自动记录偏好
                  </Text>
                </View>
              ) : (
                memories.map((item) => (
                  <View key={item.id} className='memory-item'>
                    <View className='memory-info'>
                      <Text className='memory-type'>{MEMORY_LABELS[item.memoryType] || item.memoryType}</Text>
                      <Text className='memory-content'>{item.content}</Text>
                    </View>
                    <View className='memory-delete' onClick={() => deleteMemory(item.id)}>
                      <Text className='delete-text'>删除</Text>
                    </View>
                  </View>
                ))
              )}
            </ScrollView>
          </View>
        </View>
      )}
    </ScrollView>
  )
}
