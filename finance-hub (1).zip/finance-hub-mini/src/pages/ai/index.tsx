import { View, Text, ScrollView, Input, Textarea } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState, useRef, useCallback } from 'react'
import { trpcMutate, trpcQuery, BASE_URL } from '../../utils/request'
import { formatDate } from '../../utils'
import './index.scss'

interface Message {
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp?: number
  toolCalls?: string[]
}

interface Conversation {
  id: number
  title: string
  createdAt: string
}

const QUICK_COMMANDS = [
  { icon: '📊', label: '市场日报', prompt: '请给我今日市场日报' },
  { icon: '⭐', label: '自选分析', prompt: '请分析我的自选股组合' },
  { icon: '🔥', label: '板块热点', prompt: '今天哪些板块表现最好？' },
  { icon: '📈', label: '技术分析', prompt: '请对上证指数做技术分析' },
  { icon: '💡', label: '投资建议', prompt: '根据当前市场给出投资建议' },
  { icon: '🔔', label: '预警查询', prompt: '查看我的价格预警情况' },
]

export default function AIPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [loading, setLoading] = useState(false)
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConvId, setCurrentConvId] = useState<number | null>(null)
  const [showHistory, setShowHistory] = useState(false)
  const [showCommands, setShowCommands] = useState(true)

  useDidShow(() => {
    loadConversations()
  })

  async function loadConversations() {
    try {
      const res = await trpcQuery<any>('ai.conversations.list')
      setConversations(res || [])
    } catch (e) { /* ignore */ }
  }

  async function loadConversation(convId: number) {
    try {
      const res = await trpcQuery<any>('ai.conversations.messages', { conversationId: convId })
      setMessages(res || [])
      setCurrentConvId(convId)
      setShowHistory(false)
      setShowCommands(false)
    } catch (e) {
      Taro.showToast({ title: '加载失败', icon: 'none' })
    }
  }

  async function sendMessage(text?: string) {
    const msg = text || inputText.trim()
    if (!msg || loading) return

    setShowCommands(false)
    const userMsg: Message = { role: 'user', content: msg, timestamp: Date.now() }
    setMessages((prev) => [...prev, userMsg])
    setInputText('')
    setLoading(true)

    try {
      // 使用非流式API（小程序不支持SSE）
      const res = await trpcMutate<any>('ai.chat', {
        message: msg,
        conversationId: currentConvId,
      })

      const assistantMsg: Message = {
        role: 'assistant',
        content: res.content || res.message || '抱歉，我暂时无法回答这个问题。',
        timestamp: Date.now(),
        toolCalls: res.toolCalls,
      }
      setMessages((prev) => [...prev, assistantMsg])

      if (res.conversationId && !currentConvId) {
        setCurrentConvId(res.conversationId)
      }
    } catch (e) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: '网络异常，请稍后重试。', timestamp: Date.now() },
      ])
    }
    setLoading(false)
  }

  function newConversation() {
    setMessages([])
    setCurrentConvId(null)
    setShowHistory(false)
    setShowCommands(true)
  }

  return (
    <View className='ai-page'>
      {/* 顶部栏 */}
      <View className='ai-header'>
        <View className='header-left' onClick={() => setShowHistory(!showHistory)}>
          <Text className='header-icon'>💬</Text>
          <Text className='header-text'>历史</Text>
        </View>
        <Text className='header-title'>小融 · AI助手</Text>
        <View className='header-right' onClick={newConversation}>
          <Text className='header-text'>新对话</Text>
        </View>
      </View>

      {/* 历史会话列表 */}
      {showHistory && (
        <View className='history-panel'>
          <ScrollView scrollY style={{ maxHeight: '60vh' }}>
            {conversations.length === 0 ? (
              <View className='empty-state'><Text>暂无历史会话</Text></View>
            ) : (
              conversations.map((conv) => (
                <View
                  key={conv.id}
                  className={`history-item ${conv.id === currentConvId ? 'history-active' : ''}`}
                  onClick={() => loadConversation(conv.id)}
                >
                  <Text className='history-title'>{conv.title || '未命名会话'}</Text>
                  <Text className='history-date'>{formatDate(conv.createdAt)}</Text>
                </View>
              ))
            )}
          </ScrollView>
        </View>
      )}

      {/* 消息区域 */}
      <ScrollView
        scrollY
        className='message-area'
        scrollIntoView={messages.length > 0 ? `msg-${messages.length - 1}` : ''}
      >
        {/* 欢迎信息 */}
        {messages.length === 0 && (
          <View className='welcome'>
            <Text className='welcome-emoji'>🤖</Text>
            <Text className='welcome-title'>你好，我是小融</Text>
            <Text className='welcome-desc'>你的AI金融助手，可以帮你分析行情、诊断组合、查询预警</Text>
          </View>
        )}

        {/* 快捷指令 */}
        {showCommands && messages.length === 0 && (
          <View className='commands-grid'>
            {QUICK_COMMANDS.map((cmd) => (
              <View
                key={cmd.label}
                className='command-card'
                onClick={() => sendMessage(cmd.prompt)}
              >
                <Text className='command-icon'>{cmd.icon}</Text>
                <Text className='command-label'>{cmd.label}</Text>
              </View>
            ))}
          </View>
        )}

        {/* 消息列表 */}
        {messages.map((msg, i) => (
          <View
            key={i}
            id={`msg-${i}`}
            className={`message ${msg.role === 'user' ? 'message-user' : 'message-assistant'}`}
          >
            {msg.role === 'assistant' && (
              <View className='avatar avatar-ai'>
                <Text>🤖</Text>
              </View>
            )}
            <View className={`bubble ${msg.role === 'user' ? 'bubble-user' : 'bubble-assistant'}`}>
              {msg.toolCalls && msg.toolCalls.length > 0 && (
                <View className='tool-calls'>
                  {msg.toolCalls.map((tool, j) => (
                    <Text key={j} className='tool-tag'>🔧 {tool}</Text>
                  ))}
                </View>
              )}
              <Text className='bubble-text'>{msg.content}</Text>
            </View>
            {msg.role === 'user' && (
              <View className='avatar avatar-user'>
                <Text>👤</Text>
              </View>
            )}
          </View>
        ))}

        {/* 加载指示器 */}
        {loading && (
          <View className='message message-assistant'>
            <View className='avatar avatar-ai'><Text>🤖</Text></View>
            <View className='bubble bubble-assistant'>
              <Text className='typing-indicator'>小融正在思考...</Text>
            </View>
          </View>
        )}
      </ScrollView>

      {/* 输入区域 */}
      <View className='input-area'>
        <View className='input-bar'>
          <Textarea
            className='msg-input'
            placeholder='输入你的问题...'
            value={inputText}
            onInput={(e) => setInputText(e.detail.value)}
            onConfirm={() => sendMessage()}
            maxlength={500}
            autoHeight
            style={{ maxHeight: '120px' }}
          />
          <View
            className={`send-btn ${inputText.trim() ? 'send-active' : ''}`}
            onClick={() => sendMessage()}
          >
            <Text className='send-text'>发送</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
