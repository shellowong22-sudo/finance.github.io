import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow, useReachBottom } from '@tarojs/taro'
import { useState } from 'react'
import { trpcQuery } from '../../utils/request'
import { formatDate, truncate } from '../../utils'
import './index.scss'

const LEVELS = ['全部', '入门', '进阶', '高级']

export default function CoursesPage() {
  const [courses, setCourses] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [level, setLevel] = useState('全部')

  useDidShow(() => {
    loadData(1, true)
  })

  async function loadData(p: number, reset = false) {
    if (!reset && !hasMore) return
    setLoading(true)
    try {
      const input: any = { page: p, limit: 20 }
      if (level !== '全部') input.level = level
      const res = await trpcQuery<any>('course.list', input)
      const data = res?.data || res || []
      if (reset) {
        setCourses(data)
      } else {
        setCourses((prev) => [...prev, ...data])
      }
      setHasMore(data.length >= 20)
      setPage(p)
    } catch (e) {
      console.error('加载课程失败', e)
    }
    setLoading(false)
  }

  useReachBottom(() => {
    if (hasMore && !loading) loadData(page + 1)
  })

  function switchLevel(l: string) {
    setLevel(l)
    loadData(1, true)
  }

  const levelColors: Record<string, string> = {
    '入门': '#22c55e',
    '进阶': '#f59e0b',
    '高级': '#ef4444',
  }

  return (
    <View className='courses-page'>
      {/* 级别筛选 */}
      <View className='level-bar'>
        {LEVELS.map((l) => (
          <View
            key={l}
            className={`level-btn ${level === l ? 'level-active' : ''}`}
            onClick={() => switchLevel(l)}
          >
            <Text>{l}</Text>
          </View>
        ))}
      </View>

      <ScrollView scrollY className='list-content'>
        {courses.map((item) => (
          <View
            key={item.id}
            className='course-card'
            onClick={() => Taro.navigateTo({ url: `/pages/courseDetail/index?id=${item.id}` })}
          >
            <View className='course-header'>
              <Text
                className='course-level-badge'
                style={{ color: levelColors[item.level] || '#0c2340', backgroundColor: `${levelColors[item.level] || '#0c2340'}15` }}
              >
                {item.level || '入门'}
              </Text>
              {item.lessonCount && (
                <Text className='course-lessons'>{item.lessonCount}课时</Text>
              )}
            </View>
            <Text className='course-title'>{item.title}</Text>
            <Text className='course-desc'>{truncate(item.description || '', 60)}</Text>
            <View className='course-footer'>
              <Text className='course-instructor'>{item.instructor || '讲师'}</Text>
              <Text className='course-date'>{formatDate(item.createdAt)}</Text>
            </View>
          </View>
        ))}
        {loading && <View className='loading-center'><Text>加载中...</Text></View>}
        {!loading && !hasMore && courses.length > 0 && (
          <View className='loading-center'><Text>已加载全部</Text></View>
        )}
        {!loading && courses.length === 0 && (
          <View className='empty-state'>
            <Text style={{ fontSize: '48px', marginBottom: '16px' }}>📚</Text>
            <Text>暂无课程</Text>
          </View>
        )}
      </ScrollView>
    </View>
  )
}
