import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Eye, Clock, ThumbsUp, MessageSquare, Share2, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ArticleDetail() {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated } = useAuth();
  const [comment, setComment] = useState("");
  const utils = trpc.useUtils();

  const { data: article, isLoading } = trpc.article.detail.useQuery({ id: Number(id) });
  const { data: commentsData } = trpc.social.comments.useQuery({ articleId: Number(id) });
  const { data: liked } = trpc.social.checkLiked.useQuery(
    { targetType: "article", targetId: Number(id) },
    { enabled: isAuthenticated }
  );

  const likeMutation = trpc.social.like.useMutation({
    onSuccess: () => utils.social.checkLiked.invalidate(),
  });
  const commentMutation = trpc.social.addComment.useMutation({
    onSuccess: () => { setComment(""); utils.social.comments.invalidate(); toast.success("评论发布成功"); },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-8"><div className="h-96 bg-muted animate-pulse rounded-lg" /></div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-16 text-center text-muted-foreground">文章不存在或已下架</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 max-w-4xl">
        <Button variant="ghost" size="sm" className="mb-6" asChild>
          <Link href="/articles"><ArrowLeft className="w-4 h-4 mr-1" />返回列表</Link>
        </Button>

        <article className="bg-card rounded-xl border border-border p-6 md:p-8 mb-6">
          <div className="flex items-center gap-2 mb-4">
            {article.isPinned && <Badge className="bg-amber-100 text-amber-700 border-amber-200">置顶</Badge>}
            {article.isTop && <Badge variant="secondary">推荐</Badge>}
          </div>
          <h1 className="text-2xl md:text-3xl font-bold mb-4 leading-tight">{article.title}</h1>
          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6 pb-6 border-b border-border">
            <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{article.viewCount} 次阅读</span>
            <span className="flex items-center gap-1"><MessageSquare className="w-4 h-4" />{article.commentCount} 评论</span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {article.publishedAt ? new Date(article.publishedAt).toLocaleString("zh-CN") : ""}
            </span>
          </div>
          <div className="prose prose-sm max-w-none text-foreground leading-relaxed whitespace-pre-wrap">
            {article.content}
          </div>
          <div className="flex items-center gap-3 mt-8 pt-6 border-t border-border">
            <Button
              variant={liked ? "default" : "outline"}
              size="sm"
              onClick={() => isAuthenticated
                ? likeMutation.mutate({ targetType: "article", targetId: Number(id) })
                : (window.location.href = getLoginUrl())
              }
              className="gap-1.5"
            >
              <ThumbsUp className="w-4 h-4" />{liked ? "已点赞" : "点赞"} ({article.likeCount})
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { navigator.clipboard.writeText(window.location.href); toast.success("链接已复制"); }}
              className="gap-1.5"
            >
              <Share2 className="w-4 h-4" />分享
            </Button>
          </div>
        </article>

        <Card>
          <CardContent className="p-6">
            <h2 className="font-bold text-lg mb-4">评论 ({commentsData?.total || 0})</h2>
            {isAuthenticated ? (
              <div className="mb-6">
                <Textarea
                  placeholder="发表您的看法..."
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  className="mb-2"
                  rows={3}
                />
                <Button
                  size="sm"
                  onClick={() => comment.trim() && commentMutation.mutate({ articleId: Number(id), content: comment })}
                  disabled={!comment.trim() || commentMutation.isPending}
                >
                  {commentMutation.isPending ? "发布中..." : "发布评论"}
                </Button>
              </div>
            ) : (
              <div className="mb-6 p-4 bg-muted rounded-lg text-center">
                <p className="text-muted-foreground text-sm mb-2">登录后参与评论</p>
                <Button size="sm" asChild><a href={getLoginUrl()}>立即登录</a></Button>
              </div>
            )}
            <div className="space-y-4">
              {commentsData?.data?.map(c => (
                <div key={c.id} className="flex gap-3 pb-4 border-b border-border last:border-0">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-bold shrink-0">U</div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">{new Date(c.createdAt).toLocaleString("zh-CN")}</div>
                    <p className="text-sm">{c.content}</p>
                  </div>
                </div>
              ))}
              {(!commentsData?.data || commentsData.data.length === 0) && (
                <p className="text-center text-muted-foreground text-sm py-4">暂无评论，来发表第一条评论吧</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
