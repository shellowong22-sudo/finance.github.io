import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  FileText,
  Shield,
  TrendingUp,
  Users,
  Eye,
  Clock,
  Star,
  Activity,
  Wifi,
  WifiOff,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Zap,
  ChevronDown,
  ChevronUp,
  Timer,
} from "lucide-react";
import { useState, useMemo } from "react";

const features = [
  {
    icon: FileText,
    title: "金融资讯",
    desc: "实时金融资讯、政策解读、市场动态，专业内容审核保障信息质量",
    href: "/articles",
    color: "text-blue-600",
    bg: "bg-blue-50",
  },
  {
    icon: TrendingUp,
    title: "金融研报",
    desc: "券商机构研报、宏观/行业/个股深度分析，专业投研参考",
    href: "/reports",
    color: "text-amber-600",
    bg: "bg-amber-50",
  },
  {
    icon: BookOpen,
    title: "金融课程",
    desc: "系统化金融学习课程，理财/基金/股票/风控全覆盖",
    href: "/courses",
    color: "text-green-600",
    bg: "bg-green-50",
  },
  {
    icon: Users,
    title: "社区互动",
    desc: "关注专家、评论交流、分享研究，构建金融学习社区",
    href: "/social",
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  {
    icon: Shield,
    title: "合规保障",
    desc: "严格合规审核机制，禁止违规理财话术，保护投资者权益",
    href: "/channel/apply",
    color: "text-red-600",
    bg: "bg-red-50",
  },
  {
    icon: BarChart3,
    title: "渠道合作",
    desc: "券商、银行、自媒体渠道合作，专业分成结算体系",
    href: "/channel/apply",
    color: "text-indigo-600",
    bg: "bg-indigo-50",
  },
];

const stats = [
  { label: "注册用户", value: "50,000+", icon: Users },
  { label: "专业文章", value: "10,000+", icon: FileText },
  { label: "金融研报", value: "5,000+", icon: TrendingUp },
  { label: "精品课程", value: "200+", icon: BookOpen },
];

// 可用性历史图表组件
function AvailabilityChart({ data }: { data: any }) {
  if (!data || !data.records || data.records.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <Timer className="w-8 h-8 mx-auto mb-2 opacity-30" />
        <p className="text-sm">暂无历史数据</p>
        <p className="text-xs opacity-60 mt-1">系统启动后将自动记录每次刷新的可用性数据</p>
      </div>
    );
  }

  const records = data.records as Array<{
    timestamp: string; success: boolean; updated: number; total: number;
    errors: number; durationMs: number; backoffLevel: number; successRate: number;
  }>;
  const summary = data.summary;
  const hourly = data.hourly as Array<{
    hour: string; successRate: number; totalRequests: number;
    successfulRequests: number; avgDurationMs: number;
  }>;

  // SVG 图表参数
  const chartW = 720;
  const chartH = 140;
  const padL = 40;
  const padR = 16;
  const padT = 12;
  const padB = 28;
  const innerW = chartW - padL - padR;
  const innerH = chartH - padT - padB;

  // 使用每条记录的成功率画点
  const points = records.map((r, i) => {
    const x = padL + (i / Math.max(records.length - 1, 1)) * innerW;
    const y = padT + innerH - (r.successRate / 100) * innerH;
    return { x, y, ...r };
  });

  // 生成曲线路径
  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  // 填充路径
  const areaPath = linePath + ` L${points[points.length - 1].x.toFixed(1)},${padT + innerH} L${points[0].x.toFixed(1)},${padT + innerH} Z`;

  // 时间轴标签（最多6个）
  const timeLabels = useMemo(() => {
    if (records.length < 2) return [];
    const labels: { x: number; label: string }[] = [];
    const step = Math.max(1, Math.floor(records.length / 6));
    for (let i = 0; i < records.length; i += step) {
      const d = new Date(records[i].timestamp);
      labels.push({
        x: padL + (i / Math.max(records.length - 1, 1)) * innerW,
        label: `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`,
      });
    }
    return labels;
  }, [records]);

  // 成功率颜色
  const rateColor = summary.overallSuccessRate >= 90 ? 'text-emerald-600' :
    summary.overallSuccessRate >= 70 ? 'text-amber-600' : 'text-red-600';
  const gradientId = 'avail-gradient';
  const lineColor = summary.overallSuccessRate >= 90 ? '#10b981' :
    summary.overallSuccessRate >= 70 ? '#f59e0b' : '#ef4444';

  return (
    <div className="space-y-3">
      {/* 汇总统计 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-lg border bg-muted/20 px-3 py-2">
          <div className="text-[10px] text-muted-foreground">总体成功率</div>
          <div className={`text-lg font-bold ${rateColor}`}>{summary.overallSuccessRate}%</div>
        </div>
        <div className="rounded-lg border bg-muted/20 px-3 py-2">
          <div className="text-[10px] text-muted-foreground">刷新次数</div>
          <div className="text-lg font-bold">{summary.totalRecords}</div>
        </div>
        <div className="rounded-lg border bg-muted/20 px-3 py-2">
          <div className="text-[10px] text-muted-foreground">成功 / 失败</div>
          <div className="text-lg font-bold">
            <span className="text-emerald-600">{summary.successfulRecords}</span>
            <span className="text-muted-foreground mx-1">/</span>
            <span className="text-red-500">{summary.failedRecords}</span>
          </div>
        </div>
        <div className="rounded-lg border bg-muted/20 px-3 py-2">
          <div className="text-[10px] text-muted-foreground">平均耗时</div>
          <div className="text-lg font-bold">{(summary.avgDurationMs / 1000).toFixed(1)}s</div>
        </div>
      </div>

      {/* SVG 图表 */}
      <div className="rounded-lg border bg-muted/10 p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground">API 成功率走势（过24小时）</span>
          <span className="text-[10px] text-muted-foreground">共 {records.length} 次刷新</span>
        </div>
        <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-auto" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={lineColor} stopOpacity="0.3" />
              <stop offset="100%" stopColor={lineColor} stopOpacity="0.02" />
            </linearGradient>
          </defs>
          {/* Y轴网格线 */}
          {[0, 25, 50, 75, 100].map(v => {
            const y = padT + innerH - (v / 100) * innerH;
            return (
              <g key={v}>
                <line x1={padL} y1={y} x2={chartW - padR} y2={y} stroke="currentColor" strokeOpacity="0.08" strokeDasharray="4 4" />
                <text x={padL - 6} y={y + 3} textAnchor="end" fill="currentColor" fillOpacity="0.35" fontSize="9">{v}%</text>
              </g>
            );
          })}
          {/* 填充区域 */}
          {points.length > 1 && <path d={areaPath} fill={`url(#${gradientId})`} />}
          {/* 折线 */}
          {points.length > 1 && <path d={linePath} fill="none" stroke={lineColor} strokeWidth="2" strokeLinejoin="round" />}
          {/* 数据点 */}
          {points.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r={records.length > 50 ? 1.5 : 3}
              fill={p.success ? lineColor : '#ef4444'} stroke="white" strokeWidth={records.length > 50 ? 0.5 : 1} />
          ))}
          {/* X轴时间标签 */}
          {timeLabels.map((t, i) => (
            <text key={i} x={t.x} y={chartH - 4} textAnchor="middle" fill="currentColor" fillOpacity="0.4" fontSize="9">{t.label}</text>
          ))}
        </svg>
      </div>

      {/* 小时级别柱状图 */}
      {hourly.length > 0 && (
        <div className="rounded-lg border bg-muted/10 p-3">
          <span className="text-xs font-medium text-muted-foreground mb-2 block">小时级别成功率</span>
          <div className="flex items-end gap-1 h-16">
            {hourly.map((h, i) => {
              const barH = Math.max(2, (h.successRate / 100) * 56);
              const barColor = h.successRate >= 90 ? 'bg-emerald-400' :
                h.successRate >= 70 ? 'bg-amber-400' : 'bg-red-400';
              const hourLabel = h.hour.slice(11, 16);
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-0.5" title={`${hourLabel} 成功率:${h.successRate}% 刷新:${h.totalRequests}次 平均耗时:${(h.avgDurationMs / 1000).toFixed(1)}s`}>
                  <div className={`w-full rounded-t ${barColor} transition-all`} style={{ height: `${barH}px` }} />
                  <span className="text-[8px] text-muted-foreground/60 leading-none">{hourLabel}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [showAvailability, setShowAvailability] = useState(false);
  const { data: healthData } = trpc.quant.market.systemHealth.useQuery(undefined, { refetchInterval: 30000 });
  const { data: availabilityData } = trpc.quant.market.availabilityHistory.useQuery(undefined, {
    refetchInterval: 60000,
    enabled: showAvailability,
  });
  const { data: articlesData } = trpc.article.list.useQuery({ page: 1, limit: 6, status: "published" });
  const { data: reportsData } = trpc.report.list.useQuery({ page: 1, limit: 4 });
  const { data: coursesData } = trpc.course.list.useQuery({ page: 1, limit: 4 });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="finance-gradient text-white py-20 px-4">
        <div className="container text-center">
          <Badge className="mb-4 bg-white/20 text-white border-white/30 hover:bg-white/30">
            专业 · 合规 · 智能
          </Badge>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            金融综合服务平台
          </h1>
          <p className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            集资讯发布、研报分析、课程学习、社区互动于一体的专业金融服务平台，
            为您提供全方位的金融知识与投资参考
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isAuthenticated ? (
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold" asChild>
                <Link href="/articles">浏览资讯 <ArrowRight className="ml-2 w-4 h-4" /></Link>
              </Button>
            ) : (
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold" asChild>
                <a href={getLoginUrl()}>免费注册 <ArrowRight className="ml-2 w-4 h-4" /></a>
              </Button>
            )}
            <Button size="lg" variant="outline" className="border-white/50 text-white hover:bg-white/10" asChild>
              <Link href="/courses">探索课程</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-b border-border bg-card">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="w-8 h-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl md:text-3xl font-bold text-primary">{stat.value}</div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* System Health Indicator */}
      <section className="py-6 px-4">
        <div className="container">
          <Card className="border-border overflow-hidden">
            <CardContent className="p-0">
              <div className="flex flex-col md:flex-row items-stretch">
                {/* Status Indicator */}
                <div className={`flex items-center gap-3 px-6 py-4 ${
                  healthData?.status === 'healthy' ? 'bg-emerald-50 dark:bg-emerald-950/30' :
                  healthData?.status === 'degraded' ? 'bg-amber-50 dark:bg-amber-950/30' :
                  healthData?.status === 'warning' ? 'bg-orange-50 dark:bg-orange-950/30' :
                  'bg-muted/30'
                }`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    healthData?.status === 'healthy' ? 'bg-emerald-100 dark:bg-emerald-900' :
                    healthData?.status === 'degraded' ? 'bg-amber-100 dark:bg-amber-900' :
                    'bg-orange-100 dark:bg-orange-900'
                  }`}>
                    {healthData?.status === 'healthy' ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> :
                     healthData?.status === 'degraded' ? <AlertTriangle className="w-5 h-5 text-amber-600" /> :
                     <WifiOff className="w-5 h-5 text-orange-600" />}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">
                      {healthData?.status === 'healthy' ? '系统运行正常' :
                       healthData?.status === 'degraded' ? '服务降级中' :
                       healthData?.status === 'warning' ? '数据延迟' : '检测中...'}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {healthData?.backoff?.quotaExhausted ? 'API配额已耗尽，已自动降低请求频率' : '行情数据实时更新中'}
                    </div>
                  </div>
                </div>

                {/* Metrics */}
                <div className="flex-1 flex items-center gap-6 px-6 py-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="text-muted-foreground">监控品种 </span>
                      <span className="font-semibold">{healthData?.totalQuotes || 0}</span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wifi className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="text-muted-foreground">数据新鲜度 </span>
                      <Badge variant="outline" className={`text-xs ${
                        healthData?.dataFreshness === 'fresh' ? 'border-emerald-300 text-emerald-700 bg-emerald-50' :
                        healthData?.dataFreshness === 'stale' ? 'border-amber-300 text-amber-700 bg-amber-50' :
                        'border-orange-300 text-orange-700 bg-orange-50'
                      }`}>
                        {healthData?.dataFreshness === 'fresh' ? '实时' :
                         healthData?.dataFreshness === 'stale' ? '延迟' :
                         healthData?.dataFreshness === 'outdated' ? '过时' : '未知'}
                      </Badge>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <RefreshCw className={`w-4 h-4 text-muted-foreground ${healthData?.isRefreshing ? 'animate-spin' : ''}`} />
                    <span className="text-sm">
                      <span className="text-muted-foreground">上次刷新 </span>
                      <span className="font-semibold">
                        {healthData?.minutesSinceRefresh !== null && healthData?.minutesSinceRefresh !== undefined
                          ? `${healthData.minutesSinceRefresh}分钟前`
                          : '未刷新'}
                      </span>
                    </span>
                  </div>
                  {healthData?.backoff && healthData.backoff.backoffLevel > 0 && (
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-500" />
                      <span className="text-sm">
                        <span className="text-muted-foreground">退避级别 </span>
                        <span className="font-semibold text-amber-600">
                          L{healthData.backoff.backoffLevel} ({healthData.backoff.currentIntervalLabel})
                        </span>
                      </span>
                    </div>
                  )}
                  {/* 展开历史图表按钮 */}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs gap-1 text-muted-foreground hover:text-foreground ml-auto"
                    onClick={() => setShowAvailability(!showAvailability)}
                  >
                    {showAvailability ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    {showAvailability ? '收起历史' : '24小时可用性'}
                  </Button>
                </div>
              </div>
              {/* 可用性历史图表展开区域 */}
              {showAvailability && (
                <div className="border-t px-6 py-4">
                  <AvailabilityChart data={availabilityData} />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">核心功能模块</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              五大核心业务模块，覆盖金融信息消费全场景
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => (
              <Link key={f.title} href={f.href}>
                <Card className="card-hover cursor-pointer h-full border-border">
                  <CardContent className="p-6">
                    <div className={`w-12 h-12 ${f.bg} rounded-xl flex items-center justify-center mb-4`}>
                      <f.icon className={`w-6 h-6 ${f.color}`} />
                    </div>
                    <h3 className="font-bold text-lg mb-2">{f.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">最新资讯</h2>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/articles">查看全部 <ArrowRight className="ml-1 w-4 h-4" /></Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {articlesData?.data?.slice(0, 6).map((article) => (
              <Link key={article.id} href={`/articles/${article.id}`}>
                <Card className="card-hover cursor-pointer h-full">
                  <CardContent className="p-5">
                    {article.isTop && (
                      <Badge className="mb-2 bg-amber-100 text-amber-700 border-amber-200">置顶</Badge>
                    )}
                    <h3 className="font-semibold text-base mb-2 line-clamp-2 leading-snug">{article.title}</h3>
                    {article.summary && (
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{article.summary}</p>
                    )}
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />{article.viewCount}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {article.publishedAt ? new Date(article.publishedAt).toLocaleDateString("zh-CN") : ""}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
            {(!articlesData?.data || articlesData.data.length === 0) && (
              <div className="col-span-3 text-center py-12 text-muted-foreground">
                <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>暂无发布文章，管理员可前往后台添加内容</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Reports & Courses */}
      <section className="py-16 px-4">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Reports */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">热门研报</h2>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/reports">查看全部 <ArrowRight className="ml-1 w-4 h-4" /></Link>
                </Button>
              </div>
              <div className="space-y-3">
                {reportsData?.data?.slice(0, 4).map((report) => (
                  <Link key={report.id} href={`/reports/${report.id}`}>
                    <Card className="card-hover cursor-pointer">
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className="w-10 h-10 bg-amber-50 rounded-lg flex items-center justify-center shrink-0">
                          <TrendingUp className="w-5 h-5 text-amber-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium text-sm line-clamp-1">{report.title}</h3>
                            {report.isPaid && <Badge variant="outline" className="text-xs shrink-0">付费</Badge>}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{report.institution || "机构研报"}</span>
                            <span>·</span>
                            <span>{report.viewCount} 次阅读</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
                {(!reportsData?.data || reportsData.data.length === 0) && (
                  <div className="text-center py-8 text-muted-foreground">
                    <TrendingUp className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">暂无研报</p>
                  </div>
                )}
              </div>
            </div>

            {/* Courses */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">精品课程</h2>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/courses">查看全部 <ArrowRight className="ml-1 w-4 h-4" /></Link>
                </Button>
              </div>
              <div className="space-y-3">
                {coursesData?.data?.slice(0, 4).map((course) => (
                  <Link key={course.id} href={`/courses/${course.id}`}>
                    <Card className="card-hover cursor-pointer">
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center shrink-0">
                          <BookOpen className="w-5 h-5 text-green-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-sm line-clamp-1 mb-1">{course.title}</h3>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-0.5">
                              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                              {course.rating}
                            </span>
                            <span>·</span>
                            <span>{course.studentCount} 人学习</span>
                            <span>·</span>
                            <span className="text-primary font-medium">
                              {course.isFree ? "免费" : `¥${course.price}`}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
                {(!coursesData?.data || coursesData.data.length === 0) && (
                  <div className="text-center py-8 text-muted-foreground">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">暂无课程</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      {!isAuthenticated && (
        <section className="py-16 px-4 finance-gradient text-white">
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-4">立即加入金融综合服务平台</h2>
            <p className="text-white/80 mb-8 max-w-xl mx-auto">
              注册即可免费访问海量金融资讯、参与社区讨论，开启您的金融学习之旅
            </p>
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold" asChild>
              <a href={getLoginUrl()}>免费注册 <ArrowRight className="ml-2 w-4 h-4" /></a>
            </Button>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 bg-muted/20">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 finance-gradient rounded flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold text-sm">金融综合服务平台</span>
            </div>
            <p className="text-muted-foreground text-sm">
              © 2024 金融综合服务平台 · 合规经营 · 数据安全 · 隐私保护
            </p>
            <div className="flex gap-4 text-sm text-muted-foreground">
              <span>用户协议</span>
              <span>隐私政策</span>
              <span>合规声明</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
