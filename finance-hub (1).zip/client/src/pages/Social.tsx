import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { MessageSquare, Send, Users, Heart, Clock, Shield } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Social() {
  const { isAuthenticated, user } = useAuth();
  const [messageContent, setMessageContent] = useState("");
  const [receiverId, setReceiverId] = useState("");
  const utils = trpc.useUtils();

  const { data: messagesData } = trpc.social.messages.useQuery({ page: 1 }, { enabled: isAuthenticated });

  const sendMessageMutation = trpc.social.sendMessage.useMutation({
    onSuccess: () => {
      setMessageContent("");
      setReceiverId("");
      utils.social.messages.invalidate();
      toast.success("私信发送成功");
    },
    onError: (e) => toast.error(e.message),
  });

  const maskPhone = (phone: string) => phone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2");
  const maskId = (id: string) => id.replace(/(\d{6})\d{8}(\d{4})/, "$1********$2");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold">社区互动</h1>
          <p className="text-muted-foreground text-sm mt-1">关注专家、私信交流、共建金融学习社区</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Social Features */}
          <div className="lg:col-span-2 space-y-6">
            {/* Private Messages */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MessageSquare className="w-5 h-5" />私信中心
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isAuthenticated ? (
                  <>
                    {/* Send Message */}
                    <div className="mb-6 p-4 bg-muted/30 rounded-lg">
                      <h3 className="font-medium text-sm mb-3">发送私信</h3>
                      <Input
                        placeholder="收件人用户ID"
                        value={receiverId}
                        onChange={e => setReceiverId(e.target.value)}
                        className="mb-2"
                        type="number"
                      />
                      <Textarea
                        placeholder="输入私信内容（最多2000字）..."
                        value={messageContent}
                        onChange={e => setMessageContent(e.target.value)}
                        rows={3}
                        className="mb-2"
                        maxLength={2000}
                      />
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">{messageContent.length}/2000</span>
                        <Button
                          size="sm"
                          onClick={() => {
                            if (!receiverId || !messageContent.trim()) {
                              toast.error("请填写收件人ID和消息内容");
                              return;
                            }
                            sendMessageMutation.mutate({ receiverId: Number(receiverId), content: messageContent });
                          }}
                          disabled={sendMessageMutation.isPending}
                          className="gap-1.5"
                        >
                          <Send className="w-4 h-4" />
                          {sendMessageMutation.isPending ? "发送中..." : "发送"}
                        </Button>
                      </div>
                    </div>

                    {/* Message List */}
                    <div className="space-y-3">
                      <h3 className="font-medium text-sm">消息记录</h3>
                      {messagesData?.data?.map(msg => (
                        <div key={msg.id} className={`flex gap-3 p-3 rounded-lg ${msg.senderId === user?.id ? "bg-primary/5 flex-row-reverse" : "bg-muted/30"}`}>
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                            {msg.senderId === user?.id ? "我" : "U"}
                          </div>
                          <div className={`flex-1 ${msg.senderId === user?.id ? "text-right" : ""}`}>
                            <div className="text-xs text-muted-foreground mb-1">
                              {msg.senderId === user?.id ? "我" : `用户 ${msg.senderId}`}
                              <span className="ml-2">{new Date(msg.createdAt).toLocaleString("zh-CN")}</span>
                            </div>
                            <p className="text-sm bg-card rounded-lg p-2 inline-block">{msg.content}</p>
                          </div>
                        </div>
                      ))}
                      {(!messagesData?.data || messagesData.data.length === 0) && (
                        <div className="text-center py-8 text-muted-foreground">
                          <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30" />
                          <p className="text-sm">暂无消息记录</p>
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <MessageSquare className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-30" />
                    <p className="text-muted-foreground mb-4">登录后使用私信功能</p>
                    <Button asChild><a href={getLoginUrl()}>立即登录</a></Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right: Info Panel */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4" />社区规范
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-muted-foreground">
                <div className="flex items-start gap-2">
                  <Shield className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p>禁止发布虚假金融信息和违规理财话术</p>
                </div>
                <div className="flex items-start gap-2">
                  <Shield className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p>个人信息（手机号、身份证）自动脱敏保护</p>
                </div>
                <div className="flex items-start gap-2">
                  <Shield className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p>违规言论将被自动过滤，情节严重将封禁账号</p>
                </div>
                <div className="flex items-start gap-2">
                  <Shield className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p>请文明交流，共建健康的金融学习社区</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">数据脱敏示例</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="p-2 bg-muted rounded">
                  <span className="text-muted-foreground">手机号：</span>
                  <span className="font-mono">{maskPhone("13812345678")}</span>
                </div>
                <div className="p-2 bg-muted rounded">
                  <span className="text-muted-foreground">身份证：</span>
                  <span className="font-mono">{maskId("110101199001011234")}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">所有敏感信息在展示时自动脱敏处理</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">互动统计</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {isAuthenticated ? (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="text-center p-3 bg-muted/30 rounded-lg">
                      <div className="text-xl font-bold text-primary">0</div>
                      <div className="text-xs text-muted-foreground">粉丝</div>
                    </div>
                    <div className="text-center p-3 bg-muted/30 rounded-lg">
                      <div className="text-xl font-bold text-primary">0</div>
                      <div className="text-xs text-muted-foreground">关注</div>
                    </div>
                    <div className="text-center p-3 bg-muted/30 rounded-lg">
                      <div className="text-xl font-bold text-primary">{messagesData?.total || 0}</div>
                      <div className="text-xs text-muted-foreground">消息</div>
                    </div>
                    <div className="text-center p-3 bg-muted/30 rounded-lg">
                      <div className="text-xl font-bold text-primary">0</div>
                      <div className="text-xs text-muted-foreground">点赞</div>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-2">登录后查看互动数据</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
