import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { BookOpen, Search, Star, Users, Clock } from "lucide-react";
import { useState } from "react";

const categories = [
  { value: "", label: "全部" },
  { value: "finance", label: "理财" },
  { value: "fund", label: "基金" },
  { value: "stock", label: "股票" },
  { value: "risk", label: "风控" },
  { value: "crypto", label: "数字货币" },
  { value: "forex", label: "外汇" },
];

const categoryColors: Record<string, string> = {
  finance: "bg-blue-50 text-blue-700",
  fund: "bg-green-50 text-green-700",
  stock: "bg-amber-50 text-amber-700",
  risk: "bg-red-50 text-red-700",
  crypto: "bg-purple-50 text-purple-700",
  forex: "bg-indigo-50 text-indigo-700",
};

export default function Courses() {
  const [keyword, setKeyword] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(1);
  const { data, isLoading } = trpc.course.list.useQuery({ page, limit: 12, keyword: searchVal || undefined, category: category || undefined });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">金融课程</h1>
            <p className="text-muted-foreground text-sm mt-1">系统化金融学习，从入门到进阶</p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <Input placeholder="搜索课程..." value={keyword} onChange={e => setKeyword(e.target.value)} className="sm:w-64"
              onKeyDown={e => { if (e.key === "Enter") { setSearchVal(keyword); setPage(1); } }} />
            <Button size="sm" onClick={() => { setSearchVal(keyword); setPage(1); }}><Search className="w-4 h-4" /></Button>
          </div>
        </div>

        <div className="flex gap-2 mb-6 flex-wrap">
          {categories.map(cat => (
            <Button key={cat.value} variant={category === cat.value ? "default" : "outline"} size="sm"
              onClick={() => { setCategory(cat.value); setPage(1); }}>
              {cat.label}
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-52 bg-muted animate-pulse rounded-lg" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data?.data?.map(course => (
                <Link key={course.id} href={`/courses/${course.id}`}>
                  <Card className="card-hover cursor-pointer h-full">
                    <CardContent className="p-5">
                      <div className="flex items-center justify-between mb-3">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${categoryColors[course.category] || "bg-gray-50 text-gray-700"}`}>
                          {categories.find(c => c.value === course.category)?.label || course.category}
                        </span>
                        <Badge variant="outline" className="text-xs">{course.type === "video" ? "视频" : "图文"}</Badge>
                      </div>
                      <h3 className="font-semibold text-base mb-2 line-clamp-2">{course.title}</h3>
                      {course.description && (
                        <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{course.description}</p>
                      )}
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-amber-400 fill-amber-400" />{course.rating}
                        </span>
                        <span className="flex items-center gap-1"><Users className="w-3 h-3" />{course.studentCount} 人</span>
                        {course.hasCertificate && <Badge variant="secondary" className="text-xs">含证书</Badge>}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-primary text-lg">
                          {course.isFree ? <span className="text-green-600">免费</span> : `¥${course.price}`}
                        </span>
                        {course.originalPrice && !course.isFree && (
                          <span className="text-muted-foreground text-xs line-through">¥{course.originalPrice}</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
              {data?.data?.length === 0 && (
                <div className="col-span-3 text-center py-16 text-muted-foreground">
                  <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>暂无课程</p>
                </div>
              )}
            </div>
            {data && data.total > 12 && (
              <div className="flex justify-center gap-2 mt-8">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
                <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页</span>
                <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 12)} onClick={() => setPage(p => p + 1)}>下一页</Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
