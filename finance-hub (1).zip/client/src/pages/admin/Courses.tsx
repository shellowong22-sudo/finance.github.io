import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { BookOpen, Plus, Edit, Eye, Users, Star } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const categoryMap: Record<string, string> = { finance: "理财", fund: "基金", stock: "股票", risk: "风控", crypto: "数字货币", forex: "外汇" };

export default function AdminCourses() {
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "", description: "", category: "finance" as const, type: "video" as const,
    price: "", originalPrice: "", isFree: false, hasCertificate: false, hasExam: false, refundPolicy: "",
  });
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.course.list.useQuery({ page, limit: 10 });
  const createMutation = trpc.course.create.useMutation({
    onSuccess: () => { toast.success("课程创建成功"); setOpen(false); utils.course.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const toggleMutation = trpc.course.update.useMutation({
    onSuccess: () => utils.course.list.invalidate(),
    onError: (e) => toast.error(e.message),
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">课程管理</h1>
            <p className="text-muted-foreground text-sm">管理金融课程，设置价格与权限</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="w-4 h-4" />新建课程</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>新建课程</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>课程标题 *</Label>
                  <Input className="mt-1" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="请输入课程标题" />
                </div>
                <div>
                  <Label>课程描述</Label>
                  <Textarea className="mt-1" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={3} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>分类</Label>
                    <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v as any }))}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(categoryMap).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>类型</Label>
                    <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as any }))}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="video">视频</SelectItem>
                        <SelectItem value="graphic">图文</SelectItem>
                        <SelectItem value="live">直播</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={form.isFree} onCheckedChange={v => setForm(f => ({ ...f, isFree: v }))} />
                  <Label>免费课程</Label>
                </div>
                {!form.isFree && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>价格（元）</Label>
                      <Input className="mt-1" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
                    </div>
                    <div>
                      <Label>原价（元）</Label>
                      <Input className="mt-1" type="number" value={form.originalPrice} onChange={e => setForm(f => ({ ...f, originalPrice: e.target.value }))} />
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Switch checked={form.hasCertificate} onCheckedChange={v => setForm(f => ({ ...f, hasCertificate: v }))} />
                    <Label>含证书</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={form.hasExam} onCheckedChange={v => setForm(f => ({ ...f, hasExam: v }))} />
                    <Label>含考试</Label>
                  </div>
                </div>
                <div>
                  <Label>退款政策</Label>
                  <Textarea className="mt-1" value={form.refundPolicy} onChange={e => setForm(f => ({ ...f, refundPolicy: e.target.value }))} rows={2} placeholder="如：购买后7天内可退款" />
                </div>
                <Button className="w-full" onClick={() => createMutation.mutate({ ...form, instructorId: 1, price: form.price || undefined, originalPrice: form.originalPrice || undefined })} disabled={!form.title || createMutation.isPending}>
                  {createMutation.isPending ? "创建中..." : "创建课程"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/30">
                  <tr>
                    <th className="text-left p-4 font-medium text-muted-foreground">课程名称</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">分类</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">价格</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">学员</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">评分</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">状态</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-border">
                        {Array.from({ length: 7 }).map((_, j) => <td key={j} className="p-4"><div className="h-4 bg-muted animate-pulse rounded" /></td>)}
                      </tr>
                    ))
                  ) : data?.data?.map(course => (
                    <tr key={course.id} className="border-b border-border hover:bg-muted/20 transition-colors">
                      <td className="p-4">
                        <div className="font-medium line-clamp-1">{course.title}</div>
                        <div className="text-xs text-muted-foreground">{course.type === "video" ? "视频" : "图文"}</div>
                      </td>
                      <td className="p-4"><Badge variant="secondary">{categoryMap[course.category] || course.category}</Badge></td>
                      <td className="p-4">{course.isFree ? <span className="text-green-600 font-medium">免费</span> : <span className="font-medium">¥{course.price}</span>}</td>
                      <td className="p-4"><span className="flex items-center gap-1"><Users className="w-3 h-3" />{course.studentCount}</span></td>
                      <td className="p-4"><span className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-400" />{course.rating}</span></td>
                      <td className="p-4">
                        <Badge variant={course.status === "published" ? "default" : "secondary"}>
                          {course.status === "published" ? "已上架" : course.status === "draft" ? "草稿" : "已下架"}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" onClick={() => toggleMutation.mutate({ id: course.id, status: course.status === "published" ? "offline" : "published" })}>
                            {course.status === "published" ? "下架" : "上架"}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {data?.data?.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>暂无课程</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {data && data.total > 10 && (
          <div className="flex justify-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
            <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页</span>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 10)} onClick={() => setPage(p => p + 1)}>下一页</Button>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
