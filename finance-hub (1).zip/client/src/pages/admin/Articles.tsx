import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FileText, Plus, Eye, Pin, CheckCircle, XCircle, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminArticles() {
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const [keyword, setKeyword] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const [form, setForm] = useState({ title: "", summary: "", content: "", status: "draft" as "draft" | "pending" | "published" | "rejected" | "offline" });
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.article.list.useQuery({ page, limit: 10, keyword: searchVal || undefined });
  const createMutation = trpc.article.create.useMutation({
    onSuccess: () => { toast.success("文章创建成功"); setOpen(false); utils.article.list.invalidate(); setForm({ title: "", summary: "", content: "", status: "draft" }); },
    onError: (e) => toast.error(e.message),
  });
  const reviewMutation = trpc.article.review.useMutation({
    onSuccess: () => { toast.success("操作成功"); utils.article.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const toggleStatusMutation = trpc.article.toggleStatus.useMutation({
    onSuccess: () => { toast.success("状态更新成功"); utils.article.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const togglePinMutation = trpc.article.togglePin.useMutation({
    onSuccess: () => utils.article.list.invalidate(),
    onError: (e) => toast.error(e.message),
  });

  const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    draft: { label: "草稿", variant: "secondary" },
    pending: { label: "待审核", variant: "outline" },
    published: { label: "已发布", variant: "default" },
    rejected: { label: "已拒绝", variant: "destructive" },
    offline: { label: "已下架", variant: "secondary" },
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">文章管理</h1>
            <p className="text-muted-foreground text-sm">发布金融资讯，管理文章状态</p>
          </div>
          <div className="flex gap-2">
            <div className="flex gap-2">
              <Input placeholder="搜索文章..." value={keyword} onChange={e => setKeyword(e.target.value)} className="w-48"
                onKeyDown={e => { if (e.key === "Enter") { setSearchVal(keyword); setPage(1); } }} />
              <Button size="sm" variant="outline" onClick={() => { setSearchVal(keyword); setPage(1); }}><Search className="w-4 h-4" /></Button>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2"><Plus className="w-4 h-4" />发布文章</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader><DialogTitle>发布文章</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>文章标题 *</Label>
                    <Input className="mt-1" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="请输入文章标题" />
                  </div>
                  <div>
                    <Label>摘要</Label>
                    <Textarea className="mt-1" value={form.summary} onChange={e => setForm(f => ({ ...f, summary: e.target.value }))} rows={2} placeholder="文章摘要（可选）" />
                  </div>
                  <div>
                    <Label>正文内容 *</Label>
                    <Textarea className="mt-1" value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} rows={8} placeholder="请输入文章正文..." />
                  </div>
                  <div className="flex gap-3">
                    <Button variant="outline" onClick={() => createMutation.mutate({ title: form.title, content: form.content, summary: form.summary || undefined })} disabled={!form.title || !form.content || createMutation.isPending}>
                      保存草稿
                    </Button>
                    <Button onClick={() => createMutation.mutate({ title: form.title, content: form.content, summary: form.summary || undefined })} disabled={!form.title || !form.content || createMutation.isPending}>
                      {createMutation.isPending ? "发布中..." : "立即发布"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/30">
                  <tr>
                    <th className="text-left p-4 font-medium text-muted-foreground">文章标题</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">阅读量</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">状态</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">置顶</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">发布时间</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-border">
                        {Array.from({ length: 6 }).map((_, j) => <td key={j} className="p-4"><div className="h-4 bg-muted animate-pulse rounded" /></td>)}
                      </tr>
                    ))
                  ) : data?.data?.map(article => (
                    <tr key={article.id} className="border-b border-border hover:bg-muted/20 transition-colors">
                      <td className="p-4">
                        <div className="font-medium line-clamp-1 max-w-xs">{article.title}</div>
                        {article.summary && <div className="text-xs text-muted-foreground line-clamp-1">{article.summary}</div>}
                      </td>
                      <td className="p-4">
                        <span className="flex items-center gap-1 text-muted-foreground"><Eye className="w-3 h-3" />{article.viewCount}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant={statusConfig[article.status]?.variant || "secondary"}>
                          {statusConfig[article.status]?.label || article.status}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Button variant="ghost" size="sm" onClick={() => togglePinMutation.mutate({ id: article.id, isPinned: !article.isPinned })}>
                          <Pin className={`w-4 h-4 ${article.isPinned ? "text-amber-500 fill-amber-500" : "text-muted-foreground"}`} />
                        </Button>
                      </td>
                      <td className="p-4 text-muted-foreground text-xs">
                        {article.publishedAt ? new Date(article.publishedAt).toLocaleDateString("zh-CN") : "-"}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-1">
                          {article.status === "pending" && (
                            <>
                              <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-700" onClick={() => reviewMutation.mutate({ id: article.id, action: "approve" })}>
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => reviewMutation.mutate({ id: article.id, action: "reject" })}>
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                          <Button variant="ghost" size="sm" onClick={() => toggleStatusMutation.mutate({ id: article.id, status: article.status === "published" ? "offline" : "published" })}>
                            {article.status === "published" ? "下架" : "上架"}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {data?.data?.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <FileText className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>暂无文章</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {data && data.total > 10 && (
          <div className="flex justify-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
            <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页</span>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 10)} onClick={() => setPage(p => p + 1)}>下一页</Button>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
