import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Globe, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const channelTypeMap: Record<string, string> = { broker: "券商", bank: "银行", media: "自媒体", other: "其他" };

export default function AdminChannels() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [reviewOpen, setReviewOpen] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [commissionRate, setCommissionRate] = useState("10");
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.channel.adminList.useQuery({ page, status: statusFilter || undefined });
  const reviewMutation = trpc.channel.review.useMutation({
    onSuccess: () => {
      toast.success("审核操作成功");
      setReviewOpen(false);
      setSelectedChannel(null);
      utils.channel.adminList.invalidate();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const statusConfig: Record<string, { label: string; color: string }> = {
    pending: { label: "待审核", color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
    approved: { label: "已通过", color: "bg-green-100 text-green-700 border-green-200" },
    rejected: { label: "已拒绝", color: "bg-red-100 text-red-700 border-red-200" },
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">渠道管理</h1>
            <p className="text-muted-foreground text-sm">审核渠道申请，配置分成比例</p>
          </div>
          <div className="flex gap-2">
            {["", "pending", "approved", "rejected"].map(s => (
              <Button key={s} variant={statusFilter === s ? "default" : "outline"} size="sm" onClick={() => { setStatusFilter(s); setPage(1); }}>
                {s === "" ? "全部" : statusConfig[s]?.label}
              </Button>
            ))}
          </div>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/30">
                  <tr>
                    <th className="text-left p-4 font-medium text-muted-foreground">公司名称</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">类型</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">联系人</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">联系方式</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">分成比例</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">状态</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">申请时间</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-border">
                        {Array.from({ length: 8 }).map((_, j) => <td key={j} className="p-4"><div className="h-4 bg-muted animate-pulse rounded" /></td>)}
                      </tr>
                    ))
                  ) : data?.data?.map(channel => (
                    <tr key={channel.id} className="border-b border-border hover:bg-muted/20 transition-colors">
                      <td className="p-4 font-medium">{channel.companyName}</td>
                      <td className="p-4"><Badge variant="secondary">{channelTypeMap[channel.channelType] || channel.channelType}</Badge></td>
                      <td className="p-4 text-muted-foreground">{channel.contactName}</td>
                      <td className="p-4 text-muted-foreground text-xs">{channel.contactPhone}</td>
                      <td className="p-4">{channel.commissionRate ? <span className="text-primary font-medium">{channel.commissionRate}%</span> : <span className="text-muted-foreground">未配置</span>}</td>
                      <td className="p-4">
                        <Badge className={statusConfig[channel.status]?.color || ""}>
                          {statusConfig[channel.status]?.label || channel.status}
                        </Badge>
                      </td>
                      <td className="p-4 text-muted-foreground text-xs">{new Date(channel.createdAt).toLocaleDateString("zh-CN")}</td>
                      <td className="p-4">
                        {channel.status === "pending" && (
                          <Button variant="outline" size="sm" onClick={() => { setSelectedChannel(channel); setReviewOpen(true); }}>
                            审核
                          </Button>
                        )}
                        {channel.status === "approved" && (
                          <span className="text-xs text-muted-foreground">已通过</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {data?.data?.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <Globe className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>暂无渠道申请</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {data && data.total > 10 && (
          <div className="flex justify-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
            <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页</span>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 10)} onClick={() => setPage(p => p + 1)}>下一页</Button>
          </div>
        )}

        {/* Review Dialog */}
        <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>渠道审核 - {selectedChannel?.companyName}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="p-3 bg-muted/30 rounded-lg text-sm space-y-2">
                <div><span className="text-muted-foreground">公司：</span>{selectedChannel?.companyName}</div>
                <div><span className="text-muted-foreground">类型：</span>{channelTypeMap[selectedChannel?.channelType] || selectedChannel?.channelType}</div>
                <div><span className="text-muted-foreground">联系人：</span>{selectedChannel?.contactName}</div>
                <div><span className="text-muted-foreground">电话：</span>{selectedChannel?.contactPhone}</div>
                <div><span className="text-muted-foreground">邮箱：</span>{selectedChannel?.contactEmail}</div>
                {selectedChannel?.description && <div><span className="text-muted-foreground">说明：</span>{selectedChannel.description}</div>}
              </div>
              <div>
                <Label>分成比例（%）</Label>
                <Input className="mt-1" type="number" min="0" max="100" value={commissionRate} onChange={e => setCommissionRate(e.target.value)} />
              </div>
              <div>
                <Label>拒绝原因（拒绝时填写）</Label>
                <Input className="mt-1" value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="可选，拒绝时说明原因" />
              </div>
              <div className="flex gap-3">
                <Button
                  className="flex-1 gap-2 bg-green-600 hover:bg-green-700"
                  onClick={() => reviewMutation.mutate({ id: selectedChannel.id, action: "approve", commissionRate: String(commissionRate) })}
                  disabled={reviewMutation.isPending}
                >
                  <CheckCircle className="w-4 h-4" />通过审核
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1 gap-2"
                  onClick={() => reviewMutation.mutate({ id: selectedChannel.id, action: "reject", rejectReason })}
                  disabled={reviewMutation.isPending}
                >
                  <XCircle className="w-4 h-4" />拒绝申请
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
