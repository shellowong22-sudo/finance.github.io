import AdminLayout from "@/components/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  Shield, AlertTriangle, Activity, Database, BarChart3, Zap, FileText, Server,
  Plus, RefreshCw, StopCircle, CheckCircle, XCircle, Clock, Eye,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function QuantManage() {
  const { data: riskRules } = trpc.quant.risk.rules.useQuery({});
  const { data: riskLogs } = trpc.quant.risk.logs.useQuery({ limit: 50 });
  const { data: complianceLogs } = trpc.quant.compliance.logs.useQuery({ limit: 50 });
  const { data: alerts } = trpc.quant.monitor.alerts.useQuery({ limit: 50 });
  const { data: sysHealth } = trpc.quant.monitor.health.useQuery();

  const generateQuotesMut = trpc.quant.market.generateQuotes.useMutation({ onSuccess: () => toast.success("行情数据生成成功") });
  const generateIPOMut = trpc.quant.market.generateIPOs.useMutation({ onSuccess: () => toast.success("IPO数据生成成功") });
  const createRuleMut = trpc.quant.risk.createRule.useMutation({ onSuccess: () => toast.success("风控规则创建成功") });
  const updateRuleMut = trpc.quant.risk.updateRule.useMutation({ onSuccess: () => toast.success("规则已更新") });
  const emergencyMut = trpc.quant.risk.emergencyStop.useMutation({ onSuccess: () => toast.success("紧急停止已执行！所有策略已暂停") });
  const resolveAlertMut = trpc.quant.monitor.resolveAlert.useMutation({ onSuccess: () => toast.success("告警已处理") });

  const [showNewRule, setShowNewRule] = useState(false);
  const [newRule, setNewRule] = useState({
    name: "", description: "", ruleType: "position_limit", market: "a_share",
    thresholdValue: "", action: "block" as "block" | "alert" | "review", isMandatory: true,
  });

  return (
    <AdminLayout title="量化系统管理">
      <Tabs defaultValue="dashboard">
        <TabsList className="mb-6 flex-wrap">
          <TabsTrigger value="dashboard" className="gap-1"><BarChart3 className="w-4 h-4" />系统概览</TabsTrigger>
          <TabsTrigger value="risk" className="gap-1"><Shield className="w-4 h-4" />风控管理</TabsTrigger>
          <TabsTrigger value="compliance" className="gap-1"><FileText className="w-4 h-4" />合规审计</TabsTrigger>
          <TabsTrigger value="monitor" className="gap-1"><Activity className="w-4 h-4" />运维监控</TabsTrigger>
          <TabsTrigger value="data" className="gap-1"><Database className="w-4 h-4" />数据管理</TabsTrigger>
        </TabsList>

        {/* Dashboard */}
        <TabsContent value="dashboard">
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">系统状态</p>
                    <p className="text-lg font-bold text-green-600">{sysHealth ? "正常运行" : "检测中"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">风控规则</p>
                    <p className="text-lg font-bold">{riskRules?.length || 0} 条</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">未处理告警</p>
                    <p className="text-lg font-bold text-amber-600">{alerts?.filter((a: any) => a.status === "active").length || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                    <StopCircle className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">紧急停止</p>
                    <Button variant="destructive" size="sm" className="mt-1" onClick={() => emergencyMut.mutate()}>
                      一键停止
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Risk Logs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2"><AlertTriangle className="w-4 h-4" />最近风控触发</CardTitle>
            </CardHeader>
            <CardContent>
              {riskLogs && riskLogs.length > 0 ? (
                <div className="space-y-2">
                  {riskLogs.slice(0, 10).map((log: any) => (
                    <div key={log.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 text-sm">
                      <div className="flex items-center gap-3">
                        <Badge variant={log.triggerType === "blocked" ? "destructive" : "secondary"} className="text-xs">
                          {log.triggerType === "blocked" ? "拦截" : log.triggerType === "emergency_stop" ? "紧急停止" : log.triggerType}
                        </Badge>
                        <span className="font-mono">{log.symbol || "-"}</span>
                        <span className="text-muted-foreground">{log.triggerDetail?.substring(0, 60) || "-"}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">暂无风控触发记录</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Risk Management */}
        <TabsContent value="risk">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold flex items-center gap-2"><Shield className="w-5 h-5" />风控规则配置</h2>
            <div className="flex gap-2">
              <Button variant="destructive" className="gap-2" onClick={() => emergencyMut.mutate()}>
                <StopCircle className="w-4 h-4" />一键紧急停止
              </Button>
              <Dialog open={showNewRule} onOpenChange={setShowNewRule}>
                <DialogTrigger asChild>
                  <Button className="gap-2"><Plus className="w-4 h-4" />新增规则</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>创建风控规则</DialogTitle></DialogHeader>
                  <div className="space-y-3">
                    <Input placeholder="规则名称" value={newRule.name} onChange={(e) => setNewRule({ ...newRule, name: e.target.value })} />
                    <Textarea placeholder="规则描述" value={newRule.description} onChange={(e) => setNewRule({ ...newRule, description: e.target.value })} />
                    <Select value={newRule.ruleType} onValueChange={(v) => setNewRule({ ...newRule, ruleType: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="position_limit">持仓限额</SelectItem>
                        <SelectItem value="order_limit">单笔限额</SelectItem>
                        <SelectItem value="daily_loss_limit">日亏损限额</SelectItem>
                        <SelectItem value="frequency_limit">频率限制</SelectItem>
                        <SelectItem value="concentration_limit">集中度限制</SelectItem>
                        <SelectItem value="volatility_limit">波动率限制</SelectItem>
                        <SelectItem value="drawdown_limit">回撤限制</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="阈值" value={newRule.thresholdValue} onChange={(e) => setNewRule({ ...newRule, thresholdValue: e.target.value })} />
                    <Select value={newRule.action} onValueChange={(v) => setNewRule({ ...newRule, action: v as any })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="block">拦截（硬性）</SelectItem>
                        <SelectItem value="alert">告警</SelectItem>
                        <SelectItem value="review">人工审核</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex items-center gap-2">
                      <Switch checked={newRule.isMandatory} onCheckedChange={(v) => setNewRule({ ...newRule, isMandatory: v })} />
                      <span className="text-sm">强制执行（不可绕过）</span>
                    </div>
                    <Button className="w-full" onClick={() => createRuleMut.mutate(newRule, { onSuccess: () => setShowNewRule(false) })} disabled={!newRule.name || createRuleMut.isPending}>
                      创建规则
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {riskRules && riskRules.length > 0 ? (
            <div className="space-y-3">
              {riskRules.map((rule: any) => (
                <Card key={rule.id}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-3 h-3 rounded-full ${rule.isEnabled ? "bg-green-500" : "bg-gray-300"}`} />
                      <div>
                        <h3 className="font-medium flex items-center gap-2">
                          {rule.name}
                          {rule.isMandatory && <Badge variant="destructive" className="text-xs">强制</Badge>}
                        </h3>
                        <p className="text-sm text-muted-foreground">{rule.description || rule.ruleType} · 阈值: {rule.thresholdValue || "-"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={rule.action === "block" ? "destructive" : rule.action === "alert" ? "secondary" : "outline"}>
                        {rule.action === "block" ? "拦截" : rule.action === "alert" ? "告警" : "审核"}
                      </Badge>
                      <Switch checked={rule.isEnabled} onCheckedChange={(v) => updateRuleMut.mutate({ id: rule.id, isEnabled: v })} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card><CardContent className="py-16 text-center"><p className="text-muted-foreground">暂无风控规则，请创建</p></CardContent></Card>
          )}
        </TabsContent>

        {/* Compliance */}
        <TabsContent value="compliance">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><FileText className="w-5 h-5" />合规审计日志</h2>
          {complianceLogs && complianceLogs.length > 0 ? (
            <Card>
              <CardContent className="p-0">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-3">时间</th>
                      <th className="text-left p-3">操作人</th>
                      <th className="text-left p-3">操作类型</th>
                      <th className="text-left p-3">目标</th>
                      <th className="text-left p-3">详情</th>
                      <th className="text-left p-3">合规</th>
                    </tr>
                  </thead>
                  <tbody>
                    {complianceLogs.map((log: any) => (
                      <tr key={log.id} className="border-b hover:bg-muted/30">
                        <td className="p-3 text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString()}</td>
                        <td className="p-3">{log.operatorName || "-"}</td>
                        <td className="p-3"><Badge variant="outline" className="text-xs">{log.actionType}</Badge></td>
                        <td className="p-3 font-mono text-xs">{log.targetType}#{log.targetId}</td>
                        <td className="p-3 text-xs text-muted-foreground max-w-xs truncate">{log.detail?.substring(0, 80) || "-"}</td>
                        <td className="p-3">
                          {log.isCompliant ? <CheckCircle className="w-4 h-4 text-green-600" /> : <XCircle className="w-4 h-4 text-red-600" />}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          ) : (
            <Card><CardContent className="py-16 text-center"><p className="text-muted-foreground">暂无合规审计记录</p></CardContent></Card>
          )}
        </TabsContent>

        {/* Monitor */}
        <TabsContent value="monitor">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><Activity className="w-5 h-5" />运维监控</h2>

          {/* System Health */}
          {sysHealth && (
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              {Object.entries(sysHealth as Record<string, any>).map(([key, val]) => (
                <Card key={key}>
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground uppercase">{key}</p>
                    <p className="text-lg font-bold mt-1">{typeof val === "object" ? JSON.stringify(val) : String(val)}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Alerts */}
          <h3 className="font-bold mb-3 flex items-center gap-2"><AlertTriangle className="w-4 h-4" />告警列表</h3>
          {alerts && alerts.length > 0 ? (
            <div className="space-y-2">
              {alerts.map((alert: any) => (
                <Card key={alert.id}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${alert.severity === "critical" ? "bg-red-500" : alert.severity === "warning" ? "bg-amber-500" : "bg-blue-500"}`} />
                      <div>
                        <p className="font-medium text-sm">{alert.title}</p>
                        <p className="text-xs text-muted-foreground">{alert.message?.substring(0, 80) || "-"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={alert.status === "active" ? "destructive" : "secondary"} className="text-xs">
                        {alert.status === "active" ? "活跃" : "已处理"}
                      </Badge>
                      {alert.status === "active" && (
                        <Button size="sm" variant="outline" onClick={() => resolveAlertMut.mutate({ id: alert.id })}>处理</Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card><CardContent className="py-12 text-center"><p className="text-muted-foreground">暂无告警</p></CardContent></Card>
          )}
        </TabsContent>

        {/* Data Management */}
        <TabsContent value="data">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><Database className="w-5 h-5" />数据管理</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="w-4 h-4" />行情数据生成</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  生成A股、美股、港股、全球指数的模拟行情数据，包含实时价格、涨跌幅、成交量等完整字段。
                </p>
                <Button className="w-full gap-2" onClick={() => generateQuotesMut.mutate()} disabled={generateQuotesMut.isPending}>
                  {generateQuotesMut.isPending ? <><RefreshCw className="w-4 h-4 animate-spin" />生成中...</> : <><Zap className="w-4 h-4" />生成行情数据</>}
                </Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><Zap className="w-4 h-4" />IPO数据生成</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  生成模拟IPO新股发行数据，包含发行价、申购日期、上市日期等信息。
                </p>
                <Button className="w-full gap-2" onClick={() => generateIPOMut.mutate()} disabled={generateIPOMut.isPending}>
                  {generateIPOMut.isPending ? <><RefreshCw className="w-4 h-4 animate-spin" />生成中...</> : <><Zap className="w-4 h-4" />生成IPO数据</>}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}
