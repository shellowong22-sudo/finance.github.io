import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Shield, Plus, Trash2, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminCompliance() {
  const [newWord, setNewWord] = useState("");
  const [wordCategory, setWordCategory] = useState<"finance" | "political" | "obscene" | "fraud" | "other">("finance");
  const [wordLevel, setWordLevel] = useState<"block" | "review" | "warn">("block");
  const [open, setOpen] = useState(false);
  const utils = trpc.useUtils();

  const { data: sensitiveWords, isLoading: wordsLoading } = trpc.admin.sensitiveWords.useQuery();
  const { data: auditLogs } = trpc.admin.auditLogs.useQuery({ page: 1 });
  const { data: pendingArticles } = trpc.admin.pendingArticles.useQuery({ page: 1 });

  const addWordMutation = trpc.admin.addSensitiveWord.useMutation({
    onSuccess: () => { toast.success("敏感词添加成功"); setOpen(false); setNewWord(""); utils.admin.sensitiveWords.invalidate(); },
    onError: (e: any) => toast.error(e.message),
  });
  const deleteWordMutation = trpc.admin.deleteSensitiveWord.useMutation({
    onSuccess: () => { toast.success("敏感词已删除"); utils.admin.sensitiveWords.invalidate(); },
    onError: (e: any) => toast.error(e.message),
  });
  const reviewMutation = trpc.article.review.useMutation({
    onSuccess: () => { toast.success("操作成功"); utils.admin.pendingArticles.invalidate(); },
    onError: (e: any) => toast.error(e.message),
  });

  const levelConfig: Record<string, { label: string; color: string }> = {
    block: { label: "拦截", color: "bg-red-100 text-red-700" },
    review: { label: "审核", color: "bg-yellow-100 text-yellow-700" },
    warn: { label: "警告", color: "bg-blue-100 text-blue-700" },
  };
  const categoryConfig: Record<string, string> = {
    finance: "金融违规", political: "政治敏感", obscene: "违规内容", fraud: "诈骗话术", other: "其他"
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">合规监控</h1>
          <p className="text-muted-foreground text-sm">敏感词管理、内容审核、合规日志</p>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-3 gap-4">
          <Card className="border-red-200 bg-red-50/50">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-red-500" />
              <div>
                <div className="text-2xl font-bold text-red-700">{sensitiveWords?.length || 0}</div>
                <div className="text-sm text-red-600">敏感词总数</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-yellow-200 bg-yellow-50/50">
            <CardContent className="p-4 flex items-center gap-3">
              <Clock className="w-8 h-8 text-yellow-500" />
              <div>
                <div className="text-2xl font-bold text-yellow-700">{pendingArticles?.total || 0}</div>
                <div className="text-sm text-yellow-600">待审核文章</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-green-200 bg-green-50/50">
            <CardContent className="p-4 flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-500" />
              <div>
                <div className="text-2xl font-bold text-green-700">{auditLogs?.total || 0}</div>
                <div className="text-sm text-green-600">审核操作记录</div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Sensitive Words */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="w-4 h-4" />敏感词库
              </CardTitle>
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="gap-1"><Plus className="w-3 h-3" />添加</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>添加敏感词</DialogTitle></DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>敏感词 *</Label>
                      <Input className="mt-1" value={newWord} onChange={e => setNewWord(e.target.value)} placeholder="输入敏感词" />
                    </div>
                    <div>
                      <Label>分类</Label>
                      <Select value={wordCategory} onValueChange={v => setWordCategory(v as any)}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {Object.entries(categoryConfig).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>处理级别</Label>
                      <Select value={wordLevel} onValueChange={v => setWordLevel(v as any)}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="block">拦截（直接屏蔽）</SelectItem>
                          <SelectItem value="review">审核（转人工审核）</SelectItem>
                          <SelectItem value="warn">警告（提示用户）</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button className="w-full" onClick={() => addWordMutation.mutate({ word: newWord, category: wordCategory, level: wordLevel })} disabled={!newWord || addWordMutation.isPending}>
                      {addWordMutation.isPending ? "添加中..." : "添加敏感词"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-80 overflow-y-auto divide-y divide-border">
                {wordsLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <div key={i} className="p-3 flex justify-between"><div className="h-4 w-24 bg-muted animate-pulse rounded" /><div className="h-4 w-16 bg-muted animate-pulse rounded" /></div>)
                ) : sensitiveWords?.map(word => (
                  <div key={word.id} className="px-4 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm">{word.word}</span>
                      <Badge className={`text-xs ${levelConfig[word.level]?.color}`}>{levelConfig[word.level]?.label}</Badge>
                      <span className="text-xs text-muted-foreground">{categoryConfig[word.category]}</span>
                    </div>
                    <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700" onClick={() => deleteWordMutation.mutate({ id: word.id })}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
                {sensitiveWords?.length === 0 && <div className="p-8 text-center text-muted-foreground text-sm">暂无敏感词</div>}
              </div>
            </CardContent>
          </Card>

          {/* Pending Articles */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4" />待审核文章
                {(pendingArticles?.total || 0) > 0 && <Badge className="bg-yellow-100 text-yellow-700">{pendingArticles?.total}</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-80 overflow-y-auto divide-y divide-border">
                {pendingArticles?.data?.map(article => (
                  <div key={article.id} className="px-4 py-3">
                    <p className="text-sm font-medium line-clamp-1">{article.title}</p>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{article.summary}</p>
                    <div className="flex gap-2 mt-2">
                      <Button size="sm" className="h-6 text-xs bg-green-600 hover:bg-green-700" onClick={() => reviewMutation.mutate({ id: article.id, action: "approve" })}>通过</Button>
                      <Button size="sm" variant="destructive" className="h-6 text-xs" onClick={() => reviewMutation.mutate({ id: article.id, action: "reject" })}>拒绝</Button>
                    </div>
                  </div>
                ))}
                {(!pendingArticles?.data || pendingArticles.data.length === 0) && (
                  <div className="p-8 text-center text-muted-foreground text-sm">
                    <CheckCircle className="w-6 h-6 mx-auto mb-1 text-green-500" />
                    暂无待审核文章
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Audit Logs */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">操作审计日志</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {auditLogs?.data?.slice(0, 10).map(log => (
                <div key={log.id} className="px-6 py-3 flex items-center justify-between">
                  <div>
                    <span className="text-sm font-medium">{log.action}</span>
                    <span className="text-xs text-muted-foreground ml-2">{log.targetType} #{log.targetId}</span>
                    {log.remark && <span className="text-xs text-muted-foreground ml-2">- {log.remark}</span>}
                  </div>
                  <span className="text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString("zh-CN")}</span>
                </div>
              ))}
              {(!auditLogs?.data || auditLogs.data.length === 0) && (
                <div className="p-8 text-center text-muted-foreground text-sm">暂无审计日志</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
