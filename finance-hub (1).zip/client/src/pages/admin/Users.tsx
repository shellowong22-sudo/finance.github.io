import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminUsers() {
  const [page, setPage] = useState(1);
  const [keyword, setKeyword] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.admin.users.useQuery({ page, limit: 10 });
  const updateRoleMutation = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => { toast.success("角色更新成功"); utils.admin.users.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const maskEmail = (email: string | null) => {
    if (!email) return "-";
    const [local, domain] = email.split("@");
    if (!local || !domain) return email;
    return `${local.charAt(0)}***@${domain}`;
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">用户管理</h1>
            <p className="text-muted-foreground text-sm">管理平台用户，设置角色权限</p>
          </div>
          <div className="flex gap-2">
            <Input placeholder="搜索用户..." value={keyword} onChange={e => setKeyword(e.target.value)} className="w-48"
              onKeyDown={e => { if (e.key === "Enter") { setSearchVal(keyword); setPage(1); } }} />
            <Button size="sm" onClick={() => { setSearchVal(keyword); setPage(1); }}><Search className="w-4 h-4" /></Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{data?.total || 0}</div>
              <div className="text-sm text-muted-foreground">总用户数</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{data?.data?.filter(u => u.role === "user").length || 0}</div>
              <div className="text-sm text-muted-foreground">普通用户</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-amber-600">{data?.data?.filter(u => u.role === "admin").length || 0}</div>
              <div className="text-sm text-muted-foreground">管理员</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/30">
                  <tr>
                    <th className="text-left p-4 font-medium text-muted-foreground">ID</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">用户名</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">邮箱（脱敏）</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">角色</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">注册时间</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">最后登录</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-border">
                        {Array.from({ length: 7 }).map((_, j) => <td key={j} className="p-4"><div className="h-4 bg-muted animate-pulse rounded" /></td>)}
                      </tr>
                    ))
                  ) : data?.data?.map(user => (
                    <tr key={user.id} className="border-b border-border hover:bg-muted/20 transition-colors">
                      <td className="p-4 text-muted-foreground">#{user.id}</td>
                      <td className="p-4 font-medium">{user.name || "未设置"}</td>
                      <td className="p-4 text-muted-foreground font-mono text-xs">{maskEmail(user.email)}</td>
                      <td className="p-4">
                        <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                          {user.role === "admin" ? "管理员" : "普通用户"}
                        </Badge>
                      </td>
                      <td className="p-4 text-muted-foreground">{new Date(user.createdAt).toLocaleDateString("zh-CN")}</td>
                      <td className="p-4 text-muted-foreground">{user.lastSignedIn ? new Date(user.lastSignedIn).toLocaleDateString("zh-CN") : "-"}</td>
                      <td className="p-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateRoleMutation.mutate({ userId: user.id, role: user.role === "admin" ? "user" : "admin" })}
                          disabled={updateRoleMutation.isPending}
                        >
                          {user.role === "admin" ? "降为用户" : "设为管理员"}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {data?.data?.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>暂无用户数据</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {data && data.total > 10 && (
          <div className="flex justify-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
            <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页 / 共 {Math.ceil(data.total / 10)} 页</span>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 10)} onClick={() => setPage(p => p + 1)}>下一页</Button>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
