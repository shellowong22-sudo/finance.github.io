import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Globe, Zap, Database, RefreshCw, CheckCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminCrawler() {
  const [crawlCount, setCrawlCount] = useState(5);
  const [sampleCount, setSampleCount] = useState(3);
  const utils = trpc.useUtils();

  const crawlMutation = trpc.admin.crawlArticles.useMutation({
    onSuccess: (data) => {
      toast.success(`成功采集 ${data.count} 篇文章`);
      utils.article.list.invalidate();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const generateArticlesMutation = trpc.admin.generateSampleData.useMutation({
    onSuccess: (data) => {
      toast.success(`成功生成 ${data.count} 条数据`);
      utils.article.list.invalidate();
      utils.report.list.invalidate();
      utils.course.list.invalidate();
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">数据采集与AI生成</h1>
          <p className="text-muted-foreground text-sm">爬取三分钟学财经文章，AI生成示例数据</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Crawler */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-blue-500" />
                文章爬虫采集
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 bg-blue-50 rounded-lg text-sm text-blue-700">
                <p className="font-medium">数据来源：三分钟学财经</p>
                <p className="mt-1 text-blue-600">自动采集公开金融资讯文章，经合规过滤后导入系统</p>
              </div>
              <div>
                <Label>采集数量：{crawlCount} 篇</Label>
                <Slider
                  className="mt-2"
                  min={1}
                  max={20}
                  step={1}
                  value={[crawlCount]}
                  onValueChange={([v]) => setCrawlCount(v)}
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>1篇</span><span>20篇</span>
                </div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg text-xs text-muted-foreground space-y-1">
                <p>• 自动过滤敏感词和违规内容</p>
                <p>• 文章以草稿状态入库，需审核后发布</p>
                <p>• 采集内容仅供学习参考，请遵守版权规定</p>
              </div>
              <Button
                className="w-full gap-2"
                onClick={() => crawlMutation.mutate()}
                disabled={crawlMutation.isPending}
              >
                {crawlMutation.isPending ? (
                  <><RefreshCw className="w-4 h-4 animate-spin" />采集中...</>
                ) : (
                  <><Globe className="w-4 h-4" />开始采集</>
                )}
              </Button>
              {crawlMutation.isSuccess && (
                <div className="flex items-center gap-2 text-green-600 text-sm">
                  <CheckCircle className="w-4 h-4" />
                  采集完成，已导入 {crawlMutation.data?.count} 篇文章
                </div>
              )}
            </CardContent>
          </Card>

          {/* AI Data Generator */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-500" />
                AI 示例数据生成
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 bg-amber-50 rounded-lg text-sm text-amber-700">
                <p className="font-medium">AI深度学习生成</p>
                <p className="mt-1 text-amber-600">使用大语言模型生成专业金融内容，快速填充平台数据</p>
              </div>
              <div>
                <Label>每类生成数量：{sampleCount} 条</Label>
                <Slider
                  className="mt-2"
                  min={1}
                  max={10}
                  step={1}
                  value={[sampleCount]}
                  onValueChange={([v]) => setSampleCount(v)}
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>1条</span><span>10条</span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-muted/30 rounded">
                  <div className="font-medium">{sampleCount}</div>
                  <div className="text-muted-foreground">文章</div>
                </div>
                <div className="p-2 bg-muted/30 rounded">
                  <div className="font-medium">{sampleCount}</div>
                  <div className="text-muted-foreground">研报</div>
                </div>
                <div className="p-2 bg-muted/30 rounded">
                  <div className="font-medium">{sampleCount}</div>
                  <div className="text-muted-foreground">课程</div>
                </div>
              </div>
              <Button
                className="w-full gap-2 bg-amber-600 hover:bg-amber-700"
                onClick={() => generateArticlesMutation.mutate({ type: "articles", count: sampleCount })}
                disabled={generateArticlesMutation.isPending}
              >
                {generateArticlesMutation.isPending ? (
                  <><RefreshCw className="w-4 h-4 animate-spin" />AI生成中...</>
                ) : (
                  <><Zap className="w-4 h-4" />AI生成数据</>
                )}
              </Button>
              {generateArticlesMutation.isSuccess && (
                <div className="flex items-center gap-2 text-green-600 text-sm">
                  <CheckCircle className="w-4 h-4" />
                  生成完成！共 {generateArticlesMutation.data?.count} 条数据
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Data Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Database className="w-4 h-4" />数据库状态
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "文章数据", desc: "包含草稿、已发布、待审核" },
                { label: "研报数据", desc: "宏观/行业/个股分类" },
                { label: "课程数据", desc: "视频/图文/直播课程" },
                { label: "用户数据", desc: "注册用户及行为数据" },
              ].map(item => (
                <div key={item.label} className="p-3 border border-border rounded-lg">
                  <div className="font-medium text-sm">{item.label}</div>
                  <div className="text-xs text-muted-foreground mt-1">{item.desc}</div>
                  <Badge variant="secondary" className="mt-2 text-xs">已初始化</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
