import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { TrendingUp, Plus, Eye, Download } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const categoryMap: Record<string, string> = { macro: "宏观", industry: "行业", stock: "个股", strategy: "策略", fixed_income: "固收" };

export default function AdminReports() {
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "", summary: "", institution: "",
    category: "macro" as "macro" | "industry" | "stock" | "strategy" | "fixed_income",
    fileUrl: "", fileKey: "", fileType: "pdf" as "pdf" | "word",
    isPaid: false, price: "",
  });
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.report.list.useQuery({ page, limit: 10 });
  const createMutation = trpc.report.create.useMutation({
    onSuccess: () => { toast.success("研报创建成功"); setOpen(false); utils.report.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const updateMutation = trpc.report.update.useMutation({
    onSuccess: () => utils.report.list.invalidate(),
    onError: (e) => toast.error(e.message),
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">研报管理</h1>
            <p className="text-muted-foreground text-sm">管理金融研报，设置付费权限</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="w-4 h-4" />上传研报</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>上传研报</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>研报标题 *</Label>
                  <Input className="mt-1" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
                </div>
                <div>
                  <Label>摘要</Label>
                  <Textarea className="mt-1" value={form.summary} onChange={e => setForm(f => ({ ...f, summary: e.target.value }))} rows={3} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>发布机构</Label>
                    <Input className="mt-1" value={form.institution} onChange={e => setForm(f => ({ ...f, institution: e.target.value }))} />
                  </div>
                  <div>
                    <Label>分类</Label>
                    <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v as any }))}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(categoryMap).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label>文件URL *</Label>
                  <Input className="mt-1" value={form.fileUrl} onChange={e => setForm(f => ({ ...f, fileUrl: e.target.value }))} placeholder="https://..." />
                </div>
                <div>
                  <Label>文件Key *</Label>
                  <Input className="mt-1" value={form.fileKey} onChange={e => setForm(f => ({ ...f, fileKey: e.target.value }))} placeholder="reports/xxx.pdf" />
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={form.isPaid} onCheckedChange={v => setForm(f => ({ ...f, isPaid: v }))} />
                  <Label>付费研报</Label>
                </div>
                {form.isPaid && (
                  <div>
                    <Label>价格（元）</Label>
                    <Input className="mt-1" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
                  </div>
                )}
                <Button className="w-full" onClick={() => createMutation.mutate({ ...form, price: form.price || undefined })} disabled={!form.title || !form.fileUrl || !form.fileKey || createMutation.isPending}>
                  {createMutation.isPending ? "上传中..." : "上传研报"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/30">
                  <tr>
                    <th className="text-left p-4 font-medium text-muted-foreground">研报标题</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">机构</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">分类</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">价格</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">阅读/下载</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">状态</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-border">
                        {Array.from({ length: 7 }).map((_, j) => <td key={j} className="p-4"><div className="h-4 bg-muted animate-pulse rounded" /></td>)}
                      </tr>
                    ))
                  ) : data?.data?.map(report => (
                    <tr key={report.id} className="border-b border-border hover:bg-muted/20 transition-colors">
                      <td className="p-4">
                        <div className="font-medium line-clamp-1">{report.title}</div>
                        <div className="text-xs text-muted-foreground">{report.fileType?.toUpperCase()}</div>
                      </td>
                      <td className="p-4 text-muted-foreground">{report.institution || "-"}</td>
                      <td className="p-4"><Badge variant="secondary">{categoryMap[report.category] || report.category}</Badge></td>
                      <td className="p-4">{report.isPaid ? <span className="font-medium text-amber-600">¥{report.price}</span> : <span className="text-green-600">免费</span>}</td>
                      <td className="p-4">
                        <span className="flex items-center gap-2 text-muted-foreground">
                          <Eye className="w-3 h-3" />{report.viewCount}
                          <Download className="w-3 h-3" />{report.downloadCount}
                        </span>
                      </td>
                      <td className="p-4">
                        <Badge variant={report.status === "published" ? "default" : "secondary"}>
                          {report.status === "published" ? "已发布" : "草稿"}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Button variant="ghost" size="sm" onClick={() => updateMutation.mutate({ id: report.id, status: report.status === "published" ? "offline" : "published" })}>
                          {report.status === "published" ? "下架" : "上架"}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {data?.data?.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <TrendingUp className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>暂无研报</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {data && data.total > 10 && (
          <div className="flex justify-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
            <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页</span>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 10)} onClick={() => setPage(p => p + 1)}>下一页</Button>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
