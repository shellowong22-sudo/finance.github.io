import { useState } from "react";
import { trpc } from "@/lib/trpc";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import {
  Brain, Globe, RefreshCw, CheckCircle, XCircle, Clock,
  Download, Zap, BarChart3, AlertTriangle, TrendingUp,
  FileText, Activity, Settings, Play, Pause, Eye
} from "lucide-react";

export default function AdminAIManage() {
  const [crawlCount, setCrawlCount] = useState(5);
  const [crawlResults, setCrawlResults] = useState<string[]>([]);
  const [isCrawling, setIsCrawling] = useState(false);
  const [generateType, setGenerateType] = useState<"articles" | "reports" | "courses">("articles");
  const [generateCount, setGenerateCount] = useState(5);
  const [aiTaskLogs, setAiTaskLogs] = useState<Array<{time: string; task: string; status: "success" | "error" | "running"; detail: string}>>([]);

  // 爬虫文章列表
  const { data: crawledData, refetch: refetchCrawled } = trpc.admin.crawledArticles.useQuery({ page: 1 });
  // 爬虫触发
  const crawlMutation = trpc.admin.crawlArticles.useMutation({
    onSuccess: (data) => {
      setIsCrawling(false);
      setCrawlResults(data.titles || []);
      toast.success(`成功爬取并AI改写 ${data.count} 篇文章`);
      addLog("新浪财经爬虫+AI改写", "success", `成功处理 ${data.count} 篇，标题：${(data.titles || []).slice(0, 2).join("、")}`);
      refetchCrawled();
    },
    onError: (err) => {
      setIsCrawling(false);
      toast.error("爬虫失败：" + err.message);
      addLog("新浪财经爬虫+AI改写", "error", err.message);
    }
  });
  // 导入爬虫文章
  const importMutation = trpc.admin.importCrawledArticle.useMutation({
    onSuccess: () => { toast.success("文章已导入发布系统"); refetchCrawled(); },
    onError: (err) => toast.error("导入失败：" + err.message),
  });
  // AI数据生成
  const generateMutation = trpc.admin.generateSampleData.useMutation({
    onSuccess: (data) => {
      toast.success(`AI成功生成 ${data.count} 条${generateType === "articles" ? "文章" : generateType === "reports" ? "研报" : "课程"}数据`);
      addLog(`AI生成${generateType}数据`, "success", `生成 ${data.count} 条数据`);
    },
    onError: (err) => {
      toast.error("生成失败：" + err.message);
      addLog(`AI生成${generateType}数据`, "error", err.message);
    }
  });

  const addLog = (task: string, status: "success" | "error" | "running", detail: string) => {
    setAiTaskLogs(prev => [{
      time: new Date().toLocaleTimeString(),
      task, status, detail
    }, ...prev.slice(0, 19)]);
  };

  const handleCrawl = () => {
    setIsCrawling(true);
    setCrawlResults([]);
    addLog("新浪财经爬虫+AI改写", "running", `准备爬取 ${crawlCount} 篇文章...`);
    crawlMutation.mutate({ count: crawlCount });
  };

  const handleGenerate = () => {
    addLog(`AI生成${generateType}数据`, "running", `正在生成 ${generateCount} 条...`);
    generateMutation.mutate({ type: generateType, count: generateCount });
  };

  // AI模型能力列表
  const aiCapabilities = [
    { name: "文章情感分析", model: "LLM-Finance-v2", status: "active", accuracy: 94, calls: 1284 },
    { name: "智能内容推荐", model: "Collaborative-Filter", status: "active", accuracy: 87, calls: 3421 },
    { name: "风险等级预测", model: "Risk-Assessment-v1", status: "active", accuracy: 91, calls: 567 },
    { name: "用户画像分析", model: "User-Profile-AI", status: "active", accuracy: 88, calls: 892 },
    { name: "内容摘要生成", model: "Summarizer-v3", status: "active", accuracy: 96, calls: 2103 },
    { name: "市场趋势分析", model: "Market-Trend-AI", status: "active", accuracy: 82, calls: 445 },
    { name: "违规内容检测", model: "Compliance-Guard", status: "active", accuracy: 99, calls: 5678 },
    { name: "文章AI改写", model: "Rewriter-Finance", status: "active", accuracy: 93, calls: 234 },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Brain className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">AI深度学习管理</h1>
            <p className="text-muted-foreground text-sm">管理AI模型、数据爬虫与内容生成任务</p>
          </div>
        </div>

        {/* 概览统计 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-2 mb-1">
                <Brain className="w-4 h-4 text-primary" />
                <span className="text-sm text-muted-foreground">AI模型数量</span>
              </div>
              <p className="text-2xl font-bold">8</p>
              <p className="text-xs text-green-500 mt-1">全部在线</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-2 mb-1">
                <Globe className="w-4 h-4 text-blue-500" />
                <span className="text-sm text-muted-foreground">已爬取文章</span>
              </div>
              <p className="text-2xl font-bold">{crawledData?.total || 0}</p>
              <p className="text-xs text-muted-foreground mt-1">含AI改写版本</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-2 mb-1">
                <Zap className="w-4 h-4 text-yellow-500" />
                <span className="text-sm text-muted-foreground">今日AI调用</span>
              </div>
              <p className="text-2xl font-bold">14,624</p>
              <p className="text-xs text-green-500 mt-1">↑ 12% vs 昨日</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-2 mb-1">
                <Activity className="w-4 h-4 text-green-500" />
                <span className="text-sm text-muted-foreground">平均准确率</span>
              </div>
              <p className="text-2xl font-bold">91.8%</p>
              <p className="text-xs text-muted-foreground mt-1">综合评估</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="crawler">
          <TabsList className="grid grid-cols-4 w-full max-w-lg">
            <TabsTrigger value="crawler"><Globe className="w-3 h-3 mr-1" />爬虫管理</TabsTrigger>
            <TabsTrigger value="generate"><Zap className="w-3 h-3 mr-1" />AI生成</TabsTrigger>
            <TabsTrigger value="models"><Brain className="w-3 h-3 mr-1" />模型状态</TabsTrigger>
            <TabsTrigger value="logs"><FileText className="w-3 h-3 mr-1" />任务日志</TabsTrigger>
          </TabsList>

          {/* 爬虫管理 */}
          <TabsContent value="crawler" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Globe className="w-4 h-4 text-blue-500" />爬虫配置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg text-sm">
                    <p className="font-medium text-blue-600 mb-1">数据源：新浪财经</p>
                    <p className="text-muted-foreground text-xs">爬取最新金融资讯，通过AI改写为「三分钟学财经」风格</p>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">爬取数量</label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        min={1}
                        max={20}
                        value={crawlCount}
                        onChange={e => setCrawlCount(Number(e.target.value))}
                        className="w-24"
                      />
                      <span className="text-sm text-muted-foreground self-center">篇（最多20篇）</span>
                    </div>
                  </div>
                  <div className="space-y-2 text-xs text-muted-foreground">
                    <div className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-green-500" />爬取文章列表</div>
                    <div className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-green-500" />抓取文章正文</div>
                    <div className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-green-500" />AI改写用词句式</div>
                    <div className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-green-500" />保存至爬虫库</div>
                  </div>
                  <Button onClick={handleCrawl} className="w-full" disabled={isCrawling}>
                    <RefreshCw className={`w-4 h-4 mr-2 ${isCrawling ? "animate-spin" : ""}`} />
                    {isCrawling ? `爬取中...` : "立即爬取+AI改写"}
                  </Button>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="text-base">爬取结果预览</CardTitle>
                </CardHeader>
                <CardContent>
                  {isCrawling && (
                    <div className="space-y-3 mb-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <RefreshCw className="w-4 h-4 animate-spin text-primary" />
                        <span>正在爬取新浪财经并AI改写...</span>
                      </div>
                      <Progress value={undefined} className="h-1.5 animate-pulse" />
                    </div>
                  )}
                  {crawlResults.length > 0 && (
                    <div className="mb-4">
                      <p className="text-sm font-medium mb-2 text-green-600">✓ 本次改写完成 {crawlResults.length} 篇：</p>
                      <ul className="space-y-1">
                        {crawlResults.map((title, i) => (
                          <li key={i} className="text-xs text-muted-foreground flex items-start gap-1">
                            <span className="text-green-400 mt-0.5">•</span>{title}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <div className="space-y-2">
                    <p className="text-sm font-medium">爬虫库文章（{crawledData?.total || 0} 篇）</p>
                    {crawledData?.data?.length === 0 ? (
                      <p className="text-muted-foreground text-sm py-4 text-center">暂无爬取数据，点击"立即爬取"开始</p>
                    ) : (
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {crawledData?.data?.map((article: any) => (
                          <div key={article.id} className="flex items-start justify-between p-2 bg-muted/30 rounded text-xs gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium truncate">{article.title}</p>
                              {article.originalTitle && article.originalTitle !== article.title && (
                                <p className="text-muted-foreground truncate">原标题：{article.originalTitle}</p>
                              )}
                              <p className="text-muted-foreground">来源：{article.author} · {article.isImported ? "已导入" : "待导入"}</p>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {article.isImported ? (
                                <Badge variant="secondary" className="text-xs">已发布</Badge>
                              ) : (
                                <Button size="sm" variant="outline" className="h-6 text-xs px-2"
                                  onClick={() => importMutation.mutate({ crawledId: article.id })}>
                                  <Download className="w-3 h-3 mr-1" />导入
                                </Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* AI数据生成 */}
          <TabsContent value="generate" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-500" />AI批量数据生成
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-sm">
                    <p className="text-yellow-700">AI将根据所选类型，自动生成专业的金融内容数据并直接写入数据库</p>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">生成类型</label>
                    <Select value={generateType} onValueChange={(v: any) => setGenerateType(v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="articles">金融资讯文章</SelectItem>
                        <SelectItem value="reports">金融研报</SelectItem>
                        <SelectItem value="courses">金融课程</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">生成数量</label>
                    <Input type="number" min={1} max={20} value={generateCount} onChange={e => setGenerateCount(Number(e.target.value))} />
                  </div>
                  <Button onClick={handleGenerate} className="w-full" disabled={generateMutation.isPending}>
                    <Brain className={`w-4 h-4 mr-2 ${generateMutation.isPending ? "animate-spin" : ""}`} />
                    {generateMutation.isPending ? "AI生成中..." : "开始AI生成"}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle className="text-base">快速操作</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: "生成10篇金融资讯", type: "articles" as const, count: 10, icon: FileText, color: "text-blue-500" },
                    { label: "生成5份研报摘要", type: "reports" as const, count: 5, icon: BarChart3, color: "text-purple-500" },
                    { label: "生成3门金融课程", type: "courses" as const, count: 3, icon: Brain, color: "text-green-500" },
                  ].map(item => (
                    <div key={item.label} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <item.icon className={`w-4 h-4 ${item.color}`} />
                        <span className="text-sm">{item.label}</span>
                      </div>
                      <Button size="sm" variant="outline"
                        disabled={generateMutation.isPending}
                        onClick={() => { setGenerateType(item.type); setGenerateCount(item.count); generateMutation.mutate({ type: item.type, count: item.count }); }}>
                        <Play className="w-3 h-3 mr-1" />执行
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* AI模型状态 */}
          <TabsContent value="models">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Brain className="w-4 h-4 text-primary" />AI模型运行状态
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {aiCapabilities.map((model, i) => (
                    <div key={i} className="flex items-center gap-4 p-3 border rounded-lg hover:bg-muted/30 transition-colors">
                      <div className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-sm font-medium">{model.name}</p>
                          <Badge variant="outline" className="text-xs">{model.model}</Badge>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>准确率：{model.accuracy}%</span>
                          <span>调用次数：{model.calls.toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="w-24 shrink-0">
                        <div className="flex justify-between text-xs mb-1">
                          <span>准确率</span><span>{model.accuracy}%</span>
                        </div>
                        <Progress value={model.accuracy} className="h-1.5" />
                      </div>
                      <Badge className="bg-green-500/10 text-green-600 border-green-500/20 shrink-0">在线</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 任务日志 */}
          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center justify-between">
                  <span className="flex items-center gap-2"><FileText className="w-4 h-4" />AI任务执行日志</span>
                  <Button size="sm" variant="outline" onClick={() => setAiTaskLogs([])}>清空日志</Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {aiTaskLogs.length === 0 ? (
                  <div className="text-center py-10 text-muted-foreground text-sm">
                    <Clock className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>暂无任务记录，执行爬虫或AI生成后将在此显示</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {aiTaskLogs.map((log, i) => (
                      <div key={i} className="flex items-start gap-3 p-2 bg-muted/30 rounded text-xs">
                        {log.status === "success" ? <CheckCircle className="w-3 h-3 text-green-500 mt-0.5 shrink-0" /> :
                          log.status === "error" ? <XCircle className="w-3 h-3 text-red-500 mt-0.5 shrink-0" /> :
                          <RefreshCw className="w-3 h-3 text-blue-500 mt-0.5 shrink-0 animate-spin" />}
                        <div className="flex-1">
                          <span className="font-medium">[{log.time}]</span>{" "}
                          <span className={log.status === "success" ? "text-green-600" : log.status === "error" ? "text-red-600" : "text-blue-600"}>
                            {log.task}
                          </span>{" "}
                          <span className="text-muted-foreground">{log.detail}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}
