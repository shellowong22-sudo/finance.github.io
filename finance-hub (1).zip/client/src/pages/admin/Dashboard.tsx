import AdminLayout from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FileText, TrendingUp, BookOpen, Users, Globe, BarChart3, CheckCircle, Clock, AlertTriangle } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats } = trpc.admin.dashboard.useQuery();
  const { data: recentArticles } = trpc.article.list.useQuery({ page: 1 });
  const { data: pendingChannels } = trpc.channel.adminList.useQuery({ page: 1, status: "pending" });

  const statCards = [
    { label: "文章总数", value: stats?.totalArticles || 0, icon: FileText, color: "text-blue-500", bg: "bg-blue-50" },
    { label: "研报总数", value: stats?.totalReports || 0, icon: TrendingUp, color: "text-amber-500", bg: "bg-amber-50" },
    { label: "课程总数", value: stats?.totalCourses || 0, icon: BookOpen, color: "text-green-500", bg: "bg-green-50" },
    { label: "用户总数", value: stats?.totalUsers || 0, icon: Users, color: "text-purple-500", bg: "bg-purple-50" },
    { label: "渠道合作", value: stats?.pendingChannels || 0, icon: Globe, color: "text-indigo-500", bg: "bg-indigo-50" },
    { label: "待审核文章", value: stats?.pendingArticles || 0, icon: Clock, color: "text-orange-500", bg: "bg-orange-50" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">数据总览</h1>
          <p className="text-muted-foreground text-sm mt-1">金融综合服务平台后台管理系统</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {statCards.map(card => (
            <Card key={card.label}>
              <CardContent className="p-4">
                <div className={`w-8 h-8 rounded-lg ${card.bg} flex items-center justify-center mb-3`}>
                  <card.icon className={`w-4 h-4 ${card.color}`} />
                </div>
                <div className="text-2xl font-bold">{card.value}</div>
                <div className="text-xs text-muted-foreground mt-1">{card.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "发布文章", href: "/admin/articles", icon: FileText },
            { label: "上传研报", href: "/admin/reports", icon: TrendingUp },
            { label: "管理课程", href: "/admin/courses", icon: BookOpen },
            { label: "渠道审核", href: "/admin/channels", icon: Globe },
          ].map(action => (
            <Button key={action.label} variant="outline" className="h-auto py-3 gap-2 flex-col" asChild>
              <Link href={action.href}>
                <action.icon className="w-5 h-5" />
                <span className="text-sm">{action.label}</span>
              </Link>
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Articles */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-base">最新文章</CardTitle>
              <Button variant="ghost" size="sm" asChild><Link href="/admin/articles">查看全部</Link></Button>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {recentArticles?.data?.map(article => (
                  <div key={article.id} className="px-6 py-3 flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{article.title}</p>
                      <p className="text-xs text-muted-foreground">{article.publishedAt ? new Date(article.publishedAt).toLocaleDateString("zh-CN") : "草稿"}</p>
                    </div>
                    <Badge variant={article.status === "published" ? "default" : article.status === "pending" ? "outline" : "secondary"} className="ml-2 shrink-0 text-xs">
                      {article.status === "published" ? "已发布" : article.status === "pending" ? "待审核" : "草稿"}
                    </Badge>
                  </div>
                ))}
                {(!recentArticles?.data || recentArticles.data.length === 0) && (
                  <div className="px-6 py-8 text-center text-muted-foreground text-sm">暂无文章</div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Pending Channels */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                待审核渠道
                {(pendingChannels?.total || 0) > 0 && (
                  <Badge className="bg-orange-100 text-orange-700 border-orange-200">{pendingChannels?.total}</Badge>
                )}
              </CardTitle>
              <Button variant="ghost" size="sm" asChild><Link href="/admin/channels">查看全部</Link></Button>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {pendingChannels?.data?.map(channel => (
                  <div key={channel.id} className="px-6 py-3 flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{channel.companyName}</p>
                      <p className="text-xs text-muted-foreground">{channel.channelType} · {new Date(channel.createdAt).toLocaleDateString("zh-CN")}</p>
                    </div>
                    <Badge variant="outline" className="ml-2 shrink-0 text-xs text-orange-600 border-orange-300">待审核</Badge>
                  </div>
                ))}
                {(!pendingChannels?.data || pendingChannels.data.length === 0) && (
                  <div className="px-6 py-8 text-center text-muted-foreground text-sm">
                    <CheckCircle className="w-6 h-6 mx-auto mb-1 text-green-500" />
                    暂无待审核渠道
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Compliance Alert */}
        <Card className="border-amber-200 bg-amber-50/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-800">合规提醒</p>
                <p className="text-sm text-amber-700 mt-1">
                  系统已启用敏感词过滤，禁止发布虚假金融信息、违规理财话术。所有用户数据已启用脱敏保护。
                  如发现违规内容，请及时处理。
                </p>
                <Button variant="outline" size="sm" className="mt-2 border-amber-300 text-amber-700 hover:bg-amber-100" asChild>
                  <Link href="/admin/compliance">查看合规监控</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
