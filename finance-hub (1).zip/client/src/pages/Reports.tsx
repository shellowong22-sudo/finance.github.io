import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { TrendingUp, Search, Eye, Download, Star, Lock } from "lucide-react";
import { useState } from "react";

const categories = [
  { value: "", label: "全部" },
  { value: "macro", label: "宏观" },
  { value: "industry", label: "行业" },
  { value: "stock", label: "个股" },
  { value: "strategy", label: "策略" },
  { value: "fixed_income", label: "固收" },
];

export default function Reports() {
  const [keyword, setKeyword] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(1);
  const { data, isLoading } = trpc.report.list.useQuery({ page, limit: 12, keyword: searchVal || undefined, category: category || undefined });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">金融研报</h1>
            <p className="text-muted-foreground text-sm mt-1">券商机构研报、深度分析报告</p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <Input placeholder="搜索研报..." value={keyword} onChange={e => setKeyword(e.target.value)} className="sm:w-64"
              onKeyDown={e => { if (e.key === "Enter") { setSearchVal(keyword); setPage(1); } }} />
            <Button size="sm" onClick={() => { setSearchVal(keyword); setPage(1); }}><Search className="w-4 h-4" /></Button>
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {categories.map(cat => (
            <Button
              key={cat.value}
              variant={category === cat.value ? "default" : "outline"}
              size="sm"
              onClick={() => { setCategory(cat.value); setPage(1); }}
            >
              {cat.label}
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-48 bg-muted animate-pulse rounded-lg" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data?.data?.map(report => (
                <Link key={report.id} href={`/reports/${report.id}`}>
                  <Card className="card-hover cursor-pointer h-full">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between mb-3">
                        <div className="w-10 h-10 bg-amber-50 rounded-lg flex items-center justify-center shrink-0">
                          <TrendingUp className="w-5 h-5 text-amber-600" />
                        </div>
                        <div className="flex gap-1">
                          {report.isPaid && (
                            <Badge variant="outline" className="text-xs flex items-center gap-1">
                              <Lock className="w-3 h-3" />付费
                            </Badge>
                          )}
                          <Badge variant="secondary" className="text-xs">
                            {categories.find(c => c.value === report.category)?.label || report.category}
                          </Badge>
                        </div>
                      </div>
                      <h3 className="font-semibold text-sm mb-2 line-clamp-2">{report.title}</h3>
                      {report.summary && <p className="text-muted-foreground text-xs line-clamp-2 mb-3">{report.summary}</p>}
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{report.institution || "机构研报"}</span>
                        <div className="flex items-center gap-2">
                          <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{report.viewCount}</span>
                          <span className="flex items-center gap-1"><Download className="w-3 h-3" />{report.downloadCount}</span>
                        </div>
                      </div>
                      {report.isPaid && report.price && (
                        <div className="mt-2 pt-2 border-t border-border">
                          <span className="text-primary font-semibold text-sm">¥{report.price}</span>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </Link>
              ))}
              {data?.data?.length === 0 && (
                <div className="col-span-3 text-center py-16 text-muted-foreground">
                  <TrendingUp className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>暂无研报</p>
                </div>
              )}
            </div>
            {data && data.total > 12 && (
              <div className="flex justify-center gap-2 mt-8">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
                <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页</span>
                <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 12)} onClick={() => setPage(p => p + 1)}>下一页</Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
