import { trpc } from "@/lib/trpc";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, CheckCircle, Play, Award, BookOpen } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export default function CourseLearn() {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const [currentChapter, setCurrentChapter] = useState(0);
  const [progress, setProgress] = useState(0);

  const { data: course } = trpc.course.detail.useQuery({ id: Number(id) });
  const { data: progressData } = trpc.course.getProgress.useQuery({ courseId: Number(id) }, { enabled: isAuthenticated });
  const { data: certificate } = trpc.course.certificate.useQuery({ courseId: Number(id) }, { enabled: isAuthenticated });

  const saveProgressMutation = trpc.course.saveProgress.useMutation();

  const chapters = (course as any)?.chapters || [];
  const chapter = chapters[currentChapter];

  useEffect(() => {
    if (chapter) {
      const timer = setInterval(() => {
        setProgress(p => {
          const newP = Math.min(p + 5, 100);
          if (newP % 20 === 0) {
            saveProgressMutation.mutate({
              courseId: Number(id),
              chapterId: chapter.id,
              progress: newP,
              watchedDuration: Math.floor(newP / 100 * (chapter.duration || 300)),
            });
          }
          return newP;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [currentChapter, chapter]);

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground text-sm">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-card px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="sm" asChild>
          <Link href={`/courses/${id}`}><ArrowLeft className="w-4 h-4" /></Link>
        </Button>
        <h1 className="font-semibold text-sm flex-1 truncate">{course.title}</h1>
        {certificate && (
          <Badge className="bg-amber-100 text-amber-700 border-amber-200 gap-1">
            <Award className="w-3 h-3" />已获证书
          </Badge>
        )}
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Chapter List */}
        <aside className="w-72 border-r border-border bg-card overflow-y-auto hidden md:block">
          <div className="p-4">
            <h2 className="font-semibold text-sm mb-3">课程目录</h2>
            <div className="space-y-1">
              {chapters.map((ch: any, idx: number) => {
                const chProgress = progressData?.find((p: any) => p.chapterId === ch.id);
                return (
                  <button
                    key={ch.id}
                    onClick={() => { setCurrentChapter(idx); setProgress(chProgress?.progress || 0); }}
                    className={`w-full text-left p-3 rounded-lg text-sm transition-colors ${currentChapter === idx ? "bg-primary/10 text-primary" : "hover:bg-muted"}`}
                  >
                    <div className="flex items-center gap-2">
                      {chProgress?.isCompleted ? (
                        <CheckCircle className="w-4 h-4 text-green-500 shrink-0" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/30 shrink-0 flex items-center justify-center text-xs text-muted-foreground">
                          {idx + 1}
                        </div>
                      )}
                      <span className="flex-1 truncate">{ch.title}</span>
                    </div>
                    {chProgress && !chProgress.isCompleted && (
                      <div className="mt-1 ml-6 h-1 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${chProgress.progress}%` }} />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {chapter ? (
            <div className="max-w-3xl mx-auto">
              <h2 className="text-xl font-bold mb-4">{chapter.title}</h2>

              {/* Video Player Placeholder */}
              {chapter.videoUrl ? (
                <div className="aspect-video bg-black rounded-xl mb-4 flex items-center justify-center">
                  <div className="text-center text-white">
                    <Play className="w-16 h-16 mx-auto mb-2 opacity-70" />
                    <p className="text-sm opacity-70">视频播放器</p>
                    <p className="text-xs opacity-50 mt-1">{chapter.videoUrl}</p>
                  </div>
                </div>
              ) : (
                <div className="aspect-video bg-muted rounded-xl mb-4 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <Play className="w-12 h-12 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">图文课程内容</p>
                  </div>
                </div>
              )}

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-1">
                  <span>学习进度</span>
                  <span>{progress}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
                </div>
              </div>

              {/* Chapter Content */}
              {chapter.content && (
                <div className="prose prose-sm max-w-none text-foreground leading-relaxed whitespace-pre-wrap">
                  {chapter.content}
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between mt-8 pt-4 border-t border-border">
                <Button variant="outline" disabled={currentChapter === 0} onClick={() => { setCurrentChapter(c => c - 1); setProgress(0); }}>
                  上一节
                </Button>
                <Button disabled={currentChapter >= chapters.length - 1} onClick={() => { setCurrentChapter(c => c + 1); setProgress(0); }}>
                  下一节
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-muted-foreground">
              <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>请从左侧选择章节开始学习</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

