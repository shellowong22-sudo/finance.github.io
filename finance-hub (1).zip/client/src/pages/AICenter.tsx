import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import {
  Brain, TrendingUp, TrendingDown, Minus, AlertTriangle,
  Lightbulb, BarChart3, User, MessageSquare, Zap, Target,
  BookOpen, FileText, Shield, Activity, RefreshCw, Send,
  Layers, PieChart, Bell, Cpu, Database, Globe, Lock,
  Sparkles, ArrowRight, CheckCircle2
} from "lucide-react";

// ============================================================
// AI竞争力框架数据
// ============================================================
const AI_CAPABILITIES = [
  {
    icon: Database, title: "数据壁垒", color: "text-blue-500", bgColor: "bg-blue-500/10",
    desc: "独有金融场景数据闭环，用户使用产生新数据，模型持续迭代优化",
    metrics: ["200+ 实时品种", "10大核心指数", "98个行业板块", "全球多市场覆盖"],
  },
  {
    icon: Cpu, title: "模型效率", color: "text-purple-500", bgColor: "bg-purple-500/10",
    desc: "更快、更准、更低成本的深度学习推理，同等效果成本更低",
    metrics: ["毫秒级情感分析", "实时风险评估", "多维度组合分析", "智能板块轮动"],
  },
  {
    icon: Target, title: "降本增效", color: "text-green-500", bgColor: "bg-green-500/10",
    desc: "替代人工重复分析，提升投资决策效率，可量化ROI",
    metrics: ["自动市场日报", "智能预警通知", "组合健康诊断", "个性化推荐"],
  },
  {
    icon: Lock, title: "场景独占", color: "text-orange-500", bgColor: "bg-orange-500/10",
    desc: "垂直深耕金融领域，先入为主+行业Know-How，通用模型进不来",
    metrics: ["金融专属语料", "行业知识图谱", "合规风控引擎", "专业术语理解"],
  },
  {
    icon: Sparkles, title: "多模态融合", color: "text-cyan-500", bgColor: "bg-cyan-500/10",
    desc: "文本+数据+图表统一理解，比单一模态更智能",
    metrics: ["K线形态识别", "财报数据解读", "新闻情感分析", "语音交互支持"],
  },
  {
    icon: Globe, title: "生态绑定", color: "text-pink-500", bgColor: "bg-pink-500/10",
    desc: "上下游产业链整合，用户迁移成本极高，形成深度护城河",
    metrics: ["自选股管理", "价格预警系统", "AI助手对话", "一站式金融服务"],
  },
];

const AI_TOOLS_SHOWCASE = [
  { name: "行情查询", desc: "200+品种实时行情", icon: BarChart3, color: "text-blue-500" },
  { name: "K线分析", desc: "多周期技术图表", icon: TrendingUp, color: "text-green-500" },
  { name: "板块热力图", desc: "行业轮动分析", icon: Layers, color: "text-purple-500" },
  { name: "组合分析", desc: "自选持仓诊断", icon: PieChart, color: "text-orange-500" },
  { name: "价格预警", desc: "智能触发通知", icon: Bell, color: "text-red-500" },
  { name: "情感分析", desc: "金融文本情绪", icon: Activity, color: "text-cyan-500" },
  { name: "风险预测", desc: "资产风险评估", icon: Shield, color: "text-yellow-500" },
  { name: "智能推荐", desc: "个性化内容", icon: Target, color: "text-pink-500" },
  { name: "内容摘要", desc: "研报要点提炼", icon: FileText, color: "text-indigo-500" },
  { name: "智能问答", desc: "金融知识百科", icon: MessageSquare, color: "text-emerald-500" },
  { name: "用户画像", desc: "投资者分析", icon: User, color: "text-amber-500" },
  { name: "市场趋势", desc: "宏观走势研判", icon: Globe, color: "text-teal-500" },
];

export default function AICenter() {
  const { user, isAuthenticated } = useAuth();
  const [sentimentText, setSentimentText] = useState("");
  const [riskAssets, setRiskAssets] = useState("");
  const [riskHorizon, setRiskHorizon] = useState<"short" | "medium" | "long">("medium");
  const [riskTolerance, setRiskTolerance] = useState<"conservative" | "moderate" | "aggressive">("moderate");
  const [summaryContent, setSummaryContent] = useState("");
  const [question, setQuestion] = useState("");
  const [marketTopic, setMarketTopic] = useState("当前A股市场");

  // AI看板数据
  const { data: dashboardData, isLoading: dashboardLoading, refetch: refetchDashboard } = trpc.ai.dashboard.useQuery();
  // 市场趋势
  const { data: marketData, isLoading: marketLoading, refetch: refetchMarket } = trpc.ai.marketTrend.useQuery({ topic: marketTopic });
  // 用户画像（需要登录）
  const { data: profileData, isLoading: profileLoading } = trpc.ai.userProfile.useQuery(undefined, { enabled: isAuthenticated });
  // 智能推荐（需要登录）
  const { data: recommendData, isLoading: recommendLoading } = trpc.ai.recommend.useQuery({ type: "article", limit: 6 }, { enabled: isAuthenticated });

  // 情感分析
  const sentimentMutation = trpc.ai.sentimentAnalysis.useMutation();
  // 风险预测
  const riskMutation = trpc.ai.riskPrediction.useMutation();
  // 内容摘要
  const summaryMutation = trpc.ai.generateSummary.useMutation();
  // 智能问答
  const askMutation = trpc.ai.askFinance.useMutation();

  const handleSentiment = () => {
    if (!sentimentText.trim()) return toast.error("请输入要分析的文本");
    sentimentMutation.mutate({ text: sentimentText });
  };

  const handleRisk = () => {
    if (!isAuthenticated) return toast.error("请先登录");
    if (!riskAssets.trim()) return toast.error("请描述您的资产组合");
    riskMutation.mutate({ assets: riskAssets, investmentHorizon: riskHorizon, riskTolerance });
  };

  const handleSummary = () => {
    if (!summaryContent.trim()) return toast.error("请输入要分析的内容");
    summaryMutation.mutate({ content: summaryContent, type: "article" });
  };

  const handleAsk = () => {
    if (!question.trim()) return toast.error("请输入问题");
    askMutation.mutate({ question });
  };

  const getSentimentColor = (s: string) => {
    if (s === "positive") return "text-green-500";
    if (s === "negative") return "text-red-500";
    return "text-yellow-500";
  };

  const getSentimentIcon = (s: string) => {
    if (s === "positive") return <TrendingUp className="w-5 h-5 text-green-500" />;
    if (s === "negative") return <TrendingDown className="w-5 h-5 text-red-500" />;
    return <Minus className="w-5 h-5 text-yellow-500" />;
  };

  const getRiskColor = (level: string) => {
    const map: Record<string, string> = { low: "bg-green-500", medium: "bg-yellow-500", high: "bg-orange-500", very_high: "bg-red-500" };
    return map[level] || "bg-gray-500";
  };

  const getTrendIcon = (trend: string) => {
    if (trend === "bullish") return <TrendingUp className="w-6 h-6 text-green-400" />;
    if (trend === "bearish") return <TrendingDown className="w-6 h-6 text-red-400" />;
    return <Minus className="w-6 h-6 text-yellow-400" />;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        {/* ============================================================ */}
        {/* 页面标题 + AI竞争力概览 */}
        {/* ============================================================ */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 bg-gradient-to-br from-primary/20 to-purple-500/20 rounded-xl">
              <Brain className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">AI 深度学习中心</h1>
              <p className="text-muted-foreground">基于深度学习模型的金融智能分析平台 — 数据驱动 · 场景深耕 · 多模态融合</p>
            </div>
          </div>
          {/* AI能力标签 */}
          <div className="flex flex-wrap gap-2 mt-4">
            {["智能推荐", "情感分析", "风险预测", "用户画像", "市场趋势", "板块轮动", "组合诊断", "价格预警", "内容摘要", "智能问答"].map(tag => (
              <Badge key={tag} variant="secondary" className="text-xs px-3 py-1">
                <Zap className="w-3 h-3 mr-1" />{tag}
              </Badge>
            ))}
          </div>
        </div>

        {/* ============================================================ */}
        {/* AI竞争力框架卡片 */}
        {/* ============================================================ */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI 核心竞争力矩阵
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {AI_CAPABILITIES.map((cap) => (
              <Card key={cap.title} className="group hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/30">
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`p-2 rounded-lg ${cap.bgColor}`}>
                      <cap.icon className={`w-5 h-5 ${cap.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm">{cap.title}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{cap.desc}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {cap.metrics.map((m) => (
                      <div key={m} className="flex items-center gap-1 text-xs text-muted-foreground">
                        <CheckCircle2 className="w-3 h-3 text-green-500 shrink-0" />
                        <span className="truncate">{m}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* ============================================================ */}
        {/* AI工具矩阵 */}
        {/* ============================================================ */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-primary" />
            AI 工具能力矩阵 — 12大核心工具
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {AI_TOOLS_SHOWCASE.map((tool) => (
              <Card key={tool.name} className="group hover:shadow-md transition-all cursor-default border-border/50 hover:border-primary/20">
                <CardContent className="pt-4 pb-3 text-center">
                  <tool.icon className={`w-6 h-6 mx-auto mb-2 ${tool.color} group-hover:scale-110 transition-transform`} />
                  <p className="text-xs font-medium">{tool.name}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{tool.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* ============================================================ */}
        {/* AI看板概览 */}
        {/* ============================================================ */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {dashboardLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse"><CardContent className="h-24 pt-6" /></Card>
            ))
          ) : dashboardData ? (
            <>
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">市场情绪</p>
                      <p className={`text-xl font-bold mt-1 ${dashboardData.marketSentiment === "bullish" ? "text-green-500" : dashboardData.marketSentiment === "bearish" ? "text-red-500" : "text-yellow-500"}`}>
                        {dashboardData.marketSentiment === "bullish" ? "看涨" : dashboardData.marketSentiment === "bearish" ? "看跌" : "中性"}
                      </p>
                    </div>
                    {getTrendIcon(dashboardData.marketSentiment || "neutral")}
                  </div>
                  <Progress value={dashboardData.sentimentScore || 50} className="mt-2 h-1.5" />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-muted-foreground">热门板块</p>
                  <p className="text-xl font-bold mt-1">{dashboardData.hotSectors?.length || 0} 个</p>
                  <p className="text-xs text-muted-foreground mt-1">{dashboardData.hotSectors?.[0]?.name || "暂无数据"}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-muted-foreground">风险预警</p>
                  <p className="text-xl font-bold mt-1 text-orange-500">{dashboardData.riskWarnings?.length || 0} 条</p>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{dashboardData.riskWarnings?.[0] || "暂无预警"}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-muted-foreground">AI洞察</p>
                  <p className="text-xl font-bold mt-1 text-blue-500">{dashboardData.aiInsights?.length || 0} 条</p>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{dashboardData.aiInsights?.[0] || "暂无洞察"}</p>
                </CardContent>
              </Card>
            </>
          ) : null}
        </div>

        {/* ============================================================ */}
        {/* 功能标签页 */}
        {/* ============================================================ */}
        <Tabs defaultValue="market" className="space-y-6">
          <TabsList className="grid grid-cols-3 md:grid-cols-7 h-auto gap-1 p-1">
            <TabsTrigger value="market" className="text-xs"><BarChart3 className="w-3 h-3 mr-1" />市场趋势</TabsTrigger>
            <TabsTrigger value="sentiment" className="text-xs"><Activity className="w-3 h-3 mr-1" />情感分析</TabsTrigger>
            <TabsTrigger value="risk" className="text-xs"><Shield className="w-3 h-3 mr-1" />风险预测</TabsTrigger>
            <TabsTrigger value="recommend" className="text-xs"><Target className="w-3 h-3 mr-1" />智能推荐</TabsTrigger>
            <TabsTrigger value="profile" className="text-xs"><User className="w-3 h-3 mr-1" />用户画像</TabsTrigger>
            <TabsTrigger value="summary" className="text-xs"><FileText className="w-3 h-3 mr-1" />内容摘要</TabsTrigger>
            <TabsTrigger value="ask" className="text-xs"><MessageSquare className="w-3 h-3 mr-1" />智能问答</TabsTrigger>
          </TabsList>

          {/* 市场趋势 */}
          <TabsContent value="market">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-primary" />市场趋势分析
                  </CardTitle>
                  <CardDescription>基于深度学习的宏观市场研判，融合多维度数据源</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">分析主题</label>
                    <Input value={marketTopic} onChange={e => setMarketTopic(e.target.value)} placeholder="如：A股市场、新能源板块..." />
                  </div>
                  <Button onClick={() => refetchMarket()} className="w-full" disabled={marketLoading}>
                    <RefreshCw className={`w-4 h-4 mr-2 ${marketLoading ? "animate-spin" : ""}`} />
                    {marketLoading ? "AI分析中..." : "开始分析"}
                  </Button>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      <Lightbulb className="w-3 h-3 inline mr-1 text-yellow-500" />
                      分析引擎综合宏观经济指标、行业数据和市场情绪，给出趋势研判和投资机会识别。
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="text-base">分析结果</CardTitle>
                </CardHeader>
                <CardContent>
                  {marketLoading ? (
                    <div className="flex items-center justify-center h-40">
                      <div className="text-center">
                        <Brain className="w-10 h-10 text-primary mx-auto mb-2 animate-pulse" />
                        <p className="text-muted-foreground text-sm">AI深度分析中...</p>
                      </div>
                    </div>
                  ) : marketData ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                        {getTrendIcon(marketData.trend)}
                        <div>
                          <p className="font-semibold">{marketData.trend === "bullish" ? "看涨" : marketData.trend === "bearish" ? "看跌" : "震荡"}</p>
                          <p className="text-sm text-muted-foreground">置信度 {marketData.confidence}%</p>
                        </div>
                        <Progress value={marketData.confidence} className="flex-1 h-2" />
                      </div>
                      <p className="text-sm leading-relaxed">{marketData.summary}</p>
                      {marketData.hotTopics?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">热点话题</p>
                          <div className="flex flex-wrap gap-2">
                            {marketData.hotTopics.map((t: string, i: number) => (
                              <Badge key={i} variant="outline" className="text-xs">{t}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {marketData.riskFactors?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2 flex items-center gap-1"><AlertTriangle className="w-3 h-3 text-orange-500" />风险因素</p>
                          <ul className="space-y-1">
                            {marketData.riskFactors.slice(0, 3).map((r: string, i: number) => (
                              <li key={i} className="text-xs text-muted-foreground flex items-start gap-1"><span className="text-orange-400 mt-0.5">•</span>{r}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {marketData.opportunities?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2 flex items-center gap-1"><Lightbulb className="w-3 h-3 text-green-500" />投资机会</p>
                          <ul className="space-y-1">
                            {marketData.opportunities.slice(0, 3).map((o: string, i: number) => (
                              <li key={i} className="text-xs text-muted-foreground flex items-start gap-1"><span className="text-green-400 mt-0.5">•</span>{o}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground py-10">点击"开始分析"获取AI市场分析</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 情感分析 */}
          <TabsContent value="sentiment">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Activity className="w-4 h-4 text-primary" />金融文本情感分析
                  </CardTitle>
                  <CardDescription>基于NLP深度学习模型，精准识别金融文本情感倾向</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="输入金融资讯、研报摘要、市场评论等文本，AI将分析其情感倾向..."
                    value={sentimentText}
                    onChange={e => setSentimentText(e.target.value)}
                    rows={6}
                  />
                  <Button onClick={handleSentiment} className="w-full" disabled={sentimentMutation.isPending}>
                    <Brain className={`w-4 h-4 mr-2 ${sentimentMutation.isPending ? "animate-spin" : ""}`} />
                    {sentimentMutation.isPending ? "分析中..." : "开始情感分析"}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle className="text-base">分析结果</CardTitle></CardHeader>
                <CardContent>
                  {sentimentMutation.isPending ? (
                    <div className="flex items-center justify-center h-40">
                      <Brain className="w-10 h-10 text-primary animate-pulse" />
                    </div>
                  ) : sentimentMutation.data ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        {getSentimentIcon(sentimentMutation.data.sentiment)}
                        <div>
                          <p className={`text-lg font-bold ${getSentimentColor(sentimentMutation.data.sentiment)}`}>
                            {sentimentMutation.data.sentiment === "positive" ? "正面情绪" : sentimentMutation.data.sentiment === "negative" ? "负面情绪" : "中性情绪"}
                          </p>
                          <p className="text-sm text-muted-foreground">情感得分：{sentimentMutation.data.score}/100</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>情感强度</span><span>{sentimentMutation.data.score}%</span>
                        </div>
                        <Progress value={sentimentMutation.data.score} className="h-2" />
                        <div className="flex justify-between text-sm">
                          <span>置信度</span><span>{sentimentMutation.data.confidence}%</span>
                        </div>
                        <Progress value={sentimentMutation.data.confidence} className="h-2" />
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-1">风险等级</p>
                        <Badge className={`${sentimentMutation.data.riskLevel === "high" ? "bg-red-500" : sentimentMutation.data.riskLevel === "medium" ? "bg-yellow-500" : "bg-green-500"} text-white`}>
                          {sentimentMutation.data.riskLevel === "high" ? "高风险" : sentimentMutation.data.riskLevel === "medium" ? "中等风险" : "低风险"}
                        </Badge>
                      </div>
                      {sentimentMutation.data.keywords?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">关键词</p>
                          <div className="flex flex-wrap gap-1">
                            {sentimentMutation.data.keywords.map((k: string, i: number) => (
                              <Badge key={i} variant="outline" className="text-xs">{k}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      <p className="text-sm text-muted-foreground">{sentimentMutation.data.summary}</p>
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground py-10">输入文本后点击分析按钮</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 风险预测 */}
          <TabsContent value="risk">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Shield className="w-4 h-4 text-primary" />投资风险预测
                  </CardTitle>
                  <CardDescription>基于蒙特卡洛模拟和深度学习的资产风险评估引擎</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!isAuthenticated && (
                    <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-sm text-yellow-600">
                      请登录后使用风险预测功能
                    </div>
                  )}
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">资产组合描述</label>
                    <Textarea
                      placeholder="描述您的资产组合，如：50%沪深300指数基金、30%债券基金、20%货币基金..."
                      value={riskAssets}
                      onChange={e => setRiskAssets(e.target.value)}
                      rows={4}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm text-muted-foreground mb-1 block">投资期限</label>
                      <Select value={riskHorizon} onValueChange={(v: any) => setRiskHorizon(v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="short">短期（1年内）</SelectItem>
                          <SelectItem value="medium">中期（1-3年）</SelectItem>
                          <SelectItem value="long">长期（3年以上）</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground mb-1 block">风险偏好</label>
                      <Select value={riskTolerance} onValueChange={(v: any) => setRiskTolerance(v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="conservative">保守型</SelectItem>
                          <SelectItem value="moderate">稳健型</SelectItem>
                          <SelectItem value="aggressive">激进型</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button onClick={handleRisk} className="w-full" disabled={riskMutation.isPending || !isAuthenticated}>
                    <Shield className={`w-4 h-4 mr-2 ${riskMutation.isPending ? "animate-spin" : ""}`} />
                    {riskMutation.isPending ? "评估中..." : "开始风险评估"}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle className="text-base">风险评估报告</CardTitle></CardHeader>
                <CardContent>
                  {riskMutation.isPending ? (
                    <div className="flex items-center justify-center h-40">
                      <Brain className="w-10 h-10 text-primary animate-pulse" />
                    </div>
                  ) : riskMutation.data ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-full ${getRiskColor(riskMutation.data.riskLevel)} flex items-center justify-center text-white font-bold text-lg`}>
                          {riskMutation.data.riskScore}
                        </div>
                        <div>
                          <p className="font-bold text-lg">
                            {riskMutation.data.riskLevel === "low" ? "低风险" : riskMutation.data.riskLevel === "medium" ? "中等风险" : riskMutation.data.riskLevel === "high" ? "高风险" : "极高风险"}
                          </p>
                          <p className="text-sm text-muted-foreground">风险评分 {riskMutation.data.riskScore}/100</p>
                        </div>
                      </div>
                      <p className="text-sm">{riskMutation.data.summary}</p>
                      {(riskMutation.data.suggestions?.length ?? 0) > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">优化建议</p>
                          <ul className="space-y-1">
                            {(riskMutation.data.suggestions ?? []).map((s: string, i: number) => (
                              <li key={i} className="text-xs flex items-start gap-1"><span className="text-primary mt-0.5">•</span>{s}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {(riskMutation.data.assetAllocation?.length ?? 0) > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">建议资产配置</p>
                          <div className="space-y-2">
                            {(riskMutation.data.assetAllocation ?? []).map((a: any, i: number) => (
                              <div key={i} className="flex items-center gap-2">
                                <span className="text-xs w-20 truncate">{a.asset}</span>
                                <Progress value={a.ratio} className="flex-1 h-2" />
                                <span className="text-xs w-8">{a.ratio}%</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground py-10">填写资产信息后开始评估</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 智能推荐 */}
          <TabsContent value="recommend">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Target className="w-4 h-4 text-primary" />个性化智能推荐
                  {!isAuthenticated && <Badge variant="outline" className="text-xs">需要登录</Badge>}
                </CardTitle>
                <CardDescription>基于协同过滤+深度学习的推荐引擎，千人千面精准推送</CardDescription>
              </CardHeader>
              <CardContent>
                {!isAuthenticated ? (
                  <div className="text-center py-10 text-muted-foreground">请登录后查看个性化推荐内容</div>
                ) : recommendLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {Array(6).fill(0).map((_, i) => <Card key={i} className="animate-pulse h-32" />)}
                  </div>
                ) : (recommendData?.data?.length ?? 0) > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {(recommendData?.data ?? []).map((item: any, i: number) => (
                      <Card key={i} className="hover:shadow-md transition-shadow cursor-pointer border-primary/10">
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between mb-2">
                            <BookOpen className="w-4 h-4 text-primary mt-0.5" />
                            <Badge variant="secondary" className="text-xs">{item.score}% 匹配</Badge>
                          </div>
                          <p className="font-medium text-sm mb-2 line-clamp-2">{item.title}</p>
                          <p className="text-xs text-muted-foreground mb-2">{item.reason}</p>
                          <div className="flex flex-wrap gap-1">
                            {item.tags?.slice(0, 3).map((t: string, j: number) => (
                              <Badge key={j} variant="outline" className="text-xs px-1 py-0">{t}</Badge>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 text-muted-foreground">暂无推荐内容</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* 用户画像 */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <User className="w-4 h-4 text-primary" />AI用户画像分析
                  {!isAuthenticated && <Badge variant="outline" className="text-xs">需要登录</Badge>}
                </CardTitle>
                <CardDescription>基于行为序列建模的投资者画像，精准刻画用户特征</CardDescription>
              </CardHeader>
              <CardContent>
                {!isAuthenticated ? (
                  <div className="text-center py-10 text-muted-foreground">请登录后查看您的AI用户画像</div>
                ) : profileLoading ? (
                  <div className="flex items-center justify-center h-40"><Brain className="w-10 h-10 text-primary animate-pulse" /></div>
                ) : profileData ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="p-4 bg-primary/5 rounded-lg">
                        <p className="text-sm text-muted-foreground">投资者类型</p>
                        <p className="text-xl font-bold mt-1">{profileData.investorType}</p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground">风险偏好</p>
                        <p className="text-lg font-semibold mt-1">{profileData.riskProfile}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2">兴趣标签</p>
                        <div className="flex flex-wrap gap-2">
                          {profileData.interests?.map((tag: string, i: number) => (
                            <Badge key={i} className="bg-primary/10 text-primary border-primary/20">{tag}</Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2">学习进度</p>
                        <Progress value={profileData.learningProgress || 30} className="h-3" />
                        <p className="text-xs text-muted-foreground mt-1">{profileData.learningProgress || 30}% 完成</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      {profileData.insights?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2 flex items-center gap-1"><Lightbulb className="w-3 h-3 text-yellow-500" />AI洞察</p>
                          <ul className="space-y-2">
                            {profileData.insights.map((insight: string, i: number) => (
                              <li key={i} className="text-sm p-2 bg-muted/50 rounded flex items-start gap-2">
                                <span className="text-primary mt-0.5">•</span>{insight}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {profileData.nextSteps?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">建议行动</p>
                          <ul className="space-y-1">
                            {profileData.nextSteps.map((step: string, i: number) => (
                              <li key={i} className="text-xs text-muted-foreground flex items-start gap-1">
                                <span className="text-green-400 mt-0.5"><ArrowRight className="w-3 h-3" /></span>{step}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                ) : null}
              </CardContent>
            </Card>
          </TabsContent>

          {/* 内容摘要 */}
          <TabsContent value="summary">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-4 h-4 text-primary" />AI内容摘要生成
                  </CardTitle>
                  <CardDescription>基于Transformer的文本理解引擎，自动提炼核心要点</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="粘贴金融文章、研报内容，AI将自动提炼核心要点并生成摘要..."
                    value={summaryContent}
                    onChange={e => setSummaryContent(e.target.value)}
                    rows={8}
                  />
                  <Button onClick={handleSummary} className="w-full" disabled={summaryMutation.isPending}>
                    <Brain className={`w-4 h-4 mr-2 ${summaryMutation.isPending ? "animate-spin" : ""}`} />
                    {summaryMutation.isPending ? "生成中..." : "生成AI摘要"}
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="text-base">摘要结果</CardTitle></CardHeader>
                <CardContent>
                  {summaryMutation.isPending ? (
                    <div className="flex items-center justify-center h-40"><Brain className="w-10 h-10 text-primary animate-pulse" /></div>
                  ) : summaryMutation.data ? (
                    <div className="space-y-4">
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm font-medium mb-1">核心摘要</p>
                        <p className="text-sm leading-relaxed">{summaryMutation.data.summary}</p>
                      </div>
                      {summaryMutation.data.keyPoints?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">核心要点</p>
                          <ul className="space-y-1">
                            {summaryMutation.data.keyPoints.map((p: string, i: number) => (
                              <li key={i} className="text-sm flex items-start gap-2">
                                <span className="text-primary font-bold mt-0.5">{i + 1}.</span>{p}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      <div className="flex items-center justify-between">
                        <div className="flex flex-wrap gap-1">
                          {summaryMutation.data.tags?.map((t: string, i: number) => (
                            <Badge key={i} variant="secondary" className="text-xs">{t}</Badge>
                          ))}
                        </div>
                        <Badge variant="outline" className="text-xs">预计阅读 {summaryMutation.data.readTime}</Badge>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground py-10">粘贴内容后点击生成摘要</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 智能问答 */}
          <TabsContent value="ask">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-primary" />金融知识智能问答
                </CardTitle>
                <CardDescription>基于金融领域知识图谱的问答引擎，减少幻觉，提升专业度</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {["什么是P/E市盈率？", "如何判断基金好坏？", "债券和股票的区别？", "什么是量化交易？", "如何做资产配置？", "什么是Alpha收益？", "ETF和LOF的区别？", "如何看懂财报？"].map(q => (
                    <Button key={q} variant="outline" size="sm" className="text-xs h-auto py-2 text-left whitespace-normal" onClick={() => setQuestion(q)}>
                      {q}
                    </Button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="输入您的金融问题，AI将用通俗易懂的语言解答..."
                    value={question}
                    onChange={e => setQuestion(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && handleAsk()}
                  />
                  <Button onClick={handleAsk} disabled={askMutation.isPending}>
                    <Send className={`w-4 h-4 ${askMutation.isPending ? "animate-spin" : ""}`} />
                  </Button>
                </div>
                {askMutation.isPending && (
                  <div className="flex items-center gap-2 text-muted-foreground text-sm">
                    <Brain className="w-4 h-4 animate-pulse" />AI正在思考...
                  </div>
                )}
                {askMutation.data && (
                  <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                    <div className="flex items-start gap-2">
                      <Brain className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{askMutation.data.answer}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
