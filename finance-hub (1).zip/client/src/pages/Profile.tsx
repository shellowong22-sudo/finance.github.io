import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { User, BookOpen, TrendingUp, Award, Heart, MessageSquare, LogOut } from "lucide-react";
import { Link } from "wouter";

export default function Profile() {
  const { isAuthenticated, user, logout } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-16 text-center">
          <User className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <p className="text-muted-foreground mb-6">登录后查看个人中心</p>
          <Button asChild><a href={getLoginUrl()}>立即登录</a></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-2xl font-bold">个人中心</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Profile Card */}
          <Card className="md:col-span-1">
            <CardContent className="p-6 text-center">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center text-primary text-2xl font-bold mx-auto mb-4">
                {user?.name?.charAt(0) || "U"}
              </div>
              <h2 className="font-bold text-lg">{user?.name || "用户"}</h2>
              <p className="text-muted-foreground text-sm mt-1">{user?.email || ""}</p>
              <Badge className="mt-2" variant={user?.role === "admin" ? "default" : "secondary"}>
                {user?.role === "admin" ? "管理员" : "普通用户"}
              </Badge>
              <div className="mt-4 pt-4 border-t border-border">
                <p className="text-xs text-muted-foreground">
                  注册时间：{user?.createdAt ? new Date(user.createdAt).toLocaleDateString("zh-CN") : ""}
                </p>
              </div>
              <Button variant="outline" size="sm" className="mt-4 w-full gap-2" onClick={logout}>
                <LogOut className="w-4 h-4" />退出登录
              </Button>
            </CardContent>
          </Card>

          {/* Quick Links */}
          <div className="md:col-span-2 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: BookOpen, label: "我的课程", desc: "查看已购课程", href: "/courses", color: "text-blue-500" },
                { icon: TrendingUp, label: "收藏研报", desc: "查看收藏研报", href: "/reports", color: "text-amber-500" },
                { icon: MessageSquare, label: "社区互动", desc: "查看消息评论", href: "/social", color: "text-green-500" },
                { icon: Award, label: "我的证书", desc: "查看获得证书", href: "/courses", color: "text-purple-500" },
              ].map(item => (
                <Link key={item.label} href={item.href}>
                  <Card className="card-hover cursor-pointer">
                    <CardContent className="p-4">
                      <item.icon className={`w-6 h-6 ${item.color} mb-2`} />
                      <div className="font-medium text-sm">{item.label}</div>
                      <div className="text-xs text-muted-foreground">{item.desc}</div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            {user?.role === "admin" && (
              <Card className="border-primary/30 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-primary">管理员权限</div>
                      <div className="text-sm text-muted-foreground">您拥有后台管理权限</div>
                    </div>
                    <Button asChild size="sm">
                      <Link href="/admin">进入后台</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader><CardTitle className="text-base">账户安全</CardTitle></CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">登录方式</span>
                  <span>{user?.loginMethod || "Manus OAuth"}</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">最后登录</span>
                  <span>{user?.lastSignedIn ? new Date(user.lastSignedIn).toLocaleString("zh-CN") : ""}</span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-muted-foreground">数据保护</span>
                  <Badge variant="secondary" className="text-xs">已启用脱敏</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
