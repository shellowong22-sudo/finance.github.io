import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { Eye, Clock, Search, FileText, Pin } from "lucide-react";
import { useState } from "react";

export default function Articles() {
  const [keyword, setKeyword] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const [page, setPage] = useState(1);
  const { data, isLoading } = trpc.article.list.useQuery({ page, limit: 12, status: "published", keyword: searchVal || undefined });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold">金融资讯</h1>
            <p className="text-muted-foreground text-sm mt-1">实时金融资讯、政策解读、市场动态</p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <Input placeholder="搜索文章..." value={keyword} onChange={e => setKeyword(e.target.value)} className="sm:w-64"
              onKeyDown={e => { if (e.key === "Enter") { setSearchVal(keyword); setPage(1); } }} />
            <Button size="sm" onClick={() => { setSearchVal(keyword); setPage(1); }}><Search className="w-4 h-4" /></Button>
          </div>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-40 bg-muted animate-pulse rounded-lg" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data?.data?.map(article => (
                <Link key={article.id} href={`/articles/${article.id}`}>
                  <Card className="card-hover cursor-pointer h-full">
                    <CardContent className="p-5">
                      <div className="flex items-center gap-2 mb-2">
                        {article.isPinned && <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs"><Pin className="w-3 h-3 mr-1" />置顶</Badge>}
                        {article.isTop && <Badge variant="secondary" className="text-xs">推荐</Badge>}
                      </div>
                      <h3 className="font-semibold text-base mb-2 line-clamp-2">{article.title}</h3>
                      {article.summary && <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{article.summary}</p>}
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{article.viewCount}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{article.publishedAt ? new Date(article.publishedAt).toLocaleDateString("zh-CN") : ""}</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
              {data?.data?.length === 0 && (
                <div className="col-span-3 text-center py-16 text-muted-foreground">
                  <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>暂无文章，请等待管理员发布内容</p>
                </div>
              )}
            </div>
            {data && data.total > 12 && (
              <div className="flex justify-center gap-2 mt-8">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>上一页</Button>
                <span className="flex items-center text-sm text-muted-foreground px-3">第 {page} 页 / 共 {Math.ceil(data.total / 12)} 页</span>
                <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / 12)} onClick={() => setPage(p => p + 1)}>下一页</Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
