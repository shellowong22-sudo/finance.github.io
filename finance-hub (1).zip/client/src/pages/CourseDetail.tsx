import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { useParams, Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { ArrowLeft, Star, Users, BookOpen, Award, Play, Lock, CheckCircle } from "lucide-react";
import { toast } from "sonner";

const categoryMap: Record<string, string> = { finance: "理财", fund: "基金", stock: "股票", risk: "风控", crypto: "数字货币", forex: "外汇" };

export default function CourseDetail() {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const { data: course, isLoading } = trpc.course.detail.useQuery({ id: Number(id) });
  const { data: purchaseStatus } = trpc.course.checkPurchase.useQuery({ courseId: Number(id) }, { enabled: isAuthenticated });
  const { data: reviews } = trpc.course.reviews.useQuery({ courseId: Number(id) });

  const purchaseMutation = trpc.course.purchase.useMutation({
    onSuccess: () => {
      toast.success("购买成功！");
      utils.course.checkPurchase.invalidate();
      navigate(`/courses/${id}/learn`);
    },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-8"><div className="h-96 bg-muted animate-pulse rounded-lg" /></div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-16 text-center text-muted-foreground">课程不存在</div>
      </div>
    );
  }

  const hasPurchased = purchaseStatus?.purchased;
  const canAccess = hasPurchased || course.isFree;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <Button variant="ghost" size="sm" className="mb-6" asChild>
          <Link href="/courses"><ArrowLeft className="w-4 h-4 mr-1" />返回列表</Link>
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-card rounded-xl border border-border p-6">
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="secondary">{categoryMap[course.category] || course.category}</Badge>
                <Badge variant="outline">{course.type === "video" ? "视频课程" : "图文课程"}</Badge>
                {course.hasCertificate && <Badge className="bg-amber-100 text-amber-700 border-amber-200"><Award className="w-3 h-3 mr-1" />含证书</Badge>}
              </div>
              <h1 className="text-2xl font-bold mb-3">{course.title}</h1>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1"><Star className="w-4 h-4 text-amber-400 fill-amber-400" />{course.rating} ({course.ratingCount} 评价)</span>
                <span className="flex items-center gap-1"><Users className="w-4 h-4" />{course.studentCount} 人学习</span>
              </div>
              {course.description && (
                <p className="text-muted-foreground leading-relaxed">{course.description}</p>
              )}
            </div>

            {/* Chapters */}
            <div className="bg-card rounded-xl border border-border p-6">
              <h2 className="font-bold text-lg mb-4">课程目录</h2>
              <div className="space-y-2">
                {(course as any).chapters?.map((chapter: any, idx: number) => (
                  <div key={chapter.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{chapter.title}</p>
                      {chapter.duration && <p className="text-xs text-muted-foreground">{Math.floor(chapter.duration / 60)} 分钟</p>}
                    </div>
                    {chapter.isFree || canAccess ? (
                      <Play className="w-4 h-4 text-primary shrink-0" />
                    ) : (
                      <Lock className="w-4 h-4 text-muted-foreground shrink-0" />
                    )}
                  </div>
                ))}
                {(!(course as any).chapters || (course as any).chapters.length === 0) && (
                  <p className="text-muted-foreground text-sm text-center py-4">课程目录更新中...</p>
                )}
              </div>
            </div>

            {/* Reviews */}
            <div className="bg-card rounded-xl border border-border p-6">
              <h2 className="font-bold text-lg mb-4">学员评价 ({reviews?.total || 0})</h2>
              <div className="space-y-4">
                {reviews?.data?.map(review => (
                  <div key={review.id} className="pb-4 border-b border-border last:border-0">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < review.rating ? "text-amber-400 fill-amber-400" : "text-muted"}`} />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">{new Date(review.createdAt).toLocaleDateString("zh-CN")}</span>
                    </div>
                    {review.content && <p className="text-sm">{review.content}</p>}
                  </div>
                ))}
                {(!reviews?.data || reviews.data.length === 0) && (
                  <p className="text-muted-foreground text-sm text-center py-4">暂无评价</p>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <Card className="sticky top-20">
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  {course.isFree ? (
                    <div className="text-3xl font-bold text-green-600">免费</div>
                  ) : (
                    <div>
                      <div className="text-3xl font-bold text-primary">¥{course.price}</div>
                      {course.originalPrice && (
                        <div className="text-muted-foreground text-sm line-through">¥{course.originalPrice}</div>
                      )}
                    </div>
                  )}
                </div>

                {canAccess ? (
                  <Button className="w-full gap-2" asChild>
                    <Link href={`/courses/${id}/learn`}><Play className="w-4 h-4" />开始学习</Link>
                  </Button>
                ) : isAuthenticated ? (
                  <Button
                    className="w-full"
                    onClick={() => purchaseMutation.mutate({ courseId: Number(id) })}
                    disabled={purchaseMutation.isPending}
                  >
                    {purchaseMutation.isPending ? "处理中..." : "立即购买"}
                  </Button>
                ) : (
                  <Button className="w-full" asChild>
                    <a href={getLoginUrl()}>登录后购买</a>
                  </Button>
                )}

                <div className="mt-4 space-y-2 text-sm text-muted-foreground">
                  {course.hasExam && (
                    <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" />包含考试测评</div>
                  )}
                  {course.hasCertificate && (
                    <div className="flex items-center gap-2"><Award className="w-4 h-4 text-amber-500" />通过考试颁发证书</div>
                  )}
                  <div className="flex items-center gap-2"><BookOpen className="w-4 h-4" />终身学习权限</div>
                  {course.refundPolicy && (
                    <div className="text-xs mt-2 p-2 bg-muted rounded">{course.refundPolicy}</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
