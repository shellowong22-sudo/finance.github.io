import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { ArrowLeft, Download, Star, Eye, Clock, Heart, Lock, TrendingUp } from "lucide-react";
import { toast } from "sonner";

const categoryMap: Record<string, string> = { macro: "宏观", industry: "行业", stock: "个股", strategy: "策略", fixed_income: "固收" };

export default function ReportDetail() {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const { data: report, isLoading } = trpc.report.detail.useQuery({ id: Number(id) });

  const downloadMutation = trpc.report.checkDownload.useMutation({
    onSuccess: (data) => {
      toast.success("下载权限验证通过，正在下载...");
      window.open(data.fileUrl, "_blank");
    },
    onError: (e) => toast.error(e.message),
  });

  const favoriteMutation = trpc.report.favorite.useMutation({
    onSuccess: (data) => {
      toast.success(data.favorited ? "已收藏" : "已取消收藏");
      utils.report.detail.invalidate();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-8"><div className="h-96 bg-muted animate-pulse rounded-lg" /></div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-16 text-center text-muted-foreground">研报不存在或已下架</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 max-w-4xl">
        <Button variant="ghost" size="sm" className="mb-6" asChild>
          <Link href="/reports"><ArrowLeft className="w-4 h-4 mr-1" />返回列表</Link>
        </Button>

        <div className="bg-card rounded-xl border border-border p-6 md:p-8">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary">{categoryMap[report.category] || report.category}</Badge>
              <Badge variant="outline">{report.fileType?.toUpperCase()}</Badge>
              {report.isPaid && <Badge className="bg-amber-100 text-amber-700 border-amber-200"><Lock className="w-3 h-3 mr-1" />付费研报</Badge>}
            </div>
          </div>

          <h1 className="text-2xl md:text-3xl font-bold mb-3">{report.title}</h1>

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6 pb-6 border-b border-border">
            <span className="font-medium text-foreground">{report.institution || "机构研报"}</span>
            <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{report.viewCount} 次阅读</span>
            <span className="flex items-center gap-1"><Download className="w-4 h-4" />{report.downloadCount} 次下载</span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {report.publishedAt ? new Date(report.publishedAt).toLocaleDateString("zh-CN") : ""}
            </span>
          </div>

          {report.summary && (
            <div className="mb-6">
              <h2 className="font-semibold mb-2">研报摘要</h2>
              <div className="watermark-overlay bg-muted/30 rounded-lg p-4" data-watermark={isAuthenticated ? "内部资料" : "请登录"}>
                <p className="text-sm leading-relaxed text-foreground">{report.summary}</p>
              </div>
            </div>
          )}

          {report.isPaid && (
            <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-amber-800">付费研报</p>
                  <p className="text-amber-700 text-sm">购买后可下载完整PDF研报</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-amber-700">¥{report.price}</div>
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <Button
                  onClick={() => downloadMutation.mutate({ reportId: Number(id) })}
                  disabled={downloadMutation.isPending}
                  className="gap-2"
                >
                  <Download className="w-4 h-4" />
                  {downloadMutation.isPending ? "验证中..." : report.isPaid ? "购买并下载" : "免费下载"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => favoriteMutation.mutate({ reportId: Number(id) })}
                  className="gap-2"
                >
                  <Heart className="w-4 h-4" />收藏 ({report.favoriteCount})
                </Button>
              </>
            ) : (
              <div className="flex items-center gap-3">
                <Button asChild><a href={getLoginUrl()}>登录后下载</a></Button>
                <p className="text-sm text-muted-foreground">登录后可下载研报</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
