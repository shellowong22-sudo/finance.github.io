import Navbar from "@/components/Navbar";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Globe, CheckCircle, Clock, XCircle, BarChart3, Link2, DollarSign } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ChannelApply() {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const [form, setForm] = useState({
    companyName: "",
    contactName: "",
    contactPhone: "",
    contactEmail: "",
    channelType: "other" as "broker" | "bank" | "media" | "other",
    description: "",
  });

  const { data: myChannel } = trpc.channel.myChannel.useQuery(undefined, { enabled: isAuthenticated });
  const { data: promoLinks } = trpc.channel.promoLinks.useQuery(undefined, { enabled: isAuthenticated && myChannel?.status === "approved" });
  const { data: settlements } = trpc.channel.settlements.useQuery({ page: 1 }, { enabled: isAuthenticated && myChannel?.status === "approved" });

  const applyMutation = trpc.channel.submitApplication.useMutation({
    onSuccess: () => {
      toast.success("申请提交成功，等待审核");
      utils.channel.myChannel.invalidate();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const createPromoMutation = trpc.channel.createPromoLink.useMutation({
    onSuccess: () => {
      toast.success("推广链接生成成功");
      utils.channel.promoLinks.invalidate();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const statusConfig = {
    pending: { label: "审核中", icon: Clock, color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
    approved: { label: "已通过", icon: CheckCircle, color: "bg-green-100 text-green-700 border-green-200" },
    rejected: { label: "已拒绝", icon: XCircle, color: "bg-red-100 text-red-700 border-red-200" },
  };

  const channelTypeMap = { broker: "券商", bank: "银行", media: "自媒体", other: "其他" };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold">渠道合作</h1>
          <p className="text-muted-foreground text-sm mt-1">券商、银行、自媒体渠道合作，专业分成结算体系</p>
        </div>

        {!isAuthenticated ? (
          <div className="text-center py-16">
            <Globe className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
            <h2 className="text-xl font-bold mb-2">登录后申请渠道合作</h2>
            <p className="text-muted-foreground mb-6">成为我们的合作渠道，享受专业分成结算服务</p>
            <Button asChild><a href={getLoginUrl()}>立即登录</a></Button>
          </div>
        ) : myChannel ? (
          <div className="space-y-6">
            {/* Channel Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>渠道状态</span>
                  {myChannel.status && statusConfig[myChannel.status as keyof typeof statusConfig] && (
                    <Badge className={statusConfig[myChannel.status as keyof typeof statusConfig].color}>
                      {statusConfig[myChannel.status as keyof typeof statusConfig].label}
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm text-muted-foreground">公司名称</div>
                    <div className="font-medium mt-1">{myChannel.companyName}</div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm text-muted-foreground">渠道类型</div>
                    <div className="font-medium mt-1">{channelTypeMap[myChannel.channelType as keyof typeof channelTypeMap]}</div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm text-muted-foreground">分成比例</div>
                    <div className="font-medium mt-1 text-primary">{myChannel.commissionRate ? `${myChannel.commissionRate}%` : "待配置"}</div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm text-muted-foreground">申请时间</div>
                    <div className="font-medium mt-1">{new Date(myChannel.createdAt).toLocaleDateString("zh-CN")}</div>
                  </div>
                </div>
                {myChannel.status === "rejected" && myChannel.rejectReason && (
                  <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                    拒绝原因：{myChannel.rejectReason}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Promo Links - only for approved channels */}
            {myChannel.status === "approved" && (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between text-base">
                      <span className="flex items-center gap-2"><Link2 className="w-4 h-4" />推广链接</span>
                      <Button size="sm" onClick={() => createPromoMutation.mutate({ targetType: "platform" })} disabled={createPromoMutation.isPending}>
                        生成新链接
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {promoLinks?.map(link => (
                        <div key={link.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                          <code className="flex-1 text-sm font-mono text-primary">{`${window.location.origin}?ref=${link.code}`}</code>
                          <div className="text-xs text-muted-foreground">{link.clickCount} 次点击</div>
                          <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(`${window.location.origin}?ref=${link.code}`); toast.success("链接已复制"); }}>
                            复制
                          </Button>
                        </div>
                      ))}
                      {(!promoLinks || promoLinks.length === 0) && (
                        <p className="text-sm text-muted-foreground text-center py-4">暂无推广链接，点击上方按钮生成</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <DollarSign className="w-4 h-4" />结算记录
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {settlements?.data?.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">暂无结算记录</p>
                    ) : (
                      <div className="space-y-2">
                        {settlements?.data?.map(s => (
                          <div key={s.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                            <div>
                              <div className="text-sm font-medium">结算金额：¥{s.commissionAmount}</div>
                              <div className="text-xs text-muted-foreground">{new Date(s.createdAt).toLocaleDateString("zh-CN")}</div>
                            </div>
                            <Badge variant={s.status === "settled" ? "default" : "secondary"}>{s.status === "settled" ? "已结算" : "待结算"}</Badge>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Apply Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>渠道入驻申请</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>公司/机构名称 *</Label>
                      <Input className="mt-1" placeholder="请输入公司名称" value={form.companyName} onChange={e => setForm(f => ({ ...f, companyName: e.target.value }))} />
                    </div>
                    <div>
                      <Label>联系人姓名 *</Label>
                      <Input className="mt-1" placeholder="请输入联系人姓名" value={form.contactName} onChange={e => setForm(f => ({ ...f, contactName: e.target.value }))} />
                    </div>
                    <div>
                      <Label>联系电话 *</Label>
                      <Input className="mt-1" placeholder="请输入手机号" value={form.contactPhone} onChange={e => setForm(f => ({ ...f, contactPhone: e.target.value }))} />
                    </div>
                    <div>
                      <Label>联系邮箱 *</Label>
                      <Input className="mt-1" type="email" placeholder="请输入邮箱" value={form.contactEmail} onChange={e => setForm(f => ({ ...f, contactEmail: e.target.value }))} />
                    </div>
                  </div>
                  <div>
                    <Label>渠道类型 *</Label>
                    <Select value={form.channelType} onValueChange={v => setForm(f => ({ ...f, channelType: v as any }))}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="broker">券商</SelectItem>
                        <SelectItem value="bank">银行</SelectItem>
                        <SelectItem value="media">自媒体</SelectItem>
                        <SelectItem value="other">其他</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>合作说明</Label>
                    <Textarea className="mt-1" placeholder="请描述您的渠道资源和合作意向..." rows={4} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
                  </div>
                  <Button
                    className="w-full"
                    onClick={() => applyMutation.mutate(form)}
                    disabled={applyMutation.isPending || !form.companyName || !form.contactName || !form.contactPhone || !form.contactEmail}
                  >
                    {applyMutation.isPending ? "提交中..." : "提交申请"}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Info Panel */}
            <div className="space-y-4">
              <Card>
                <CardHeader><CardTitle className="text-base">合作权益</CardTitle></CardHeader>
                <CardContent className="space-y-3 text-sm">
                  {["专属推广链接，用户溯源精准", "灵活分成比例，按月结算", "实时数据看板，业绩一目了然", "专属客户经理，一对一服务", "合同保障，合规经营"].map(item => (
                    <div key={item} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="text-base">审核流程</CardTitle></CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  {["提交入驻申请", "资质审核（1-3工作日）", "签署合作协议", "配置分成比例", "正式开始合作"].map((step, i) => (
                    <div key={step} className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center font-bold shrink-0">{i + 1}</div>
                      <span>{step}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
