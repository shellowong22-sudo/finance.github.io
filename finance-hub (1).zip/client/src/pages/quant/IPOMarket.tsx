import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import {
  Rocket, Calendar, DollarSign, TrendingUp, Building2, Clock, CheckCircle, XCircle,
} from "lucide-react";

const statusMap: Record<string, { label: string; color: string }> = {
  upcoming: { label: "即将发行", color: "bg-blue-100 text-blue-700" },
  open: { label: "申购中", color: "bg-green-100 text-green-700" },
  closed: { label: "已截止", color: "bg-gray-100 text-gray-700" },
  listed: { label: "已上市", color: "bg-purple-100 text-purple-700" },
  cancelled: { label: "已取消", color: "bg-red-100 text-red-700" },
};

export default function IPOMarket() {
  const { data: ipos, isLoading } = trpc.quant.ipo.list.useQuery({});

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Rocket className="w-7 h-7 text-primary" />一级市场 · IPO专区
          </h1>
          <p className="text-muted-foreground mt-1">新股发行 · 申购信息 · 定增配售</p>
        </div>

        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">全部</TabsTrigger>
            <TabsTrigger value="open">申购中</TabsTrigger>
            <TabsTrigger value="upcoming">即将发行</TabsTrigger>
            <TabsTrigger value="listed">已上市</TabsTrigger>
          </TabsList>

          {["all", "open", "upcoming", "listed"].map((tab) => (
            <TabsContent key={tab} value={tab}>
              {isLoading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <div className="space-y-4">
                  {(ipos || []).filter((ipo: any) => tab === "all" || ipo.status === tab).length === 0 ? (
                    <Card>
                      <CardContent className="py-20 text-center">
                        <Rocket className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                        <p className="text-muted-foreground">暂无IPO数据</p>
                        <p className="text-sm text-muted-foreground/70 mt-1">请在后台管理中生成模拟IPO数据</p>
                      </CardContent>
                    </Card>
                  ) : (
                    (ipos || []).filter((ipo: any) => tab === "all" || ipo.status === tab).map((ipo: any) => {
                      const st = statusMap[ipo.status] || statusMap.upcoming;
                      return (
                        <Card key={ipo.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-5">
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <h3 className="font-bold text-lg flex items-center gap-2">
                                  {ipo.companyName}
                                  <span className="text-sm font-mono text-primary">{ipo.symbol}</span>
                                </h3>
                                <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                                  <Building2 className="w-3 h-3" />{ipo.exchange || ipo.market}
                                  {ipo.industry && <Badge variant="outline" className="text-xs">{ipo.industry}</Badge>}
                                </p>
                              </div>
                              <Badge className={st.color}>{st.label}</Badge>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                              <div className="text-center p-3 rounded-lg bg-muted/50">
                                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><DollarSign className="w-3 h-3" />发行价</p>
                                <p className="text-lg font-bold font-mono">{ipo.ipoPrice ? `¥${parseFloat(ipo.ipoPrice).toFixed(2)}` : (ipo.issuePrice ? `¥${parseFloat(ipo.issuePrice).toFixed(2)}` : "待定")}</p>
                              </div>
                              <div className="text-center p-3 rounded-lg bg-muted/50">
                                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><TrendingUp className="w-3 h-3" />发行量</p>
                                <p className="text-lg font-bold">{ipo.ipoShares ? `${(parseInt(ipo.ipoShares) / 10000).toFixed(0)}万股` : (ipo.issueShares ? `${(parseInt(ipo.issueShares) / 10000).toFixed(0)}万股` : "待定")}</p>
                              </div>
                              <div className="text-center p-3 rounded-lg bg-muted/50">
                                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><Calendar className="w-3 h-3" />申购日期</p>
                                <p className="text-sm font-medium">{ipo.subscriptionStart ? new Date(ipo.subscriptionStart).toLocaleDateString('zh-CN') : "待定"}</p>
                              </div>
                              <div className="text-center p-3 rounded-lg bg-muted/50">
                                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><Clock className="w-3 h-3" />上市日期</p>
                                <p className="text-sm font-medium">{ipo.listingDate ? (typeof ipo.listingDate === 'string' ? ipo.listingDate : new Date(ipo.listingDate).toLocaleDateString('zh-CN')) : "待定"}</p>
                              </div>
                            </div>
                            {ipo.description && (
                              <p className="text-sm text-muted-foreground mt-3 line-clamp-2">{ipo.description}</p>
                            )}
                          </CardContent>
                        </Card>
                      );
                    })
                  )}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}
