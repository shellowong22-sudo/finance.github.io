import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  Brain, Zap, TrendingUp, Shield, BarChart3, Plus, Sparkles, Code, Target,
  ArrowRight, AlertTriangle,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

const strategyTypes: Record<string, { label: string; icon: typeof Brain; color: string }> = {
  trend: { label: "趋势跟踪", icon: TrendingUp, color: "text-blue-600 bg-blue-100" },
  mean_reversion: { label: "均值回归", icon: Target, color: "text-purple-600 bg-purple-100" },
  arbitrage: { label: "套利策略", icon: Zap, color: "text-amber-600 bg-amber-100" },
  momentum: { label: "动量策略", icon: ArrowRight, color: "text-green-600 bg-green-100" },
  value: { label: "价值投资", icon: Shield, color: "text-cyan-600 bg-cyan-100" },
  ml_based: { label: "机器学习", icon: Brain, color: "text-pink-600 bg-pink-100" },
  hft: { label: "高频交易", icon: Zap, color: "text-red-600 bg-red-100" },
  custom: { label: "自定义", icon: Code, color: "text-gray-600 bg-gray-100" },
};

const riskLabels: Record<string, { label: string; color: string }> = {
  conservative: { label: "保守型", color: "bg-green-100 text-green-700" },
  moderate: { label: "稳健型", color: "bg-blue-100 text-blue-700" },
  aggressive: { label: "激进型", color: "bg-red-100 text-red-700" },
};

export default function StrategyMarket() {
  const { isAuthenticated } = useAuth();
  const { data: strategies, isLoading } = trpc.quant.strategy.publicList.useQuery();
  const { data: myStrategies } = trpc.quant.strategy.list.useQuery(undefined, { enabled: isAuthenticated });
  const createMutation = trpc.quant.strategy.create.useMutation({
    onSuccess: () => { toast.success("策略创建成功"); },
  });
  const aiGenMutation = trpc.quant.strategy.aiGenerate.useMutation();

  const [showCreate, setShowCreate] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [newStrategy, setNewStrategy] = useState({ name: "", description: "", strategyType: "trend" as const, applicableMarkets: "a_share", riskLevel: "moderate" as const });
  const [aiDesc, setAiDesc] = useState("");
  const [aiMarket, setAiMarket] = useState("a_share");
  const [aiType, setAiType] = useState("trend");
  const [aiResult, setAiResult] = useState("");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Brain className="w-7 h-7 text-primary" />
              量化策略市场
            </h1>
            <p className="text-muted-foreground mt-1">探索、创建、回测量化交易策略</p>
          </div>
          <div className="flex gap-2">
            {isAuthenticated ? (
              <>
                <Dialog open={showAI} onOpenChange={setShowAI}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="gap-2">
                      <Sparkles className="w-4 h-4" />AI生成策略
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2"><Sparkles className="w-5 h-5 text-primary" />AI策略生成器</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Textarea placeholder="描述你想要的策略，例如：基于MACD金叉死叉的A股趋势策略，配合RSI过滤假信号..." value={aiDesc} onChange={(e) => setAiDesc(e.target.value)} rows={3} />
                      <div className="grid grid-cols-2 gap-3">
                        <Select value={aiType} onValueChange={setAiType}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(strategyTypes).map(([k, v]) => (
                              <SelectItem key={k} value={k}>{v.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={aiMarket} onValueChange={setAiMarket}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="a_share">A股</SelectItem>
                            <SelectItem value="us_stock">美股</SelectItem>
                            <SelectItem value="hk_stock">港股</SelectItem>
                            <SelectItem value="futures">期货</SelectItem>
                            <SelectItem value="global">全球</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button className="w-full gap-2" onClick={() => aiGenMutation.mutate({ description: aiDesc, strategyType: aiType, market: aiMarket }, { onSuccess: (d) => setAiResult(typeof d.code === 'string' ? d.code : '') })} disabled={!aiDesc || aiGenMutation.isPending}>
                        {aiGenMutation.isPending ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />生成中...</> : <><Sparkles className="w-4 h-4" />生成策略</>}
                      </Button>
                      {aiResult && (
                        <Card>
                          <CardContent className="p-4 prose prose-sm max-w-none">
                            <Streamdown>{aiResult}</Streamdown>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog open={showCreate} onOpenChange={setShowCreate}>
                  <DialogTrigger asChild>
                    <Button className="gap-2"><Plus className="w-4 h-4" />创建策略</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader><DialogTitle>创建新策略</DialogTitle></DialogHeader>
                    <div className="space-y-4">
                      <Input placeholder="策略名称" value={newStrategy.name} onChange={(e) => setNewStrategy({ ...newStrategy, name: e.target.value })} />
                      <Textarea placeholder="策略描述" value={newStrategy.description} onChange={(e) => setNewStrategy({ ...newStrategy, description: e.target.value })} />
                      <div className="grid grid-cols-2 gap-3">
                        <Select value={newStrategy.strategyType} onValueChange={(v) => setNewStrategy({ ...newStrategy, strategyType: v as any })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(strategyTypes).map(([k, v]) => (
                              <SelectItem key={k} value={k}>{v.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={newStrategy.riskLevel} onValueChange={(v) => setNewStrategy({ ...newStrategy, riskLevel: v as any })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="conservative">保守型</SelectItem>
                            <SelectItem value="moderate">稳健型</SelectItem>
                            <SelectItem value="aggressive">激进型</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button className="w-full" onClick={() => createMutation.mutate(newStrategy, { onSuccess: () => setShowCreate(false) })} disabled={!newStrategy.name || createMutation.isPending}>
                        创建策略
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </>
            ) : (
              <Button asChild><a href={getLoginUrl()}>登录后创建策略</a></Button>
            )}
          </div>
        </div>

        {/* My Strategies */}
        {isAuthenticated && myStrategies && myStrategies.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
              <Code className="w-5 h-5 text-primary" />我的策略
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myStrategies.map((s) => {
                const typeInfo = strategyTypes[s.strategyType] || strategyTypes.custom;
                const riskInfo = riskLabels[s.riskLevel || "moderate"];
                const Icon = typeInfo.icon;
                return (
                  <Card key={s.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${typeInfo.color}`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <Badge variant={s.status === "live" ? "default" : "secondary"} className="text-xs">
                          {s.status === "live" ? "运行中" : s.status === "draft" ? "草稿" : s.status === "paused" ? "已暂停" : s.status}
                        </Badge>
                      </div>
                      <CardTitle className="text-base mt-2">{s.name}</CardTitle>
                      <CardDescription className="line-clamp-2">{s.description || "暂无描述"}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="text-xs">{typeInfo.label}</Badge>
                        {riskInfo && <Badge className={`text-xs ${riskInfo.color}`}>{riskInfo.label}</Badge>}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Public Strategies */}
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />公开策略
        </h2>
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : strategies && strategies.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {strategies.map((s) => {
              const typeInfo = strategyTypes[s.strategyType] || strategyTypes.custom;
              const Icon = typeInfo.icon;
              return (
                <Card key={s.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${typeInfo.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <CardTitle className="text-base mt-2">{s.name}</CardTitle>
                    <CardDescription className="line-clamp-2">{s.description || "暂无描述"}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Badge variant="outline" className="text-xs">{typeInfo.label}</Badge>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="py-20 text-center">
              <Brain className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">暂无公开策略</p>
              <p className="text-sm text-muted-foreground/70 mt-1">创建策略并设为公开后将显示在此处</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
