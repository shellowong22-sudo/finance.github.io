import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import {
  Layers, TrendingUp, TrendingDown, RefreshCw, BarChart3,
  ArrowUpRight, ArrowDownRight, ChevronDown, ChevronUp, X, Star,
} from "lucide-react";
import { useState, useMemo, useCallback } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

// Color mapping for change percent
function getHeatBgStyle(pct: number): React.CSSProperties {
  const intensity = Math.min(Math.abs(pct) / 5, 1);
  if (pct >= 0) {
    const r = Math.round(34 + (1 - intensity) * 200);
    const g = Math.round(139 + (1 - intensity) * 80);
    const b = Math.round(34 + (1 - intensity) * 200);
    return { backgroundColor: `rgb(${r},${g},${b})`, color: intensity > 0.3 ? "white" : "#1a1a1a" };
  } else {
    const r = Math.round(220 - (1 - intensity) * 100);
    const g = Math.round(38 + (1 - intensity) * 180);
    const b = Math.round(38 + (1 - intensity) * 180);
    return { backgroundColor: `rgb(${r},${g},${b})`, color: intensity > 0.3 ? "white" : "#1a1a1a" };
  }
}

interface SectorData {
  sector: string;
  stockCount: number;
  avgChangePercent: number;
  totalVolume: number;
  totalTurnover: number;
  upCount: number;
  downCount: number;
  flatCount: number;
  stocks: Array<{ symbol: string; name: string; market: string; changePercent: number; lastPrice: number }>;
}

// Treemap layout algorithm (squarified)
interface TreemapRect {
  x: number; y: number; w: number; h: number; data: SectorData;
}

function layoutTreemap(sectors: SectorData[], width: number, height: number): TreemapRect[] {
  if (sectors.length === 0) return [];
  const totalWeight = sectors.reduce((sum, s) => sum + s.stockCount, 0);
  if (totalWeight === 0) return [];

  const sorted = [...sectors].sort((a, b) => b.stockCount - a.stockCount);
  const rects: TreemapRect[] = [];

  function squarify(items: SectorData[], x: number, y: number, w: number, h: number) {
    if (items.length === 0) return;
    if (items.length === 1) { rects.push({ x, y, w, h, data: items[0] }); return; }

    const total = items.reduce((s, i) => s + i.stockCount, 0);
    const isHorizontal = w >= h;
    let bestRatio = Infinity;
    let bestSplit = 1;

    for (let i = 1; i <= items.length; i++) {
      const sumA = items.slice(0, i).reduce((s, item) => s + item.stockCount, 0);
      if (isHorizontal) {
        const sliceW = w * (sumA / total);
        const maxRatio = items.slice(0, i).reduce((max, item) => {
          const itemH = h * (item.stockCount / sumA);
          return Math.max(max, Math.max(sliceW / itemH, itemH / sliceW));
        }, 0);
        if (maxRatio < bestRatio) { bestRatio = maxRatio; bestSplit = i; }
      } else {
        const sliceH = h * (sumA / total);
        const maxRatio = items.slice(0, i).reduce((max, item) => {
          const itemW = w * (item.stockCount / sumA);
          return Math.max(max, Math.max(sliceH / itemW, itemW / sliceH));
        }, 0);
        if (maxRatio < bestRatio) { bestRatio = maxRatio; bestSplit = i; }
      }
    }

    const groupA = items.slice(0, bestSplit);
    const groupB = items.slice(bestSplit);
    const sumA = groupA.reduce((s, i) => s + i.stockCount, 0);
    const fracA = sumA / total;

    if (isHorizontal) {
      const wA = w * fracA;
      let cy = y;
      for (const item of groupA) {
        const itemH = h * (item.stockCount / sumA);
        rects.push({ x, y: cy, w: wA, h: itemH, data: item });
        cy += itemH;
      }
      squarify(groupB, x + wA, y, w - wA, h);
    } else {
      const hA = h * fracA;
      let cx = x;
      for (const item of groupA) {
        const itemW = w * (item.stockCount / sumA);
        rects.push({ x: cx, y, w: itemW, h: hA, data: item });
        cx += itemW;
      }
      squarify(groupB, x, y + hA, w, h - hA);
    }
  }

  squarify(sorted, 0, 0, width, height);
  return rects;
}

const marketLabel: Record<string, string> = {
  a_share: "A股", us_stock: "美股", hk_stock: "港股", index: "指数",
  futures: "期货", option: "期权", fund: "基金", bond: "债券",
  crypto: "加密", forex: "外汇",
};

// Expanded stock list component for a sector
function SectorStockList({ sector, onClose }: { sector: SectorData; onClose: () => void }) {
  const [sortBy, setSortBy] = useState<"change" | "price">("change");
  const [sortDir, setSortDir] = useState<"desc" | "asc">("desc");
  const [showAll, setShowAll] = useState(false);
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const addMutation = trpc.quant.watchlist.add.useMutation({
    onSuccess: () => { toast.success("已添加到自选"); utils.quant.watchlist.list.invalidate(); },
    onError: () => toast.error("添加失败"),
  });

  const sortedStocks = useMemo(() => {
    const stocks = [...sector.stocks];
    if (sortBy === "change") {
      stocks.sort((a, b) => sortDir === "desc" ? b.changePercent - a.changePercent : a.changePercent - b.changePercent);
    } else {
      stocks.sort((a, b) => sortDir === "desc" ? b.lastPrice - a.lastPrice : a.lastPrice - b.lastPrice);
    }
    return stocks;
  }, [sector.stocks, sortBy, sortDir]);

  const displayStocks = showAll ? sortedStocks : sortedStocks.slice(0, 20);

  const toggleSort = (field: "change" | "price") => {
    if (sortBy === field) setSortDir(d => d === "desc" ? "asc" : "desc");
    else { setSortBy(field); setSortDir("desc"); }
  };

  return (
    <Card className="border-2 border-primary/30 shadow-lg animate-in slide-in-from-top-2 duration-300">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle className="text-lg">{sector.sector}</CardTitle>
            <Badge
              variant="outline"
              className={`font-mono font-bold ${
                sector.avgChangePercent > 0 ? "text-green-600 border-green-300" :
                sector.avgChangePercent < 0 ? "text-red-600 border-red-300" : ""
              }`}
            >
              {sector.avgChangePercent > 0 ? "+" : ""}{sector.avgChangePercent.toFixed(2)}%
            </Badge>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span>共 {sector.stockCount} 只</span>
          <span className="text-green-600 flex items-center gap-0.5">
            <ArrowUpRight className="w-3 h-3" /> {sector.upCount} 涨
          </span>
          <span className="text-red-600 flex items-center gap-0.5">
            <ArrowDownRight className="w-3 h-3" /> {sector.downCount} 跌
          </span>
          <span>{sector.flatCount} 平</span>
        </div>
        {/* Up/Down ratio bar */}
        <div className="h-2 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden flex mt-1">
          <div className="bg-green-500 h-full transition-all" style={{ width: `${(sector.upCount / sector.stockCount) * 100}%` }} />
          <div className="bg-gray-300 h-full transition-all" style={{ width: `${(sector.flatCount / sector.stockCount) * 100}%` }} />
          <div className="bg-red-500 h-full transition-all" style={{ width: `${(sector.downCount / sector.stockCount) * 100}%` }} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-2 font-medium w-8">#</th>
                <th className="text-left p-2 font-medium">代码</th>
                <th className="text-left p-2 font-medium">名称</th>
                <th className="text-left p-2 font-medium">市场</th>
                <th className="text-right p-2 font-medium cursor-pointer select-none hover:text-primary" onClick={() => toggleSort("price")}>
                  最新价 {sortBy === "price" && (sortDir === "desc" ? <ChevronDown className="w-3 h-3 inline" /> : <ChevronUp className="w-3 h-3 inline" />)}
                </th>
                <th className="text-right p-2 font-medium cursor-pointer select-none hover:text-primary" onClick={() => toggleSort("change")}>
                  涨跌幅 {sortBy === "change" && (sortDir === "desc" ? <ChevronDown className="w-3 h-3 inline" /> : <ChevronUp className="w-3 h-3 inline" />)}
                </th>
                {isAuthenticated && <th className="text-center p-2 font-medium w-16">操作</th>}
              </tr>
            </thead>
            <tbody>
              {displayStocks.map((stock, idx) => {
                const isUp = stock.changePercent > 0;
                const isDown = stock.changePercent < 0;
                const colorClass = isUp ? "text-green-600" : isDown ? "text-red-600" : "text-foreground";
                return (
                  <tr key={stock.symbol} className="border-b hover:bg-muted/30 transition-colors">
                    <td className="p-2 text-muted-foreground text-xs">{idx + 1}</td>
                    <td className="p-2 font-mono text-xs text-primary">{stock.symbol}</td>
                    <td className="p-2 font-medium text-sm">{stock.name}</td>
                    <td className="p-2">
                      <Badge variant="outline" className="text-[10px]">
                        {marketLabel[stock.market] || stock.market}
                      </Badge>
                    </td>
                    <td className={`p-2 text-right font-mono font-bold ${colorClass}`}>
                      {stock.lastPrice.toFixed(2)}
                    </td>
                    <td className={`p-2 text-right font-mono font-medium ${colorClass}`}>
                      <span className="inline-flex items-center gap-0.5">
                        {isUp ? <TrendingUp className="w-3 h-3" /> : isDown ? <TrendingDown className="w-3 h-3" /> : null}
                        {isUp ? "+" : ""}{stock.changePercent.toFixed(2)}%
                      </span>
                    </td>
                    {isAuthenticated && (
                      <td className="p-2 text-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0"
                          onClick={() => addMutation.mutate({ symbol: stock.symbol, name: stock.name, market: stock.market })}
                          disabled={addMutation.isPending}
                        >
                          <Star className="w-3.5 h-3.5 text-yellow-500" />
                        </Button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {sector.stocks.length > 20 && (
          <div className="flex justify-center mt-3">
            <Button variant="ghost" size="sm" onClick={() => setShowAll(!showAll)}>
              {showAll ? (
                <><ChevronUp className="w-4 h-4 mr-1" />收起</>
              ) : (
                <><ChevronDown className="w-4 h-4 mr-1" />展开全部 ({sector.stocks.length} 只)</>
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function SectorHeatmap() {
  const [expandedSector, setExpandedSector] = useState<SectorData | null>(null);
  const [viewMode, setViewMode] = useState<"treemap" | "grid">("treemap");

  const { data: sectors, isLoading, refetch } = trpc.quant.sectorHeatmap.data.useQuery(undefined, {
    refetchInterval: 30000,
  });

  const treemapRects = useMemo(() => {
    if (!sectors || sectors.length === 0) return [];
    return layoutTreemap(sectors as SectorData[], 1000, 600);
  }, [sectors]);

  const summary = useMemo(() => {
    if (!sectors) return { totalSectors: 0, totalStocks: 0, upSectors: 0, downSectors: 0 };
    return {
      totalSectors: sectors.length,
      totalStocks: sectors.reduce((s: number, sec: any) => s + sec.stockCount, 0),
      upSectors: sectors.filter((s: any) => s.avgChangePercent > 0).length,
      downSectors: sectors.filter((s: any) => s.avgChangePercent < 0).length,
    };
  }, [sectors]);

  const handleSectorClick = useCallback((sector: SectorData) => {
    setExpandedSector(prev => prev?.sector === sector.sector ? null : sector);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 text-white shadow-lg">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">板块热力图</h1>
              <p className="text-sm text-muted-foreground">
                {summary.totalSectors} 个板块 · {summary.totalStocks} 只个股 ·
                <span className="text-green-600 ml-1">{summary.upSectors} 涨</span>
                <span className="text-red-600 ml-1">{summary.downSectors} 跌</span>
                {expandedSector && <span className="ml-2 text-primary font-medium">· 点击板块查看个股</span>}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant={viewMode === "treemap" ? "default" : "outline"} size="sm" onClick={() => setViewMode("treemap")}>
              <Layers className="w-4 h-4 mr-1" />热力图
            </Button>
            <Button variant={viewMode === "grid" ? "default" : "outline"} size="sm" onClick={() => setViewMode("grid")}>
              <BarChart3 className="w-4 h-4 mr-1" />列表
            </Button>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <RefreshCw className="w-4 h-4 mr-1" />刷新
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-32">
            <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : viewMode === "treemap" ? (
          <>
            {/* Treemap Visualization */}
            <Card className="mb-4 overflow-hidden">
              <CardContent className="p-0">
                <div className="relative w-full" style={{ paddingBottom: "60%" }}>
                  <svg
                    viewBox="0 0 1000 600"
                    className="absolute inset-0 w-full h-full"
                    style={{ fontFamily: "system-ui, sans-serif" }}
                  >
                    {treemapRects.map((rect, i) => {
                      const pct = rect.data.avgChangePercent;
                      const style = getHeatBgStyle(pct);
                      const showLabel = rect.w > 50 && rect.h > 35;
                      const showDetail = rect.w > 80 && rect.h > 55;
                      const isExpanded = expandedSector?.sector === rect.data.sector;
                      return (
                        <g
                          key={i}
                          onClick={() => handleSectorClick(rect.data)}
                          className="cursor-pointer"
                        >
                          <rect
                            x={rect.x + 1}
                            y={rect.y + 1}
                            width={Math.max(0, rect.w - 2)}
                            height={Math.max(0, rect.h - 2)}
                            fill={style.backgroundColor}
                            rx={4}
                            stroke={isExpanded ? "#3b82f6" : "rgba(255,255,255,0.3)"}
                            strokeWidth={isExpanded ? 3 : 1}
                            opacity={expandedSector && !isExpanded ? 0.5 : 1}
                            style={{ transition: "opacity 0.3s, stroke-width 0.3s" }}
                          />
                          {showLabel && (
                            <>
                              <text
                                x={rect.x + rect.w / 2}
                                y={rect.y + rect.h / 2 - (showDetail ? 8 : 0)}
                                textAnchor="middle"
                                dominantBaseline="middle"
                                fill={style.color}
                                fontSize={Math.min(rect.w / 6, 16, rect.h / 4)}
                                fontWeight="bold"
                              >
                                {rect.data.sector}
                              </text>
                              {showDetail && (
                                <>
                                  <text
                                    x={rect.x + rect.w / 2}
                                    y={rect.y + rect.h / 2 + 10}
                                    textAnchor="middle"
                                    dominantBaseline="middle"
                                    fill={style.color}
                                    fontSize={Math.min(rect.w / 8, 13)}
                                    opacity={0.9}
                                  >
                                    {pct > 0 ? "+" : ""}{pct.toFixed(2)}%
                                  </text>
                                  <text
                                    x={rect.x + rect.w / 2}
                                    y={rect.y + rect.h / 2 + 26}
                                    textAnchor="middle"
                                    dominantBaseline="middle"
                                    fill={style.color}
                                    fontSize={Math.min(rect.w / 10, 11)}
                                    opacity={0.7}
                                  >
                                    {rect.data.stockCount}只 · 点击展开
                                  </text>
                                </>
                              )}
                            </>
                          )}
                        </g>
                      );
                    })}
                  </svg>
                </div>
              </CardContent>
            </Card>

            {/* Color Legend */}
            <div className="flex items-center justify-center gap-1 mb-4 flex-wrap">
              <span className="text-xs text-muted-foreground mr-2">涨跌幅:</span>
              {[
                { label: ">5%", color: "bg-green-700" },
                { label: "3~5%", color: "bg-green-600" },
                { label: "1~3%", color: "bg-green-500" },
                { label: "0~1%", color: "bg-green-400" },
                { label: "平", color: "bg-gray-300" },
                { label: "0~-1%", color: "bg-red-400" },
                { label: "-1~-3%", color: "bg-red-500" },
                { label: "-3~-5%", color: "bg-red-600" },
                { label: "<-5%", color: "bg-red-700" },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-1">
                  <div className={`w-4 h-3 rounded-sm ${item.color}`} />
                  <span className="text-[10px] text-muted-foreground">{item.label}</span>
                </div>
              ))}
            </div>

            {/* Expanded Sector Stock List */}
            {expandedSector && (
              <SectorStockList
                sector={expandedSector}
                onClose={() => setExpandedSector(null)}
              />
            )}
          </>
        ) : (
          /* Grid View */
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {(sectors as SectorData[])?.sort((a, b) => b.avgChangePercent - a.avgChangePercent).map((sector) => {
                const pct = sector.avgChangePercent;
                const isUp = pct > 0;
                const isDown = pct < 0;
                const isExpanded = expandedSector?.sector === sector.sector;
                return (
                  <Card
                    key={sector.sector}
                    className={`cursor-pointer transition-all ${
                      isExpanded ? "border-primary ring-2 ring-primary/20 shadow-md" :
                      isUp ? "border-green-200 hover:border-green-300 hover:shadow-md" :
                      isDown ? "border-red-200 hover:border-red-300 hover:shadow-md" :
                      "border-gray-200 hover:shadow-md"
                    }`}
                    onClick={() => handleSectorClick(sector)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-bold text-sm">{sector.sector}</span>
                        <Badge
                          variant="outline"
                          className={`text-[10px] font-mono font-bold ${
                            isUp ? "text-green-600 border-green-300" :
                            isDown ? "text-red-600 border-red-300" :
                            "text-muted-foreground"
                          }`}
                        >
                          {isUp ? "+" : ""}{pct.toFixed(2)}%
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span>{sector.stockCount}只</span>
                        <span className="text-green-600">{sector.upCount}涨</span>
                        <span className="text-red-600">{sector.downCount}跌</span>
                        <span>{sector.flatCount}平</span>
                      </div>
                      <div className="mt-2 h-1.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden flex">
                        <div className="bg-green-500 h-full" style={{ width: `${(sector.upCount / sector.stockCount) * 100}%` }} />
                        <div className="bg-red-500 h-full" style={{ width: `${(sector.downCount / sector.stockCount) * 100}%` }} />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1.5 text-center">点击展开个股列表</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Expanded Sector Stock List in Grid View */}
            {expandedSector && (
              <SectorStockList
                sector={expandedSector}
                onClose={() => setExpandedSector(null)}
              />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
