import Navbar from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import KLineChart from "@/components/KLineChart";
import {
  TrendingUp, TrendingDown, Search, Globe, BarChart3, Activity,
  ArrowUpRight, ArrowDownRight, Minus, CandlestickChart, Clock,
  Radio, Zap, Newspaper, Coins, Landmark, Shield, DollarSign,
  Bitcoin, LineChart, Layers, Star, Plus, Check,
} from "lucide-react";
import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

// ============================================================
// Market tabs - 10 categories
// ============================================================
const marketTabs = [
  { value: "all", label: "全部", icon: Globe },
  { value: "a_share", label: "A股", icon: BarChart3 },
  { value: "us_stock", label: "美股", icon: TrendingUp },
  { value: "hk_stock", label: "港股", icon: Activity },
  { value: "futures", label: "期货", icon: Layers },
  { value: "option", label: "期权", icon: Shield },
  { value: "fund", label: "基金", icon: Coins },
  { value: "bond", label: "债券", icon: Landmark },
  { value: "index", label: "全球指数", icon: LineChart },
  { value: "forex", label: "外汇", icon: DollarSign },
  { value: "crypto", label: "加密货币", icon: Bitcoin },
];

const periodOptions = [
  { value: "1m", label: "1分" },
  { value: "5m", label: "5分" },
  { value: "30m", label: "30分" },
  { value: "1h", label: "60分" },
  { value: "1d", label: "日K" },
  { value: "1w", label: "周K" },
];

const periodLimits: Record<string, number> = {
  "1m": 500, "5m": 300, "30m": 200, "1h": 200, "1d": 200, "1w": 200,
};

const marketLabel: Record<string, string> = {
  a_share: "A股", us_stock: "美股", hk_stock: "港股", index: "指数",
  futures: "期货", option: "期权", fund: "基金", bond: "债券",
  crypto: "加密", forex: "外汇", global: "全球",
};

// Index name mapping
const indexNameMap: Record<string, string> = {
  "000001.SH": "上证指数",
  "399001.SZ": "深证成指",
  "399006.SZ": "创业板指",
  "HSI": "恒生指数",
  "DJI": "道琼斯",
  "SPX": "标普500",
  "IXIC": "纳斯达克",
  "N225": "日经225",
  "FTSE": "富时100",
  "GDAXI": "DAX",
};

// ============================================================
// Client-side ultra-fast tick simulation
// ============================================================
interface SimulatedQuote {
  id: number;
  symbol: string;
  name: string;
  market: string;
  exchange: string | null;
  lastPrice: string;
  openPrice: string | null;
  highPrice: string | null;
  lowPrice: string | null;
  prevClose: string | null;
  change: string | null;
  changePercent: string | null;
  volume: number | null;
  turnover: string | null;
  marketCap: string | null;
  pe: string | null;
  pb: string | null;
  sector: string | null;
  // Client-side simulated fields
  _simPrice?: number;
  _simChange?: number;
  _simChangePercent?: number;
  _simHigh?: number;
  _simLow?: number;
  _simVolume?: number;
  _simTurnover?: number;
  _prevSimPrice?: number;
}

function useUltraFastTick(baseQuotes: SimulatedQuote[] | undefined, isLive: boolean, market: string) {
  const [simQuotes, setSimQuotes] = useState<SimulatedQuote[]>([]);
  const rafRef = useRef<number>(0);
  const lastTickRef = useRef<number>(0);
  const tickCountRef = useRef<number>(0);
  const [tickCount, setTickCount] = useState(0);
  const prevMarketRef = useRef(market);

  // Clear immediately when market tab changes
  useEffect(() => {
    if (prevMarketRef.current !== market) {
      prevMarketRef.current = market;
      setSimQuotes([]);
      tickCountRef.current = 0;
      setTickCount(0);
    }
  }, [market]);

  // Initialize simulated data from server data
  useEffect(() => {
    if (!baseQuotes || baseQuotes.length === 0) {
      setSimQuotes([]);
      return;
    }
    setSimQuotes(baseQuotes.map(q => ({
      ...q,
      _simPrice: parseFloat(q.lastPrice),
      _simChange: parseFloat(q.change || "0"),
      _simChangePercent: parseFloat(q.changePercent || "0"),
      _simHigh: parseFloat(q.highPrice || q.lastPrice),
      _simLow: parseFloat(q.lowPrice || q.lastPrice),
      _simVolume: q.volume || 0,
      _simTurnover: parseFloat(q.turnover || "0"),
      _prevSimPrice: parseFloat(q.lastPrice),
    })));
    tickCountRef.current = 0;
    setTickCount(0);
  }, [baseQuotes]);

  // Ultra-fast RAF tick loop
  useEffect(() => {
    if (!isLive || simQuotes.length === 0) return;

    const tick = (timestamp: number) => {
      // Tick every ~50ms (20 FPS) for smooth visual updates without CPU overload
      if (timestamp - lastTickRef.current >= 50) {
        lastTickRef.current = timestamp;
        tickCountRef.current += 1;

        setSimQuotes(prev => prev.map(q => {
          const price = q._simPrice || parseFloat(q.lastPrice);
          const prevClose = parseFloat(q.prevClose || q.lastPrice);
          // Micro volatility: 0.01% - 0.05% per tick
          const vol = 0.0001 + Math.random() * 0.0004;
          const dir = Math.random() > 0.48 ? 1 : -1; // slight upward bias
          const newPrice = +(price * (1 + vol * dir)).toFixed(4);
          const totalChange = +(newPrice - prevClose).toFixed(4);
          const changePct = +((totalChange / prevClose) * 100).toFixed(4);
          const newHigh = Math.max(q._simHigh || newPrice, newPrice);
          const newLow = Math.min(q._simLow || newPrice, newPrice);
          const volAdd = Math.floor(Math.random() * 5000 + 500);
          const newVol = (q._simVolume || 0) + volAdd;
          const newTurnover = (q._simTurnover || 0) + volAdd * newPrice;

          return {
            ...q,
            _prevSimPrice: price,
            _simPrice: newPrice,
            _simChange: totalChange,
            _simChangePercent: changePct,
            _simHigh: newHigh,
            _simLow: newLow,
            _simVolume: newVol,
            _simTurnover: newTurnover,
          };
        }));

        // Update visible tick count every 20 ticks
        if (tickCountRef.current % 20 === 0) {
          setTickCount(tickCountRef.current);
        }
      }

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [isLive, simQuotes.length]);

  return { simQuotes, tickCount };
}

// ============================================================
// Sub-components
// ============================================================
function WorldClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (tz: string) =>
    now.toLocaleTimeString("zh-CN", { timeZone: tz, hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });

  const zones = [
    { name: "北京", tz: "Asia/Shanghai", flag: "🇨🇳" },
    { name: "香港", tz: "Asia/Hong_Kong", flag: "🇭🇰" },
    { name: "纽约", tz: "America/New_York", flag: "🇺🇸" },
    { name: "伦敦", tz: "Europe/London", flag: "🇬🇧" },
    { name: "东京", tz: "Asia/Tokyo", flag: "🇯🇵" },
  ];

  return (
    <div className="flex items-center gap-4 text-xs flex-wrap">
      {zones.map((z) => (
        <div key={z.name} className="flex items-center gap-1.5">
          <span>{z.flag}</span>
          <span className="text-muted-foreground">{z.name}</span>
          <span className="font-mono font-bold text-foreground">{formatTime(z.tz)}</span>
        </div>
      ))}
    </div>
  );
}

function MarketStatus() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 10000);
    return () => clearInterval(timer);
  }, []);

  const getMinutes = (tz: string) => {
    const parts = now.toLocaleTimeString("en-US", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false }).split(":");
    return parseInt(parts[0]) * 60 + parseInt(parts[1]);
  };

  const getStatus = (market: string): { label: string; color: string; detail?: string } => {
    const dow = now.getDay();
    const isWeekend = dow === 0 || dow === 6;

    // A股：周末休市，集合竞价 9:15-9:25，上午盘 9:30-11:30，午休 11:30-13:00，下午盘 13:00-15:00
    if (market === "a_share" || market === "fund" || market === "bond") {
      if (isWeekend) return { label: "休市", color: "bg-gray-400", detail: "周末休市" };
      const t = getMinutes("Asia/Shanghai");
      if (t >= 555 && t < 565) return { label: "集合竞价", color: "bg-amber-500", detail: "9:15-9:25" };
      if (t >= 565 && t < 570) return { label: "开盘前", color: "bg-amber-500", detail: "9:25-9:30" };
      if (t >= 570 && t < 690) return { label: "交易中", color: "bg-green-500", detail: "上午盘 9:30-11:30" };
      if (t >= 690 && t < 780) return { label: "午间休市", color: "bg-yellow-500", detail: "11:30-13:00" };
      if (t >= 780 && t < 897) return { label: "交易中", color: "bg-green-500", detail: "下午盘 13:00-15:00" };
      if (t >= 897 && t < 900) return { label: "尾盘集合竞价", color: "bg-amber-500", detail: "14:57-15:00" };
      if (t >= 900) return { label: "已收盘", color: "bg-gray-400", detail: "15:00收盘" };
      return { label: "未开盘", color: "bg-gray-400", detail: "9:30开盘" };
    }

    // 港股：周末休市，开市前竞价 9:00-9:30，上午盘 9:30-12:00，午休 12:00-13:00，下午盘 13:00-16:00
    if (market === "hk_stock") {
      if (isWeekend) return { label: "休市", color: "bg-gray-400", detail: "周末休市" };
      const t = getMinutes("Asia/Hong_Kong");
      if (t >= 540 && t < 570) return { label: "开市前竞价", color: "bg-amber-500", detail: "9:00-9:30" };
      if (t >= 570 && t < 720) return { label: "交易中", color: "bg-green-500", detail: "上午盘 9:30-12:00" };
      if (t >= 720 && t < 780) return { label: "午间休市", color: "bg-yellow-500", detail: "12:00-13:00" };
      if (t >= 780 && t < 960) return { label: "交易中", color: "bg-green-500", detail: "下午盘 13:00-16:00" };
      if (t >= 960 && t < 976) return { label: "收市竞价", color: "bg-amber-500", detail: "16:00-16:10" };
      if (t >= 976) return { label: "已收盘", color: "bg-gray-400", detail: "16:00收盘" };
      return { label: "未开盘", color: "bg-gray-400", detail: "9:30开盘" };
    }

    // 美股：盘前 4:00-9:30，盘中 9:30-16:00，盘后 16:00-20:00（纽约时间）
    if (market === "us_stock") {
      if (isWeekend) return { label: "休市", color: "bg-gray-400", detail: "周末休市" };
      const t = getMinutes("America/New_York");
      if (t >= 240 && t < 570) return { label: "盘前交易", color: "bg-blue-500", detail: "Pre-Market 4:00-9:30" };
      if (t >= 570 && t < 960) return { label: "交易中", color: "bg-green-500", detail: "Regular 9:30-16:00" };
      if (t >= 960 && t < 1200) return { label: "盘后交易", color: "bg-purple-500", detail: "After-Hours 16:00-20:00" };
      return { label: "已收盘", color: "bg-gray-400", detail: "9:30开盘(ET)" };
    }

    // 加密货币/外汇：24小时交易
    if (market === "crypto") return { label: "24H交易", color: "bg-green-500", detail: "全天候交易" };
    if (market === "forex") {
      if (isWeekend) return { label: "休市", color: "bg-gray-400", detail: "周末休市" };
      return { label: "24H交易", color: "bg-green-500", detail: "工作日全天交易" };
    }

    // 期货/期权：日盘 9:00-11:30, 13:30-15:00，夜盘 21:00-23:00
    if (market === "futures" || market === "option") {
      if (isWeekend) return { label: "休市", color: "bg-gray-400", detail: "周末休市" };
      const t = getMinutes("Asia/Shanghai");
      if (t >= 540 && t < 625) return { label: "交易中", color: "bg-green-500", detail: "日盘 9:00-10:15" };
      if (t >= 625 && t < 630) return { label: "小节休息", color: "bg-yellow-500", detail: "10:15-10:30" };
      if (t >= 630 && t < 690) return { label: "交易中", color: "bg-green-500", detail: "日盘 10:30-11:30" };
      if (t >= 690 && t < 810) return { label: "午间休市", color: "bg-yellow-500", detail: "11:30-13:30" };
      if (t >= 810 && t < 900) return { label: "交易中", color: "bg-green-500", detail: "日盘 13:30-15:00" };
      if (t >= 1260 && t < 1380) return { label: "夜盘交易", color: "bg-indigo-500", detail: "夜盘 21:00-23:00" };
      return { label: "已收盘", color: "bg-gray-400" };
    }

    // 指数：跟随对应市场
    if (market === "index") {
      if (isWeekend) return { label: "休市", color: "bg-gray-400" };
      return { label: "交易中", color: "bg-green-500" };
    }

    return { label: "交易中", color: "bg-green-500" };
  };

  const markets = [
    { key: "a_share", label: "A股" },
    { key: "hk_stock", label: "港股" },
    { key: "us_stock", label: "美股" },
    { key: "futures", label: "期货" },
    { key: "option", label: "期权" },
    { key: "fund", label: "基金" },
    { key: "bond", label: "债券" },
    { key: "crypto", label: "加密" },
    { key: "forex", label: "外汇" },
  ];

  return (
    <div className="flex items-center gap-3 flex-wrap">
      {markets.map((m) => {
        const status = getStatus(m.key);
        const isActive = status.label.includes("交易") || status.label === "24H交易";
        return (
          <div key={m.key} className="flex items-center gap-1.5 text-xs group relative" title={status.detail || ""}>
            <div className={`w-2 h-2 rounded-full ${status.color} ${isActive ? "animate-pulse" : ""}`} />
            <span className="text-muted-foreground">{m.label}</span>
            <span className={`font-medium ${isActive ? "text-green-600 dark:text-green-400" : ""}`}>{status.label}</span>
            {status.detail && (
              <span className="hidden group-hover:block absolute -bottom-6 left-0 bg-popover text-popover-foreground text-[10px] px-2 py-0.5 rounded shadow-md border whitespace-nowrap z-50">
                {status.detail}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

function NewsTicker() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [offset, setOffset] = useState(0);
  const { data: newsData } = trpc.quant.news.latest.useQuery(undefined, {
    refetchInterval: 60000, // Refresh news every minute
  });
  const headlines = useMemo(() => {
    const items = newsData?.map((n: any) => n.title) || ["全球行情数据加载中..."];
    return [...items, ...items];
  }, [newsData]);
  const itemCount = newsData?.length || 1;

  useEffect(() => {
    const timer = setInterval(() => {
      setOffset((prev) => {
        const maxOffset = itemCount * 400;
        return prev >= maxOffset ? 0 : prev + 1;
      });
    }, 25);
    return () => clearInterval(timer);
  }, [itemCount]);

  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 rounded-lg border border-primary/10 py-2 px-3">
      <div className="flex items-center gap-2 absolute left-3 top-1/2 -translate-y-1/2 z-10 bg-gradient-to-r from-primary/5 via-primary/5 to-transparent pr-6">
        <Newspaper className="w-3.5 h-3.5 text-primary" />
        <Badge variant="default" className="text-[10px] px-1.5 py-0 bg-green-600 hover:bg-green-600">快讯</Badge>
      </div>
      <div ref={containerRef} className="overflow-hidden ml-20">
        <div className="flex gap-12 whitespace-nowrap" style={{ transform: `translateX(-${offset}px)` }}>
          {headlines.map((h: string, i: number) => (
            <span key={i} className="text-xs text-foreground/80 inline-flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-primary/50" />
              {h}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Format helpers
// ============================================================
function formatVolume(vol: number | null | undefined): string {
  if (!vol) return "-";
  if (vol > 1e8) return `${(vol / 1e8).toFixed(2)}亿`;
  if (vol > 1e4) return `${(vol / 1e4).toFixed(0)}万`;
  return vol.toLocaleString();
}

function formatAmount(amt: number | string | null | undefined): string {
  if (!amt) return "-";
  const n = typeof amt === "string" ? parseFloat(amt) : amt;
  if (n > 1e8) return `${(n / 1e8).toFixed(2)}亿`;
  if (n > 1e4) return `${(n / 1e4).toFixed(0)}万`;
  return n.toFixed(2);
}

function formatPrice(price: number, market: string): string {
  if (market === "forex") return price.toFixed(4);
  if (market === "crypto" && price < 1) return price.toFixed(4);
  if (market === "option" && price < 1) return price.toFixed(4);
  if (market === "bond") return price.toFixed(3);
  if (market === "fund") return price.toFixed(4);
  if (price < 0.01) return price.toFixed(6);
  if (price < 1) return price.toFixed(4);
  return price.toFixed(2);
}

// ============================================================
// Main Component
// ============================================================
// ============================================================
// Index Card with Mini Sparkline Chart
// ============================================================
function IndexCardWithSparkline({ index: idx, onClickIndex }: { index: any; onClickIndex?: (idx: any) => void }) {
  const price = parseFloat(idx.lastPrice);
  const pct = parseFloat(idx.changePercent || "0");
  const changeVal = parseFloat(idx.change || "0");
  const isUp = pct > 0;
  const isDown = pct < 0;

  // Fetch intraday data for sparkline
  const { data: intradayData } = trpc.quant.indices.intraday.useQuery(
    { symbol: idx.symbol },
    { refetchInterval: 60000, staleTime: 30000 }
  );

  // Generate SVG sparkline path
  const sparklinePath = useMemo(() => {
    if (!intradayData || intradayData.length < 2) return null;
    const prices = intradayData.map((p: any) => p.price);
    const minP = Math.min(...prices);
    const maxP = Math.max(...prices);
    const range = maxP - minP || 1;
    const w = 120;
    const h = 32;
    const padding = 2;

    const points = prices.map((p: number, i: number) => {
      const x = padding + (i / (prices.length - 1)) * (w - 2 * padding);
      const y = padding + (1 - (p - minP) / range) * (h - 2 * padding);
      return `${x},${y}`;
    });

    // Line path
    const linePath = `M${points.join(" L")}`;
    // Area path (fill below line)
    const areaPath = `${linePath} L${w - padding},${h} L${padding},${h} Z`;

    // Baseline (prevClose)
    const prevClose = parseFloat(idx.prevClose || idx.lastPrice);
    const baselineY = padding + (1 - (prevClose - minP) / range) * (h - 2 * padding);

    return { linePath, areaPath, baselineY, w, h };
  }, [intradayData, idx.prevClose, idx.lastPrice]);

  const lineColor = isUp ? "#16a34a" : isDown ? "#dc2626" : "#6b7280";
  const fillColor = isUp ? "rgba(22,163,74,0.15)" : isDown ? "rgba(220,38,38,0.15)" : "rgba(107,114,128,0.08)";

  return (
    <Card
      className={`border overflow-hidden cursor-pointer ${
        isUp ? "border-green-200 bg-green-50/30 dark:bg-green-950/10" :
        isDown ? "border-red-200 bg-red-50/30 dark:bg-red-950/10" :
        "border-gray-200"
      } transition-all hover:shadow-md hover:scale-[1.02]`}
      onClick={() => onClickIndex?.(idx)}
    >
      <CardContent className="p-3">
        <div className="flex items-start justify-between mb-1">
          <p className="text-xs text-muted-foreground font-medium truncate">
            {indexNameMap[idx.symbol] || idx.name}
          </p>
          <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
            isUp ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" :
            isDown ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400" :
            "bg-gray-100 text-gray-600"
          }`}>
            {isUp ? "+" : ""}{pct.toFixed(2)}%
          </span>
        </div>
        <p className={`text-lg font-bold font-mono ${
          isUp ? "text-green-600" : isDown ? "text-red-600" : "text-foreground"
        }`}>
          {price > 10000 ? price.toFixed(0) : price.toFixed(2)}
        </p>
        <span className={`text-[11px] font-mono ${
          isUp ? "text-green-600" : isDown ? "text-red-600" : "text-muted-foreground"
        }`}>
          {isUp ? "+" : ""}{changeVal.toFixed(2)}
        </span>

        {/* Mini Sparkline */}
        <div className="mt-1.5">
          {sparklinePath ? (
            <svg
              viewBox={`0 0 ${sparklinePath.w} ${sparklinePath.h}`}
              className="w-full"
              style={{ height: 32 }}
              preserveAspectRatio="none"
            >
              {/* Baseline */}
              <line
                x1={2}
                y1={sparklinePath.baselineY}
                x2={sparklinePath.w - 2}
                y2={sparklinePath.baselineY}
                stroke="#9ca3af"
                strokeWidth={0.5}
                strokeDasharray="3,3"
                opacity={0.5}
              />
              {/* Area fill */}
              <path d={sparklinePath.areaPath} fill={fillColor} />
              {/* Line */}
              <path d={sparklinePath.linePath} fill="none" stroke={lineColor} strokeWidth={1.5} />
            </svg>
          ) : (
            <div className="h-8 flex items-center justify-center">
              <div className="w-full h-[1px] bg-muted-foreground/20" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function MarketBoard() {
  const [market, setMarket] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedStock, setSelectedStock] = useState<{ symbol: string; market: string; name: string } | null>(null);
  const [klinePeriod, setKlinePeriod] = useState("1d");
  const [isLive, setIsLive] = useState(true);
  const [klineIndicator, setKlineIndicator] = useState<"MACD" | "KDJ" | "RSI" | "NONE">("MACD");
  const { user, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  // Fetch main indices for overview cards
  const { data: mainIndices } = trpc.quant.indices.main.useQuery(undefined, {
    refetchInterval: isLive ? 15000 : false,
  });

  // Watchlist add mutation
  const addToWatchlist = trpc.quant.watchlist.add.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      utils.quant.watchlist.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const { data: baseQuotes, isLoading, isFetching } = trpc.quant.market.quotes.useQuery(
    { market, search: search || undefined, limit: 200 },
    { refetchInterval: isLive ? 10000 : false, placeholderData: undefined } // Slow server refresh, fast client sim
  );

  const { simQuotes, tickCount } = useUltraFastTick(baseQuotes as any, isLive, market);

  // Flash detection
  const [flashMap, setFlashMap] = useState<Record<number, "up" | "down" | null>>({});
  const prevPricesRef = useRef<Record<number, number>>({});

  useEffect(() => {
    if (!simQuotes || simQuotes.length === 0) return;
    const newFlash: Record<number, "up" | "down" | null> = {};
    for (const q of simQuotes) {
      const curr = q._simPrice || 0;
      const prev = q._prevSimPrice || curr;
      if (prev !== curr) {
        newFlash[q.id] = curr > prev ? "up" : "down";
      }
    }
    if (Object.keys(newFlash).length > 0) {
      setFlashMap(newFlash);
      const timer = setTimeout(() => setFlashMap({}), 300);
      return () => clearTimeout(timer);
    }
  }, [simQuotes]);

  const sortedQuotes = useMemo(() => {
    if (!simQuotes || simQuotes.length === 0) return [];
    return [...simQuotes].sort((a, b) => {
      const aChange = Math.abs(a._simChangePercent || 0);
      const bChange = Math.abs(b._simChangePercent || 0);
      return bChange - aChange;
    });
  }, [simQuotes]);

  const stats = useMemo(() => {
    if (!simQuotes || simQuotes.length === 0) return { up: 0, down: 0, flat: 0, total: 0 };
    return {
      up: simQuotes.filter(q => (q._simChangePercent || 0) > 0).length,
      down: simQuotes.filter(q => (q._simChangePercent || 0) < 0).length,
      flat: simQuotes.filter(q => (q._simChangePercent || 0) === 0).length,
      total: simQuotes.length,
    };
  }, [simQuotes]);

  const topMovers = useMemo(() => {
    if (!simQuotes || simQuotes.length === 0) return { gainers: [], losers: [] };
    const sorted = [...simQuotes].sort((a, b) => (b._simChangePercent || 0) - (a._simChangePercent || 0));
    return {
      gainers: sorted.slice(0, 5),
      losers: sorted.slice(-5).reverse(),
    };
  }, [simQuotes]);

  const klineSymbols = useMemo(() => new Set([
    "000858.SZ", "002475.SZ", "002594.SZ", "00700.HK", "01810.HK", "09988.HK",
    "300750.SZ", "600036.SH", "600519.SH", "601318.SH", "601899.SH",
    "AAPL", "MSFT", "NVDA", "TSLA",
    // Index symbols for click-to-K-line
    "000001.SH", "399001.SZ", "399006.SZ", "HSI", "DJI", "SPX", "IXIC", "N225", "FTSE", "GDAXI",
  ]), []);

  const hasKlineData = (symbol: string) => klineSymbols.has(symbol);

  const handleStockClick = (q: SimulatedQuote) => {
    if (hasKlineData(q.symbol)) {
      setSelectedStock({ symbol: q.symbol, market: q.market, name: q.name });
      setKlinePeriod("1d");
    }
  };

  const { data: klineData, isLoading: klineLoading } = trpc.quant.market.kline.useQuery(
    { symbol: selectedStock?.symbol || "", market: selectedStock?.market || "", period: klinePeriod, limit: periodLimits[klinePeriod] || 200 },
    { enabled: !!selectedStock, refetchInterval: selectedStock ? 1000 : false }
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* News Ticker */}
      <div className="container pt-4 pb-2">
        <NewsTicker />
      </div>

      {/* Index Overview Cards with Mini Sparklines */}
      {mainIndices && mainIndices.length > 0 && (
        <div className="container py-3">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-5 gap-3">
            {mainIndices.map((idx: any) => (
              <IndexCardWithSparkline
                key={idx.symbol}
                index={idx}
                onClickIndex={(index) => {
                  setSelectedStock({
                    symbol: index.symbol,
                    market: "index",
                    name: indexNameMap[index.symbol] || index.name,
                  });
                  setKlinePeriod("1d");
                }}
              />
            ))}
          </div>
        </div>
      )}

      <div className="container py-4">
        {/* Header */}
        <div className="flex flex-col gap-3 mb-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Globe className="w-8 h-8 text-primary" />
                <div className={`absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background ${isLive ? "bg-green-500 animate-pulse" : "bg-gray-400"}`} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  全球行情看板
                  {isLive && (
                    <Badge variant="default" className="text-[10px] px-1.5 py-0 bg-green-600 hover:bg-green-600 animate-pulse">
                      <Radio className="w-3 h-3 mr-0.5" />
                      LIVE
                    </Badge>
                  )}
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 font-mono">
                    {stats.total} 品种
                  </Badge>
                </h1>
                <p className="text-muted-foreground text-sm mt-0.5">
                  股票 · 期货 · 期权 · 基金 · 债券 · 外汇 · 加密货币 · 全球指数
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="搜索代码/名称..."
                  className="pl-9 w-60"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <Button
                variant={isLive ? "default" : "outline"}
                size="sm"
                onClick={() => setIsLive(!isLive)}
                className={isLive ? "bg-green-600 hover:bg-green-700" : ""}
              >
                <Zap className="w-4 h-4 mr-1" />
                {isLive ? "实时" : "暂停"}
              </Button>
            </div>
          </div>

          {/* World Clock + Market Status */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2 px-1">
            <WorldClock />
            <MarketStatus />
          </div>
        </div>

        {/* Stats Cards + Top Movers */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-5">
          <div className="lg:col-span-4 grid grid-cols-3 gap-3">
            <Card className="border-green-200 bg-green-50/50 dark:bg-green-950/20">
              <CardContent className="p-3 text-center">
                <ArrowUpRight className="w-5 h-5 text-green-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-green-600">{stats.up}</p>
                <p className="text-[10px] text-muted-foreground">上涨</p>
              </CardContent>
            </Card>
            <Card className="border-red-200 bg-red-50/50 dark:bg-red-950/20">
              <CardContent className="p-3 text-center">
                <ArrowDownRight className="w-5 h-5 text-red-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-red-600">{stats.down}</p>
                <p className="text-[10px] text-muted-foreground">下跌</p>
              </CardContent>
            </Card>
            <Card className="border-gray-200 bg-gray-50/50 dark:bg-gray-950/20">
              <CardContent className="p-3 text-center">
                <Minus className="w-5 h-5 text-gray-500 mx-auto mb-1" />
                <p className="text-2xl font-bold text-gray-600">{stats.flat}</p>
                <p className="text-[10px] text-muted-foreground">平盘</p>
              </CardContent>
            </Card>
          </div>

          {/* Top Gainers */}
          <div className="lg:col-span-4">
            <Card className="h-full">
              <CardContent className="p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <span className="text-xs font-bold text-green-600">涨幅榜 TOP5</span>
                </div>
                <div className="space-y-1.5">
                  {topMovers.gainers.map((q, i) => (
                    <div key={q.id} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded-full bg-green-100 text-green-700 text-[10px] font-bold flex items-center justify-center">{i + 1}</span>
                        <span className="font-medium truncate max-w-[80px]">{q.name}</span>
                        <span className="text-muted-foreground font-mono text-[10px]">{q.symbol}</span>
                      </div>
                      <span className="font-mono font-bold text-green-600">+{(q._simChangePercent || 0).toFixed(2)}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Losers */}
          <div className="lg:col-span-4">
            <Card className="h-full">
              <CardContent className="p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <TrendingDown className="w-4 h-4 text-red-600" />
                  <span className="text-xs font-bold text-red-600">跌幅榜 TOP5</span>
                </div>
                <div className="space-y-1.5">
                  {topMovers.losers.map((q, i) => (
                    <div key={q.id} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded-full bg-red-100 text-red-700 text-[10px] font-bold flex items-center justify-center">{i + 1}</span>
                        <span className="font-medium truncate max-w-[80px]">{q.name}</span>
                        <span className="text-muted-foreground font-mono text-[10px]">{q.symbol}</span>
                      </div>
                      <span className="font-mono font-bold text-red-600">{(q._simChangePercent || 0).toFixed(2)}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Live indicator bar */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="w-3.5 h-3.5" />
            <span>客户端极速模拟 · 50ms/tick</span>
            {tickCount > 0 && <span className="font-mono">· 已更新 {tickCount.toLocaleString()} 次</span>}
          </div>
          {isLive ? (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[10px] text-green-600 font-medium">极速推送中</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-gray-400" />
              <span className="text-[10px] text-muted-foreground font-medium">已暂停</span>
            </div>
          )}
        </div>

        {/* Market Tabs + Table */}
        <Tabs value={market} onValueChange={setMarket}>
          <TabsList className="mb-4 flex-wrap h-auto gap-1">
            {marketTabs.map((tab) => (
              <TabsTrigger key={tab.value} value={tab.value} className="gap-1.5">
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {marketTabs.map((tab) => (
            <TabsContent key={tab.value} value={tab.value} className="mt-2">
              {(isLoading || (isFetching && sortedQuotes.length === 0)) ? (
                <div className="flex items-center justify-center py-20">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : sortedQuotes.length === 0 ? (
                <Card>
                  <CardContent className="py-20 text-center">
                    <BarChart3 className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                    <p className="text-muted-foreground">暂无行情数据</p>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                      <table className="w-full text-sm">
                        <thead className="sticky top-0 z-10">
                          <tr className="border-b bg-muted/90 backdrop-blur-sm">
                            <th className="text-left p-3 font-medium">代码</th>
                            <th className="text-left p-3 font-medium">名称</th>
                            <th className="text-left p-3 font-medium">市场</th>
                            <th className="text-right p-3 font-medium">最新价</th>
                            <th className="text-right p-3 font-medium">涨跌额</th>
                            <th className="text-right p-3 font-medium">涨跌幅</th>
                            <th className="text-right p-3 font-medium">成交量</th>
                            <th className="text-right p-3 font-medium">成交额</th>
                            <th className="text-left p-3 font-medium">板块</th>
                            <th className="text-center p-3 font-medium">K线</th>
                            {isAuthenticated && <th className="text-center p-3 font-medium">自选</th>}
                          </tr>
                        </thead>
                        <tbody>
                          {sortedQuotes.map((q) => {
                            const changePct = q._simChangePercent || 0;
                            const price = q._simPrice || parseFloat(q.lastPrice);
                            const changeVal = q._simChange || 0;
                            const isUp = changePct > 0;
                            const isDown = changePct < 0;
                            const colorClass = isUp ? "text-green-600" : isDown ? "text-red-600" : "text-foreground";
                            const hasKline = hasKlineData(q.symbol);
                            const flash = flashMap[q.id];
                            const flashBg = flash === "up"
                              ? "bg-green-100/60 dark:bg-green-900/20"
                              : flash === "down"
                              ? "bg-red-100/60 dark:bg-red-900/20"
                              : "";

                            return (
                              <tr
                                key={q.id}
                                className={`border-b transition-colors duration-200 ${hasKline ? "hover:bg-primary/5 cursor-pointer" : "hover:bg-muted/30"} ${flashBg}`}
                                onClick={() => handleStockClick(q)}
                              >
                                <td className="p-3 font-mono font-medium text-primary text-xs">{q.symbol}</td>
                                <td className="p-3 font-medium text-xs">{q.name}</td>
                                <td className="p-3">
                                  <Badge variant="outline" className="text-[10px]">{marketLabel[q.market] || q.market}</Badge>
                                </td>
                                <td className={`p-3 text-right font-mono font-bold ${colorClass}`}>
                                  {formatPrice(price, q.market)}
                                </td>
                                <td className={`p-3 text-right font-mono text-xs ${colorClass}`}>
                                  {isUp ? "+" : ""}{changeVal.toFixed(2)}
                                </td>
                                <td className={`p-3 text-right font-mono font-medium ${colorClass}`}>
                                  <span className="inline-flex items-center gap-1">
                                    {isUp ? <TrendingUp className="w-3 h-3" /> : isDown ? <TrendingDown className="w-3 h-3" /> : null}
                                    {isUp ? "+" : ""}{changePct.toFixed(2)}%
                                  </span>
                                </td>
                                <td className="p-3 text-right font-mono text-muted-foreground text-xs">
                                  {formatVolume(q._simVolume)}
                                </td>
                                <td className="p-3 text-right font-mono text-muted-foreground text-xs">
                                  {formatAmount(q._simTurnover)}
                                </td>
                                <td className="p-3">
                                  {q.sector && <Badge variant="secondary" className="text-[10px]">{q.sector}</Badge>}
                                </td>
                                <td className="p-3 text-center">
                                  {hasKline ? (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-7 w-7 p-0 text-primary hover:text-primary hover:bg-primary/10"
                                      onClick={(e) => { e.stopPropagation(); handleStockClick(q); }}
                                    >
                                      <CandlestickChart className="w-4 h-4" />
                                    </Button>
                                  ) : (
                                    <span className="text-muted-foreground/30 text-xs">-</span>
                                  )}
                                </td>
                                {isAuthenticated && (
                                  <td className="p-3 text-center">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-7 w-7 p-0 text-yellow-500 hover:text-yellow-600 hover:bg-yellow-50"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addToWatchlist.mutate({ symbol: q.symbol, name: q.name, market: q.market });
                                      }}
                                      disabled={addToWatchlist.isPending}
                                    >
                                      <Star className="w-4 h-4" />
                                    </Button>
                                  </td>
                                )}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* K-Line Chart Dialog */}
      <Dialog open={!!selectedStock} onOpenChange={(open) => { if (!open) setSelectedStock(null); }}>
        <DialogContent className="max-w-5xl w-[95vw] p-0 gap-0 overflow-hidden">
          <DialogHeader className="px-6 pt-5 pb-3 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CandlestickChart className="w-5 h-5 text-primary" />
                <DialogTitle className="text-lg">
                  {selectedStock?.name}
                  <span className="text-sm font-mono text-muted-foreground ml-2">{selectedStock?.symbol}</span>
                  <Badge variant="outline" className="ml-2 text-xs">{marketLabel[selectedStock?.market || ""] || selectedStock?.market}</Badge>
                </DialogTitle>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-muted rounded-lg p-0.5">
                  {periodOptions.map((p) => (
                    <button
                      key={p.value}
                      onClick={() => setKlinePeriod(p.value)}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${
                        klinePeriod === p.value
                          ? "bg-background text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </DialogHeader>
          <div className="px-4 py-3">
            {klineLoading ? (
              <div className="flex items-center justify-center" style={{ height: 500 }}>
                <div className="text-center">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">加载K线数据...</p>
                </div>
              </div>
            ) : (
              <KLineChart
                data={klineData || []}
                stockName={selectedStock?.name}
                symbol={selectedStock?.symbol}
                height={580}
                showMA={true}
                showVolume={true}
                indicator={klineIndicator}
                onIndicatorChange={setKlineIndicator}
              />
            )}
          </div>
          {klineData && klineData.length > 0 && (
            <div className="px-6 pb-4 flex items-center justify-between text-xs text-muted-foreground border-t pt-3">
              <div className="flex items-center gap-6">
                <span>数据区间: {new Date(klineData[klineData.length - 1]?.timestamp || 0).toLocaleDateString("zh-CN")} ~ {new Date(klineData[0]?.timestamp || 0).toLocaleDateString("zh-CN")}</span>
                <span>共 {klineData.length} 根K线</span>
                <span>周期: {periodOptions.find(p => p.value === klinePeriod)?.label}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[10px] text-green-600 font-medium">实时更新中</span>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
