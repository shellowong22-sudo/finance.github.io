import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";
import {
  Star, StarOff, Search, Plus, Trash2, TrendingUp, TrendingDown,
  BarChart3, RefreshCw, LogIn, Bell, BellOff, BellRing, AlertTriangle,
  Settings2,
} from "lucide-react";
import { useState, useMemo } from "react";

const marketLabel: Record<string, string> = {
  a_share: "A股", us_stock: "美股", hk_stock: "港股", index: "指数",
  futures: "期货", option: "期权", fund: "基金", bond: "债券",
  crypto: "加密", forex: "外汇",
};

const alertTypeLabels: Record<string, string> = {
  change_percent_above: "涨幅超过",
  change_percent_below: "跌幅超过",
  price_above: "价格高于",
  price_below: "价格低于",
};

const alertTypeUnits: Record<string, string> = {
  change_percent_above: "%",
  change_percent_below: "%",
  price_above: "",
  price_below: "",
};

function formatPrice(price: number, market: string): string {
  if (market === "forex") return price.toFixed(4);
  if (market === "crypto" && price < 1) return price.toFixed(4);
  if (market === "bond") return price.toFixed(3);
  if (market === "fund") return price.toFixed(4);
  if (price < 1) return price.toFixed(4);
  return price.toFixed(2);
}

function formatVolume(vol: number | null | undefined): string {
  if (!vol) return "-";
  if (vol > 1e8) return `${(vol / 1e8).toFixed(2)}亿`;
  if (vol > 1e4) return `${(vol / 1e4).toFixed(0)}万`;
  return vol.toLocaleString();
}

export default function Watchlist() {
  const { user, isAuthenticated } = useAuth();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showAlertDialog, setShowAlertDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Alert form state
  const [alertSymbol, setAlertSymbol] = useState("");
  const [alertName, setAlertName] = useState("");
  const [alertMarket, setAlertMarket] = useState("");
  const [alertType, setAlertType] = useState<string>("change_percent_above");
  const [alertThreshold, setAlertThreshold] = useState("");
  const [alertCooldown, setAlertCooldown] = useState("30");

  const utils = trpc.useUtils();

  // Fetch watchlist with quotes
  const { data: watchlist, isLoading } = trpc.quant.watchlist.list.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 10000,
  });

  // Fetch portfolio stats
  const { data: portfolioStats } = trpc.quant.watchlist.portfolioStats.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 15000,
  });

  // Fetch price alerts
  const { data: alerts } = trpc.quant.priceAlert.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Search available stocks to add
  const { data: searchResults } = trpc.quant.market.quotes.useQuery(
    { search: searchQuery, limit: 20 },
    { enabled: searchQuery.length >= 1 }
  );

  // Add to watchlist
  const addMutation = trpc.quant.watchlist.add.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      utils.quant.watchlist.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  // Remove from watchlist
  const removeMutation = trpc.quant.watchlist.remove.useMutation({
    onMutate: async ({ id }) => {
      await utils.quant.watchlist.list.cancel();
      const prev = utils.quant.watchlist.list.getData();
      utils.quant.watchlist.list.setData(undefined, (old) =>
        old ? old.filter((item: any) => item.id !== id) : []
      );
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) utils.quant.watchlist.list.setData(undefined, ctx.prev);
      toast.error("移除失败");
    },
    onSettled: () => utils.quant.watchlist.list.invalidate(),
  });

  // Create price alert
  const createAlertMutation = trpc.quant.priceAlert.create.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      utils.quant.priceAlert.list.invalidate();
      setShowAlertDialog(false);
      resetAlertForm();
    },
    onError: (err) => toast.error(err.message),
  });

  // Toggle alert
  const updateAlertMutation = trpc.quant.priceAlert.update.useMutation({
    onSuccess: () => {
      utils.quant.priceAlert.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  // Delete alert
  const deleteAlertMutation = trpc.quant.priceAlert.delete.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      utils.quant.priceAlert.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleAdd = (symbol: string, name: string, market: string) => {
    addMutation.mutate({ symbol, name, market });
  };

  const handleRemove = (id: number, name: string) => {
    removeMutation.mutate({ id });
    toast.success(`已移除 ${name}`);
  };

  const resetAlertForm = () => {
    setAlertSymbol("");
    setAlertName("");
    setAlertMarket("");
    setAlertType("change_percent_above");
    setAlertThreshold("");
    setAlertCooldown("30");
  };

  const openAlertDialog = (symbol: string, name: string, market: string) => {
    setAlertSymbol(symbol);
    setAlertName(name);
    setAlertMarket(market);
    setShowAlertDialog(true);
  };

  const handleCreateAlert = () => {
    if (!alertThreshold || isNaN(parseFloat(alertThreshold))) {
      toast.error("请输入有效的阈值");
      return;
    }
    createAlertMutation.mutate({
      symbol: alertSymbol,
      name: alertName,
      market: alertMarket,
      alertType: alertType as any,
      threshold: alertThreshold,
      cooldownMinutes: parseInt(alertCooldown) || 30,
    });
  };

  // Check which search results are already in watchlist
  const watchlistSymbols = useMemo(() => {
    if (!watchlist) return new Set<string>();
    return new Set(watchlist.map((w: any) => `${w.symbol}|${w.market}`));
  }, [watchlist]);

  // Group alerts by symbol
  const alertsBySymbol = useMemo(() => {
    if (!alerts) return new Map<string, any[]>();
    const map = new Map<string, any[]>();
    for (const a of alerts) {
      const key = `${a.symbol}|${a.market}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(a);
    }
    return map;
  }, [alerts]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <Star className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">自选股管理</h2>
          <p className="text-muted-foreground mb-6">登录后即可管理您的自选股列表</p>
          <a href={getLoginUrl()}>
            <Button size="lg">
              <LogIn className="w-4 h-4 mr-2" />
              登录
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Star className="w-7 h-7 text-yellow-500 fill-yellow-500" />
            <div>
              <h1 className="text-2xl font-bold">我的自选</h1>
              <p className="text-sm text-muted-foreground">
                共 {watchlist?.length || 0} 只自选品种 · {alerts?.length || 0} 条预警规则
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => utils.quant.watchlist.list.invalidate()}>
              <RefreshCw className="w-4 h-4 mr-1" />
              刷新
            </Button>
            <Button size="sm" onClick={() => setShowAddDialog(true)}>
              <Plus className="w-4 h-4 mr-1" />
              添加自选
            </Button>
          </div>
        </div>

        {/* Portfolio Stats Card */}
        {portfolioStats && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
            {/* Main Stats */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-primary" />
                  组合收益概览
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">平均涨跌幅</p>
                    <p className={`text-2xl font-bold font-mono ${
                      portfolioStats.avgChangePercent > 0 ? "text-green-600" :
                      portfolioStats.avgChangePercent < 0 ? "text-red-600" : "text-foreground"
                    }`}>
                      {portfolioStats.avgChangePercent > 0 ? "+" : ""}{portfolioStats.avgChangePercent.toFixed(2)}%
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">涨/跌/平</p>
                    <p className="text-lg font-bold">
                      <span className="text-green-600">{portfolioStats.upCount}</span>
                      <span className="text-muted-foreground mx-1">/</span>
                      <span className="text-red-600">{portfolioStats.downCount}</span>
                      <span className="text-muted-foreground mx-1">/</span>
                      <span>{portfolioStats.flatCount}</span>
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">领涨股</p>
                    <p className="text-sm font-bold text-green-600 truncate">
                      {portfolioStats.maxGainer.name}
                    </p>
                    <p className="text-xs text-green-600 font-mono">
                      +{portfolioStats.maxGainer.changePercent.toFixed(2)}%
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">领跌股</p>
                    <p className="text-sm font-bold text-red-600 truncate">
                      {portfolioStats.maxLoser.name}
                    </p>
                    <p className="text-xs text-red-600 font-mono">
                      {portfolioStats.maxLoser.changePercent.toFixed(2)}%
                    </p>
                  </div>
                </div>
                {/* Up/Down ratio bar */}
                <div className="h-3 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden flex">
                  <div className="bg-green-500 h-full transition-all" style={{ width: `${(portfolioStats.upCount / portfolioStats.totalCount) * 100}%` }} />
                  <div className="bg-gray-300 dark:bg-gray-600 h-full transition-all" style={{ width: `${(portfolioStats.flatCount / portfolioStats.totalCount) * 100}%` }} />
                  <div className="bg-red-500 h-full transition-all" style={{ width: `${(portfolioStats.downCount / portfolioStats.totalCount) * 100}%` }} />
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                  <span>上涨 {((portfolioStats.upCount / portfolioStats.totalCount) * 100).toFixed(0)}%</span>
                  <span>下跌 {((portfolioStats.downCount / portfolioStats.totalCount) * 100).toFixed(0)}%</span>
                </div>
              </CardContent>
            </Card>

            {/* Performance Curve */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  30日组合走势
                </CardTitle>
              </CardHeader>
              <CardContent>
                {portfolioStats.performanceCurve && (
                  <svg viewBox="0 0 200 100" className="w-full h-32">
                    {/* Grid lines */}
                    <line x1="0" y1="50" x2="200" y2="50" stroke="currentColor" strokeOpacity="0.1" strokeDasharray="4" />
                    {/* Area fill */}
                    {(() => {
                      const curve = portfolioStats.performanceCurve;
                      const minV = Math.min(...curve.map((p: any) => p.value));
                      const maxV = Math.max(...curve.map((p: any) => p.value));
                      const range = maxV - minV || 1;
                      const points = curve.map((p: any, i: number) => {
                        const x = (i / (curve.length - 1)) * 200;
                        const y = 90 - ((p.value - minV) / range) * 80;
                        return `${x},${y}`;
                      });
                      const isPositive = curve[curve.length - 1].value >= 0;
                      const lineColor = isPositive ? "#16a34a" : "#dc2626";
                      const fillColor = isPositive ? "rgba(22,163,74,0.15)" : "rgba(220,38,38,0.15)";
                      return (
                        <>
                          <polygon
                            points={`0,90 ${points.join(" ")} 200,90`}
                            fill={fillColor}
                          />
                          <polyline
                            points={points.join(" ")}
                            fill="none"
                            stroke={lineColor}
                            strokeWidth="2"
                          />
                          <circle
                            cx="200"
                            cy={90 - ((curve[curve.length - 1].value - minV) / range) * 80}
                            r="3"
                            fill={lineColor}
                          />
                        </>
                      );
                    })()}
                    {/* Labels */}
                    <text x="0" y="98" fontSize="8" fill="currentColor" opacity="0.5">-30天</text>
                    <text x="180" y="98" fontSize="8" fill="currentColor" opacity="0.5">今天</text>
                  </svg>
                )}
                <div className="text-center mt-1">
                  <span className={`text-lg font-bold font-mono ${
                    portfolioStats.avgChangePercent >= 0 ? "text-green-600" : "text-red-600"
                  }`}>
                    今日: {portfolioStats.avgChangePercent >= 0 ? "+" : ""}{portfolioStats.avgChangePercent.toFixed(2)}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Watchlist Table */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : !watchlist || watchlist.length === 0 ? (
          <Card>
            <CardContent className="py-20 text-center">
              <StarOff className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">暂无自选品种</h3>
              <p className="text-muted-foreground mb-4">点击"添加自选"按钮搜索并添加您关注的品种</p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="w-4 h-4 mr-1" />
                添加自选
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-3 font-medium">代码</th>
                      <th className="text-left p-3 font-medium">名称</th>
                      <th className="text-left p-3 font-medium">市场</th>
                      <th className="text-right p-3 font-medium">最新价</th>
                      <th className="text-right p-3 font-medium">涨跌幅</th>
                      <th className="text-right p-3 font-medium">成交量</th>
                      <th className="text-center p-3 font-medium">预警</th>
                      <th className="text-center p-3 font-medium">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {watchlist.map((item: any) => {
                      const quote = item.quote;
                      const price = quote ? parseFloat(quote.lastPrice) : 0;
                      const changePct = quote ? parseFloat(quote.changePercent || "0") : 0;
                      const isUp = changePct > 0;
                      const isDown = changePct < 0;
                      const colorClass = isUp ? "text-green-600" : isDown ? "text-red-600" : "text-foreground";
                      const symbolAlerts = alertsBySymbol.get(`${item.symbol}|${item.market}`) || [];
                      const hasActiveAlert = symbolAlerts.some((a: any) => a.isEnabled);

                      return (
                        <tr key={item.id} className="border-b hover:bg-muted/30 transition-colors">
                          <td className="p-3 font-mono font-medium text-primary text-xs">{item.symbol}</td>
                          <td className="p-3 font-medium">{item.name || quote?.name || item.symbol}</td>
                          <td className="p-3">
                            <Badge variant="outline" className="text-[10px]">{marketLabel[item.market] || item.market}</Badge>
                          </td>
                          <td className={`p-3 text-right font-mono font-bold ${colorClass}`}>
                            {quote ? formatPrice(price, item.market) : "-"}
                          </td>
                          <td className={`p-3 text-right font-mono font-medium ${colorClass}`}>
                            {quote ? (
                              <span className="inline-flex items-center gap-1">
                                {isUp ? <TrendingUp className="w-3 h-3" /> : isDown ? <TrendingDown className="w-3 h-3" /> : null}
                                {isUp ? "+" : ""}{changePct.toFixed(2)}%
                              </span>
                            ) : "-"}
                          </td>
                          <td className="p-3 text-right font-mono text-muted-foreground text-xs">
                            {quote ? formatVolume(quote.volume) : "-"}
                          </td>
                          <td className="p-3 text-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              className={`h-7 w-7 p-0 ${hasActiveAlert ? "text-amber-500 hover:text-amber-600" : "text-muted-foreground hover:text-amber-500"}`}
                              onClick={() => openAlertDialog(item.symbol, item.name || item.symbol, item.market)}
                              title="设置预警"
                            >
                              {hasActiveAlert ? <BellRing className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
                            </Button>
                          </td>
                          <td className="p-3 text-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                              onClick={() => handleRemove(item.id, item.name || item.symbol)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Price Alerts Section */}
        {alerts && alerts.length > 0 && (
          <Card className="mt-6">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <BellRing className="w-5 h-5 text-amber-500" />
                预警规则
                <Badge variant="secondary" className="text-xs">{alerts.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-3 font-medium">品种</th>
                      <th className="text-left p-3 font-medium">预警类型</th>
                      <th className="text-right p-3 font-medium">阈值</th>
                      <th className="text-center p-3 font-medium">状态</th>
                      <th className="text-center p-3 font-medium">触发次数</th>
                      <th className="text-center p-3 font-medium">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {alerts.map((alert: any) => (
                      <tr key={alert.id} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{alert.name || alert.symbol}</span>
                            <span className="font-mono text-xs text-muted-foreground">{alert.symbol}</span>
                          </div>
                        </td>
                        <td className="p-3">
                          <Badge variant="outline" className="text-[10px]">
                            {alertTypeLabels[alert.alertType] || alert.alertType}
                          </Badge>
                        </td>
                        <td className="p-3 text-right font-mono font-bold">
                          {parseFloat(alert.threshold).toFixed(2)}{alertTypeUnits[alert.alertType]}
                        </td>
                        <td className="p-3 text-center">
                          <Switch
                            checked={alert.isEnabled}
                            onCheckedChange={(checked) =>
                              updateAlertMutation.mutate({ id: alert.id, isEnabled: checked })
                            }
                          />
                        </td>
                        <td className="p-3 text-center">
                          <Badge variant={alert.triggerCount > 0 ? "default" : "secondary"} className="text-[10px]">
                            {alert.triggerCount}次
                          </Badge>
                        </td>
                        <td className="p-3 text-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                            onClick={() => deleteAlertMutation.mutate({ id: alert.id })}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Add Stock Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-primary" />
              添加自选品种
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="搜索代码或名称..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
              />
            </div>
            <div className="max-h-[400px] overflow-y-auto space-y-1">
              {searchQuery.length === 0 ? (
                <p className="text-center text-muted-foreground py-8 text-sm">输入代码或名称搜索品种</p>
              ) : !searchResults || searchResults.length === 0 ? (
                <p className="text-center text-muted-foreground py-8 text-sm">未找到相关品种</p>
              ) : (
                searchResults.map((q: any) => {
                  const inWatchlist = watchlistSymbols.has(`${q.symbol}|${q.market}`);
                  const changePct = parseFloat(q.changePercent || "0");
                  const isUp = changePct > 0;
                  const isDown = changePct < 0;
                  const colorClass = isUp ? "text-green-600" : isDown ? "text-red-600" : "text-foreground";

                  return (
                    <div
                      key={q.id}
                      className="flex items-center justify-between p-2.5 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{q.name}</span>
                            <span className="font-mono text-xs text-muted-foreground">{q.symbol}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <Badge variant="outline" className="text-[9px] px-1">{marketLabel[q.market] || q.market}</Badge>
                            <span className={`text-xs font-mono ${colorClass}`}>
                              {parseFloat(q.lastPrice).toFixed(2)} ({isUp ? "+" : ""}{changePct.toFixed(2)}%)
                            </span>
                          </div>
                        </div>
                      </div>
                      {inWatchlist ? (
                        <Badge variant="secondary" className="text-[10px]">
                          <Star className="w-3 h-3 mr-1 fill-yellow-500 text-yellow-500" />
                          已添加
                        </Badge>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-xs"
                          onClick={() => handleAdd(q.symbol, q.name, q.market)}
                          disabled={addMutation.isPending}
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          添加
                        </Button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Price Alert Dialog */}
      <Dialog open={showAlertDialog} onOpenChange={(open) => { setShowAlertDialog(open); if (!open) resetAlertForm(); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BellRing className="w-5 h-5 text-amber-500" />
              设置价格预警
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Target stock info */}
            <div className="p-3 rounded-lg bg-muted/50 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              <div>
                <p className="font-medium text-sm">{alertName}</p>
                <p className="text-xs text-muted-foreground font-mono">{alertSymbol} · {marketLabel[alertMarket] || alertMarket}</p>
              </div>
            </div>

            {/* Existing alerts for this stock */}
            {alertsBySymbol.get(`${alertSymbol}|${alertMarket}`)?.map((a: any) => (
              <div key={a.id} className="flex items-center justify-between p-2 rounded border text-sm">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px]">{alertTypeLabels[a.alertType]}</Badge>
                  <span className="font-mono">{parseFloat(a.threshold).toFixed(2)}{alertTypeUnits[a.alertType]}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Switch
                    checked={a.isEnabled}
                    onCheckedChange={(checked) => updateAlertMutation.mutate({ id: a.id, isEnabled: checked })}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-red-500"
                    onClick={() => deleteAlertMutation.mutate({ id: a.id })}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}

            {/* New alert form */}
            <div className="space-y-3 pt-2 border-t">
              <p className="text-sm font-medium">新建预警</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">预警类型</label>
                  <Select value={alertType} onValueChange={setAlertType}>
                    <SelectTrigger className="h-9 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="change_percent_above">涨幅超过</SelectItem>
                      <SelectItem value="change_percent_below">跌幅超过</SelectItem>
                      <SelectItem value="price_above">价格高于</SelectItem>
                      <SelectItem value="price_below">价格低于</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">
                    阈值 {alertTypeUnits[alertType] && `(${alertTypeUnits[alertType]})`}
                  </label>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder={alertType.includes("percent") ? "例: 5" : "例: 100.00"}
                    value={alertThreshold}
                    onChange={(e) => setAlertThreshold(e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">冷却时间（分钟）</label>
                <Select value={alertCooldown} onValueChange={setAlertCooldown}>
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5分钟</SelectItem>
                    <SelectItem value="15">15分钟</SelectItem>
                    <SelectItem value="30">30分钟</SelectItem>
                    <SelectItem value="60">1小时</SelectItem>
                    <SelectItem value="240">4小时</SelectItem>
                    <SelectItem value="1440">24小时</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                className="w-full"
                onClick={handleCreateAlert}
                disabled={createAlertMutation.isPending || !alertThreshold}
              >
                <Bell className="w-4 h-4 mr-1" />
                {createAlertMutation.isPending ? "创建中..." : "创建预警"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
