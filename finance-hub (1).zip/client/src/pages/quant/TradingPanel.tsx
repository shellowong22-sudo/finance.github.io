import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  ArrowUpRight, ArrowDownRight, Wallet, ShoppingCart, TrendingUp, TrendingDown,
  AlertTriangle, StopCircle, DollarSign, Clock, ListOrdered,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function TradingPanel() {
  const { isAuthenticated } = useAuth();
  const { data: positions } = trpc.quant.position.list.useQuery({}, { enabled: isAuthenticated });
  const { data: orders } = trpc.quant.order.list.useQuery({ limit: 20 }, { enabled: isAuthenticated });
  const { data: accounts } = trpc.quant.account.list.useQuery(undefined, { enabled: isAuthenticated });
  const placeMutation = trpc.quant.order.submit.useMutation({
    onSuccess: () => toast.success("订单提交成功"),
    onError: (e: any) => toast.error(e.message),
  });
  const emergencyMutation = trpc.quant.risk.emergencyStop.useMutation({
    onSuccess: () => toast.success("紧急停止已执行"),
  });

  const [orderForm, setOrderForm] = useState({
    symbol: "", side: "buy" as "buy" | "sell", orderType: "limit" as "limit" | "market" | "stop" | "stop_limit",
    quantity: "", price: "", market: "a_share",
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <Wallet className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <p className="text-muted-foreground mb-4">登录后可使用量化交易功能</p>
          <Button asChild><a href={getLoginUrl()}>立即登录</a></Button>
        </div>
      </div>
    );
  }

  const totalPnl = positions?.reduce((sum: number, p: any) => sum + parseFloat(p.unrealizedPnl || "0"), 0) || 0;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Wallet className="w-7 h-7 text-primary" />交易面板
            </h1>
            <p className="text-muted-foreground mt-1">下单交易 · 持仓管理 · 订单查询</p>
          </div>
          <Button variant="destructive" className="gap-2" onClick={() => emergencyMutation.mutate()}>
            <StopCircle className="w-4 h-4" />紧急停止
          </Button>
        </div>

        {/* Account Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">交易账户</p>
              <p className="text-xl font-bold">{accounts?.length || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">持仓数量</p>
              <p className="text-xl font-bold">{positions?.length || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">浮动盈亏</p>
              <p className={`text-xl font-bold ${totalPnl >= 0 ? "text-green-600" : "text-red-600"}`}>
                {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">今日订单</p>
              <p className="text-xl font-bold">{orders?.length || 0}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Order Form */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <ShoppingCart className="w-4 h-4" />下单
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input placeholder="股票代码 (如 600519)" value={orderForm.symbol} onChange={(e) => setOrderForm({ ...orderForm, symbol: e.target.value })} />
              <Select value={orderForm.market} onValueChange={(v) => setOrderForm({ ...orderForm, market: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="a_share">A股</SelectItem>
                  <SelectItem value="us_stock">美股</SelectItem>
                  <SelectItem value="hk_stock">港股</SelectItem>
                </SelectContent>
              </Select>
              <div className="grid grid-cols-2 gap-2">
                <Button variant={orderForm.side === "buy" ? "default" : "outline"} className={orderForm.side === "buy" ? "bg-green-600 hover:bg-green-700" : ""} onClick={() => setOrderForm({ ...orderForm, side: "buy" })}>
                  <ArrowUpRight className="w-4 h-4 mr-1" />买入
                </Button>
                <Button variant={orderForm.side === "sell" ? "default" : "outline"} className={orderForm.side === "sell" ? "bg-red-600 hover:bg-red-700" : ""} onClick={() => setOrderForm({ ...orderForm, side: "sell" })}>
                  <ArrowDownRight className="w-4 h-4 mr-1" />卖出
                </Button>
              </div>
              <Select value={orderForm.orderType} onValueChange={(v) => setOrderForm({ ...orderForm, orderType: v as any })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="limit">限价单</SelectItem>
                  <SelectItem value="market">市价单</SelectItem>
                  <SelectItem value="stop">止损单</SelectItem>
                  <SelectItem value="stop_limit">止损限价单</SelectItem>
                </SelectContent>
              </Select>
              <Input type="number" placeholder="数量" value={orderForm.quantity} onChange={(e) => setOrderForm({ ...orderForm, quantity: e.target.value })} />
              {orderForm.orderType !== "market" && (
                <Input type="number" placeholder="价格" step="0.01" value={orderForm.price} onChange={(e) => setOrderForm({ ...orderForm, price: e.target.value })} />
              )}
              <Button className="w-full gap-2" disabled={!orderForm.symbol || !orderForm.quantity || placeMutation.isPending}
                onClick={() => placeMutation.mutate({
                  accountId: 1, symbol: orderForm.symbol, side: orderForm.side, orderType: orderForm.orderType,
                  quantity: orderForm.quantity, price: orderForm.price || undefined, market: orderForm.market,
                })}>
                {placeMutation.isPending ? "提交中..." : orderForm.side === "buy" ? "确认买入" : "确认卖出"}
              </Button>
            </CardContent>
          </Card>

          {/* Positions & Orders */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="positions">
              <TabsList>
                <TabsTrigger value="positions" className="gap-1"><DollarSign className="w-4 h-4" />持仓</TabsTrigger>
                <TabsTrigger value="orders" className="gap-1"><ListOrdered className="w-4 h-4" />订单</TabsTrigger>
              </TabsList>
              <TabsContent value="positions">
                {positions && positions.length > 0 ? (
                  <Card>
                    <CardContent className="p-0">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left p-3">代码</th>
                            <th className="text-right p-3">数量</th>
                            <th className="text-right p-3">成本价</th>
                            <th className="text-right p-3">现价</th>
                            <th className="text-right p-3">浮动盈亏</th>
                            <th className="text-right p-3">盈亏比例</th>
                          </tr>
                        </thead>
                        <tbody>
                          {positions.map((p: any) => {
                            const pnl = parseFloat(p.unrealizedPnl || "0");
                            const pnlPct = parseFloat(p.avgCost) > 0 ? (pnl / (parseFloat(p.avgCost) * p.quantity) * 100) : 0;
                            return (
                              <tr key={p.id} className="border-b hover:bg-muted/30">
                                <td className="p-3 font-mono font-medium text-primary">{p.symbol}</td>
                                <td className="p-3 text-right">{p.quantity}</td>
                                <td className="p-3 text-right font-mono">{parseFloat(p.avgCost).toFixed(2)}</td>
                                <td className="p-3 text-right font-mono">{parseFloat(p.currentPrice || "0").toFixed(2)}</td>
                                <td className={`p-3 text-right font-mono font-medium ${pnl >= 0 ? "text-green-600" : "text-red-600"}`}>
                                  {pnl >= 0 ? "+" : ""}{pnl.toFixed(2)}
                                </td>
                                <td className={`p-3 text-right font-mono ${pnlPct >= 0 ? "text-green-600" : "text-red-600"}`}>
                                  {pnlPct >= 0 ? "+" : ""}{pnlPct.toFixed(2)}%
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </CardContent>
                  </Card>
                ) : (
                  <Card><CardContent className="py-16 text-center"><p className="text-muted-foreground">暂无持仓</p></CardContent></Card>
                )}
              </TabsContent>
              <TabsContent value="orders">
                {orders && orders.length > 0 ? (
                  <Card>
                    <CardContent className="p-0">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left p-3">时间</th>
                            <th className="text-left p-3">代码</th>
                            <th className="text-left p-3">方向</th>
                            <th className="text-right p-3">数量</th>
                            <th className="text-right p-3">价格</th>
                            <th className="text-left p-3">状态</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orders.map((o: any) => (
                            <tr key={o.id} className="border-b hover:bg-muted/30">
                              <td className="p-3 text-muted-foreground text-xs">{new Date(o.createdAt).toLocaleString()}</td>
                              <td className="p-3 font-mono font-medium">{o.symbol}</td>
                              <td className="p-3">
                                <Badge className={o.side === "buy" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                                  {o.side === "buy" ? "买入" : "卖出"}
                                </Badge>
                              </td>
                              <td className="p-3 text-right">{o.quantity}</td>
                              <td className="p-3 text-right font-mono">{o.price ? parseFloat(o.price).toFixed(2) : "市价"}</td>
                              <td className="p-3">
                                <Badge variant="outline" className="text-xs">
                                  {o.status === "filled" ? "已成交" : o.status === "pending" ? "待成交" : o.status === "cancelled" ? "已取消" : o.status === "rejected" ? "已拒绝" : o.status}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </CardContent>
                  </Card>
                ) : (
                  <Card><CardContent className="py-16 text-center"><p className="text-muted-foreground">暂无订单记录</p></CardContent></Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
