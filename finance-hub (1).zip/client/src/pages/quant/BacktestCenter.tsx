import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  FlaskConical, TrendingUp, TrendingDown, BarChart3, Play, Calendar, DollarSign,
  Target, Percent, Clock, AlertTriangle,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function BacktestCenter() {
  const { isAuthenticated } = useAuth();
  const { data: backtests, isLoading } = trpc.quant.backtest.list.useQuery({}, { enabled: isAuthenticated });
  const { data: strategies } = trpc.quant.strategy.list.useQuery(undefined, { enabled: isAuthenticated });
  const runMutation = trpc.quant.backtest.run.useMutation({
    onSuccess: () => toast.success("回测任务已提交"),
    onError: (e: any) => toast.error(e.message),
  });

  const [showRun, setShowRun] = useState(false);
  const [form, setForm] = useState({
    strategyId: "", market: "a_share", startDate: "2024-01-01", endDate: "2025-01-01",
    initialCapital: "1000000", slippageValue: "5", commissionRate: "0.0003",
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <FlaskConical className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <p className="text-muted-foreground mb-4">登录后可使用回测功能</p>
          <Button asChild><a href={getLoginUrl()}>立即登录</a></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <FlaskConical className="w-7 h-7 text-primary" />回测中心
            </h1>
            <p className="text-muted-foreground mt-1">策略历史回测 · 收益分析 · 绩效评估</p>
          </div>
          <Dialog open={showRun} onOpenChange={setShowRun}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Play className="w-4 h-4" />创建回测</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>创建回测任务</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <Select value={form.strategyId} onValueChange={(v) => setForm({ ...form, strategyId: v })}>
                  <SelectTrigger><SelectValue placeholder="选择策略" /></SelectTrigger>
                  <SelectContent>
                    {strategies?.map((s: any) => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={form.market} onValueChange={(v) => setForm({ ...form, market: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="a_share">A股</SelectItem>
                    <SelectItem value="us_stock">美股</SelectItem>
                    <SelectItem value="hk_stock">港股</SelectItem>
                    <SelectItem value="global">全球</SelectItem>
                  </SelectContent>
                </Select>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground">开始日期</label>
                    <Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">结束日期</label>
                    <Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground">初始资金</label>
                    <Input value={form.initialCapital} onChange={(e) => setForm({ ...form, initialCapital: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">滑点(BPS)</label>
                    <Input value={form.slippageValue} onChange={(e) => setForm({ ...form, slippageValue: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">佣金率</label>
                    <Input value={form.commissionRate} onChange={(e) => setForm({ ...form, commissionRate: e.target.value })} />
                  </div>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800 flex gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>回测结果已计入真实滑点、佣金和印花税，杜绝理想化回测</span>
                </div>
                <Button className="w-full" disabled={!form.strategyId || runMutation.isPending}
                  onClick={() => runMutation.mutate({
                    strategyId: parseInt(form.strategyId), name: `回测-${new Date().toLocaleDateString()}`, market: form.market,
                    startDate: form.startDate, endDate: form.endDate,
                    initialCapital: form.initialCapital, slippageValue: form.slippageValue,
                    commissionRate: form.commissionRate,
                  }, { onSuccess: () => setShowRun(false) })}>
                  {runMutation.isPending ? "提交中..." : "开始回测"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Backtest Results */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : backtests && backtests.length > 0 ? (
          <div className="space-y-4">
            {backtests.map((bt: any) => {
              const totalReturn = parseFloat(bt.totalReturn || "0");
              const sharpe = parseFloat(bt.sharpeRatio || "0");
              const maxDrawdown = parseFloat(bt.maxDrawdown || "0");
              const winRate = parseFloat(bt.winRate || "0");
              return (
                <Card key={bt.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-bold text-lg">回测 #{bt.id}</h3>
                        <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                          <Calendar className="w-3 h-3" />{bt.startDate} ~ {bt.endDate}
                          <Badge variant="outline" className="text-xs">{bt.market}</Badge>
                        </p>
                      </div>
                      <Badge variant={bt.status === "completed" ? "default" : "secondary"}>
                        {bt.status === "completed" ? "已完成" : bt.status === "running" ? "运行中" : bt.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><TrendingUp className="w-3 h-3" />总收益率</p>
                        <p className={`text-lg font-bold ${totalReturn >= 0 ? "text-green-600" : "text-red-600"}`}>
                          {totalReturn >= 0 ? "+" : ""}{totalReturn.toFixed(2)}%
                        </p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><BarChart3 className="w-3 h-3" />夏普比率</p>
                        <p className="text-lg font-bold">{sharpe.toFixed(2)}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><TrendingDown className="w-3 h-3" />最大回撤</p>
                        <p className="text-lg font-bold text-red-600">{maxDrawdown.toFixed(2)}%</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><Target className="w-3 h-3" />胜率</p>
                        <p className="text-lg font-bold">{winRate.toFixed(1)}%</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center justify-center gap-1"><DollarSign className="w-3 h-3" />交易次数</p>
                        <p className="text-lg font-bold">{bt.totalTrades || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="py-20 text-center">
              <FlaskConical className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">暂无回测记录</p>
              <p className="text-sm text-muted-foreground/70 mt-1">创建策略后可进行历史回测</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
