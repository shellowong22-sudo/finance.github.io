import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Articles from "./pages/Articles";
import ArticleDetail from "./pages/ArticleDetail";
import Reports from "./pages/Reports";
import ReportDetail from "./pages/ReportDetail";
import Courses from "./pages/Courses";
import CourseDetail from "./pages/CourseDetail";
import CourseLearn from "./pages/CourseLearn";
import Social from "./pages/Social";
import ChannelApply from "./pages/ChannelApply";
import Profile from "./pages/Profile";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminArticles from "./pages/admin/Articles";
import AdminUsers from "./pages/admin/Users";
import AdminReports from "./pages/admin/Reports";
import AdminCourses from "./pages/admin/Courses";
import AdminChannels from "./pages/admin/Channels";
import AdminCompliance from "./pages/admin/Compliance";
import AdminCrawler from "./pages/admin/Crawler";
import AICenter from "./pages/AICenter";
import AdminAIManage from "./pages/admin/AIManage";
import MarketBoard from "./pages/quant/MarketBoard";
import StrategyMarket from "./pages/quant/StrategyMarket";
import TradingPanel from "./pages/quant/TradingPanel";
import BacktestCenter from "./pages/quant/BacktestCenter";
import IPOMarket from "./pages/quant/IPOMarket";
import Watchlist from "./pages/quant/Watchlist";
import AdminQuantManage from "./pages/admin/QuantManage";
import SectorHeatmap from "./pages/quant/SectorHeatmap";
import AIAssistantFloat from "./components/AIAssistantFloat";

function Router() {
  return (
    <Switch>
      {/* 前台路由 */}
      <Route path="/" component={Home} />
      <Route path="/articles" component={Articles} />
      <Route path="/articles/:id" component={ArticleDetail} />
      <Route path="/reports" component={Reports} />
      <Route path="/reports/:id" component={ReportDetail} />
      <Route path="/courses" component={Courses} />
      <Route path="/courses/:id" component={CourseDetail} />
      <Route path="/courses/:id/learn" component={CourseLearn} />
      <Route path="/social" component={Social} />
      <Route path="/channel/apply" component={ChannelApply} />
      <Route path="/profile" component={Profile} />
      <Route path="/ai" component={AICenter} />
      <Route path="/quant" component={MarketBoard} />
      <Route path="/quant/strategies" component={StrategyMarket} />
      <Route path="/quant/trading" component={TradingPanel} />
      <Route path="/quant/backtest" component={BacktestCenter} />
      <Route path="/quant/ipo" component={IPOMarket} />
      <Route path="/quant/watchlist" component={Watchlist} />
      <Route path="/quant/heatmap" component={SectorHeatmap} />

      {/* 后台管理路由 */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/articles" component={AdminArticles} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/reports" component={AdminReports} />
      <Route path="/admin/courses" component={AdminCourses} />
      <Route path="/admin/channels" component={AdminChannels} />
      <Route path="/admin/compliance" component={AdminCompliance} />
      <Route path="/admin/crawler" component={AdminCrawler} />
      <Route path="/admin/ai" component={AdminAIManage} />
      <Route path="/admin/quant" component={AdminQuantManage} />

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
          <AIAssistantFloat />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
