import { useEffect, useRef } from "react";
import * as echarts from "echarts";

interface KLineItem {
  timestamp: number;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: number;
  period: string;
}

interface MiniKLineChartProps {
  data: KLineItem[];
  symbol: string;
  market: string;
  period: string;
  height?: number;
}

const MARKET_LABELS: Record<string, string> = {
  a_share: "A股", us_stock: "美股", hk_stock: "港股",
  futures: "期货", option: "期权", fund: "基金",
  bond: "债券", crypto: "加密", forex: "外汇", index: "指数",
};

const PERIOD_LABELS: Record<string, string> = {
  "1m": "1分", "5m": "5分", "30m": "30分", "1h": "60分", "1d": "日K", "1w": "周K",
};

export default function MiniKLineChart({ data, symbol, market, period, height = 200 }: MiniKLineChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const instanceRef = useRef<echarts.ECharts | null>(null);

  useEffect(() => {
    if (!chartRef.current || data.length === 0) return;

    if (!instanceRef.current) {
      instanceRef.current = echarts.init(chartRef.current, undefined, { renderer: "canvas" });
    }
    const chart = instanceRef.current;

    // Parse data
    const dates = data.map(d => {
      const date = new Date(d.timestamp);
      if (period === "1d" || period === "1w") {
        return `${(date.getMonth() + 1).toString().padStart(2, "0")}/${date.getDate().toString().padStart(2, "0")}`;
      }
      return `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}`;
    });

    const ohlc = data.map(d => [
      parseFloat(d.open), parseFloat(d.close), parseFloat(d.low), parseFloat(d.high),
    ]);

    const volumes = data.map((d, i) => ({
      value: d.volume,
      itemStyle: { color: parseFloat(d.close) >= parseFloat(d.open) ? "#ef4444" : "#22c55e" },
    }));

    // Calculate MA5 and MA10
    const closes = data.map(d => parseFloat(d.close));
    const calcMA = (n: number) => closes.map((_, i) => {
      if (i < n - 1) return null;
      let sum = 0;
      for (let j = 0; j < n; j++) sum += closes[i - j];
      return +(sum / n).toFixed(2);
    });

    const option: echarts.EChartsOption = {
      animation: false,
      grid: [
        { left: 8, right: 8, top: 24, height: height * 0.55 },
        { left: 8, right: 8, top: height * 0.55 + 36, height: height * 0.2 },
      ],
      xAxis: [
        {
          type: "category", data: dates, gridIndex: 0,
          axisLine: { show: false }, axisTick: { show: false },
          axisLabel: { show: false },
          splitLine: { show: false },
        },
        {
          type: "category", data: dates, gridIndex: 1,
          axisLine: { lineStyle: { color: "#e5e7eb" } },
          axisTick: { show: false },
          axisLabel: { fontSize: 9, color: "#9ca3af", interval: Math.floor(dates.length / 4) },
          splitLine: { show: false },
        },
      ],
      yAxis: [
        {
          scale: true, gridIndex: 0,
          splitLine: { lineStyle: { color: "#f3f4f6" } },
          axisLabel: { fontSize: 9, color: "#9ca3af", inside: true },
          axisLine: { show: false }, axisTick: { show: false },
        },
        {
          scale: true, gridIndex: 1,
          splitLine: { show: false },
          axisLabel: { show: false },
          axisLine: { show: false }, axisTick: { show: false },
        },
      ],
      series: [
        {
          type: "candlestick",
          data: ohlc,
          xAxisIndex: 0, yAxisIndex: 0,
          itemStyle: {
            color: "#ef4444", color0: "#22c55e",
            borderColor: "#ef4444", borderColor0: "#22c55e",
          },
        },
        {
          type: "line", data: calcMA(5),
          xAxisIndex: 0, yAxisIndex: 0,
          smooth: true, lineStyle: { width: 1, color: "#f59e0b" },
          symbol: "none",
        },
        {
          type: "line", data: calcMA(10),
          xAxisIndex: 0, yAxisIndex: 0,
          smooth: true, lineStyle: { width: 1, color: "#8b5cf6" },
          symbol: "none",
        },
        {
          type: "bar", data: volumes,
          xAxisIndex: 1, yAxisIndex: 1,
          barMaxWidth: 6,
        },
      ],
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "cross" },
        backgroundColor: "rgba(255,255,255,0.95)",
        borderColor: "#e5e7eb",
        textStyle: { fontSize: 10, color: "#374151" },
        formatter: (params: any) => {
          if (!params || !params[0]) return "";
          const candle = params[0];
          const d = candle.data;
          if (!d) return "";
          return `<div style="font-size:10px;line-height:1.5">
            <div>${candle.axisValue}</div>
            <div>开: ${d[1]} 收: ${d[2]}</div>
            <div>低: ${d[3]} 高: ${d[4]}</div>
          </div>`;
        },
      },
    };

    chart.setOption(option);

    const observer = new ResizeObserver(() => chart.resize());
    observer.observe(chartRef.current);

    return () => {
      observer.disconnect();
    };
  }, [data, height, period]);

  useEffect(() => {
    return () => {
      instanceRef.current?.dispose();
      instanceRef.current = null;
    };
  }, []);

  if (data.length === 0) return null;

  // Latest price info
  const latest = data[data.length - 1];
  const prev = data.length > 1 ? data[data.length - 2] : latest;
  const change = parseFloat(latest.close) - parseFloat(prev.close);
  const changePercent = ((change / parseFloat(prev.close)) * 100).toFixed(2);
  const isUp = change >= 0;

  return (
    <div className="rounded-lg border bg-background/80 overflow-hidden my-2">
      <div className="flex items-center justify-between px-3 py-1.5 bg-muted/30 border-b">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-foreground">{symbol}</span>
          <span className="text-[10px] text-muted-foreground">
            {MARKET_LABELS[market] || market} · {PERIOD_LABELS[period] || period}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`text-xs font-mono font-semibold ${isUp ? "text-red-500" : "text-green-500"}`}>
            {parseFloat(latest.close).toFixed(2)}
          </span>
          <span className={`text-[10px] font-mono ${isUp ? "text-red-500" : "text-green-500"}`}>
            {isUp ? "+" : ""}{changePercent}%
          </span>
        </div>
      </div>
      <div ref={chartRef} style={{ width: "100%", height }} />
    </div>
  );
}
