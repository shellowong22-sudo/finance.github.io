import { useEffect, useRef, useCallback, useMemo, useState } from "react";
import * as echarts from "echarts";

// ============================================================
// Data types
// ============================================================
interface KLineDataItem {
  id: number;
  symbol: string;
  market: string;
  period: string;
  openPrice: string;
  highPrice: string;
  lowPrice: string;
  closePrice: string;
  volume: number;
  turnover: string | null;
  timestamp: number;
}

export type IndicatorType = "MACD" | "KDJ" | "RSI" | "NONE";

interface KLineChartProps {
  data: KLineDataItem[];
  stockName?: string;
  symbol?: string;
  height?: number;
  showMA?: boolean;
  showVolume?: boolean;
  indicator?: IndicatorType;
  onIndicatorChange?: (ind: IndicatorType) => void;
}

// ============================================================
// Technical indicator calculation functions
// ============================================================

function calculateMA(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) { result.push(null); continue; }
    let sum = 0;
    for (let j = 0; j < period; j++) sum += data[i - j];
    result.push(+(sum / period).toFixed(2));
  }
  return result;
}

function calculateEMA(data: number[], period: number): number[] {
  const result: number[] = [];
  const k = 2 / (period + 1);
  for (let i = 0; i < data.length; i++) {
    if (i === 0) { result.push(data[0]); continue; }
    result.push(+(data[i] * k + result[i - 1] * (1 - k)).toFixed(4));
  }
  return result;
}

function calculateMACD(closes: number[], fast = 12, slow = 26, signal = 9) {
  const emaFast = calculateEMA(closes, fast);
  const emaSlow = calculateEMA(closes, slow);
  const dif: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    dif.push(+(emaFast[i] - emaSlow[i]).toFixed(4));
  }
  const dea = calculateEMA(dif, signal);
  const macd: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    macd.push(+((dif[i] - dea[i]) * 2).toFixed(4));
  }
  return { dif, dea, macd };
}

function calculateKDJ(
  highs: number[], lows: number[], closes: number[],
  n = 9, m1 = 3, m2 = 3
) {
  const k: number[] = [];
  const d: number[] = [];
  const j: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    const start = Math.max(0, i - n + 1);
    let hn = -Infinity, ln = Infinity;
    for (let x = start; x <= i; x++) {
      if (highs[x] > hn) hn = highs[x];
      if (lows[x] < ln) ln = lows[x];
    }
    const rsv = hn === ln ? 50 : +((closes[i] - ln) / (hn - ln) * 100).toFixed(2);
    const prevK = i > 0 ? k[i - 1] : 50;
    const prevD = i > 0 ? d[i - 1] : 50;
    const kVal = +((prevK * (m1 - 1) + rsv) / m1).toFixed(2);
    const dVal = +((prevD * (m2 - 1) + kVal) / m2).toFixed(2);
    const jVal = +(3 * kVal - 2 * dVal).toFixed(2);
    k.push(kVal);
    d.push(dVal);
    j.push(jVal);
  }
  return { k, d, j };
}

function calculateRSI(closes: number[], periods: number[] = [6, 12, 24]) {
  const results: Record<number, (number | null)[]> = {};
  for (const period of periods) {
    const rsi: (number | null)[] = [];
    let avgGain = 0, avgLoss = 0;
    for (let i = 0; i < closes.length; i++) {
      if (i === 0) { rsi.push(null); continue; }
      const change = closes[i] - closes[i - 1];
      const gain = change > 0 ? change : 0;
      const loss = change < 0 ? -change : 0;
      if (i < period) {
        avgGain += gain;
        avgLoss += loss;
        if (i === period - 1) {
          avgGain /= period;
          avgLoss /= period;
          const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
          rsi.push(+(100 - 100 / (1 + rs)).toFixed(2));
        } else {
          rsi.push(null);
        }
      } else {
        avgGain = (avgGain * (period - 1) + gain) / period;
        avgLoss = (avgLoss * (period - 1) + loss) / period;
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        rsi.push(+(100 - 100 / (1 + rs)).toFixed(2));
      }
    }
    results[period] = rsi;
  }
  return results;
}

// ============================================================
// Indicator selector buttons (inline in chart)
// ============================================================
const INDICATORS: { key: IndicatorType; label: string; desc: string }[] = [
  { key: "MACD", label: "MACD", desc: "12,26,9" },
  { key: "KDJ", label: "KDJ", desc: "9,3,3" },
  { key: "RSI", label: "RSI", desc: "6,12,24" },
  { key: "NONE", label: "关闭", desc: "" },
];

// ============================================================
// Main component
// ============================================================
export default function KLineChart({
  data,
  stockName = "",
  symbol = "",
  height = 600,
  showMA = true,
  showVolume = true,
  indicator: externalIndicator,
  onIndicatorChange,
}: KLineChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);
  const [internalIndicator, setInternalIndicator] = useState<IndicatorType>("MACD");

  const indicator = externalIndicator ?? internalIndicator;
  const setIndicator = onIndicatorChange ?? setInternalIndicator;

  // Sort data ascending by timestamp
  const sortedData = useMemo(() => {
    if (!data || data.length === 0) return [];
    return [...data].sort((a, b) => a.timestamp - b.timestamp);
  }, [data]);

  // Precompute all price arrays
  const { dates, ohlc, volumes, closes, highs, lows } = useMemo(() => {
    if (sortedData.length === 0) return { dates: [], ohlc: [], volumes: [], closes: [], highs: [], lows: [] };
    const d = sortedData.map((item) => {
      const dt = new Date(item.timestamp);
      const period = item.period || "";
      const isMinute = ["1m", "5m", "15m", "30m", "1h", "4h"].includes(period);
      if (isMinute) {
        return `${String(dt.getMonth() + 1).padStart(2, "0")}/${String(dt.getDate()).padStart(2, "0")} ${String(dt.getHours()).padStart(2, "0")}:${String(dt.getMinutes()).padStart(2, "0")}`;
      }
      return `${dt.getFullYear()}/${String(dt.getMonth() + 1).padStart(2, "0")}/${String(dt.getDate()).padStart(2, "0")}`;
    });
    const o = sortedData.map((item) => [
      parseFloat(item.openPrice), parseFloat(item.closePrice),
      parseFloat(item.lowPrice), parseFloat(item.highPrice),
    ]);
    const v = sortedData.map((item, i) => {
      const open = parseFloat(item.openPrice);
      const close = parseFloat(item.closePrice);
      return [i, item.volume, close >= open ? 1 : -1];
    });
    const c = sortedData.map((item) => parseFloat(item.closePrice));
    const h = sortedData.map((item) => parseFloat(item.highPrice));
    const l = sortedData.map((item) => parseFloat(item.lowPrice));
    return { dates: d, ohlc: o, volumes: v, closes: c, highs: h, lows: l };
  }, [sortedData]);

  // Compute indicators
  const indicatorData = useMemo(() => {
    if (closes.length === 0) return null;
    return {
      macd: calculateMACD(closes),
      kdj: calculateKDJ(highs, lows, closes),
      rsi: calculateRSI(closes),
    };
  }, [closes, highs, lows]);

  // Build ECharts option
  const buildOption = useCallback(() => {
    if (sortedData.length === 0 || !indicatorData) return null;

    const hasIndicator = indicator !== "NONE";
    const ma5 = calculateMA(closes, 5);
    const ma10 = calculateMA(closes, 10);
    const ma20 = calculateMA(closes, 20);
    const ma60 = calculateMA(closes, 60);

    // Layout: K-line grid, volume grid, indicator grid
    const klineHeight = hasIndicator ? "38%" : (showVolume ? "55%" : "75%");
    const volTop = hasIndicator ? "50%" : "72%";
    const volHeight = hasIndicator ? "12%" : "18%";
    const indTop = "66%";
    const indHeight = "22%";

    const grids: any[] = [
      { left: "8%", right: "3%", top: "6%", height: klineHeight },
    ];
    if (showVolume) {
      grids.push({ left: "8%", right: "3%", top: volTop, height: volHeight });
    }
    if (hasIndicator) {
      grids.push({ left: "8%", right: "3%", top: indTop, height: indHeight });
    }

    const xAxisCount = grids.length;
    const xAxes: any[] = grids.map((_, idx) => ({
      type: "category",
      gridIndex: idx,
      data: dates,
      boundaryGap: true,
      axisLine: { lineStyle: { color: "#8392A5" } },
      axisLabel: { show: idx === xAxisCount - 1, fontSize: 10 },
      splitLine: { show: false },
      min: "dataMin",
      max: "dataMax",
    }));

    const yAxes: any[] = [
      {
        scale: true,
        splitArea: { show: true, areaStyle: { color: ["rgba(250,250,250,0.03)", "rgba(200,200,200,0.03)"] } },
        axisLine: { lineStyle: { color: "#8392A5" } },
        axisLabel: { fontSize: 10 },
        splitLine: { lineStyle: { color: "rgba(150,150,150,0.08)" } },
      },
    ];
    if (showVolume) {
      yAxes.push({
        scale: true, gridIndex: 1, splitNumber: 2,
        axisLabel: {
          show: true, fontSize: 9,
          formatter: (val: number) => val >= 1e8 ? `${(val / 1e8).toFixed(1)}亿` : val >= 1e4 ? `${(val / 1e4).toFixed(0)}万` : String(val),
        },
        axisLine: { show: false }, splitLine: { show: false },
      });
    }
    if (hasIndicator) {
      const indYAxis: any = {
        scale: true, gridIndex: showVolume ? 2 : 1, splitNumber: 3,
        axisLabel: { fontSize: 9 },
        axisLine: { show: false },
        splitLine: { lineStyle: { color: "rgba(150,150,150,0.06)" } },
      };
      if (indicator === "RSI") {
        indYAxis.min = 0;
        indYAxis.max = 100;
      }
      yAxes.push(indYAxis);
    }

    // Series
    const series: any[] = [
      {
        name: "K线", type: "candlestick", data: ohlc,
        itemStyle: {
          color: "#ef4444", color0: "#22c55e",
          borderColor: "#ef4444", borderColor0: "#22c55e",
        },
      },
    ];

    if (showMA) {
      const maConfigs = [
        { name: "MA5", data: ma5, color: "#f59e0b" },
        { name: "MA10", data: ma10, color: "#3b82f6" },
        { name: "MA20", data: ma20, color: "#a855f7" },
        { name: "MA60", data: ma60, color: "#06b6d4" },
      ];
      for (const ma of maConfigs) {
        series.push({
          name: ma.name, type: "line", data: ma.data, smooth: true,
          showSymbol: false, lineStyle: { width: 1, color: ma.color },
          itemStyle: { color: ma.color },
        });
      }
    }

    if (showVolume) {
      series.push({
        name: "成交量", type: "bar", xAxisIndex: 1, yAxisIndex: 1,
        data: volumes.map((v) => ({
          value: v[1],
          itemStyle: { color: (v[2] as number) >= 0 ? "rgba(239,68,68,0.5)" : "rgba(34,197,94,0.5)" },
        })),
      });
    }

    // Indicator series
    const indAxisIdx = showVolume ? 2 : 1;
    const indXAxisIdx = showVolume ? 2 : 1;

    if (hasIndicator && indicator === "MACD") {
      const { dif, dea, macd } = indicatorData.macd;
      series.push(
        {
          name: "DIF", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: dif, showSymbol: false, lineStyle: { width: 1.2, color: "#f59e0b" },
          itemStyle: { color: "#f59e0b" },
        },
        {
          name: "DEA", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: dea, showSymbol: false, lineStyle: { width: 1.2, color: "#3b82f6" },
          itemStyle: { color: "#3b82f6" },
        },
        {
          name: "MACD", type: "bar", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: macd.map((v) => ({
            value: v,
            itemStyle: { color: v >= 0 ? "rgba(239,68,68,0.7)" : "rgba(34,197,94,0.7)" },
          })),
        }
      );
    }

    if (hasIndicator && indicator === "KDJ") {
      const { k, d, j } = indicatorData.kdj;
      series.push(
        {
          name: "K", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: k, showSymbol: false, lineStyle: { width: 1.2, color: "#f59e0b" },
          itemStyle: { color: "#f59e0b" },
        },
        {
          name: "D", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: d, showSymbol: false, lineStyle: { width: 1.2, color: "#3b82f6" },
          itemStyle: { color: "#3b82f6" },
        },
        {
          name: "J", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: j, showSymbol: false, lineStyle: { width: 1.2, color: "#a855f7" },
          itemStyle: { color: "#a855f7" },
        }
      );
    }

    if (hasIndicator && indicator === "RSI") {
      const rsi = indicatorData.rsi;
      series.push(
        {
          name: "RSI6", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: rsi[6], showSymbol: false, lineStyle: { width: 1.2, color: "#f59e0b" },
          itemStyle: { color: "#f59e0b" },
        },
        {
          name: "RSI12", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: rsi[12], showSymbol: false, lineStyle: { width: 1.2, color: "#3b82f6" },
          itemStyle: { color: "#3b82f6" },
        },
        {
          name: "RSI24", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: rsi[24], showSymbol: false, lineStyle: { width: 1.2, color: "#a855f7" },
          itemStyle: { color: "#a855f7" },
        }
      );
      // Overbought/oversold reference lines
      series.push(
        {
          name: "超买线", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: Array(dates.length).fill(80), showSymbol: false,
          lineStyle: { width: 1, type: "dashed", color: "rgba(239,68,68,0.3)" },
          itemStyle: { color: "transparent" },
        },
        {
          name: "超卖线", type: "line", xAxisIndex: indXAxisIdx, yAxisIndex: indAxisIdx,
          data: Array(dates.length).fill(20), showSymbol: false,
          lineStyle: { width: 1, type: "dashed", color: "rgba(34,197,94,0.3)" },
          itemStyle: { color: "transparent" },
        }
      );
    }

    // Tooltip formatter
    const tooltipFormatter = (params: any) => {
      if (!Array.isArray(params) || params.length === 0) return "";
      const kline = params.find((p: any) => p.seriesName === "K线");
      if (!kline) return "";
      const [open, close, low, high] = kline.data;
      const change = close - open;
      const changePercent = open > 0 ? ((change / open) * 100).toFixed(2) : "0.00";
      const changeColor = change >= 0 ? "#ef4444" : "#22c55e";
      let html = `<div style="font-weight:600;margin-bottom:4px;font-size:12px">${kline.axisValue}</div>`;
      html += `<div style="display:grid;grid-template-columns:auto 1fr;gap:1px 10px;font-size:11px">`;
      html += `<span style="color:#94a3b8">开</span><span style="text-align:right">${open.toFixed(2)}</span>`;
      html += `<span style="color:#94a3b8">收</span><span style="text-align:right;color:${changeColor};font-weight:600">${close.toFixed(2)}</span>`;
      html += `<span style="color:#94a3b8">高</span><span style="text-align:right">${high.toFixed(2)}</span>`;
      html += `<span style="color:#94a3b8">低</span><span style="text-align:right">${low.toFixed(2)}</span>`;
      html += `<span style="color:#94a3b8">幅</span><span style="text-align:right;color:${changeColor}">${change >= 0 ? "+" : ""}${changePercent}%</span>`;
      html += `</div>`;

      // MA values
      const maParams = params.filter((p: any) => p.seriesName.startsWith("MA") && !p.seriesName.startsWith("MACD"));
      if (maParams.length > 0) {
        html += `<div style="margin-top:3px;font-size:10px;display:flex;gap:6px;flex-wrap:wrap">`;
        for (const ma of maParams) {
          if (ma.data != null) html += `<span><span style="color:${ma.color}">${ma.seriesName}</span>:${typeof ma.data === "number" ? ma.data.toFixed(2) : ma.data}</span>`;
        }
        html += `</div>`;
      }

      // Volume
      const volParam = params.find((p: any) => p.seriesName === "成交量");
      if (volParam) {
        const vol = volParam.data?.value ?? volParam.data;
        const volStr = vol >= 1e8 ? `${(vol / 1e8).toFixed(2)}亿` : vol >= 1e4 ? `${(vol / 1e4).toFixed(0)}万` : vol.toLocaleString();
        html += `<div style="margin-top:2px;font-size:10px;color:#94a3b8">量:${volStr}</div>`;
      }

      // Indicator values
      if (indicator === "MACD") {
        const difP = params.find((p: any) => p.seriesName === "DIF");
        const deaP = params.find((p: any) => p.seriesName === "DEA");
        const macdP = params.find((p: any) => p.seriesName === "MACD");
        if (difP || deaP || macdP) {
          html += `<div style="margin-top:3px;font-size:10px;border-top:1px solid rgba(100,116,139,0.2);padding-top:3px">`;
          html += `<span style="font-weight:600;color:#94a3b8">MACD(12,26,9)</span><br/>`;
          if (difP?.data != null) html += `<span style="color:#f59e0b">DIF:${Number(difP.data).toFixed(3)}</span> `;
          if (deaP?.data != null) html += `<span style="color:#3b82f6">DEA:${Number(deaP.data).toFixed(3)}</span> `;
          if (macdP) {
            const mv = macdP.data?.value ?? macdP.data;
            if (mv != null) html += `<span style="color:${Number(mv) >= 0 ? "#ef4444" : "#22c55e"}">MACD:${Number(mv).toFixed(3)}</span>`;
          }
          html += `</div>`;
        }
      }
      if (indicator === "KDJ") {
        const kP = params.find((p: any) => p.seriesName === "K");
        const dP = params.find((p: any) => p.seriesName === "D");
        const jP = params.find((p: any) => p.seriesName === "J");
        if (kP || dP || jP) {
          html += `<div style="margin-top:3px;font-size:10px;border-top:1px solid rgba(100,116,139,0.2);padding-top:3px">`;
          html += `<span style="font-weight:600;color:#94a3b8">KDJ(9,3,3)</span><br/>`;
          if (kP?.data != null) html += `<span style="color:#f59e0b">K:${Number(kP.data).toFixed(2)}</span> `;
          if (dP?.data != null) html += `<span style="color:#3b82f6">D:${Number(dP.data).toFixed(2)}</span> `;
          if (jP?.data != null) html += `<span style="color:#a855f7">J:${Number(jP.data).toFixed(2)}</span>`;
          html += `</div>`;
        }
      }
      if (indicator === "RSI") {
        const r6 = params.find((p: any) => p.seriesName === "RSI6");
        const r12 = params.find((p: any) => p.seriesName === "RSI12");
        const r24 = params.find((p: any) => p.seriesName === "RSI24");
        if (r6 || r12 || r24) {
          html += `<div style="margin-top:3px;font-size:10px;border-top:1px solid rgba(100,116,139,0.2);padding-top:3px">`;
          html += `<span style="font-weight:600;color:#94a3b8">RSI</span><br/>`;
          if (r6?.data != null) html += `<span style="color:#f59e0b">RSI6:${Number(r6.data).toFixed(2)}</span> `;
          if (r12?.data != null) html += `<span style="color:#3b82f6">RSI12:${Number(r12.data).toFixed(2)}</span> `;
          if (r24?.data != null) html += `<span style="color:#a855f7">RSI24:${Number(r24.data).toFixed(2)}</span>`;
          html += `</div>`;
        }
      }
      return html;
    };

    // DataZoom linked to all x axes
    const allXIdx = Array.from({ length: xAxisCount }, (_, i) => i);
    const zoomStart = sortedData.length > 60 ? Math.max(0, 100 - (60 / sortedData.length) * 100) : 0;

    // Legend items
    const legendData = ["K线"];
    if (showMA) legendData.push("MA5", "MA10", "MA20", "MA60");
    if (indicator === "MACD") legendData.push("DIF", "DEA", "MACD");
    if (indicator === "KDJ") legendData.push("K", "D", "J");
    if (indicator === "RSI") legendData.push("RSI6", "RSI12", "RSI24");

    const option: echarts.EChartsOption = {
      backgroundColor: "transparent",
      animation: false, // Disable animation for real-time speed
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "cross" },
        backgroundColor: "rgba(15,23,42,0.94)",
        borderColor: "rgba(100,116,139,0.3)",
        textStyle: { color: "#e2e8f0", fontSize: 11 },
        formatter: tooltipFormatter,
      },
      legend: {
        data: legendData,
        top: 0,
        textStyle: { fontSize: 10, color: "#94a3b8" },
        itemWidth: 12, itemHeight: 7,
      },
      axisPointer: {
        link: [{ xAxisIndex: "all" }],
        label: { backgroundColor: "#1e293b" },
      },
      dataZoom: [
        { type: "inside", xAxisIndex: allXIdx, start: zoomStart, end: 100 },
        {
          type: "slider", xAxisIndex: allXIdx, bottom: "1%", height: 18,
          borderColor: "rgba(150,150,150,0.2)", fillerColor: "rgba(59,130,246,0.12)",
          handleStyle: { color: "#3b82f6" }, textStyle: { fontSize: 9, color: "#94a3b8" },
          start: zoomStart, end: 100,
        },
      ],
      grid: grids,
      xAxis: xAxes,
      yAxis: yAxes,
      series,
    };

    return option;
  }, [sortedData, dates, ohlc, volumes, closes, indicatorData, indicator, showMA, showVolume]);

  // Render chart
  useEffect(() => {
    if (!chartRef.current) return;
    if (!chartInstance.current) {
      chartInstance.current = echarts.init(chartRef.current, undefined, { renderer: "canvas" });
    }
    const option = buildOption();
    if (option) {
      chartInstance.current.setOption(option, true);
    }
  }, [buildOption]);

  // Resize handler
  useEffect(() => {
    const handleResize = () => chartInstance.current?.resize();
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
      chartInstance.current?.dispose();
      chartInstance.current = null;
    };
  }, []);

  if (!sortedData || sortedData.length === 0) {
    return (
      <div className="flex items-center justify-center text-muted-foreground" style={{ height }}>
        <div className="text-center">
          <svg className="w-12 h-12 mx-auto mb-3 opacity-30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M3 3v18h18" /><path d="M7 16l4-4 4 4 4-8" />
          </svg>
          <p className="text-sm">暂无K线数据</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Stock name watermark */}
      {stockName && (
        <div className="absolute top-2 left-12 z-10 pointer-events-none">
          <span className="text-lg font-bold text-foreground/15">{stockName}</span>
          {symbol && <span className="text-sm font-mono text-foreground/10 ml-2">{symbol}</span>}
        </div>
      )}

      {/* Indicator selector */}
      <div className="absolute top-1 right-4 z-10 flex items-center gap-1">
        {INDICATORS.map((ind) => (
          <button
            key={ind.key}
            onClick={() => setIndicator(ind.key)}
            className={`px-2 py-0.5 text-[10px] font-medium rounded transition-all ${
              indicator === ind.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            {ind.label}
            {ind.desc && indicator === ind.key && (
              <span className="ml-0.5 opacity-70">({ind.desc})</span>
            )}
          </button>
        ))}
      </div>

      {/* Indicator label */}
      {indicator !== "NONE" && (
        <div className="absolute z-10 pointer-events-none" style={{ top: "65%", left: "9%" }}>
          <span className="text-[10px] font-bold text-muted-foreground/40">
            {indicator === "MACD" && "MACD(12,26,9)"}
            {indicator === "KDJ" && "KDJ(9,3,3)"}
            {indicator === "RSI" && "RSI(6,12,24)"}
          </span>
        </div>
      )}

      <div ref={chartRef} style={{ width: "100%", height }} />
    </div>
  );
}
