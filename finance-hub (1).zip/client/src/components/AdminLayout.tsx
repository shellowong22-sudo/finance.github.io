import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link, useLocation } from "wouter";
import {
  BarChart3,
  BookOpen,
  Brain,
  Cpu,
  FileText,
  Home,
  LogOut,
  Shield,
  TrendingUp,
  Users,
  AlertTriangle,
  Globe,
  Rss,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { ReactNode } from "react";

const adminNavLinks = [
  { href: "/admin", label: "数据看板", icon: BarChart3, exact: true },
  { href: "/admin/articles", label: "文章管理", icon: FileText },
  { href: "/admin/reports", label: "研报管理", icon: TrendingUp },
  { href: "/admin/courses", label: "课程管理", icon: BookOpen },
  { href: "/admin/channels", label: "渠道管理", icon: Globe },
  { href: "/admin/users", label: "用户管理", icon: Users },
  { href: "/admin/compliance", label: "合规监控", icon: Shield },
  { href: "/admin/crawler", label: "内容爬虫", icon: Rss },
  { href: "/admin/ai", label: "AI深度学习", icon: Brain },
  { href: "/admin/quant", label: "量化系统管理", icon: Cpu },
];

interface AdminLayoutProps {
  children: ReactNode;
  title?: string;
}

export default function AdminLayout({ children, title }: AdminLayoutProps) {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [location] = useLocation();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      logout();
      window.location.href = "/";
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground text-sm">加载中...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">需要登录</h2>
          <p className="text-muted-foreground mb-4">请先登录后访问管理后台</p>
          <Button asChild><a href={getLoginUrl()}>立即登录</a></Button>
        </div>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">权限不足</h2>
          <p className="text-muted-foreground mb-4">您没有访问管理后台的权限</p>
          <Button variant="outline" asChild><Link href="/">返回首页</Link></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className="w-60 shrink-0 bg-sidebar text-sidebar-foreground flex flex-col">
        {/* Logo */}
        <div className="p-4 border-b border-sidebar-border">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 finance-gradient rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-sm text-sidebar-foreground">金融平台</div>
              <div className="text-xs text-sidebar-foreground/60">管理后台</div>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {adminNavLinks.map((link) => {
            const isActive = link.exact ? location === link.href : location.startsWith(link.href);
            return (
              <Link key={link.href} href={link.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={`w-full justify-start gap-2 text-sm ${
                    isActive
                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  }`}
                >
                  <link.icon className="w-4 h-4 shrink-0" />
                  {link.label}
                </Button>
              </Link>
            );
          })}
        </nav>

        {/* User Info */}
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-sidebar-primary flex items-center justify-center text-sidebar-primary-foreground text-sm font-bold">
              {user?.name?.charAt(0) || "A"}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-sidebar-foreground truncate">{user?.name}</div>
              <Badge variant="outline" className="text-xs border-sidebar-border text-sidebar-foreground/70 px-1 py-0">管理员</Badge>
            </div>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" className="flex-1 text-sidebar-foreground hover:bg-sidebar-accent" asChild>
              <Link href="/"><Home className="w-3 h-3 mr-1" />前台</Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex-1 text-destructive hover:bg-destructive/10"
              onClick={() => logoutMutation.mutate()}
            >
              <LogOut className="w-3 h-3 mr-1" />退出
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        {title && (
          <div className="border-b border-border px-6 py-4 bg-background">
            <h1 className="text-xl font-bold text-foreground">{title}</h1>
          </div>
        )}
        <div className="flex-1 overflow-auto p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
