import { useState, useCallback, useRef, useEffect, lazy, Suspense } from "react";
import {
  MessageSquareText, X, Minimize2, Send, Sparkles, User,
  Loader2, Search, ChevronLeft, Plus, Trash2, Settings2,
  Zap, BarChart3, TrendingUp, BookOpen, FileText, Globe,
  Mic, MicOff, Volume2, VolumeX, Square, Brain, Edit3, Tag,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Streamdown } from "streamdown";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

const MiniKLineChart = lazy(() => import("@/components/MiniKLineChart"));

// ============================================================
// Types
// ============================================================
type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  klineData?: KLinePayload | null;
};

type KLinePayload = {
  symbol: string;
  market: string;
  period: string;
  klineData: any[];
};

type Conversation = {
  id: number;
  title: string | null;
  style: string | null;
  updatedAt: Date;
};

// ============================================================
// 快捷指令配置
// ============================================================
const QUICK_COMMANDS = [
  { icon: BarChart3, label: "市场日报", prompt: "请生成今日市场日报，包含大盘概况、板块轮动和涨跌排行", color: "text-blue-500" },
  { icon: TrendingUp, label: "组合分析", prompt: "分析我的自选组合整体表现，包括收益统计、涨跌比例和调仓建议", color: "text-green-500" },
  { icon: Globe, label: "板块轮动", prompt: "分析当前市场板块轮动情况，哪些行业板块最强，哪些最弱", color: "text-purple-500" },
  { icon: Zap, label: "我的自选", prompt: "查看我的自选股列表，帮我分析每只自选股的最新行情和走势", color: "text-orange-500" },
  { icon: FileText, label: "最新研报", prompt: "帮我搜索最新的金融研报", color: "text-cyan-500" },
  { icon: BookOpen, label: "我的预警", prompt: "查看我设置的所有价格预警规则状态", color: "text-pink-500" },
];

// ============================================================
// 文风选项
// ============================================================
const STYLE_OPTIONS = [
  { value: "professional", label: "专业严谨", emoji: "📊" },
  { value: "casual", label: "通俗易懂", emoji: "💬" },
  { value: "humorous", label: "幽默风趣", emoji: "😄" },
  { value: "teacher", label: "循循善诱", emoji: "👨‍🏫" },
  { value: "analyst", label: "深度分析", emoji: "🔍" },
];

// Tool name mapping
const TOOL_NAME_MAP: Record<string, string> = {
  query_market_quotes: "行情数据",
  get_kline_data: "K线图表",
  query_articles: "资讯文章",
  query_reports: "金融研报",
  query_courses: "金融课程",
  get_market_overview: "市场概览",
  compare_stocks: "品种对比",
  query_user_watchlist: "自选股",
  get_sector_heatmap: "板块热力图",
  get_portfolio_analysis: "组合分析",
  get_price_alerts: "预警规则",
  save_user_memory: "记忆存储",
  get_user_memory: "记忆读取",
};

// ============================================================
// 语音录制 Hook
// ============================================================
function useVoiceRecorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : "audio/webm",
      });
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start(100);
      setIsRecording(true);
    } catch (error) {
      console.error("无法访问麦克风:", error);
      throw new Error("无法访问麦克风，请检查浏览器权限");
    }
  }, []);

  const stopRecording = useCallback((): Promise<string> => {
    return new Promise((resolve, reject) => {
      const mediaRecorder = mediaRecorderRef.current;
      if (!mediaRecorder || mediaRecorder.state === "inactive") {
        reject(new Error("没有正在进行的录音"));
        return;
      }

      mediaRecorder.onstop = async () => {
        setIsRecording(false);
        setIsTranscribing(true);

        try {
          const blob = new Blob(chunksRef.current, { type: "audio/webm" });

          // Convert to base64
          const reader = new FileReader();
          reader.onloadend = async () => {
            const base64 = (reader.result as string).split(",")[1];

            try {
              const response = await fetch("/api/voice/transcribe", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ audioData: base64, mimeType: "audio/webm" }),
              });

              if (!response.ok) throw new Error("语音识别失败");
              const data = await response.json();
              setIsTranscribing(false);
              resolve(data.text || "");
            } catch (err) {
              setIsTranscribing(false);
              reject(err);
            }
          };
          reader.readAsDataURL(blob);
        } catch (err) {
          setIsTranscribing(false);
          reject(err);
        }

        // Stop all tracks
        mediaRecorder.stream.getTracks().forEach((t) => t.stop());
      };

      mediaRecorder.stop();
    });
  }, []);

  const cancelRecording = useCallback(() => {
    const mediaRecorder = mediaRecorderRef.current;
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stream.getTracks().forEach((t) => t.stop());
      mediaRecorder.stop();
    }
    setIsRecording(false);
    setIsTranscribing(false);
    chunksRef.current = [];
  }, []);

  return { isRecording, isTranscribing, startRecording, stopRecording, cancelRecording };
}

// ============================================================
// TTS 播报 Hook
// ============================================================
function useTTS() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speakingMsgIdx, setSpeakingMsgIdx] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const speak = useCallback(async (text: string, msgIdx: number) => {
    // Stop current playback
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }

    // If same message, toggle off
    if (speakingMsgIdx === msgIdx && isSpeaking) {
      setIsSpeaking(false);
      setSpeakingMsgIdx(null);
      return;
    }

    setIsSpeaking(true);
    setSpeakingMsgIdx(msgIdx);

    try {
      // Strip markdown for cleaner TTS
      const cleanText = text
        .replace(/#{1,6}\s/g, "")
        .replace(/\*\*(.*?)\*\*/g, "$1")
        .replace(/\*(.*?)\*/g, "$1")
        .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
        .replace(/```[\s\S]*?```/g, "")
        .replace(/`([^`]+)`/g, "$1")
        .replace(/\|[^\n]+\|/g, "")
        .replace(/[-*+]\s/g, "")
        .replace(/\n{2,}/g, "。")
        .replace(/\n/g, "，")
        .trim();

      const response = await fetch("/api/voice/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ text: cleanText, voice: "alloy", speed: 1.1 }),
      });

      if (!response.ok) throw new Error("语音合成失败");
      const data = await response.json();

      const audio = new Audio(data.audioUrl);
      audioRef.current = audio;

      audio.onended = () => {
        setIsSpeaking(false);
        setSpeakingMsgIdx(null);
      };
      audio.onerror = () => {
        setIsSpeaking(false);
        setSpeakingMsgIdx(null);
      };

      await audio.play();
    } catch (error) {
      console.error("TTS error:", error);
      setIsSpeaking(false);
      setSpeakingMsgIdx(null);
    }
  }, [isSpeaking, speakingMsgIdx]);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setIsSpeaking(false);
    setSpeakingMsgIdx(null);
  }, []);

  return { isSpeaking, speakingMsgIdx, speak, stop };
}

// ============================================================
// Main Component
// ============================================================
export default function AIAssistantFloat() {
  const { user, isAuthenticated } = useAuth();

  // UI state
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showStylePicker, setShowStylePicker] = useState(false);
  const [showMemory, setShowMemory] = useState(false);

  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [streamingKline, setStreamingKline] = useState<KLinePayload | null>(null);
  const [toolStatus, setToolStatus] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [currentStyle, setCurrentStyle] = useState("professional");

  // Conversation state
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);

  // Voice hooks
  const { isRecording, isTranscribing, startRecording, stopRecording, cancelRecording } = useVoiceRecorder();
  const { isSpeaking, speakingMsgIdx, speak, stop: stopTTS } = useTTS();

  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // tRPC queries
  const conversationsQuery = trpc.aiAssistant.conversations.useQuery(undefined, {
    enabled: isAuthenticated && isOpen,
  });

  // Memory queries
  const memoriesQuery = trpc.aiAssistant.memories.useQuery(undefined, {
    enabled: isAuthenticated && showMemory,
  });
  const addMemoryMutation = trpc.aiAssistant.addMemory.useMutation({
    onSuccess: () => utils.aiAssistant.memories.invalidate(),
  });
  const deleteMemoryMutation = trpc.aiAssistant.deleteMemory.useMutation({
    onSuccess: () => utils.aiAssistant.memories.invalidate(),
  });

  const messagesQuery = trpc.aiAssistant.getMessages.useQuery(
    { conversationId: currentConversationId! },
    { enabled: !!currentConversationId }
  );

  const createConversation = trpc.aiAssistant.createConversation.useMutation();
  const saveMessageMutation = trpc.aiAssistant.saveMessage.useMutation();
  const deleteConversation = trpc.aiAssistant.deleteConversation.useMutation();
  const updateStyleMutation = trpc.aiAssistant.updateStyle.useMutation();
  const utils = trpc.useUtils();

  // Load conversation messages when switching
  useEffect(() => {
    if (messagesQuery.data && currentConversationId) {
      const loaded: ChatMessage[] = messagesQuery.data.map((m: any) => ({
        role: m.role,
        content: m.content,
        klineData: m.metadata?.klineData || null,
      }));
      setMessages(loaded);
    }
  }, [messagesQuery.data, currentConversationId]);

  const scrollToBottom = useCallback(() => {
    const viewport = scrollAreaRef.current?.querySelector(
      "[data-radix-scroll-area-viewport]"
    ) as HTMLDivElement;
    if (viewport) {
      requestAnimationFrame(() => {
        viewport.scrollTo({ top: viewport.scrollHeight, behavior: "smooth" });
      });
    }
  }, []);

  useEffect(() => {
    if (isStreaming || streamingContent) scrollToBottom();
  }, [streamingContent, isStreaming, scrollToBottom]);

  useEffect(() => {
    if (messages.length > 0) scrollToBottom();
  }, [messages.length, scrollToBottom]);

  // ============================================================
  // 发送消息（核心逻辑）
  // ============================================================
  const handleSend = useCallback(
    async (content: string) => {
      if (isStreaming) return;

      const userMessage: ChatMessage = { role: "user", content };
      const newMessages = [...messages, userMessage];
      setMessages(newMessages);
      setInput("");
      setIsStreaming(true);
      setStreamingContent("");
      setStreamingKline(null);
      setToolStatus(null);
      setShowHistory(false);

      // Create conversation if needed
      let convId = currentConversationId;
      if (isAuthenticated && !convId) {
        try {
          const result = await createConversation.mutateAsync({ style: currentStyle });
          convId = result.id;
          setCurrentConversationId(convId);
        } catch { /* Continue without persistence */ }
      }

      // Save user message
      if (convId) {
        saveMessageMutation.mutate({ conversationId: convId, role: "user", content });
      }

      // Abort any previous stream
      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      try {
        const response = await fetch("/api/ai-assistant/stream", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
            style: currentStyle,
          }),
          signal: controller.signal,
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const reader = response.body?.getReader();
        if (!reader) throw new Error("No response body");

        const decoder = new TextDecoder();
        let buffer = "";
        let accumulated = "";
        let klinePayload: KLinePayload | null = null;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || !trimmed.startsWith("data: ")) continue;

            try {
              const data = JSON.parse(trimmed.slice(6));

              switch (data.type) {
                case "content":
                  accumulated += data.text;
                  setStreamingContent(accumulated);
                  setToolStatus(null);
                  break;
                case "tool_start":
                  setToolStatus(`正在查询${TOOL_NAME_MAP[data.name] || data.name}...`);
                  break;
                case "tool_end":
                  setToolStatus(`${TOOL_NAME_MAP[data.name] || data.name}查询完成`);
                  break;
                case "kline":
                  klinePayload = data.data as KLinePayload;
                  setStreamingKline(klinePayload);
                  break;
                case "error":
                  accumulated += `\n\n抱歉，查询时遇到了问题：${data.message}`;
                  setStreamingContent(accumulated);
                  break;
                case "done":
                  break;
              }
            } catch { /* Skip malformed JSON */ }
          }
        }

        // Finalize
        const finalContent = accumulated || "抱歉，小融暂时无法响应，请稍后再试~";
        const assistantMsg: ChatMessage = {
          role: "assistant",
          content: finalContent,
          klineData: klinePayload,
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setStreamingContent("");
        setStreamingKline(null);

        // Save assistant message
        if (convId) {
          saveMessageMutation.mutate({
            conversationId: convId,
            role: "assistant",
            content: finalContent,
            metadata: klinePayload ? { klineData: klinePayload } : undefined,
          });
          utils.aiAssistant.conversations.invalidate();
        }
      } catch (error: any) {
        if (error.name === "AbortError") return;
        const errorMsg = `抱歉，连接出现问题：${error.message}。请稍后再试~`;
        setMessages((prev) => [...prev, { role: "assistant", content: errorMsg }]);
        setStreamingContent("");
        setStreamingKline(null);
      } finally {
        setIsStreaming(false);
        setToolStatus(null);
      }
    },
    [messages, isStreaming, currentConversationId, currentStyle, isAuthenticated, createConversation, saveMessageMutation, utils]
  );

  // ============================================================
  // 语音录制处理
  // ============================================================
  const handleVoiceToggle = useCallback(async () => {
    if (isRecording) {
      try {
        const text = await stopRecording();
        if (text.trim()) {
          setInput(text);
          // Auto-send after transcription
          handleSend(text.trim());
        }
      } catch (error: any) {
        console.error("语音识别错误:", error);
      }
    } else {
      try {
        await startRecording();
      } catch (error: any) {
        console.error("录音启动失败:", error);
      }
    }
  }, [isRecording, startRecording, stopRecording, handleSend]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isStreaming) return;
    handleSend(trimmed);
    textareaRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleNewConversation = () => {
    setCurrentConversationId(null);
    setMessages([]);
    setShowHistory(false);
    setStreamingContent("");
    setStreamingKline(null);
    stopTTS();
  };

  const handleSelectConversation = (conv: Conversation) => {
    setCurrentConversationId(conv.id);
    setCurrentStyle(conv.style || "professional");
    setShowHistory(false);
  };

  const handleDeleteConversation = async (convId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteConversation.mutateAsync({ conversationId: convId });
    utils.aiAssistant.conversations.invalidate();
    if (currentConversationId === convId) handleNewConversation();
  };

  const handleStyleChange = (style: string) => {
    setCurrentStyle(style);
    setShowStylePicker(false);
    if (currentConversationId) {
      updateStyleMutation.mutate({ conversationId: currentConversationId, style });
    }
  };

  const handleToggle = () => {
    if (isMinimized) {
      setIsMinimized(false);
    } else {
      setIsOpen(!isOpen);
    }
  };

  const handleClose = () => {
    setIsOpen(false);
    setIsMinimized(false);
    abortControllerRef.current?.abort();
    cancelRecording();
    stopTTS();
  };

  const currentStyleOption = STYLE_OPTIONS.find(s => s.value === currentStyle) || STYLE_OPTIONS[0];

  // ============================================================
  // Render
  // ============================================================
  return (
    <>
      {/* 浮动按钮 */}
      <button
        onClick={handleToggle}
        className={cn(
          "fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full px-4 py-3 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl",
          "bg-gradient-to-r from-blue-600 to-indigo-600 text-white",
          isOpen && !isMinimized && "scale-0 opacity-0 pointer-events-none"
        )}
      >
        <MessageSquareText className="size-5" />
        <span className="text-sm font-medium hidden sm:inline">小融 AI</span>
      </button>

      {/* 聊天窗口 */}
      {isOpen && (
        <div
          className={cn(
            "fixed z-50 transition-all duration-300 ease-in-out",
            isMinimized
              ? "bottom-6 right-6 w-64 h-12"
              : "bottom-6 right-6 w-[440px] h-[640px] max-h-[85vh]",
            "sm:w-[440px]",
            !isMinimized && "max-sm:inset-2 max-sm:w-auto max-sm:h-auto max-sm:max-h-none"
          )}
        >
          {isMinimized ? (
            <button
              onClick={() => setIsMinimized(false)}
              className="flex w-full items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 px-4 py-3 text-white shadow-lg hover:shadow-xl transition-shadow"
            >
              <MessageSquareText className="size-5" />
              <span className="text-sm font-medium flex-1 text-left">小融 AI 金融助手</span>
              <X className="size-4 opacity-70 hover:opacity-100" onClick={(e) => { e.stopPropagation(); handleClose(); }} />
            </button>
          ) : (
            <div className="flex h-full flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl">
              {/* 头部 */}
              <div className="flex items-center justify-between bg-gradient-to-r from-blue-600 to-indigo-600 px-4 py-2.5 text-white">
                <div className="flex items-center gap-2">
                  {showHistory ? (
                    <Button variant="ghost" size="icon" className="size-7 text-white/70 hover:text-white hover:bg-white/20" onClick={() => setShowHistory(false)}>
                      <ChevronLeft className="size-4" />
                    </Button>
                  ) : (
                    <div className="flex size-8 items-center justify-center rounded-full bg-white/20">
                      <Sparkles className="size-4" />
                    </div>
                  )}
                  <div>
                    <h3 className="text-sm font-semibold">{showHistory ? "对话历史" : showMemory ? "AI 记忆库" : "小融 · AI金融助手"}</h3>
                    {!showHistory && !showMemory && (
                      <p className="text-[10px] text-white/70">有温度的金融伙伴 · 语音交互 · K线图表</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {!showHistory && (
                    <>
                      {/* 文风切换 */}
                      <div className="relative">
                        <Button
                          variant="ghost" size="icon"
                          className="size-7 text-white/70 hover:text-white hover:bg-white/20"
                          onClick={() => setShowStylePicker(!showStylePicker)}
                          title="切换回答风格"
                        >
                          <Settings2 className="size-3.5" />
                        </Button>
                        {showStylePicker && (
                          <div className="absolute right-0 top-8 z-10 w-40 rounded-lg border bg-card shadow-xl overflow-hidden">
                            {STYLE_OPTIONS.map((s) => (
                              <button
                                key={s.value}
                                onClick={() => handleStyleChange(s.value)}
                                className={cn(
                                  "flex w-full items-center gap-2 px-3 py-2 text-xs hover:bg-muted transition-colors text-foreground",
                                  currentStyle === s.value && "bg-primary/10 font-medium"
                                )}
                              >
                                <span>{s.emoji}</span>
                                <span>{s.label}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      <Button variant="ghost" size="icon" className="size-7 text-white/70 hover:text-white hover:bg-white/20" onClick={handleNewConversation} title="新对话">
                        <Plus className="size-3.5" />
                      </Button>
                      {isAuthenticated && (
                        <Button variant="ghost" size="icon" className="size-7 text-white/70 hover:text-white hover:bg-white/20" onClick={() => { setShowMemory(!showMemory); setShowHistory(false); }} title="AI记忆">
                          <Brain className={cn("size-3.5", showMemory && "text-amber-300")} />
                        </Button>
                      )}
                      {isAuthenticated && (
                        <Button variant="ghost" size="icon" className="size-7 text-white/70 hover:text-white hover:bg-white/20" onClick={() => { setShowHistory(true); setShowMemory(false); }} title="对话历史">
                          <BookOpen className="size-3.5" />
                        </Button>
                      )}
                    </>
                  )}
                  <Button variant="ghost" size="icon" className="size-7 text-white/70 hover:text-white hover:bg-white/20" onClick={() => setIsMinimized(true)}>
                    <Minimize2 className="size-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="size-7 text-white/70 hover:text-white hover:bg-white/20" onClick={handleClose}>
                    <X className="size-3.5" />
                  </Button>
                </div>
              </div>

              {/* AI记忆管理面板 */}
              {showMemory ? (
                <ScrollArea className="flex-1">
                  <div className="p-3 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-semibold flex items-center gap-1.5">
                        <Brain className="size-4 text-amber-500" />
                        AI 记忆库
                      </h4>
                      <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setShowMemory(false)}>
                        返回对话
                      </Button>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      小融会记住您的投资偏好，并在后续对话中提供个性化建议。您也可以手动添加或删除记忆。
                    </p>

                    {/* 手动添加记忆 */}
                    <div className="rounded-lg border bg-muted/30 p-2.5 space-y-2">
                      <p className="text-[10px] font-medium text-muted-foreground">添加新记忆</p>
                      <div className="flex gap-1.5">
                        <select
                          className="flex-shrink-0 w-24 rounded-md border bg-background px-2 py-1 text-xs"
                          id="mem-cat"
                          defaultValue="focus_sector"
                        >
                          <option value="investment_preference">投资偏好</option>
                          <option value="focus_sector">关注板块</option>
                          <option value="focus_stock">关注个股</option>
                          <option value="risk_tolerance">风险偏好</option>
                          <option value="analysis_style">分析风格</option>
                          <option value="custom_note">自定义</option>
                        </select>
                        <input
                          className="flex-1 min-w-0 rounded-md border bg-background px-2 py-1 text-xs"
                          id="mem-key"
                          placeholder="标签"
                        />
                        <input
                          className="flex-1 min-w-0 rounded-md border bg-background px-2 py-1 text-xs"
                          id="mem-val"
                          placeholder="内容"
                        />
                        <Button
                          size="sm"
                          className="h-7 px-2 text-xs"
                          onClick={() => {
                            const cat = (document.getElementById('mem-cat') as HTMLSelectElement)?.value;
                            const key = (document.getElementById('mem-key') as HTMLInputElement)?.value;
                            const val = (document.getElementById('mem-val') as HTMLInputElement)?.value;
                            if (key && val) {
                              addMemoryMutation.mutate({ category: cat as any, key, value: val });
                              (document.getElementById('mem-key') as HTMLInputElement).value = '';
                              (document.getElementById('mem-val') as HTMLInputElement).value = '';
                            }
                          }}
                        >
                          <Plus className="size-3" />
                        </Button>
                      </div>
                    </div>

                    {/* 记忆列表 */}
                    {memoriesQuery.isLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="size-5 animate-spin text-muted-foreground" />
                      </div>
                    ) : !memoriesQuery.data?.length ? (
                      <div className="text-center py-8">
                        <Brain className="size-8 mx-auto mb-2 text-muted-foreground/30" />
                        <p className="text-sm text-muted-foreground">暂无记忆</p>
                        <p className="text-[10px] text-muted-foreground/60 mt-1">和小融聊天时，她会自动记住您的偏好</p>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {(() => {
                          const categoryLabels: Record<string, string> = {
                            investment_preference: '投资偏好',
                            focus_sector: '关注板块',
                            focus_stock: '关注个股',
                            risk_tolerance: '风险偏好',
                            analysis_style: '分析风格',
                            custom_note: '自定义',
                          };
                          const categoryColors: Record<string, string> = {
                            investment_preference: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
                            focus_sector: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300',
                            focus_stock: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300',
                            risk_tolerance: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
                            analysis_style: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300',
                            custom_note: 'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-300',
                          };
                          return (memoriesQuery.data as any[]).map((mem: any) => (
                            <div key={mem.id} className="flex items-start gap-2 rounded-lg border px-3 py-2 group hover:bg-muted/30 transition-colors">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5 mb-0.5">
                                  <span className={cn('text-[10px] px-1.5 py-0.5 rounded-full font-medium', categoryColors[mem.category] || categoryColors.custom_note)}>
                                    {categoryLabels[mem.category] || mem.category}
                                  </span>
                                  <span className="text-[10px] text-muted-foreground/50">
                                    {mem.source === 'ai_extracted' ? 'AI提取' : '手动添加'}
                                  </span>
                                </div>
                                <p className="text-xs">
                                  <span className="font-medium">{mem.key}</span>
                                  <span className="text-muted-foreground"> → </span>
                                  <span>{mem.value}</span>
                                </p>
                              </div>
                              <Button
                                variant="ghost" size="icon"
                                className="size-5 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive shrink-0 mt-0.5"
                                onClick={() => deleteMemoryMutation.mutate({ id: mem.id })}
                              >
                                <Trash2 className="size-3" />
                              </Button>
                            </div>
                          ));
                        })()}
                      </div>
                    )}
                  </div>
                </ScrollArea>
              ) : showHistory ? (
                <ScrollArea className="flex-1">
                  <div className="p-3 space-y-1">
                    {conversationsQuery.data?.length === 0 && (
                      <p className="text-center text-sm text-muted-foreground py-8">暂无对话历史</p>
                    )}
                    {conversationsQuery.data?.map((conv: any) => (
                      <div
                        key={conv.id}
                        onClick={() => handleSelectConversation(conv)}
                        className={cn(
                          "flex items-center gap-2 rounded-lg px-3 py-2.5 cursor-pointer hover:bg-muted transition-colors group",
                          currentConversationId === conv.id && "bg-primary/10"
                        )}
                      >
                        <MessageSquareText className="size-4 shrink-0 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm truncate">{conv.title || "新对话"}</p>
                          <p className="text-[10px] text-muted-foreground">
                            {new Date(conv.updatedAt).toLocaleDateString("zh-CN")}
                          </p>
                        </div>
                        <Button
                          variant="ghost" size="icon"
                          className="size-6 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                          onClick={(e) => handleDeleteConversation(conv.id, e)}
                        >
                          <Trash2 className="size-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <>
                  {/* 消息区域 */}
                  <div className="flex-1 overflow-hidden" ref={scrollAreaRef}>
                    {messages.length === 0 && !isStreaming && !streamingContent ? (
                      <div className="flex h-full flex-col p-4">
                        <div className="flex flex-col items-center gap-4 pt-4">
                          <div className="flex flex-col items-center gap-2">
                            <div className="relative">
                              <Sparkles className="size-10 text-primary/30" />
                              <div className="absolute -bottom-1 -right-1 size-4 rounded-full bg-green-500 border-2 border-card" />
                            </div>
                            <p className="text-sm font-medium">嗨，我是小融！</p>
                            <p className="text-xs text-muted-foreground text-center max-w-[280px]">
                              你的专属金融AI伙伴，有什么金融问题都可以问我哦~ 也可以点击麦克风用语音提问 🎙️
                            </p>
                            <div className="flex items-center gap-1 text-[10px] text-muted-foreground/60">
                              <span>当前风格：{currentStyleOption.emoji} {currentStyleOption.label}</span>
                            </div>
                          </div>

                          {/* 快捷指令面板 */}
                          <div className="w-full space-y-2">
                            <p className="text-[10px] text-muted-foreground font-medium px-1">快捷指令</p>
                            <div className="grid grid-cols-2 gap-2">
                              {QUICK_COMMANDS.map((cmd, idx) => (
                                <button
                                  key={idx}
                                  onClick={() => handleSend(cmd.prompt)}
                                  disabled={isStreaming}
                                  className="flex items-center gap-2 rounded-lg border px-3 py-2.5 text-left hover:bg-muted/50 transition-colors disabled:opacity-50"
                                >
                                  <cmd.icon className={cn("size-4 shrink-0", cmd.color)} />
                                  <span className="text-xs font-medium">{cmd.label}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <ScrollArea className="h-full">
                        <div className="flex flex-col space-y-3 p-4">
                          {messages.map((message, index) => (
                            <div key={index}>
                              <div
                                className={cn(
                                  "flex gap-2.5",
                                  message.role === "user" ? "justify-end items-start" : "justify-start items-start"
                                )}
                              >
                                {message.role === "assistant" && (
                                  <div className="size-6 shrink-0 mt-1 rounded-full bg-primary/10 flex items-center justify-center">
                                    <Sparkles className="size-3 text-primary" />
                                  </div>
                                )}
                                <div
                                  className={cn(
                                    "max-w-[82%] rounded-lg px-3 py-2",
                                    message.role === "user"
                                      ? "bg-primary text-primary-foreground"
                                      : "bg-muted text-foreground"
                                  )}
                                >
                                  {message.role === "assistant" ? (
                                    <div className="prose prose-sm dark:prose-invert max-w-none text-sm">
                                      <Streamdown>{message.content}</Streamdown>
                                    </div>
                                  ) : (
                                    <p className="whitespace-pre-wrap text-sm">{message.content}</p>
                                  )}
                                </div>
                                {message.role === "user" && (
                                  <div className="size-6 shrink-0 mt-1 rounded-full bg-secondary flex items-center justify-center">
                                    <User className="size-3 text-secondary-foreground" />
                                  </div>
                                )}
                              </div>
                              {/* 助手消息操作栏：TTS 播报 */}
                              {message.role === "assistant" && (
                                <div className="ml-8 mt-0.5 flex items-center gap-1">
                                  <button
                                    onClick={() => speak(message.content, index)}
                                    className="flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                                    title={speakingMsgIdx === index && isSpeaking ? "停止播报" : "语音播报"}
                                  >
                                    {speakingMsgIdx === index && isSpeaking ? (
                                      <>
                                        <VolumeX className="size-3" />
                                        <span>停止</span>
                                      </>
                                    ) : (
                                      <>
                                        <Volume2 className="size-3" />
                                        <span>播报</span>
                                      </>
                                    )}
                                  </button>
                                </div>
                              )}
                              {/* K线图表 */}
                              {message.role === "assistant" && message.klineData && (
                                <div className="ml-8 mr-2 mt-1">
                                  <Suspense fallback={<div className="h-[200px] animate-pulse bg-muted rounded-lg" />}>
                                    <MiniKLineChart
                                      data={message.klineData.klineData}
                                      symbol={message.klineData.symbol}
                                      market={message.klineData.market}
                                      period={message.klineData.period}
                                      height={200}
                                    />
                                  </Suspense>
                                </div>
                              )}
                            </div>
                          ))}

                          {/* 流式输出中的消息 */}
                          {(isStreaming || streamingContent) && (
                            <div>
                              <div className="flex gap-2.5 justify-start items-start">
                                <div className="size-6 shrink-0 mt-1 rounded-full bg-primary/10 flex items-center justify-center">
                                  <Sparkles className="size-3 text-primary" />
                                </div>
                                <div className="max-w-[82%] rounded-lg px-3 py-2 bg-muted text-foreground">
                                  {streamingContent ? (
                                    <div className="prose prose-sm dark:prose-invert max-w-none text-sm">
                                      <Streamdown>{streamingContent}</Streamdown>
                                    </div>
                                  ) : toolStatus ? (
                                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                      <Search className="size-3.5 animate-pulse" />
                                      <span>{toolStatus}</span>
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                      <Loader2 className="size-3.5 animate-spin" />
                                      <span>小融正在思考...</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                              {/* 流式K线图 */}
                              {streamingKline && (
                                <div className="ml-8 mr-2 mt-1">
                                  <Suspense fallback={<div className="h-[200px] animate-pulse bg-muted rounded-lg" />}>
                                    <MiniKLineChart
                                      data={streamingKline.klineData}
                                      symbol={streamingKline.symbol}
                                      market={streamingKline.market}
                                      period={streamingKline.period}
                                      height={200}
                                    />
                                  </Suspense>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    )}
                  </div>

                  {/* 快捷指令栏（有消息时显示在输入框上方） */}
                  {messages.length > 0 && !isStreaming && (
                    <div className="flex gap-1.5 px-3 pt-2 pb-0 overflow-x-auto no-scrollbar">
                      {QUICK_COMMANDS.slice(0, 4).map((cmd, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSend(cmd.prompt)}
                          className="flex items-center gap-1 shrink-0 rounded-full border px-2.5 py-1 text-[10px] hover:bg-muted/50 transition-colors"
                        >
                          <cmd.icon className={cn("size-3", cmd.color)} />
                          <span>{cmd.label}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* 录音状态指示器 */}
                  {(isRecording || isTranscribing) && (
                    <div className="flex items-center justify-center gap-2 px-3 py-2 bg-red-50 dark:bg-red-950/20 border-t">
                      {isRecording ? (
                        <>
                          <div className="size-2 rounded-full bg-red-500 animate-pulse" />
                          <span className="text-xs text-red-600 dark:text-red-400">正在录音...点击麦克风停止</span>
                          <button
                            onClick={cancelRecording}
                            className="text-xs text-muted-foreground hover:text-foreground ml-2"
                          >
                            取消
                          </button>
                        </>
                      ) : (
                        <>
                          <Loader2 className="size-3.5 animate-spin text-blue-500" />
                          <span className="text-xs text-blue-600 dark:text-blue-400">正在识别语音...</span>
                        </>
                      )}
                    </div>
                  )}

                  {/* 输入区域 */}
                  <form
                    onSubmit={handleSubmit}
                    className="flex gap-2 p-3 border-t bg-background/50 items-end"
                  >
                    {/* 语音按钮 */}
                    <Button
                      type="button"
                      variant={isRecording ? "destructive" : "outline"}
                      size="icon"
                      className={cn(
                        "shrink-0 h-[36px] w-[36px] transition-all",
                        isRecording && "animate-pulse"
                      )}
                      onClick={handleVoiceToggle}
                      disabled={isStreaming || isTranscribing}
                      title={isRecording ? "停止录音" : "语音输入"}
                    >
                      {isRecording ? (
                        <Square className="size-4" />
                      ) : isTranscribing ? (
                        <Loader2 className="size-4 animate-spin" />
                      ) : (
                        <Mic className="size-4" />
                      )}
                    </Button>

                    <Textarea
                      ref={textareaRef}
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="输入金融问题，或点击🎙️语音提问"
                      className="flex-1 max-h-24 resize-none min-h-9 text-sm"
                      rows={1}
                    />
                    <Button
                      type="submit"
                      size="icon"
                      disabled={!input.trim() || isStreaming}
                      className="shrink-0 h-[36px] w-[36px]"
                    >
                      {isStreaming ? (
                        <Loader2 className="size-4 animate-spin" />
                      ) : (
                        <Send className="size-4" />
                      )}
                    </Button>
                  </form>
                </>
              )}
            </div>
          )}
        </div>
      )}
    </>
  );
}
