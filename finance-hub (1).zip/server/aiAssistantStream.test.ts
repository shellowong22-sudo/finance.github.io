import { describe, expect, it } from "vitest";
import { aiTools, executeToolCall, buildSystemPrompt } from "./routers/aiAssistant";

describe("AI Assistant - Streaming Support", () => {
  it("buildSystemPrompt generates prompt with key instructions", () => {
    const prompt = buildSystemPrompt("professional");
    expect(prompt).toBeDefined();
    expect(typeof prompt).toBe("string");
    expect(prompt.length).toBeGreaterThan(100);
    expect(prompt).toContain("金融");
  });

  it("aiTools contains all required tool definitions", () => {
    expect(aiTools).toBeDefined();
    expect(Array.isArray(aiTools)).toBe(true);
    expect(aiTools.length).toBeGreaterThanOrEqual(4);

    const toolNames = aiTools.map((t: any) => t.function.name);
    expect(toolNames).toContain("query_market_quotes");
    expect(toolNames).toContain("get_market_overview");
    expect(toolNames).toContain("compare_stocks");

    // Each tool should have proper structure
    for (const tool of aiTools) {
      expect(tool).toHaveProperty("type", "function");
      expect(tool).toHaveProperty("function.name");
      expect(tool).toHaveProperty("function.description");
      expect(tool).toHaveProperty("function.parameters");
    }
  });

  it("executeToolCall returns valid JSON for query_market_quotes", async () => {
    const result = await executeToolCall("query_market_quotes", { search: "茅台" });
    expect(typeof result).toBe("string");

    const parsed = JSON.parse(result);
    expect(parsed).toHaveProperty("total");
    expect(parsed).toHaveProperty("data");
    expect(Array.isArray(parsed.data)).toBe(true);
  });

  it("executeToolCall returns valid JSON for get_market_overview", async () => {
    const result = await executeToolCall("get_market_overview", { market: "a_share" });
    expect(typeof result).toBe("string");

    const parsed = JSON.parse(result);
    expect(parsed).toBeDefined();
  });

  it("executeToolCall returns valid JSON for compare_stocks", async () => {
    const result = await executeToolCall("compare_stocks", { symbols: ["AAPL", "TSLA"] });
    expect(typeof result).toBe("string");

    const parsed = JSON.parse(result);
    expect(parsed).toBeDefined();
  });

  it("executeToolCall returns error for unknown tool", async () => {
    const result = await executeToolCall("unknown_tool", {});
    expect(typeof result).toBe("string");
    expect(result).toContain("未知");
  });

  it("executeToolCall handles empty search gracefully", async () => {
    const result = await executeToolCall("query_market_quotes", {});
    expect(typeof result).toBe("string");
    const parsed = JSON.parse(result);
    expect(parsed).toHaveProperty("data");
  });
});
