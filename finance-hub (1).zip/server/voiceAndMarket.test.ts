import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { buildSystemPrompt, STYLE_PROMPTS } from "./routers/aiAssistant";
import { getAllMarketStatuses, getMarketStatus, getYahooSymbol } from "./services/realMarketData";

// ============================================================
// Helper
// ============================================================
function createAuthContext() {
  const user = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user" as const,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };

  return { ctx, user };
}

// ============================================================
// 市场状态判断测试
// ============================================================
describe("Market Status - Trading Hours", () => {
  it("getMarketStatus returns valid status for a_share", () => {
    const status = getMarketStatus("a_share");
    expect(status).toBeDefined();
    expect(status.market).toBe("a_share");
    expect(status.label).toBeTruthy();
    expect(["trading", "pre_market", "post_market", "lunch_break", "closed", "weekend", "24h"]).toContain(status.status);
    expect(status.color).toBeTruthy();
  });

  it("getMarketStatus returns valid status for us_stock", () => {
    const status = getMarketStatus("us_stock");
    expect(status).toBeDefined();
    expect(status.market).toBe("us_stock");
    expect(status.label).toBeTruthy();
    expect(["trading", "pre_market", "post_market", "lunch_break", "closed", "weekend", "24h"]).toContain(status.status);
    expect(status.color).toBeTruthy();
  });

  it("getMarketStatus returns valid status for hk_stock", () => {
    const status = getMarketStatus("hk_stock");
    expect(status).toBeDefined();
    expect(status.market).toBe("hk_stock");
    expect(status.label).toBeTruthy();
    expect(["trading", "pre_market", "post_market", "lunch_break", "closed", "weekend", "24h"]).toContain(status.status);
  });

  it("getAllMarketStatuses returns all major markets", () => {
    const statuses = getAllMarketStatuses();
    expect(statuses.length).toBeGreaterThanOrEqual(3);
    const markets = statuses.map((s) => s.market);
    expect(markets).toContain("a_share");
    expect(markets).toContain("us_stock");
    expect(markets).toContain("hk_stock");
  });

  it("getMarketStatus returns a valid status for unknown market", () => {
    const status = getMarketStatus("unknown_market");
    expect(["trading", "pre_market", "post_market", "lunch_break", "closed", "weekend", "24h"]).toContain(status.status);
    expect(status.label).toBeTruthy();
  });
});

// ============================================================
// Yahoo Finance Symbol 映射测试
// ============================================================
describe("Yahoo Finance Symbol Mapping", () => {
  it("maps A-share symbols correctly", () => {
    expect(getYahooSymbol("600519", "a_share")).toBe("600519.SS");
    expect(getYahooSymbol("000001", "a_share")).toBe("000001.SZ");
    expect(getYahooSymbol("300750", "a_share")).toBe("300750.SZ");
  });

  it("maps US stock symbols correctly", () => {
    expect(getYahooSymbol("AAPL", "us_stock")).toBe("AAPL");
    expect(getYahooSymbol("TSLA", "us_stock")).toBe("TSLA");
  });

  it("maps HK stock symbols correctly", () => {
    expect(getYahooSymbol("00700.HK", "hk_stock")).toBe("0700.HK");
    expect(getYahooSymbol("09988.HK", "hk_stock")).toBe("9988.HK");
  });

  it("maps crypto symbols correctly", () => {
    expect(getYahooSymbol("BTCUSDT", "crypto")).toBe("BTC-USD");
    expect(getYahooSymbol("ETHUSDT", "crypto")).toBe("ETH-USD");
  });

  it("maps forex symbols correctly", () => {
    expect(getYahooSymbol("USDCNY", "forex")).toBe("USDCNY=X");
    expect(getYahooSymbol("EURUSD", "forex")).toBe("EURUSD=X");
  });
});

// ============================================================
// AI 人设 "小融" 测试
// ============================================================
describe("AI Persona - 小融", () => {
  it("system prompt contains 小融 persona", () => {
    const prompt = buildSystemPrompt("professional");
    expect(prompt).toContain("小融");
  });

  it("system prompt contains emotional personality traits", () => {
    const prompt = buildSystemPrompt("casual");
    // 应该包含情感化的描述
    expect(prompt.length).toBeGreaterThan(200);
    expect(prompt).toContain("小融");
  });

  it("all 5 styles produce distinct prompts", () => {
    const prompts = Object.keys(STYLE_PROMPTS).map((s) => buildSystemPrompt(s));
    const uniquePrompts = new Set(prompts);
    expect(uniquePrompts.size).toBe(5);
  });
});

// ============================================================
// 行情看板路由测试
// ============================================================
describe("Market Board Routes", () => {
  it("market.quotes procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.quant.market.quotes).toBeDefined();
  });

  it("market.marketStatus procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.quant.market.marketStatus).toBeDefined();
  });

  it("market.refreshRealData procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.quant.market.refreshRealData).toBeDefined();
  });
});

// ============================================================
// Voice API 路由结构测试
// ============================================================
describe("Voice API Routes", () => {
  it("voice transcribe endpoint responds to POST", async () => {
    // Test that the endpoint exists (will return 400 without audio data)
    try {
      const res = await fetch("http://localhost:3000/api/voice/transcribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      // Should return 400 (missing audio data) not 404
      expect(res.status).toBe(400);
      const data = await res.json();
      expect(data.error).toContain("音频");
    } catch {
      // Server might not be running in test env, skip
    }
  });

  it("voice tts endpoint responds to POST", async () => {
    try {
      const res = await fetch("http://localhost:3000/api/voice/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      expect(res.status).toBe(400);
      const data = await res.json();
      expect(data.error).toContain("文本");
    } catch {
      // Server might not be running in test env, skip
    }
  });
});
