/**
 * 量化交易系统 - 全面模拟数据生成脚本
 * 
 * 覆盖13张量化表：
 * 1. market_quotes - 市场行情（A股/美股/港股/指数/期货/加密货币）
 * 2. kline_data - K线数据（日K/周K/月K）
 * 3. quant_strategies - 交易策略
 * 4. trading_accounts - 交易账户
 * 5. quant_orders - 交易订单
 * 6. positions - 持仓
 * 7. risk_rules - 风控规则
 * 8. risk_logs - 风控日志
 * 9. backtest_records - 回测记录
 * 10. backtest_trades - 回测交易
 * 11. compliance_audit - 合规审计
 * 12. monitor_alerts - 监控告警
 */

import mysql from 'mysql2/promise';

// ========== 工具函数 ==========
const rand = (min, max) => Math.random() * (max - min) + min;
const randInt = (min, max) => Math.floor(rand(min, max + 1));
const pick = (arr) => arr[randInt(0, arr.length - 1)];
const decimal = (val, digits = 4) => parseFloat(val.toFixed(digits));
const uuid = () => Math.random().toString(36).substring(2, 10) + Date.now().toString(36);

function dateStr(daysAgo) {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
}

function timestamp(daysAgo) {
  return Date.now() - daysAgo * 86400000 + randInt(0, 86400000);
}

// ========== 数据定义 ==========

// A股行情
const A_SHARES = [
  { symbol: '600519.SH', name: '贵州茅台', sector: '白酒', price: 1680, pe: 28.5, pb: 8.2 },
  { symbol: '300750.SZ', name: '宁德时代', sector: '锂电池', price: 198, pe: 22.3, pb: 4.5 },
  { symbol: '601318.SH', name: '中国平安', sector: '保险', price: 48.5, pe: 8.2, pb: 1.1 },
  { symbol: '000858.SZ', name: '五粮液', sector: '白酒', price: 135, pe: 18.6, pb: 5.3 },
  { symbol: '002594.SZ', name: '比亚迪', sector: '新能源汽车', price: 268, pe: 32.1, pb: 5.8 },
  { symbol: '600036.SH', name: '招商银行', sector: '银行', price: 35.2, pe: 5.8, pb: 0.9 },
  { symbol: '601899.SH', name: '紫金矿业', sector: '有色金属', price: 18.6, pe: 12.3, pb: 3.2 },
  { symbol: '002475.SZ', name: '立讯精密', sector: '电子', price: 32.8, pe: 25.6, pb: 4.1 },
  { symbol: '600900.SH', name: '长江电力', sector: '电力', price: 28.9, pe: 22.1, pb: 3.8 },
  { symbol: '000001.SZ', name: '平安银行', sector: '银行', price: 11.2, pe: 4.5, pb: 0.5 },
  { symbol: '601012.SH', name: '隆基绿能', sector: '光伏', price: 22.5, pe: 15.8, pb: 2.1 },
  { symbol: '300059.SZ', name: '东方财富', sector: '券商', price: 16.8, pe: 28.9, pb: 3.6 },
  { symbol: '600276.SH', name: '恒瑞医药', sector: '医药', price: 42.3, pe: 45.2, pb: 6.8 },
  { symbol: '002415.SZ', name: '海康威视', sector: '安防', price: 31.5, pe: 18.9, pb: 4.2 },
  { symbol: '601398.SH', name: '工商银行', sector: '银行', price: 5.8, pe: 5.2, pb: 0.6 },
];

// 美股行情
const US_STOCKS = [
  { symbol: 'AAPL', name: '苹果公司', sector: '科技', price: 198.5, pe: 32.1, pb: 48.5 },
  { symbol: 'MSFT', name: '微软', sector: '科技', price: 425.8, pe: 36.5, pb: 12.8 },
  { symbol: 'NVDA', name: '英伟达', sector: '半导体', price: 875.2, pe: 65.3, pb: 42.1 },
  { symbol: 'TSLA', name: '特斯拉', sector: '新能源汽车', price: 178.6, pe: 58.9, pb: 11.2 },
  { symbol: 'AMZN', name: '亚马逊', sector: '电商', price: 185.3, pe: 62.1, pb: 8.5 },
  { symbol: 'GOOGL', name: '谷歌', sector: '科技', price: 155.8, pe: 25.8, pb: 6.9 },
  { symbol: 'META', name: 'Meta', sector: '社交', price: 502.3, pe: 28.5, pb: 8.2 },
  { symbol: 'JPM', name: '摩根大通', sector: '金融', price: 198.5, pe: 11.2, pb: 1.8 },
];

// 港股行情
const HK_STOCKS = [
  { symbol: '00700.HK', name: '腾讯控股', sector: '科技', price: 368.2, pe: 18.5, pb: 3.8 },
  { symbol: '09988.HK', name: '阿里巴巴', sector: '电商', price: 78.5, pe: 12.3, pb: 1.5 },
  { symbol: '01810.HK', name: '小米集团', sector: '消费电子', price: 18.9, pe: 22.1, pb: 2.8 },
  { symbol: '09618.HK', name: '京东集团', sector: '电商', price: 128.5, pe: 15.6, pb: 1.9 },
  { symbol: '03690.HK', name: '美团', sector: '本地生活', price: 135.2, pe: 45.8, pb: 5.2 },
  { symbol: '02318.HK', name: '中国平安', sector: '保险', price: 42.8, pe: 7.5, pb: 0.9 },
];

// 全球指数
const INDICES = [
  { symbol: '000001.SH', name: '上证指数', sector: '指数', price: 3285, pe: 12.8, pb: 1.3 },
  { symbol: '399001.SZ', name: '深证成指', sector: '指数', price: 10250, pe: 22.5, pb: 2.1 },
  { symbol: '399006.SZ', name: '创业板指', sector: '指数', price: 2058, pe: 32.1, pb: 3.5 },
  { symbol: 'HSI', name: '恒生指数', sector: '指数', price: 18520, pe: 9.8, pb: 1.0 },
  { symbol: 'DJI', name: '道琼斯指数', sector: '指数', price: 39150, pe: 22.5, pb: 4.2 },
  { symbol: 'SPX', name: '标普500', sector: '指数', price: 5280, pe: 24.8, pb: 4.5 },
  { symbol: 'IXIC', name: '纳斯达克', sector: '指数', price: 16750, pe: 35.2, pb: 6.8 },
  { symbol: 'N225', name: '日经225', sector: '指数', price: 38950, pe: 18.5, pb: 1.8 },
];

// 策略定义
const STRATEGIES = [
  { name: '双均线交叉策略', type: 'trend', risk: 'moderate', desc: '基于MA5和MA20金叉死叉信号的趋势跟踪策略，适用于A股大盘蓝筹股。当短期均线上穿长期均线时买入，下穿时卖出。', markets: 'a_share', ret: rand(15, 45), dd: rand(8, 20), sharpe: rand(1.2, 2.5), win: rand(45, 65) },
  { name: 'MACD动量策略', type: 'momentum', risk: 'aggressive', desc: '利用MACD指标的DIF和DEA交叉信号捕捉动量变化，结合RSI过滤假信号。适用于波动较大的科技股。', markets: 'a_share,us_stock', ret: rand(20, 55), dd: rand(12, 25), sharpe: rand(1.0, 2.2), win: rand(42, 58) },
  { name: '布林带均值回归策略', type: 'mean_reversion', risk: 'conservative', desc: '当价格触及布林带下轨时买入，触及上轨时卖出。利用统计学原理捕捉价格偏离后的回归趋势。', markets: 'a_share', ret: rand(10, 30), dd: rand(5, 15), sharpe: rand(1.5, 3.0), win: rand(55, 72) },
  { name: '跨市场套利策略', type: 'arbitrage', risk: 'conservative', desc: 'A股与港股同一标的价差套利，利用AH股溢价率波动获取无风险收益。需要同时持有两地账户。', markets: 'a_share,hk_stock', ret: rand(8, 18), dd: rand(2, 8), sharpe: rand(2.0, 4.0), win: rand(65, 85) },
  { name: '价值因子选股策略', type: 'value', risk: 'moderate', desc: '基于PE、PB、ROE等基本面指标构建多因子模型，每月调仓一次，选取低估值高质量股票组合。', markets: 'a_share', ret: rand(12, 35), dd: rand(10, 22), sharpe: rand(0.8, 1.8), win: rand(50, 65) },
  { name: 'AI深度学习预测策略', type: 'ml_based', risk: 'aggressive', desc: '使用LSTM神经网络对历史价格、成交量、情绪指标进行深度学习，预测未来5日涨跌概率。', markets: 'a_share,us_stock', ret: rand(25, 60), dd: rand(15, 30), sharpe: rand(1.1, 2.8), win: rand(48, 62) },
  { name: '网格交易策略', type: 'custom', risk: 'conservative', desc: '在预设价格区间内设置等距网格，价格下跌到网格线买入，上涨到网格线卖出，适合震荡行情。', markets: 'a_share,hk_stock', ret: rand(8, 22), dd: rand(3, 12), sharpe: rand(1.8, 3.5), win: rand(60, 78) },
  { name: '海龟交易法则', type: 'trend', risk: 'moderate', desc: '经典趋势跟踪系统，基于20日突破入场、10日突破离场，配合ATR动态止损和仓位管理。', markets: 'us_stock,futures', ret: rand(18, 42), dd: rand(12, 25), sharpe: rand(1.0, 2.0), win: rand(38, 52) },
  { name: '统计套利配对交易', type: 'arbitrage', risk: 'moderate', desc: '寻找高度相关的股票对（如招商银行vs工商银行），当价差偏离均值时做多低估做空高估。', markets: 'a_share', ret: rand(10, 25), dd: rand(5, 15), sharpe: rand(1.5, 3.0), win: rand(58, 75) },
  { name: '高频做市策略', type: 'hft', risk: 'aggressive', desc: '通过在买卖盘口同时挂单赚取买卖价差，需要极低延迟的交易通道和高频数据支持。', markets: 'futures,crypto', ret: rand(30, 80), dd: rand(5, 15), sharpe: rand(2.5, 5.0), win: rand(55, 70) },
  { name: '多因子Alpha策略', type: 'ml_based', risk: 'moderate', desc: '融合动量、价值、质量、波动率等多个Alpha因子，使用机器学习优化因子权重，月度调仓。', markets: 'a_share,us_stock', ret: rand(15, 40), dd: rand(8, 20), sharpe: rand(1.2, 2.5), win: rand(50, 65) },
  { name: '事件驱动策略', type: 'custom', risk: 'aggressive', desc: '基于财报发布、并购重组、政策变化等事件信号进行交易，利用市场对事件的反应不充分获利。', markets: 'a_share,hk_stock', ret: rand(20, 50), dd: rand(15, 30), sharpe: rand(0.8, 1.8), win: rand(45, 60) },
];

// 风控规则
const RISK_RULES = [
  { name: '单笔最大下单金额限制', type: 'max_order_amount', market: 'all', threshold: 500000, action: 'block', mandatory: true, desc: '单笔订单金额不得超过50万元，防止异常大额交易' },
  { name: '日内最大亏损限制', type: 'max_daily_loss', market: 'all', threshold: 50000, action: 'block', mandatory: true, desc: '单日亏损达到5万元时自动暂停所有交易' },
  { name: '单只股票最大持仓比例', type: 'max_single_position', market: 'a_share', threshold: 20, action: 'block', mandatory: true, desc: '单只股票持仓不得超过总资产的20%' },
  { name: '总持仓上限', type: 'max_position', market: 'all', threshold: 80, action: 'alert', mandatory: false, desc: '总持仓比例超过80%时发出预警' },
  { name: '价格偏离保护', type: 'price_deviation', market: 'a_share', threshold: 3, action: 'review', mandatory: true, desc: '委托价格偏离最新价超过3%时需人工审核' },
  { name: '高频交易限制', type: 'frequency_limit', market: 'all', threshold: 100, action: 'block', mandatory: false, desc: '单日交易次数不得超过100次' },
  { name: '大额订单预警', type: 'large_order_alert', market: 'all', threshold: 200000, action: 'alert', mandatory: false, desc: '单笔订单超过20万元时触发预警通知' },
  { name: '最大回撤限制', type: 'drawdown_limit', market: 'all', threshold: 15, action: 'block', mandatory: true, desc: '账户回撤超过15%时强制暂停所有策略' },
  { name: '市价单保护', type: 'market_price_protect', market: 'a_share', threshold: 5, action: 'block', mandatory: true, desc: '市价单成交价偏离预期超过5%时拒绝执行' },
  { name: '反向开仓限制', type: 'reverse_position', market: 'futures', threshold: 1, action: 'review', mandatory: false, desc: '持有多头时开空头需人工审核确认' },
];

async function main() {
  console.log('============================================================');
  console.log('📊 量化交易系统 - 全面模拟数据生成');
  console.log('============================================================\n');

  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  // ========== 1. 市场行情数据 ==========
  console.log('📈 [1/12] 生成市场行情数据...');
  
  const allQuotes = [];
  
  // A股
  for (const s of A_SHARES) {
    const change = decimal(rand(-5, 5), 2);
    const lastPrice = decimal(s.price * (1 + change / 100), 2);
    const openPrice = decimal(s.price * (1 + rand(-1, 1) / 100), 2);
    const highPrice = decimal(Math.max(lastPrice, openPrice) * (1 + rand(0, 2) / 100), 2);
    const lowPrice = decimal(Math.min(lastPrice, openPrice) * (1 - rand(0, 2) / 100), 2);
    allQuotes.push([s.symbol, s.name, 'a_share', 'SSE/SZSE', lastPrice, openPrice, highPrice, lowPrice, s.price, decimal(lastPrice - s.price, 2), change, randInt(50000000, 800000000), decimal(rand(5, 80) * 100000000, 2), decimal(rand(500, 20000) * 100000000, 2), s.pe, s.pb, s.sector, 'secondary', dateStr(randInt(1000, 5000))]);
  }
  
  // 美股
  for (const s of US_STOCKS) {
    const change = decimal(rand(-4, 4), 2);
    const lastPrice = decimal(s.price * (1 + change / 100), 2);
    const openPrice = decimal(s.price * (1 + rand(-1, 1) / 100), 2);
    const highPrice = decimal(Math.max(lastPrice, openPrice) * (1 + rand(0, 1.5) / 100), 2);
    const lowPrice = decimal(Math.min(lastPrice, openPrice) * (1 - rand(0, 1.5) / 100), 2);
    allQuotes.push([s.symbol, s.name, 'us_stock', 'NYSE/NASDAQ', lastPrice, openPrice, highPrice, lowPrice, s.price, decimal(lastPrice - s.price, 2), change, randInt(10000000, 200000000), decimal(rand(10, 500) * 100000000, 2), decimal(rand(1000, 30000) * 100000000, 2), s.pe, s.pb, s.sector, 'secondary', dateStr(randInt(2000, 8000))]);
  }
  
  // 港股
  for (const s of HK_STOCKS) {
    const change = decimal(rand(-4, 4), 2);
    const lastPrice = decimal(s.price * (1 + change / 100), 2);
    const openPrice = decimal(s.price * (1 + rand(-1, 1) / 100), 2);
    const highPrice = decimal(Math.max(lastPrice, openPrice) * (1 + rand(0, 2) / 100), 2);
    const lowPrice = decimal(Math.min(lastPrice, openPrice) * (1 - rand(0, 2) / 100), 2);
    allQuotes.push([s.symbol, s.name, 'hk_stock', 'HKEX', lastPrice, openPrice, highPrice, lowPrice, s.price, decimal(lastPrice - s.price, 2), change, randInt(20000000, 500000000), decimal(rand(5, 200) * 100000000, 2), decimal(rand(500, 15000) * 100000000, 2), s.pe, s.pb, s.sector, 'secondary', dateStr(randInt(1000, 6000))]);
  }
  
  // 指数
  for (const s of INDICES) {
    const change = decimal(rand(-3, 3), 2);
    const lastPrice = decimal(s.price * (1 + change / 100), 2);
    const openPrice = decimal(s.price * (1 + rand(-0.5, 0.5) / 100), 2);
    const highPrice = decimal(Math.max(lastPrice, openPrice) * (1 + rand(0, 1) / 100), 2);
    const lowPrice = decimal(Math.min(lastPrice, openPrice) * (1 - rand(0, 1) / 100), 2);
    allQuotes.push([s.symbol, s.name, 'index', 'INDEX', lastPrice, openPrice, highPrice, lowPrice, s.price, decimal(lastPrice - s.price, 2), change, randInt(100000000, 2000000000), decimal(rand(100, 5000) * 100000000, 2), null, s.pe, s.pb, s.sector, 'secondary', null]);
  }

  // IPO / 一级市场数据
  const IPO_STOCKS = [
    { symbol: '688XXX.SH', name: '芯联集成', sector: '半导体', price: 8.88, ipoDate: dateStr(5) },
    { symbol: '301XXX.SZ', name: '智元机器人', sector: '人工智能', price: 45.68, ipoDate: dateStr(3) },
    { symbol: '688YYY.SH', name: '中芯国际B', sector: '半导体', price: 28.50, ipoDate: dateStr(8) },
    { symbol: '301YYY.SZ', name: '极氪汽车', sector: '新能源汽车', price: 15.80, ipoDate: dateStr(12) },
    { symbol: '09XXX.HK', name: '商汤科技B', sector: '人工智能', price: 2.35, ipoDate: dateStr(15) },
  ];
  
  for (const s of IPO_STOCKS) {
    const change = decimal(rand(5, 80), 2);
    const lastPrice = decimal(s.price * (1 + change / 100), 2);
    allQuotes.push([s.symbol, s.name, s.symbol.includes('HK') ? 'hk_stock' : 'a_share', s.symbol.includes('HK') ? 'HKEX' : 'SSE/SZSE', lastPrice, s.price, decimal(lastPrice * 1.05, 2), decimal(s.price * 0.95, 2), s.price, decimal(lastPrice - s.price, 2), change, randInt(100000000, 500000000), decimal(rand(10, 100) * 100000000, 2), decimal(rand(100, 2000) * 100000000, 2), rand(20, 80), rand(2, 10), s.sector, 'primary', s.ipoDate]);
  }

  for (const q of allQuotes) {
    await conn.execute(
      `INSERT INTO market_quotes (symbol, name, market, exchange, lastPrice, openPrice, highPrice, lowPrice, prevClose, changeVal, changePercent, volume, turnover, marketCap, pe, pb, sector, listingType, ipoDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      q
    );
  }
  console.log(`  ✅ 插入 ${allQuotes.length} 条行情数据（A股${A_SHARES.length} + 美股${US_STOCKS.length} + 港股${HK_STOCKS.length} + 指数${INDICES.length} + IPO${IPO_STOCKS.length}）`);

  // ========== 2. K线数据 ==========
  console.log('📊 [2/12] 生成K线数据...');
  
  let klineCount = 0;
  const klineSymbols = [...A_SHARES.slice(0, 8), ...US_STOCKS.slice(0, 4), ...HK_STOCKS.slice(0, 3)];
  
  for (const s of klineSymbols) {
    const market = A_SHARES.includes(s) ? 'a_share' : US_STOCKS.includes(s) ? 'us_stock' : 'hk_stock';
    let price = s.price;
    
    // 生成60天日K线
    for (let d = 60; d >= 0; d--) {
      const change = rand(-3, 3) / 100;
      const open = decimal(price, 2);
      const close = decimal(price * (1 + change), 2);
      const high = decimal(Math.max(open, close) * (1 + rand(0, 2) / 100), 2);
      const low = decimal(Math.min(open, close) * (1 - rand(0, 2) / 100), 2);
      const vol = randInt(10000000, 300000000);
      const ts = timestamp(d);
      
      await conn.execute(
        `INSERT INTO kline_data (symbol, market, period, openPrice, highPrice, lowPrice, closePrice, volume, turnover, timestamp) VALUES (?, ?, '1d', ?, ?, ?, ?, ?, ?, ?)`,
        [s.symbol, market, open, high, low, close, vol, decimal(vol * (open + close) / 2, 2), ts]
      );
      klineCount++;
      price = close;
    }
    
    // 生成12周周K线
    price = s.price * 0.9;
    for (let w = 12; w >= 0; w--) {
      const change = rand(-5, 5) / 100;
      const open = decimal(price, 2);
      const close = decimal(price * (1 + change), 2);
      const high = decimal(Math.max(open, close) * (1 + rand(0, 4) / 100), 2);
      const low = decimal(Math.min(open, close) * (1 - rand(0, 4) / 100), 2);
      const vol = randInt(50000000, 1500000000);
      const ts = timestamp(w * 7);
      
      await conn.execute(
        `INSERT INTO kline_data (symbol, market, period, openPrice, highPrice, lowPrice, closePrice, volume, turnover, timestamp) VALUES (?, ?, '1w', ?, ?, ?, ?, ?, ?, ?)`,
        [s.symbol, market, open, high, low, close, vol, decimal(vol * (open + close) / 2, 2), ts]
      );
      klineCount++;
      price = close;
    }
  }
  console.log(`  ✅ 插入 ${klineCount} 条K线数据（${klineSymbols.length}只标的 × 日K+周K）`);

  // ========== 3. 交易策略 ==========
  console.log('🧠 [3/12] 生成交易策略数据...');
  
  const strategyIds = [];
  const statuses = ['live', 'paper_trading', 'paused', 'backtesting', 'draft', 'live', 'live', 'paper_trading'];
  const approvals = ['approved', 'approved', 'approved', 'pending', 'approved', 'approved', 'approved', 'rejected'];
  
  for (let i = 0; i < STRATEGIES.length; i++) {
    const s = STRATEGIES[i];
    const status = statuses[i % statuses.length];
    const approval = approvals[i % approvals.length];
    const [result] = await conn.execute(
      `INSERT INTO quant_strategies (userId, name, description, strategyType, applicableMarkets, code, parameters, status, riskLevel, totalReturn, annualReturn, maxDrawdown, sharpeRatio, winRate, totalTrades, isPublic, approvalStatus, complianceCheck) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [s.name, s.desc, s.type, s.markets, 
       `# ${s.name}\nimport numpy as np\nimport pandas as pd\n\nclass Strategy:\n    def __init__(self, params):\n        self.params = params\n    \n    def on_bar(self, bar):\n        # 策略核心逻辑\n        pass\n    \n    def on_order(self, order):\n        pass`,
       JSON.stringify({ period: randInt(5, 30), threshold: decimal(rand(0.5, 3), 2), stopLoss: decimal(rand(2, 8), 1), takeProfit: decimal(rand(5, 20), 1) }),
       status, s.risk,
       decimal(s.ret, 2), decimal(s.ret * rand(0.6, 1.2), 2), decimal(s.dd, 2), decimal(s.sharpe, 2), decimal(s.win, 2),
       randInt(100, 2000), i < 8 ? 1 : 0, approval, approval === 'approved' ? 1 : 0]
    );
    strategyIds.push(result.insertId);
  }
  console.log(`  ✅ 插入 ${STRATEGIES.length} 个交易策略`);

  // ========== 4. 交易账户 ==========
  console.log('💰 [4/12] 生成交易账户数据...');
  
  const accounts = [
    { name: 'A股主力账户', broker: '中信证券', market: 'a_share', type: 'live', balance: 2000000, currency: 'CNY' },
    { name: 'A股模拟账户', broker: '华泰证券', market: 'a_share', type: 'paper', balance: 1000000, currency: 'CNY' },
    { name: '美股交易账户', broker: 'Interactive Brokers', market: 'us_stock', type: 'live', balance: 150000, currency: 'USD' },
    { name: '港股交易账户', broker: '富途证券', market: 'hk_stock', type: 'live', balance: 800000, currency: 'HKD' },
    { name: '期货账户', broker: '中金期货', market: 'futures', type: 'live', balance: 500000, currency: 'CNY' },
    { name: '全球模拟账户', broker: 'Manus Quant', market: 'global', type: 'paper', balance: 5000000, currency: 'CNY' },
  ];
  
  const accountIds = [];
  for (const a of accounts) {
    const avail = decimal(a.balance * rand(0.3, 0.7), 2);
    const frozen = decimal(a.balance * rand(0.05, 0.2), 2);
    const totalPnl = decimal(rand(-50000, 200000), 2);
    const todayPnl = decimal(rand(-10000, 30000), 2);
    const [result] = await conn.execute(
      `INSERT INTO trading_accounts (userId, accountName, broker, market, accountType, balance, availableBalance, frozenBalance, totalPnl, todayPnl, currency, status, riskLevel) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)`,
      [a.name, a.broker, a.market, a.type, a.balance, avail, frozen, totalPnl, todayPnl, a.currency, totalPnl > 0 ? 'low' : 'medium']
    );
    accountIds.push(result.insertId);
  }
  console.log(`  ✅ 插入 ${accounts.length} 个交易账户`);

  // ========== 5. 交易订单 ==========
  console.log('📋 [5/12] 生成交易订单数据...');
  
  const orderStatuses = ['filled', 'filled', 'filled', 'filled', 'partial_filled', 'pending_submit', 'submitted', 'cancelled', 'rejected'];
  const orderTypes = ['limit', 'limit', 'limit', 'market', 'stop_limit'];
  let orderCount = 0;
  const orderIds = [];
  
  for (let i = 0; i < 80; i++) {
    const stock = pick([...A_SHARES, ...US_STOCKS, ...HK_STOCKS]);
    const market = A_SHARES.includes(stock) ? 'a_share' : US_STOCKS.includes(stock) ? 'us_stock' : 'hk_stock';
    const accountId = market === 'a_share' ? accountIds[0] : market === 'us_stock' ? accountIds[2] : accountIds[3];
    const strategyId = pick(strategyIds);
    const status = pick(orderStatuses);
    const side = pick(['buy', 'sell']);
    const price = decimal(stock.price * (1 + rand(-2, 2) / 100), 2);
    const qty = randInt(100, 5000);
    const filledQty = status === 'filled' ? qty : status === 'partial_filled' ? randInt(50, qty - 1) : 0;
    const filledPrice = filledQty > 0 ? decimal(price * (1 + rand(-0.5, 0.5) / 100), 2) : 0;
    const commission = filledQty > 0 ? decimal(filledPrice * filledQty * 0.0003, 2) : 0;
    const daysAgo = randInt(0, 30);
    
    const [result] = await conn.execute(
      `INSERT INTO quant_orders (idempotentId, userId, accountId, strategyId, symbol, market, orderStatus, orderType, side, price, quantity, filledQuantity, filledPrice, commission, slippage, stampDuty, riskCheckPassed, submittedAt, filledAt, createdAt) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? DAY, ${status === 'filled' || status === 'partial_filled' ? 'NOW() - INTERVAL ? DAY' : 'NULL'}, NOW() - INTERVAL ? DAY)`,
      [uuid(), accountId, strategyId, stock.symbol, market, status, pick(orderTypes), side, price, qty, filledQty, filledPrice, commission, decimal(rand(0, 0.5), 4), side === 'sell' ? decimal(filledPrice * filledQty * 0.001, 2) : 0, status !== 'rejected' ? 1 : 0, daysAgo, ...(status === 'filled' || status === 'partial_filled' ? [daysAgo] : []), daysAgo]
    );
    orderIds.push(result.insertId);
    orderCount++;
  }
  console.log(`  ✅ 插入 ${orderCount} 条交易订单`);

  // ========== 6. 持仓数据 ==========
  console.log('📦 [6/12] 生成持仓数据...');
  
  const positionStocks = [
    ...A_SHARES.slice(0, 6).map(s => ({ ...s, market: 'a_share', accountId: accountIds[0] })),
    ...US_STOCKS.slice(0, 3).map(s => ({ ...s, market: 'us_stock', accountId: accountIds[2] })),
    ...HK_STOCKS.slice(0, 2).map(s => ({ ...s, market: 'hk_stock', accountId: accountIds[3] })),
  ];
  
  for (const s of positionStocks) {
    const qty = randInt(100, 3000);
    const avgCost = decimal(s.price * (1 + rand(-10, 5) / 100), 2);
    const currentPrice = decimal(s.price * (1 + rand(-3, 3) / 100), 2);
    const marketValue = decimal(currentPrice * qty, 2);
    const unrealizedPnl = decimal((currentPrice - avgCost) * qty, 2);
    const realizedPnl = decimal(rand(-5000, 15000), 2);
    const pnlPercent = decimal((currentPrice - avgCost) / avgCost * 100, 2);
    
    await conn.execute(
      `INSERT INTO positions (userId, accountId, symbol, symbolName, market, side, quantity, avgCost, currentPrice, marketValue, unrealizedPnl, realizedPnl, pnlPercent, todayBuyQty, todaySellQty) VALUES (1, ?, ?, ?, ?, 'long', ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [s.accountId, s.symbol, s.name, s.market, qty, avgCost, currentPrice, marketValue, unrealizedPnl, realizedPnl, pnlPercent, randInt(0, 500), randInt(0, 300)]
    );
  }
  console.log(`  ✅ 插入 ${positionStocks.length} 条持仓数据`);

  // ========== 7. 风控规则 ==========
  console.log('🛡️ [7/12] 生成风控规则数据...');
  
  const ruleIds = [];
  for (const r of RISK_RULES) {
    const [result] = await conn.execute(
      `INSERT INTO risk_rules (name, description, ruleType, market, thresholdValue, action, priority, isEnabled, isMandatory, createdBy) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, 1)`,
      [r.name, r.desc, r.type, r.market, r.threshold, r.action, randInt(1, 10), r.mandatory ? 1 : 0]
    );
    ruleIds.push(result.insertId);
  }
  console.log(`  ✅ 插入 ${RISK_RULES.length} 条风控规则`);

  // ========== 8. 风控日志 ==========
  console.log('⚠️ [8/12] 生成风控日志数据...');
  
  const triggerTypes = ['blocked', 'alerted', 'reviewed', 'blocked', 'alerted'];
  let riskLogCount = 0;
  
  for (let i = 0; i < 35; i++) {
    const rule = RISK_RULES[randInt(0, RISK_RULES.length - 1)];
    const ruleId = ruleIds[RISK_RULES.indexOf(rule)];
    const stock = pick([...A_SHARES, ...US_STOCKS]);
    const triggerType = pick(triggerTypes);
    const isResolved = randInt(0, 1);
    
    await conn.execute(
      `INSERT INTO risk_logs (userId, ruleId, ruleName, orderId, triggerType, triggerDetail, market, symbol, orderAmount, riskScore, isResolved, resolvedBy, resolvedAt, remark, createdAt) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ${isResolved ? '1' : 'NULL'}, ${isResolved ? 'NOW()' : 'NULL'}, ?, NOW() - INTERVAL ? DAY)`,
      [ruleId, rule.name, orderIds.length > 0 ? pick(orderIds) : null, triggerType,
       JSON.stringify({ rule: rule.name, threshold: rule.threshold, actual: decimal(rule.threshold * rand(1.01, 2.5), 2), action: rule.action }),
       rule.market === 'all' ? 'a_share' : rule.market, stock.symbol, decimal(rand(10000, 600000), 2), randInt(30, 100), isResolved,
       isResolved ? '风控审核通过，交易正常' : null, randInt(0, 30)]
    );
    riskLogCount++;
  }
  console.log(`  ✅ 插入 ${riskLogCount} 条风控日志`);

  // ========== 9. 回测记录 ==========
  console.log('🔄 [9/12] 生成回测记录数据...');
  
  const backtestIds = [];
  for (let i = 0; i < 15; i++) {
    const strategyIdx = i % STRATEGIES.length;
    const s = STRATEGIES[strategyIdx];
    const startDays = randInt(365, 1095);
    const endDays = randInt(0, 30);
    const initialCapital = pick([500000, 1000000, 2000000, 5000000]);
    const totalReturn = decimal(rand(-10, 60), 2);
    const finalCapital = decimal(initialCapital * (1 + totalReturn / 100), 2);
    const status = i < 12 ? 'completed' : pick(['running', 'failed']);
    const totalTrades = randInt(50, 500);
    const winTrades = Math.floor(totalTrades * rand(0.35, 0.7));
    
    // 生成收益曲线
    const equityCurve = [];
    let equity = initialCapital;
    for (let d = 0; d < 24; d++) {
      equity *= (1 + rand(-3, 4) / 100);
      equityCurve.push(decimal(equity, 0));
    }
    
    const monthlyReturns = [];
    for (let m = 0; m < 12; m++) {
      monthlyReturns.push(decimal(rand(-8, 12), 2));
    }
    
    const [result] = await conn.execute(
      `INSERT INTO backtest_records (userId, strategyId, name, market, symbols, startDate, endDate, initialCapital, slippageModel, slippageValue, commissionRate, stampDutyRate, status, finalCapital, totalReturn, annualReturn, maxDrawdown, sharpeRatio, sortinoRatio, calmarRatio, winRate, profitFactor, totalTrades, winTrades, lossTrades, avgWin, avgLoss, equityCurve, monthlyReturns, startedAt, completedAt) VALUES (1, ?, ?, ?, ?, ?, ?, ?, 'fixed', 0.001, 0.0003, 0.001, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? DAY, ${status === 'completed' ? 'NOW() - INTERVAL ? DAY' : 'NULL'})`,
      [strategyIds[strategyIdx], `${s.name}-回测${i + 1}`, s.markets.split(',')[0],
       JSON.stringify(A_SHARES.slice(0, randInt(3, 8)).map(a => a.symbol)),
       dateStr(startDays), dateStr(endDays), initialCapital,
       status, status === 'completed' ? finalCapital : null,
       status === 'completed' ? totalReturn : null,
       status === 'completed' ? decimal(totalReturn * rand(0.5, 1.2), 2) : null,
       status === 'completed' ? decimal(rand(5, 25), 2) : null,
       status === 'completed' ? decimal(rand(0.5, 3.0), 2) : null,
       status === 'completed' ? decimal(rand(0.6, 3.5), 2) : null,
       status === 'completed' ? decimal(rand(0.3, 2.5), 2) : null,
       status === 'completed' ? decimal(winTrades / totalTrades * 100, 2) : null,
       status === 'completed' ? decimal(rand(1.0, 3.0), 2) : null,
       status === 'completed' ? totalTrades : 0,
       status === 'completed' ? winTrades : 0,
       status === 'completed' ? totalTrades - winTrades : 0,
       status === 'completed' ? decimal(rand(500, 5000), 2) : null,
       status === 'completed' ? decimal(rand(300, 3000), 2) : null,
       JSON.stringify(equityCurve), JSON.stringify(monthlyReturns),
       randInt(1, 30), ...(status === 'completed' ? [randInt(0, 5)] : [])]
    );
    backtestIds.push(result.insertId);
  }
  console.log(`  ✅ 插入 ${backtestIds.length} 条回测记录`);

  // ========== 10. 回测交易 ==========
  console.log('📝 [10/12] 生成回测交易数据...');
  
  let btTradeCount = 0;
  for (const btId of backtestIds.slice(0, 10)) {
    const numTrades = randInt(15, 40);
    for (let t = 0; t < numTrades; t++) {
      const stock = pick(A_SHARES);
      const side = t % 2 === 0 ? 'buy' : 'sell';
      const price = decimal(stock.price * (1 + rand(-10, 10) / 100), 2);
      const qty = randInt(100, 2000);
      const pnl = side === 'sell' ? decimal(rand(-3000, 8000), 2) : 0;
      
      await conn.execute(
        `INSERT INTO backtest_trades (backtestId, symbol, side, price, quantity, commission, slippage, pnl, pnlPercent, holdingPeriod, tradeTimestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [btId, stock.symbol, side, price, qty, decimal(price * qty * 0.0003, 2), decimal(rand(0, 1), 4), pnl, pnl !== 0 ? decimal(pnl / (price * qty) * 100, 2) : 0, side === 'sell' ? randInt(1, 30) : 0, timestamp(randInt(30, 365))]
      );
      btTradeCount++;
    }
  }
  console.log(`  ✅ 插入 ${btTradeCount} 条回测交易记录`);

  // ========== 11. 合规审计 ==========
  console.log('📜 [11/12] 生成合规审计数据...');
  
  const auditActions = ['order_submit', 'order_cancel', 'strategy_modify', 'risk_rule_change', 'account_change', 'emergency_stop', 'data_export', 'config_change', 'login', 'logout'];
  const auditDetails = [
    '提交买入订单：贵州茅台 1000股 限价1680.00',
    '撤销未成交订单 #12345',
    '修改策略参数：止损比例从5%调整为3%',
    '更新风控规则：单笔最大下单金额从50万调整为80万',
    '新增交易账户：美股交易账户（Interactive Brokers）',
    '触发紧急停止：全市场暂停交易',
    '导出近30天交易记录（CSV格式）',
    '修改系统配置：启用夜盘交易模式',
    '管理员登录系统',
    '管理员退出系统',
  ];
  
  let auditCount = 0;
  for (let i = 0; i < 50; i++) {
    const actionIdx = randInt(0, auditActions.length - 1);
    const isCompliant = randInt(0, 9) > 0 ? 1 : 0; // 90%合规
    
    await conn.execute(
      `INSERT INTO compliance_audit (userId, operatorName, actionType, targetType, targetId, detail, ipAddress, isCompliant, complianceNote, createdAt) VALUES (1, 'Manus管理员', ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? DAY)`,
      [auditActions[actionIdx], pick(['order', 'strategy', 'rule', 'account', 'system']), randInt(1, 100),
       auditDetails[actionIdx], `192.168.${randInt(1, 255)}.${randInt(1, 255)}`,
       isCompliant, isCompliant ? '操作符合合规要求' : '操作存在合规风险，已记录并通知风控部门',
       randInt(0, 60)]
    );
    auditCount++;
  }
  console.log(`  ✅ 插入 ${auditCount} 条合规审计记录`);

  // ========== 12. 监控告警 ==========
  console.log('🔔 [12/12] 生成监控告警数据...');
  
  const alerts = [
    { type: 'high_latency', severity: 'medium', title: '行情数据延迟升高', msg: 'A股行情数据延迟从50ms升至350ms，超过200ms阈值', source: '行情服务', metric: 'latency_ms', current: '350', threshold: '200' },
    { type: 'order_failure', severity: 'high', title: '订单提交失败率异常', msg: '近5分钟订单提交失败率达到12%，超过5%阈值', source: '交易引擎', metric: 'failure_rate', current: '12%', threshold: '5%' },
    { type: 'risk_trigger', severity: 'critical', title: '风控规则触发：日内亏损超限', msg: 'A股主力账户日内亏损达到48,500元，接近50,000元上限', source: '风控引擎', metric: 'daily_loss', current: '48500', threshold: '50000' },
    { type: 'cpu_overload', severity: 'medium', title: 'CPU使用率过高', msg: '回测服务器CPU使用率达到92%，超过85%阈值', source: '回测服务', metric: 'cpu_usage', current: '92%', threshold: '85%' },
    { type: 'memory_overload', severity: 'high', title: '内存使用率告警', msg: '交易引擎内存使用率达到88%，建议扩容', source: '交易引擎', metric: 'memory_usage', current: '88%', threshold: '80%' },
    { type: 'data_anomaly', severity: 'medium', title: 'K线数据异常', msg: '检测到贵州茅台(600519.SH)日K线数据缺失3根', source: '数据服务', metric: 'missing_bars', current: '3', threshold: '0' },
    { type: 'network_issue', severity: 'high', title: '券商API连接中断', msg: '中信证券交易API连接超时，已自动重连3次', source: '通道管理', metric: 'connection_status', current: 'disconnected', threshold: 'connected' },
    { type: 'service_down', severity: 'critical', title: '风控引擎服务异常', msg: '风控引擎进程异常退出，已自动重启', source: '风控引擎', metric: 'process_status', current: 'crashed', threshold: 'running' },
    { type: 'compliance_violation', severity: 'high', title: '合规检查未通过', msg: '策略"高频做市策略"未通过合规审查，存在潜在市场操纵风险', source: '合规系统', metric: 'compliance_check', current: 'failed', threshold: 'passed' },
    { type: 'security_breach', severity: 'critical', title: '异常登录检测', msg: '检测到来自未知IP(103.45.67.89)的登录尝试，已自动拦截', source: '安全系统', metric: 'login_attempt', current: 'blocked', threshold: 'normal' },
    { type: 'disk_full', severity: 'medium', title: '磁盘空间不足', msg: '日志存储磁盘使用率达到78%，建议清理历史日志', source: '运维监控', metric: 'disk_usage', current: '78%', threshold: '75%' },
    { type: 'high_latency', severity: 'low', title: '回测任务排队等待', msg: '当前有5个回测任务在排队等待，预计等待时间15分钟', source: '回测服务', metric: 'queue_length', current: '5', threshold: '3' },
  ];
  
  for (const a of alerts) {
    const isResolved = randInt(0, 1);
    await conn.execute(
      `INSERT INTO monitor_alerts (alertType, severity, title, message, source, metric, currentValue, thresholdValue, isResolved, resolvedBy, resolvedAt, acknowledgedBy, acknowledgedAt, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ${isResolved ? '1' : 'NULL'}, ${isResolved ? 'NOW()' : 'NULL'}, ${randInt(0, 1) ? '1' : 'NULL'}, ${randInt(0, 1) ? 'NOW()' : 'NULL'}, NOW() - INTERVAL ? DAY)`,
      [a.type, a.severity, a.title, a.msg, a.source, a.metric, a.current, a.threshold, isResolved, randInt(0, 14)]
    );
  }
  console.log(`  ✅ 插入 ${alerts.length} 条监控告警`);

  await conn.end();

  console.log('\n============================================================');
  console.log('🎉 量化交易系统模拟数据生成完成！');
  console.log('============================================================');
  console.log(`📈 市场行情: ${allQuotes.length} 条（A股/美股/港股/指数/IPO）`);
  console.log(`📊 K线数据: ${klineCount} 条（日K+周K）`);
  console.log(`🧠 交易策略: ${STRATEGIES.length} 个（趋势/动量/套利/价值/ML/高频等）`);
  console.log(`💰 交易账户: ${accounts.length} 个（多券商多市场）`);
  console.log(`📋 交易订单: ${orderCount} 条（多状态多类型）`);
  console.log(`📦 持仓数据: ${positionStocks.length} 条（多品种浮动盈亏）`);
  console.log(`🛡️ 风控规则: ${RISK_RULES.length} 条（硬性+软性）`);
  console.log(`⚠️ 风控日志: ${riskLogCount} 条`);
  console.log(`🔄 回测记录: ${backtestIds.length} 条（含收益曲线）`);
  console.log(`📝 回测交易: ${btTradeCount} 条`);
  console.log(`📜 合规审计: ${auditCount} 条`);
  console.log(`🔔 监控告警: ${alerts.length} 条`);
  console.log('============================================================');
}

main().catch(err => {
  console.error('脚本执行失败:', err);
  process.exit(1);
});
