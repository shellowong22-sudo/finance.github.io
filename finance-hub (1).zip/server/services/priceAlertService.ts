/**
 * Price Alert Service
 * 检测自选股预警条件并推送通知
 */
import { getDb } from "../db";
import { priceAlerts, marketQuotes } from "../../drizzle/schema";
import { eq, and, sql } from "drizzle-orm";
import { notifyOwner } from "../_core/notification";

export interface AlertCheckResult {
  triggered: number;
  checked: number;
  errors: number;
}

/**
 * 检查所有启用的预警规则，匹配行情数据触发通知
 */
export async function checkPriceAlerts(): Promise<AlertCheckResult> {
  const db = await getDb();
  if (!db) return { triggered: 0, checked: 0, errors: 0 };

  try {
    // 获取所有启用的预警
    const alerts = await db.select().from(priceAlerts).where(eq(priceAlerts.isEnabled, true));
    if (alerts.length === 0) return { triggered: 0, checked: 0, errors: 0 };

    let triggered = 0;
    let errors = 0;
    const now = new Date();
    const notifications: string[] = [];

    for (const alert of alerts) {
      try {
        // 检查冷却时间
        if (alert.lastTriggeredAt) {
          const cooldownMs = (alert.cooldownMinutes || 30) * 60 * 1000;
          if (now.getTime() - new Date(alert.lastTriggeredAt).getTime() < cooldownMs) {
            continue; // 冷却中，跳过
          }
        }

        // 获取当前行情
        const quotes = await db.select().from(marketQuotes).where(
          and(eq(marketQuotes.symbol, alert.symbol), eq(marketQuotes.market, alert.market as any))
        ).limit(1);

        if (!quotes[0]) continue;

        const quote = quotes[0];
        const price = parseFloat(quote.lastPrice);
        const changePct = parseFloat(quote.changePercent || "0");
        const threshold = parseFloat(alert.threshold);
        let shouldTrigger = false;
        let triggerMsg = "";

        switch (alert.alertType) {
          case "change_percent_above":
            if (changePct >= threshold) {
              shouldTrigger = true;
              triggerMsg = `${alert.name || alert.symbol} 涨幅达 ${changePct.toFixed(2)}%，超过预警阈值 ${threshold}%`;
            }
            break;
          case "change_percent_below":
            if (changePct <= -threshold) {
              shouldTrigger = true;
              triggerMsg = `${alert.name || alert.symbol} 跌幅达 ${changePct.toFixed(2)}%，超过预警阈值 -${threshold}%`;
            }
            break;
          case "price_above":
            if (price >= threshold) {
              shouldTrigger = true;
              triggerMsg = `${alert.name || alert.symbol} 价格 ${price.toFixed(2)} 已突破上限 ${threshold}`;
            }
            break;
          case "price_below":
            if (price <= threshold) {
              shouldTrigger = true;
              triggerMsg = `${alert.name || alert.symbol} 价格 ${price.toFixed(2)} 已跌破下限 ${threshold}`;
            }
            break;
        }

        if (shouldTrigger) {
          triggered++;
          notifications.push(triggerMsg);

          // 更新触发记录
          await db.update(priceAlerts).set({
            lastTriggeredAt: now,
            triggerCount: sql`${priceAlerts.triggerCount} + 1`,
          }).where(eq(priceAlerts.id, alert.id));
        }
      } catch (e) {
        errors++;
        console.error(`[PriceAlert] Error checking alert ${alert.id}:`, e);
      }
    }

    // 批量发送通知
    if (notifications.length > 0) {
      const title = `📊 价格预警触发 (${notifications.length}条)`;
      const content = notifications.map((msg, i) => `${i + 1}. ${msg}`).join("\n");
      try {
        await notifyOwner({ title, content });
        console.log(`[PriceAlert] Sent ${notifications.length} alert notifications`);
      } catch (e) {
        console.error("[PriceAlert] Failed to send notification:", e);
      }
    }

    return { triggered, checked: alerts.length, errors };
  } catch (error) {
    console.error("[PriceAlert] Check failed:", error);
    return { triggered: 0, checked: 0, errors: 1 };
  }
}
