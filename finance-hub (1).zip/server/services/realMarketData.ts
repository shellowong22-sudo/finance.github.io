/**
 * Real Market Data Service
 * 通过 Yahoo Finance API 获取真实行情数据
 */
import { callDataApi } from "../_core/dataApi";

// ============================================================
// Symbol 映射：将数据库中的 symbol 转换为 Yahoo Finance 的 symbol
// ============================================================
const YAHOO_SYMBOL_MAP: Record<string, Record<string, string>> = {
  // A股：symbol → symbol.SS (上海) 或 symbol.SZ (深圳)
  a_share: {
    "600519": "600519.SS", "601318": "601318.SS", "600036": "600036.SS",
    "000858": "000858.SZ", "002594": "002594.SZ", "600900": "600900.SS",
    "601012": "601012.SS", "000001": "000001.SZ", "600276": "600276.SS",
    "002475": "002475.SZ", "300750": "300750.SZ", "601888": "601888.SS",
    "601398": "601398.SS", "601288": "601288.SS", "600030": "600030.SS",
    "601166": "601166.SS", "300059": "300059.SZ", "002415": "002415.SZ",
    "600887": "600887.SS", "000333": "000333.SZ", "600690": "600690.SS",
    "601857": "601857.SS", "600028": "600028.SS", "601668": "601668.SS",
    "601899": "601899.SS", "601919": "601919.SS", "600585": "600585.SS",
    "600309": "600309.SS", "600438": "600438.SS", "600809": "600809.SS",
    "300760": "300760.SZ", "300274": "300274.SZ", "300124": "300124.SZ",
    "300015": "300015.SZ", "002714": "002714.SZ", "002371": "002371.SZ",
    "002352": "002352.SZ", "002304": "002304.SZ", "002230": "002230.SZ",
    "002142": "002142.SZ", "002049": "002049.SZ", "000725": "000725.SZ",
    "000568": "000568.SZ", "000002": "000002.SZ", "603259": "603259.SS",
    "688012": "688012.SS", "688036": "688036.SS", "688111": "688111.SS",
    "688981": "688981.SS", "600050": "600050.SS",
    // 扩充A股
    "600000": "600000.SS", "600016": "600016.SS", "600031": "600031.SS",
    "600048": "600048.SS", "600104": "600104.SS", "600111": "600111.SS",
    "600150": "600150.SS", "600176": "600176.SS", "600196": "600196.SS",
    "600346": "600346.SS", "600406": "600406.SS", "600570": "600570.SS",
    "600588": "600588.SS", "600745": "600745.SS", "600919": "600919.SS",
    "601009": "601009.SS", "601066": "601066.SS", "601088": "601088.SS",
    "601111": "601111.SS", "601225": "601225.SS", "601390": "601390.SS",
    "601628": "601628.SS", "601688": "601688.SS", "601766": "601766.SS",
    "601985": "601985.SS",
    "002001": "002001.SZ", "002027": "002027.SZ", "002120": "002120.SZ",
    "002241": "002241.SZ", "002460": "002460.SZ",
    "300014": "300014.SZ", "300122": "300122.SZ", "300308": "300308.SZ",
    "300394": "300394.SZ", "300496": "300496.SZ",
  },
  // 美股：直接使用 symbol
  us_stock: {
    "AAPL": "AAPL", "MSFT": "MSFT", "GOOGL": "GOOGL", "AMZN": "AMZN",
    "NVDA": "NVDA", "TSLA": "TSLA", "META": "META", "BRK.B": "BRK-B",
    "JPM": "JPM", "V": "V", "JNJ": "JNJ", "UNH": "UNH",
    "HD": "HD", "PG": "PG", "MA": "MA", "DIS": "DIS",
    "NFLX": "NFLX", "INTC": "INTC", "AMD": "AMD", "CRM": "CRM",
    "AVGO": "AVGO", "COST": "COST", "LLY": "LLY", "ABBV": "ABBV",
    "XOM": "XOM", "BABA": "BABA", "PDD": "PDD", "NIO": "NIO",
    "COIN": "COIN", "PLTR": "PLTR",
    // 扩充美股
    "PYPL": "PYPL", "SQ": "SQ", "UBER": "UBER", "ABNB": "ABNB",
    "SNOW": "SNOW", "SHOP": "SHOP", "ROKU": "ROKU", "ZM": "ZM",
    "SNAP": "SNAP", "RBLX": "RBLX", "MRVL": "MRVL", "MU": "MU",
    "QCOM": "QCOM", "ORCL": "ORCL", "IBM": "IBM", "BA": "BA",
    "GS": "GS", "MS": "MS", "LI": "LI", "XPEV": "XPEV",
  },
  // 港股：直接使用 xxxx.HK
  hk_stock: {
    "00700.HK": "0700.HK", "09988.HK": "9988.HK", "01810.HK": "1810.HK",
    "03690.HK": "3690.HK", "02318.HK": "2318.HK", "00941.HK": "0941.HK",
    "01299.HK": "1299.HK", "00388.HK": "0388.HK", "00005.HK": "0005.HK",
    "02020.HK": "2020.HK", "01211.HK": "1211.HK", "09618.HK": "9618.HK",
    "09999.HK": "9999.HK", "09626.HK": "9626.HK", "06618.HK": "6618.HK",
    "02269.HK": "2269.HK", "01024.HK": "1024.HK", "02015.HK": "2015.HK",
    "00981.HK": "0981.HK", "01347.HK": "1347.HK",
    // 扩充港股
    "00001.HK": "0001.HK", "00003.HK": "0003.HK", "00006.HK": "0006.HK",
    "00011.HK": "0011.HK", "00016.HK": "0016.HK", "00027.HK": "0027.HK",
    "00066.HK": "0066.HK", "00175.HK": "0175.HK", "00241.HK": "0241.HK",
    "00285.HK": "0285.HK", "00772.HK": "0772.HK", "01177.HK": "1177.HK",
    "01928.HK": "1928.HK", "02382.HK": "2382.HK", "06060.HK": "6060.HK",
  },
  // 指数
  index: {
    "000001.SH": "000001.SS", "000016.SH": "000016.SS", "000300.SH": "000300.SS",
    "399001.SZ": "399001.SZ", "399006.SZ": "399006.SZ",
    "DJI": "^DJI", "SPX": "^GSPC", "IXIC": "^IXIC",
    "HSI": "^HSI", "HSTECH": "^HSTECH",
    "N225": "^N225", "FTSE": "^FTSE", "GDAXI": "^GDAXI",
    "FCHI": "^FCHI", "AORD": "^AORD",
  },
  // 外汇
  forex: {
    "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X", "USDJPY": "USDJPY=X",
    "USDCNY": "USDCNY=X", "USDCHF": "USDCHF=X", "USDCAD": "USDCAD=X",
    "AUDUSD": "AUDUSD=X", "NZDUSD": "NZDUSD=X", "EURGBP": "EURGBP=X",
    "EURJPY": "EURJPY=X",
  },
  // 加密货币
  crypto: {
    "BTCUSDT": "BTC-USD", "ETHUSDT": "ETH-USD", "BNBUSDT": "BNB-USD",
    "SOLUSDT": "SOL-USD", "XRPUSDT": "XRP-USD", "DOGEUSDT": "DOGE-USD",
    "ADAUSDT": "ADA-USD", "DOTUSDT": "DOT-USD", "AVAXUSDT": "AVAX-USD",
    "LINKUSDT": "LINK-USD",
  },
  // 期货 - 使用国际期货代替（中国期货 Yahoo 不支持）
  futures: {
    "AU2406": "GC=F", "AG2406": "SI=F", "CU2406": "HG=F",
    "SC2406": "CL=F", "RB2410": "HRC=F", "AL2406": "ALI=F",
    "ZN2406": "^ZINC", "NI2406": "^NICKEL",
    "I2409": "TIO=F", "J2409": "^DJUSCL",
    "M2409": "ZM=F", "Y2409": "ZL=F", "P2409": "KPO=F",
    "C2409": "ZC=F", "A2409": "ZS=F",
    "CF2409": "CT=F", "SR2409": "SB=F",
    "RU2409": "^RUBBER",
    "FU2409": "BZ=F", "LU2409": "BZ=F",
    "MA2409": "^METHANOL", "TA2409": "^PTA",
    "PP2409": "^PP", "HC2410": "HRC=F",
    "JM2409": "^COKING",
  },
  // 基金 ETF - 使用对应的 A 股 ETF 代码
  fund: {
    "510050": "510050.SS", "510300": "510300.SS", "510500": "510500.SS",
    "512010": "512010.SS", "512100": "512100.SS", "512690": "512690.SS",
    "512880": "512880.SS", "513050": "513050.SS", "513100": "513100.SS",
    "515790": "515790.SS", "518880": "518880.SS",
    "159915": "159915.SZ", "159919": "159919.SZ", "159941": "159941.SZ",
    "159985": "159985.SZ",
  },
};

// ============================================================
// 获取 Yahoo Finance symbol
// ============================================================
export function getYahooSymbol(dbSymbol: string, market: string): string | null {
  const map = YAHOO_SYMBOL_MAP[market];
  if (!map) return null;
  return map[dbSymbol] || null;
}

// ============================================================
// 从 Yahoo Finance 获取单个品种的实时行情
// ============================================================
export interface RealQuoteData {
  lastPrice: number;
  openPrice: number;
  highPrice: number;
  lowPrice: number;
  prevClose: number;
  changeVal: number;
  changePercent: number;
  volume: number;
  turnover: number;
  marketCap: number;
  longName?: string;
  currency?: string;
  // 市场状态
  marketState?: string;
  hasPrePostMarketData?: boolean;
  preMarketPrice?: number;
  postMarketPrice?: number;
  // 交易时段
  tradingPeriod?: {
    pre: { start: number; end: number };
    regular: { start: number; end: number };
    post: { start: number; end: number };
  };
  timezone?: string;
  exchangeTimezoneName?: string;
  gmtoffset?: number;
}

export async function fetchRealQuote(yahooSymbol: string): Promise<RealQuoteData | null> {
  try {
    const result = await callDataApi("YahooFinance/get_stock_chart", {
      query: { symbol: yahooSymbol, interval: "1d", range: "1d" }
    }) as any;

    const chartResult = result?.chart?.result?.[0];
    if (!chartResult?.meta) return null;

    const meta = chartResult.meta;
    const quotes = chartResult.indicators?.quote?.[0];
    const timestamps = chartResult.timestamp;

    // 获取最新一天的 OHLCV
    let open = meta.regularMarketPrice;
    let high = meta.regularMarketDayHigh || meta.regularMarketPrice;
    let low = meta.regularMarketDayLow || meta.regularMarketPrice;
    let volume = meta.regularMarketVolume || 0;

    if (quotes && timestamps && timestamps.length > 0) {
      const lastIdx = timestamps.length - 1;
      if (quotes.open?.[lastIdx]) open = quotes.open[lastIdx];
      if (quotes.high?.[lastIdx]) high = quotes.high[lastIdx];
      if (quotes.low?.[lastIdx]) low = quotes.low[lastIdx];
      if (quotes.volume?.[lastIdx]) volume = quotes.volume[lastIdx];
    }

    const prevClose = meta.chartPreviousClose || meta.regularMarketPrice;
    const lastPrice = meta.regularMarketPrice;
    const changeVal = lastPrice - prevClose;
    const changePercent = prevClose > 0 ? (changeVal / prevClose) * 100 : 0;

    return {
      lastPrice,
      openPrice: open,
      highPrice: high,
      lowPrice: low,
      prevClose,
      changeVal,
      changePercent,
      volume,
      turnover: lastPrice * volume,
      marketCap: 0, // Yahoo chart API 不直接返回市值
      longName: meta.longName || meta.shortName,
      currency: meta.currency,
      hasPrePostMarketData: meta.hasPrePostMarketData,
      preMarketPrice: meta.preMarketPrice,
      postMarketPrice: meta.postMarketPrice,
      tradingPeriod: meta.currentTradingPeriod ? {
        pre: { start: meta.currentTradingPeriod.pre?.start, end: meta.currentTradingPeriod.pre?.end },
        regular: { start: meta.currentTradingPeriod.regular?.start, end: meta.currentTradingPeriod.regular?.end },
        post: { start: meta.currentTradingPeriod.post?.start, end: meta.currentTradingPeriod.post?.end },
      } : undefined,
      timezone: meta.timezone,
      exchangeTimezoneName: meta.exchangeTimezoneName,
      gmtoffset: meta.gmtoffset,
    };
  } catch (e) {
    console.error(`[RealMarketData] Failed to fetch ${yahooSymbol}:`, e);
    return null;
  }
}

// ============================================================
// 批量获取行情数据（带限流，每批最多 5 个并发）
// ============================================================
export async function fetchRealQuotesBatch(
  items: { dbSymbol: string; market: string }[]
): Promise<Map<string, RealQuoteData>> {
  const results = new Map<string, RealQuoteData>();
  const BATCH_SIZE = 5;
  const DELAY_MS = 200;

  for (let i = 0; i < items.length; i += BATCH_SIZE) {
    const batch = items.slice(i, i + BATCH_SIZE);
    const promises = batch.map(async ({ dbSymbol, market }) => {
      const yahooSymbol = getYahooSymbol(dbSymbol, market);
      if (!yahooSymbol) return;
      const data = await fetchRealQuote(yahooSymbol);
      if (data) results.set(`${dbSymbol}|${market}`, data);
    });
    await Promise.all(promises);
    if (i + BATCH_SIZE < items.length) {
      await new Promise(r => setTimeout(r, DELAY_MS));
    }
  }

  return results;
}

// ============================================================
// 市场交易状态判断
// ============================================================
export interface MarketStatusInfo {
  market: string;
  label: string;
  status: "trading" | "pre_market" | "post_market" | "lunch_break" | "closed" | "weekend" | "24h";
  color: string;
  nextEvent?: string;
  nextEventTime?: string;
}

export function getMarketStatus(market: string, now?: Date): MarketStatusInfo {
  const d = now || new Date();
  const dow = d.getDay();
  const isWeekend = dow === 0 || dow === 6;

  // 获取各时区的当前时间
  const getTimeInTz = (tz: string) => {
    const str = d.toLocaleString("en-US", { timeZone: tz, hour12: false });
    const parts = str.split(", ")[1]?.split(":") || [];
    return parseInt(parts[0] || "0") * 60 + parseInt(parts[1] || "0");
  };

  if (market === "crypto") {
    return { market, label: "24H交易中", status: "24h", color: "green" };
  }

  if (market === "forex") {
    // 外汇周一到周五24小时，周末休市
    if (isWeekend) {
      return { market, label: "周末休市", status: "weekend", color: "gray" };
    }
    return { market, label: "交易中", status: "trading", color: "green" };
  }

  if (isWeekend) {
    return { market, label: "周末休市", status: "weekend", color: "gray" };
  }

  if (market === "a_share" || market === "fund" || market === "bond") {
    const t = getTimeInTz("Asia/Shanghai");
    if (t >= 555 && t < 570) return { market, label: "集合竞价", status: "pre_market", color: "blue", nextEvent: "开盘", nextEventTime: "09:30" };
    if (t >= 570 && t < 690) return { market, label: "交易中(上午)", status: "trading", color: "green", nextEvent: "午休", nextEventTime: "11:30" };
    if (t >= 690 && t < 780) return { market, label: "午间休市", status: "lunch_break", color: "yellow", nextEvent: "开盘", nextEventTime: "13:00" };
    if (t >= 780 && t < 900) return { market, label: "交易中(下午)", status: "trading", color: "green", nextEvent: "收盘", nextEventTime: "15:00" };
    if (t >= 900) return { market, label: "已收盘", status: "closed", color: "gray", nextEvent: "明日开盘", nextEventTime: "09:30" };
    return { market, label: "未开盘", status: "closed", color: "gray", nextEvent: "开盘", nextEventTime: "09:30" };
  }

  if (market === "hk_stock") {
    const t = getTimeInTz("Asia/Hong_Kong");
    if (t >= 540 && t < 570) return { market, label: "盘前竞价", status: "pre_market", color: "blue", nextEvent: "开盘", nextEventTime: "09:30" };
    if (t >= 570 && t < 720) return { market, label: "交易中(上午)", status: "trading", color: "green", nextEvent: "午休", nextEventTime: "12:00" };
    if (t >= 720 && t < 780) return { market, label: "午间休市", status: "lunch_break", color: "yellow", nextEvent: "开盘", nextEventTime: "13:00" };
    if (t >= 780 && t < 960) return { market, label: "交易中(下午)", status: "trading", color: "green", nextEvent: "收盘", nextEventTime: "16:00" };
    if (t >= 960 && t < 976) return { market, label: "收市竞价", status: "post_market", color: "orange", nextEvent: "休市", nextEventTime: "16:10" };
    if (t >= 976) return { market, label: "已收盘", status: "closed", color: "gray", nextEvent: "明日开盘", nextEventTime: "09:30" };
    return { market, label: "未开盘", status: "closed", color: "gray", nextEvent: "开盘", nextEventTime: "09:30" };
  }

  if (market === "us_stock") {
    const t = getTimeInTz("America/New_York");
    if (t >= 240 && t < 570) return { market, label: "盘前交易", status: "pre_market", color: "blue", nextEvent: "开盘", nextEventTime: "09:30 ET" };
    if (t >= 570 && t < 960) return { market, label: "盘中交易", status: "trading", color: "green", nextEvent: "收盘", nextEventTime: "16:00 ET" };
    if (t >= 960 && t < 1200) return { market, label: "盘后交易", status: "post_market", color: "orange", nextEvent: "休市", nextEventTime: "20:00 ET" };
    if (t >= 1200) return { market, label: "已收盘", status: "closed", color: "gray", nextEvent: "明日盘前", nextEventTime: "04:00 ET" };
    return { market, label: "已收盘", status: "closed", color: "gray", nextEvent: "盘前交易", nextEventTime: "04:00 ET" };
  }

  if (market === "futures" || market === "option") {
    const t = getTimeInTz("Asia/Shanghai");
    // 中国期货交易时段：上午9:00-11:30, 下午13:30-15:00, 夜盘21:00-次日2:30
    if (t >= 540 && t < 625) return { market, label: "交易中(上午)", status: "trading", color: "green" };
    if (t >= 625 && t < 630) return { market, label: "小节休息", status: "lunch_break", color: "yellow" };
    if (t >= 630 && t < 690) return { market, label: "交易中(上午)", status: "trading", color: "green" };
    if (t >= 690 && t < 810) return { market, label: "午间休市", status: "lunch_break", color: "yellow" };
    if (t >= 810 && t < 900) return { market, label: "交易中(下午)", status: "trading", color: "green" };
    if (t >= 1260 && t < 1410) return { market, label: "夜盘交易中", status: "trading", color: "green" };
    if (t >= 900 && t < 1260) return { market, label: "已收盘", status: "closed", color: "gray" };
    if (t < 150) return { market, label: "夜盘交易中", status: "trading", color: "green" };
    return { market, label: "未开盘", status: "closed", color: "gray" };
  }

  if (market === "index") {
    // 指数跟随对应市场
    const t = getTimeInTz("Asia/Shanghai");
    if (t >= 570 && t < 690) return { market, label: "交易中", status: "trading", color: "green" };
    if (t >= 690 && t < 780) return { market, label: "午间休市", status: "lunch_break", color: "yellow" };
    if (t >= 780 && t < 900) return { market, label: "交易中", status: "trading", color: "green" };
    return { market, label: "已收盘", status: "closed", color: "gray" };
  }

  return { market, label: "未知", status: "closed", color: "gray" };
}

// ============================================================
// 获取所有市场状态
// ============================================================
export function getAllMarketStatuses(now?: Date): MarketStatusInfo[] {
  const markets = ["a_share", "hk_stock", "us_stock", "futures", "option", "fund", "bond", "crypto", "forex", "index"];
  return markets.map(m => getMarketStatus(m, now));
}
