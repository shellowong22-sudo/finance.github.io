/**
 * Market News Service
 * 基于真实行情数据动态生成市场快讯
 * 每次调用时根据当前行情数据生成最新快讯
 */
import { getDb } from "../db";
import { marketQuotes } from "../../drizzle/schema";
import { desc, sql } from "drizzle-orm";

export interface NewsItem {
  id: string;
  title: string;
  source: string;
  time: string;
  category: string;
}

/**
 * 基于真实行情数据生成动态快讯
 */
export async function generateMarketNews(): Promise<NewsItem[]> {
  const db = await getDb();
  if (!db) return getStaticNews();

  try {
    // 获取所有行情数据
    const quotes = await db.select().from(marketQuotes).orderBy(desc(marketQuotes.updatedAt)).limit(300);
    if (quotes.length === 0) return getStaticNews();

    const news: NewsItem[] = [];
    const now = new Date();
    const timeStr = (minutesAgo: number) => {
      const d = new Date(now.getTime() - minutesAgo * 60000);
      return d.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false });
    };

    // 按市场分组
    const byMarket: Record<string, typeof quotes> = {};
    for (const q of quotes) {
      if (!byMarket[q.market]) byMarket[q.market] = [];
      byMarket[q.market].push(q);
    }

    // 1. 涨幅最大的品种
    const sorted = [...quotes].sort((a, b) => parseFloat(b.changePercent || "0") - parseFloat(a.changePercent || "0"));
    const topGainer = sorted[0];
    if (topGainer && parseFloat(topGainer.changePercent || "0") > 0) {
      news.push({
        id: `g1-${topGainer.symbol}`,
        title: `${topGainer.name}(${topGainer.symbol})涨${parseFloat(topGainer.changePercent || "0").toFixed(2)}%，报${parseFloat(topGainer.lastPrice).toFixed(2)}`,
        source: "行情数据",
        time: timeStr(1),
        category: "行情",
      });
    }

    // 2. 跌幅最大的品种
    const topLoser = sorted[sorted.length - 1];
    if (topLoser && parseFloat(topLoser.changePercent || "0") < 0) {
      news.push({
        id: `l1-${topLoser.symbol}`,
        title: `${topLoser.name}(${topLoser.symbol})跌${Math.abs(parseFloat(topLoser.changePercent || "0")).toFixed(2)}%，报${parseFloat(topLoser.lastPrice).toFixed(2)}`,
        source: "行情数据",
        time: timeStr(2),
        category: "行情",
      });
    }

    // 3. A股市场概况
    const aShares = byMarket["a_share"] || [];
    if (aShares.length > 0) {
      const aUp = aShares.filter(q => parseFloat(q.changePercent || "0") > 0).length;
      const aDown = aShares.filter(q => parseFloat(q.changePercent || "0") < 0).length;
      news.push({
        id: "a-overview",
        title: `A股市场：${aUp}涨${aDown}跌，共${aShares.length}只个股`,
        source: "市场概览",
        time: timeStr(3),
        category: "A股",
      });
    }

    // 4. 核心指数快讯
    const indices = byMarket["index"] || [];
    const indexMap: Record<string, string> = {
      "000001.SH": "上证指数", "399001.SZ": "深证成指", "399006.SZ": "创业板指",
      "HSI": "恒生指数", "DJI": "道琼斯", "SPX": "标普500", "IXIC": "纳斯达克",
    };
    for (const idx of indices) {
      if (indexMap[idx.symbol]) {
        const pct = parseFloat(idx.changePercent || "0");
        const dir = pct > 0 ? "涨" : pct < 0 ? "跌" : "平";
        news.push({
          id: `idx-${idx.symbol}`,
          title: `${indexMap[idx.symbol]}${dir}${Math.abs(pct).toFixed(2)}%，报${parseFloat(idx.lastPrice).toFixed(2)}`,
          source: "指数行情",
          time: timeStr(Math.floor(Math.random() * 5) + 1),
          category: "指数",
        });
      }
    }

    // 5. 美股热门
    const usStocks = byMarket["us_stock"] || [];
    const hotUS = usStocks.filter(q => ["AAPL", "NVDA", "TSLA", "MSFT", "GOOGL", "META"].includes(q.symbol));
    for (const s of hotUS.slice(0, 3)) {
      const pct = parseFloat(s.changePercent || "0");
      news.push({
        id: `us-${s.symbol}`,
        title: `${s.name}(${s.symbol})${pct > 0 ? "涨" : "跌"}${Math.abs(pct).toFixed(2)}%，报$${parseFloat(s.lastPrice).toFixed(2)}`,
        source: "美股行情",
        time: timeStr(Math.floor(Math.random() * 8) + 2),
        category: "美股",
      });
    }

    // 6. 港股热门
    const hkStocks = byMarket["hk_stock"] || [];
    const hotHK = hkStocks.filter(q => ["00700.HK", "09988.HK", "01810.HK", "03690.HK"].includes(q.symbol));
    for (const s of hotHK.slice(0, 2)) {
      const pct = parseFloat(s.changePercent || "0");
      news.push({
        id: `hk-${s.symbol}`,
        title: `${s.name}(${s.symbol})${pct > 0 ? "涨" : "跌"}${Math.abs(pct).toFixed(2)}%，报HK$${parseFloat(s.lastPrice).toFixed(2)}`,
        source: "港股行情",
        time: timeStr(Math.floor(Math.random() * 10) + 3),
        category: "港股",
      });
    }

    // 7. 加密货币
    const cryptos = byMarket["crypto"] || [];
    const btc = cryptos.find(q => q.symbol === "BTCUSDT");
    if (btc) {
      const pct = parseFloat(btc.changePercent || "0");
      const price = parseFloat(btc.lastPrice);
      news.push({
        id: "crypto-btc",
        title: `比特币${pct > 0 ? "涨" : "跌"}${Math.abs(pct).toFixed(2)}%，现报$${price > 1000 ? (price / 1000).toFixed(1) + "K" : price.toFixed(0)}`,
        source: "加密行情",
        time: timeStr(Math.floor(Math.random() * 5) + 1),
        category: "加密",
      });
    }
    const eth = cryptos.find(q => q.symbol === "ETHUSDT");
    if (eth) {
      const pct = parseFloat(eth.changePercent || "0");
      news.push({
        id: "crypto-eth",
        title: `以太坊${pct > 0 ? "涨" : "跌"}${Math.abs(pct).toFixed(2)}%，现报$${parseFloat(eth.lastPrice).toFixed(0)}`,
        source: "加密行情",
        time: timeStr(Math.floor(Math.random() * 5) + 2),
        category: "加密",
      });
    }

    // 8. 外汇
    const forexItems = byMarket["forex"] || [];
    const usdcny = forexItems.find(q => q.symbol === "USDCNY");
    if (usdcny) {
      news.push({
        id: "fx-usdcny",
        title: `美元兑人民币报${parseFloat(usdcny.lastPrice).toFixed(4)}，${parseFloat(usdcny.changePercent || "0") > 0 ? "人民币走弱" : "人民币走强"}`,
        source: "外汇行情",
        time: timeStr(Math.floor(Math.random() * 10) + 1),
        category: "外汇",
      });
    }

    // 9. 期货
    const futures = byMarket["futures"] || [];
    const gold = futures.find(q => q.symbol === "AU2406");
    if (gold) {
      news.push({
        id: "fut-gold",
        title: `沪金主力${parseFloat(gold.changePercent || "0") > 0 ? "上涨" : "下跌"}${Math.abs(parseFloat(gold.changePercent || "0")).toFixed(2)}%，报${parseFloat(gold.lastPrice).toFixed(2)}元/克`,
        source: "期货行情",
        time: timeStr(Math.floor(Math.random() * 8) + 2),
        category: "期货",
      });
    }
    const oil = futures.find(q => q.symbol === "SC2406");
    if (oil) {
      news.push({
        id: "fut-oil",
        title: `原油期货报$${parseFloat(oil.lastPrice).toFixed(2)}/桶，${parseFloat(oil.changePercent || "0") > 0 ? "涨" : "跌"}${Math.abs(parseFloat(oil.changePercent || "0")).toFixed(2)}%`,
        source: "期货行情",
        time: timeStr(Math.floor(Math.random() * 8) + 3),
        category: "期货",
      });
    }

    // 10. 成交量最大的品种
    const byVolume = [...quotes].filter(q => q.volume && q.volume > 0).sort((a, b) => (b.volume || 0) - (a.volume || 0));
    if (byVolume[0]) {
      const vol = byVolume[0].volume || 0;
      const volStr = vol > 1e8 ? `${(vol / 1e8).toFixed(1)}亿` : vol > 1e4 ? `${(vol / 1e4).toFixed(0)}万` : vol.toString();
      news.push({
        id: `vol-${byVolume[0].symbol}`,
        title: `${byVolume[0].name}成交量达${volStr}手，领跑全市场`,
        source: "成交数据",
        time: timeStr(Math.floor(Math.random() * 15) + 5),
        category: "成交",
      });
    }

    // Shuffle and return
    return news.sort(() => Math.random() - 0.5);
  } catch (error) {
    console.error("[NewsService] Failed to generate news:", error);
    return getStaticNews();
  }
}

/**
 * 静态快讯（兜底）
 */
function getStaticNews(): NewsItem[] {
  return [
    { id: "s1", title: "全球市场行情数据实时更新中，请关注最新动态", source: "系统", time: "00:00", category: "系统" },
    { id: "s2", title: "金融综合服务平台已接入Yahoo Finance真实行情数据", source: "系统", time: "00:00", category: "系统" },
    { id: "s3", title: "支持A股、美股、港股、期货、期权、基金、债券、外汇、加密货币等多市场行情", source: "系统", time: "00:00", category: "系统" },
  ];
}
