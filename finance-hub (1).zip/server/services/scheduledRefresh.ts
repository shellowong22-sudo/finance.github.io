/**
 * Scheduled Market Data Refresh Service
 * 每5分钟自动从 Yahoo Finance 刷新所有行情数据
 * 支持指数退避策略：当 Data API 配额耗尽时自动降低请求频率
 */
import { getDb, resetDbConnection } from "../db";
import { marketQuotes } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { fetchRealQuotesBatch, getYahooSymbol } from "./realMarketData";
import { checkPriceAlerts } from "./priceAlertService";

let refreshTimer: ReturnType<typeof setTimeout> | null = null;
let isRefreshing = false;
let lastRefreshTime: Date | null = null;
let lastRefreshResult: { updated: number; total: number; errors: number } | null = null;

// ============================================================
// 24小时可用性历史记录（内存环形缓冲区）
// ============================================================
interface AvailabilityRecord {
  timestamp: string; // ISO string
  success: boolean;
  updated: number;
  total: number;
  errors: number;
  durationMs: number;
  backoffLevel: number;
  quotaExhausted: boolean;
  successRate: number; // 0-100
}

const MAX_HISTORY_RECORDS = 288; // 24h * 12 records/hour (every 5min) = 288
const availabilityHistory: AvailabilityRecord[] = [];

function addAvailabilityRecord(record: AvailabilityRecord) {
  availabilityHistory.push(record);
  // 移除超过24小时的记录
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  while (availabilityHistory.length > 0 && new Date(availabilityHistory[0].timestamp).getTime() < cutoff) {
    availabilityHistory.shift();
  }
  // 硬限制
  while (availabilityHistory.length > MAX_HISTORY_RECORDS) {
    availabilityHistory.shift();
  }
}

/**
 * 获取过去24小时的可用性历史记录
 */
export function getAvailabilityHistory() {
  // 计算汇总统计
  const total = availabilityHistory.length;
  const successful = availabilityHistory.filter(r => r.success).length;
  const avgSuccessRate = total > 0 ? Math.round(successful / total * 100) : 100;
  const avgDuration = total > 0 ? Math.round(availabilityHistory.reduce((s, r) => s + r.durationMs, 0) / total) : 0;
  
  // 按小时聚合
  const hourlyMap = new Map<string, { success: number; total: number; avgDuration: number; durations: number[] }>();
  for (const record of availabilityHistory) {
    const hour = record.timestamp.slice(0, 13) + ':00:00'; // 截取到小时
    const existing = hourlyMap.get(hour) || { success: 0, total: 0, avgDuration: 0, durations: [] };
    existing.total++;
    if (record.success) existing.success++;
    existing.durations.push(record.durationMs);
    hourlyMap.set(hour, existing);
  }
  const hourly = Array.from(hourlyMap.entries()).map(([hour, data]) => ({
    hour,
    successRate: Math.round(data.success / data.total * 100),
    totalRequests: data.total,
    successfulRequests: data.success,
    avgDurationMs: Math.round(data.durations.reduce((a, b) => a + b, 0) / data.durations.length),
  })).sort((a, b) => a.hour.localeCompare(b.hour));

  return {
    records: availabilityHistory,
    summary: {
      totalRecords: total,
      successfulRecords: successful,
      failedRecords: total - successful,
      overallSuccessRate: avgSuccessRate,
      avgDurationMs: avgDuration,
    },
    hourly,
  };
}

// ============================================================
// 指数退避策略状态
// ============================================================
const BASE_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
const MAX_INTERVAL_MS = 60 * 60 * 1000; // 60 minutes max
const BACKOFF_MULTIPLIER = 2;

let currentIntervalMs = BASE_INTERVAL_MS;
let consecutiveQuotaErrors = 0;
let lastQuotaErrorTime: Date | null = null;
let backoffLevel = 0; // 0=normal, 1=10min, 2=20min, 3=40min, 4=60min
let quotaExhausted = false;

/**
 * 获取退避状态信息
 */
export function getBackoffStatus() {
  return {
    currentIntervalMs,
    currentIntervalLabel: formatInterval(currentIntervalMs),
    backoffLevel,
    maxLevel: 4,
    quotaExhausted,
    consecutiveQuotaErrors,
    lastQuotaErrorTime: lastQuotaErrorTime?.toISOString() || null,
    baseIntervalMs: BASE_INTERVAL_MS,
    maxIntervalMs: MAX_INTERVAL_MS,
  };
}

function formatInterval(ms: number): string {
  const minutes = Math.round(ms / 60000);
  if (minutes >= 60) return `${(minutes / 60).toFixed(1)}小时`;
  return `${minutes}分钟`;
}

/**
 * 检测是否为配额耗尽错误
 */
function isQuotaExhaustedError(errorMsg: string): boolean {
  return errorMsg.includes("usage exhausted") ||
         errorMsg.includes("rate limit") ||
         errorMsg.includes("quota exceeded") ||
         errorMsg.includes("too many requests");
}

/**
 * 增加退避级别
 */
function increaseBackoff() {
  if (backoffLevel < 4) {
    backoffLevel++;
    currentIntervalMs = Math.min(
      BASE_INTERVAL_MS * Math.pow(BACKOFF_MULTIPLIER, backoffLevel),
      MAX_INTERVAL_MS
    );
    quotaExhausted = true;
    console.log(`[ScheduledRefresh] Backoff increased to level ${backoffLevel}: interval=${formatInterval(currentIntervalMs)}`);
  }
}

/**
 * 尝试恢复到正常频率
 */
function tryRecoverBackoff() {
  if (backoffLevel > 0) {
    // 成功刷新后降低一级退避
    backoffLevel = Math.max(0, backoffLevel - 1);
    currentIntervalMs = backoffLevel === 0
      ? BASE_INTERVAL_MS
      : Math.min(BASE_INTERVAL_MS * Math.pow(BACKOFF_MULTIPLIER, backoffLevel), MAX_INTERVAL_MS);
    if (backoffLevel === 0) {
      quotaExhausted = false;
      consecutiveQuotaErrors = 0;
    }
    console.log(`[ScheduledRefresh] Backoff recovered to level ${backoffLevel}: interval=${formatInterval(currentIntervalMs)}`);
  }
}

/**
 * 执行一次全量行情数据刷新
 */
export async function refreshAllMarketQuotes(): Promise<{ updated: number; total: number; errors: number; quotaErrors: number }> {
  if (isRefreshing) {
    console.log("[ScheduledRefresh] Already refreshing, skip this round");
    return { ...(lastRefreshResult || { updated: 0, total: 0, errors: 0 }), quotaErrors: 0 };
  }

  isRefreshing = true;
  const startTime = Date.now();
  console.log(`[ScheduledRefresh] Starting refresh (backoff level=${backoffLevel}, interval=${formatInterval(currentIntervalMs)})...`);

  try {
    const db = await getDb();
    if (!db) {
      console.error("[ScheduledRefresh] DB unavailable");
      return { updated: 0, total: 0, errors: 0, quotaErrors: 0 };
    }

    // 获取所有品种
    const allQuotes = await db.select({
      symbol: marketQuotes.symbol,
      market: marketQuotes.market,
    }).from(marketQuotes);

    // 筛选有 Yahoo 映射的品种
    const items = allQuotes
      .filter(q => getYahooSymbol(q.symbol, q.market) !== null)
      .map(q => ({ dbSymbol: q.symbol, market: q.market }));

    if (items.length === 0) {
      console.log("[ScheduledRefresh] No items to refresh");
      return { updated: 0, total: 0, errors: 0, quotaErrors: 0 };
    }

    console.log(`[ScheduledRefresh] Fetching real data for ${items.length} items...`);

    // 批量获取真实数据
    const realData = await fetchRealQuotesBatch(items);
    let updated = 0;
    let errors = 0;
    let quotaErrors = 0;

    // 统计配额错误（从 fetchRealQuotesBatch 的 console 输出中检测）
    // 通过比较请求数和返回数来推断配额错误
    const requestedCount = items.length;
    const returnedCount = realData.size;
    const failedCount = requestedCount - returnedCount;

    for (const [key, data] of Array.from(realData.entries())) {
      const [symbol, market] = key.split("|");
      try {
        await db.update(marketQuotes).set({
          lastPrice: data.lastPrice.toFixed(4),
          openPrice: data.openPrice.toFixed(4),
          highPrice: data.highPrice.toFixed(4),
          lowPrice: data.lowPrice.toFixed(4),
          prevClose: data.prevClose.toFixed(4),
          change: data.changeVal.toFixed(4),
          changePercent: data.changePercent.toFixed(2),
          volume: data.volume,
          turnover: data.turnover.toFixed(4),
        }).where(
          and(eq(marketQuotes.symbol, symbol), eq(marketQuotes.market, market as any))
        );
        updated++;
      } catch (e) {
        errors++;
        console.error(`[ScheduledRefresh] Failed to update ${symbol}:`, e);
      }
    }

    const durationMs = Date.now() - startTime;
    const elapsed = (durationMs / 1000).toFixed(1);
    lastRefreshTime = new Date();
    lastRefreshResult = { updated, total: items.length, errors };

    console.log(`[ScheduledRefresh] Done: ${updated}/${items.length} updated, ${errors} errors, took ${elapsed}s`);

    // 记录可用性历史
    const isSuccess = updated > 0;
    addAvailabilityRecord({
      timestamp: new Date().toISOString(),
      success: isSuccess,
      updated,
      total: items.length,
      errors,
      durationMs,
      backoffLevel,
      quotaExhausted,
      successRate: items.length > 0 ? Math.round(updated / items.length * 100) : 0,
    });

    // 判断是否有大量失败（可能是配额耗尽）
    const failureRate = failedCount / requestedCount;
    if (failureRate > 0.5 && updated === 0) {
      // 超过50%失败且没有成功更新 → 很可能配额耗尽
      consecutiveQuotaErrors++;
      lastQuotaErrorTime = new Date();
      quotaErrors = failedCount;
      increaseBackoff();
      console.log(`[ScheduledRefresh] High failure rate (${(failureRate * 100).toFixed(0)}%), likely quota exhausted. Consecutive: ${consecutiveQuotaErrors}`);
    } else if (updated > 0) {
      // 有成功更新 → 尝试恢复
      tryRecoverBackoff();
    }

    // 刷新完成后检查价格预警
    try {
      const alertResult = await checkPriceAlerts();
      if (alertResult.triggered > 0) {
        console.log(`[ScheduledRefresh] Price alerts: ${alertResult.triggered} triggered out of ${alertResult.checked}`);
      }
    } catch (e) {
      console.error("[ScheduledRefresh] Price alert check failed:", e);
    }

    // 调度下一次刷新
    scheduleNextRefresh();

    return { ...lastRefreshResult, quotaErrors };
  } catch (error: any) {
    console.error("[ScheduledRefresh] Refresh failed:", error);
    // 检查是否为配额错误
    const errMsg = error?.message || "";
    if (isQuotaExhaustedError(errMsg)) {
      consecutiveQuotaErrors++;
      lastQuotaErrorTime = new Date();
      increaseBackoff();
    }
    // Reset DB connection on connection errors
    if (error?.code === 'ECONNRESET' || error?.cause?.code === 'ECONNRESET' ||
        error?.code === 'PROTOCOL_CONNECTION_LOST' || error?.cause?.code === 'PROTOCOL_CONNECTION_LOST' ||
        error?.message?.includes('ECONNRESET') || error?.message?.includes('PROTOCOL_CONNECTION_LOST')) {
      resetDbConnection();
      console.log("[ScheduledRefresh] DB connection reset due to connection error");
    }
    // 调度下一次刷新
    scheduleNextRefresh();
    // 记录失败的可用性历史
    addAvailabilityRecord({
      timestamp: new Date().toISOString(),
      success: false,
      updated: 0,
      total: 0,
      errors: 1,
      durationMs: Date.now() - startTime,
      backoffLevel,
      quotaExhausted,
      successRate: 0,
    });
    return { updated: 0, total: 0, errors: 1, quotaErrors: 0 };
  } finally {
    isRefreshing = false;
  }
}

/**
 * 调度下一次刷新（使用当前退避间隔）
 */
function scheduleNextRefresh() {
  if (refreshTimer) {
    clearTimeout(refreshTimer);
  }
  refreshTimer = setTimeout(() => {
    refreshAllMarketQuotes().catch(console.error);
  }, currentIntervalMs);
}

/**
 * 启动定时刷新
 */
export function startScheduledRefresh(intervalMs: number = 5 * 60 * 1000) {
  if (refreshTimer) {
    console.log("[ScheduledRefresh] Already running, clearing old timer");
    clearTimeout(refreshTimer);
  }

  // 更新基础间隔（但不影响退避状态）
  if (backoffLevel === 0) {
    currentIntervalMs = intervalMs;
  }

  console.log(`[ScheduledRefresh] Starting scheduled refresh every ${formatInterval(currentIntervalMs)}`);

  // 启动后延迟30秒执行第一次刷新
  setTimeout(() => {
    refreshAllMarketQuotes().catch(console.error);
  }, 30000);
}

/**
 * 停止定时刷新
 */
export function stopScheduledRefresh() {
  if (refreshTimer) {
    clearTimeout(refreshTimer);
    refreshTimer = null;
    console.log("[ScheduledRefresh] Stopped");
  }
}

/**
 * 获取刷新状态（包含退避信息）
 */
export function getRefreshStatus() {
  return {
    isRunning: !!refreshTimer,
    isRefreshing,
    lastRefreshTime: lastRefreshTime?.toISOString() || null,
    lastResult: lastRefreshResult,
    backoff: getBackoffStatus(),
  };
}
