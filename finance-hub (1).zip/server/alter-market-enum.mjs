/**
 * 数据库Migration脚本：扩展market_quotes和quant_accounts表的market枚举
 * 添加 option, fund, bond 三个新值
 */
import mysql from "mysql2/promise";

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) { console.error("DATABASE_URL not found in env"); process.exit(1); }

const url = new URL(dbUrl);
const conn = await mysql.createConnection({
  host: url.hostname, port: parseInt(url.port || "3306"),
  user: url.username, password: decodeURIComponent(url.password),
  database: url.pathname.slice(1),
  ssl: { rejectUnauthorized: true },
});

console.log("Connected to database");

console.log("Altering market_quotes.market enum...");
await conn.execute(`
  ALTER TABLE market_quotes MODIFY COLUMN market ENUM('a_share','us_stock','hk_stock','futures','option','fund','bond','crypto','forex','index') NOT NULL
`);
console.log("market_quotes.market enum updated");

console.log("Altering trading_accounts.market enum...");
await conn.execute(`
  ALTER TABLE trading_accounts MODIFY COLUMN market ENUM('a_share','us_stock','hk_stock','futures','option','fund','bond','crypto','forex','global') NOT NULL
`);
console.log("trading_accounts.market enum updated");

await conn.end();
console.log("Migration complete!");
