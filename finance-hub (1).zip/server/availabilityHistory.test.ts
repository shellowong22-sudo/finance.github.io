import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the scheduledRefresh module to test availability history logic
describe("Availability History", () => {
  // Test the ring buffer logic
  describe("Ring Buffer Logic", () => {
    it("should maintain max 288 records", () => {
      // Simulate the ring buffer behavior
      const MAX_RECORDS = 288;
      const buffer: any[] = [];
      
      // Add 300 records
      for (let i = 0; i < 300; i++) {
        buffer.push({
          timestamp: new Date(Date.now() - (300 - i) * 60000).toISOString(),
          success: i % 3 !== 0,
          updated: i % 3 !== 0 ? 50 : 0,
          total: 50,
          errors: i % 3 === 0 ? 50 : 0,
          durationMs: 1000 + Math.random() * 2000,
          backoffLevel: 0,
          quotaExhausted: false,
          successRate: i % 3 !== 0 ? 100 : 0,
        });
        // Trim to max
        while (buffer.length > MAX_RECORDS) {
          buffer.shift();
        }
      }
      
      expect(buffer.length).toBeLessThanOrEqual(MAX_RECORDS);
      expect(buffer.length).toBe(288);
    });

    it("should remove records older than 24 hours", () => {
      const buffer: any[] = [];
      const now = Date.now();
      
      // Add old records (25 hours ago)
      buffer.push({
        timestamp: new Date(now - 25 * 60 * 60 * 1000).toISOString(),
        success: true,
        successRate: 100,
      });
      
      // Add recent record
      buffer.push({
        timestamp: new Date(now).toISOString(),
        success: true,
        successRate: 100,
      });
      
      // Trim old records
      const cutoff = now - 24 * 60 * 60 * 1000;
      while (buffer.length > 0 && new Date(buffer[0].timestamp).getTime() < cutoff) {
        buffer.shift();
      }
      
      expect(buffer.length).toBe(1);
      expect(new Date(buffer[0].timestamp).getTime()).toBeGreaterThanOrEqual(cutoff);
    });
  });

  describe("Summary Calculation", () => {
    it("should calculate correct success rate", () => {
      const records = [
        { success: true, durationMs: 1000, successRate: 100 },
        { success: true, durationMs: 2000, successRate: 100 },
        { success: false, durationMs: 500, successRate: 0 },
        { success: true, durationMs: 1500, successRate: 80 },
      ];
      
      const total = records.length;
      const successful = records.filter(r => r.success).length;
      const avgSuccessRate = Math.round(successful / total * 100);
      const avgDuration = Math.round(records.reduce((s, r) => s + r.durationMs, 0) / total);
      
      expect(avgSuccessRate).toBe(75);
      expect(avgDuration).toBe(1250);
      expect(successful).toBe(3);
      expect(total - successful).toBe(1);
    });

    it("should return 100% success rate when no records", () => {
      const records: any[] = [];
      const total = records.length;
      const avgSuccessRate = total > 0 ? Math.round(records.filter((r: any) => r.success).length / total * 100) : 100;
      
      expect(avgSuccessRate).toBe(100);
    });
  });

  describe("Hourly Aggregation", () => {
    it("should aggregate records by hour", () => {
      const now = new Date();
      const hour = now.toISOString().slice(0, 13) + ':00:00';
      
      const records = [
        { timestamp: now.toISOString(), success: true, durationMs: 1000 },
        { timestamp: new Date(now.getTime() - 60000).toISOString(), success: true, durationMs: 2000 },
        { timestamp: new Date(now.getTime() - 120000).toISOString(), success: false, durationMs: 500 },
      ];
      
      const hourlyMap = new Map<string, { success: number; total: number; durations: number[] }>();
      for (const record of records) {
        const h = record.timestamp.slice(0, 13) + ':00:00';
        const existing = hourlyMap.get(h) || { success: 0, total: 0, durations: [] };
        existing.total++;
        if (record.success) existing.success++;
        existing.durations.push(record.durationMs);
        hourlyMap.set(h, existing);
      }
      
      const hourData = hourlyMap.get(hour);
      expect(hourData).toBeDefined();
      expect(hourData!.total).toBe(3);
      expect(hourData!.success).toBe(2);
      expect(Math.round(hourData!.success / hourData!.total * 100)).toBe(67);
    });
  });

  describe("Availability Record Structure", () => {
    it("should have all required fields", () => {
      const record = {
        timestamp: new Date().toISOString(),
        success: true,
        updated: 50,
        total: 60,
        errors: 10,
        durationMs: 1500,
        backoffLevel: 0,
        quotaExhausted: false,
        successRate: 83,
      };
      
      expect(record).toHaveProperty("timestamp");
      expect(record).toHaveProperty("success");
      expect(record).toHaveProperty("updated");
      expect(record).toHaveProperty("total");
      expect(record).toHaveProperty("errors");
      expect(record).toHaveProperty("durationMs");
      expect(record).toHaveProperty("backoffLevel");
      expect(record).toHaveProperty("quotaExhausted");
      expect(record).toHaveProperty("successRate");
    });

    it("should calculate successRate correctly", () => {
      const updated = 45;
      const total = 60;
      const successRate = total > 0 ? Math.round(updated / total * 100) : 0;
      
      expect(successRate).toBe(75);
    });
  });

  describe("API Response Format", () => {
    it("should return correct response structure", () => {
      const response = {
        records: [],
        summary: {
          totalRecords: 0,
          successfulRecords: 0,
          failedRecords: 0,
          overallSuccessRate: 100,
          avgDurationMs: 0,
        },
        hourly: [],
      };
      
      expect(response).toHaveProperty("records");
      expect(response).toHaveProperty("summary");
      expect(response).toHaveProperty("hourly");
      expect(response.summary).toHaveProperty("overallSuccessRate");
      expect(response.summary).toHaveProperty("avgDurationMs");
      expect(Array.isArray(response.records)).toBe(true);
      expect(Array.isArray(response.hourly)).toBe(true);
    });

    it("should handle mixed success/failure records in response", () => {
      const records = Array.from({ length: 10 }, (_, i) => ({
        timestamp: new Date(Date.now() - i * 300000).toISOString(),
        success: i % 2 === 0,
        updated: i % 2 === 0 ? 50 : 0,
        total: 50,
        errors: i % 2 === 0 ? 0 : 50,
        durationMs: 1000 + i * 100,
        backoffLevel: i % 2 === 0 ? 0 : 1,
        quotaExhausted: i % 2 !== 0,
        successRate: i % 2 === 0 ? 100 : 0,
      }));
      
      const total = records.length;
      const successful = records.filter(r => r.success).length;
      
      expect(total).toBe(10);
      expect(successful).toBe(5);
      expect(Math.round(successful / total * 100)).toBe(50);
    });
  });
});
