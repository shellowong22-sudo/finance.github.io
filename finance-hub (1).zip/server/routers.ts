import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import * as db from "./db";
import { quantRouter } from "./routers/quantRouter";
import { aiAssistantRouter } from "./routers/aiAssistant";

// 管理员权限中间件
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "需要管理员权限" });
  return next({ ctx });
});

// 渠道或管理员权限
const channelProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" && ctx.user.role !== "channel") {
    throw new TRPCError({ code: "FORBIDDEN", message: "需要渠道权限" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  // ============================================================
  // 认证模块
  // ============================================================
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============================================================
  // 发文模块
  // ============================================================
  article: router({
    list: publicProcedure
      .input(z.object({
        page: z.number().default(1),
        limit: z.number().default(10),
        status: z.string().optional(),
        keyword: z.string().optional(),
        categoryId: z.number().optional(),
        isTop: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        const result = await db.getArticles(input);
        return result;
      }),

    detail: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const article = await db.getArticleById(input.id);
        if (!article) throw new TRPCError({ code: "NOT_FOUND" });
        if (article.status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "文章不存在或已下架" });
        await db.incrementArticleView(input.id);
        return article;
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1).max(500),
        summary: z.string().optional(),
        content: z.string().min(1),
        coverImage: z.string().optional(),
        categoryId: z.number().optional(),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // 敏感词检测
        const check = await db.checkSensitiveWords(input.title + " " + input.content);
        if (check.level === "block") {
          throw new TRPCError({ code: "BAD_REQUEST", message: `内容包含违禁词汇：${check.words.join(", ")}` });
        }
        const status = ctx.user.role === "admin" ? "published" : "pending";
        const result = await db.createArticle({
          ...input,
          tags: input.tags ? JSON.stringify(input.tags) : undefined,
          authorId: ctx.user.id,
          status,
          publishedAt: status === "published" ? new Date() : undefined,
        });
        return { success: true, status };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        summary: z.string().optional(),
        content: z.string().optional(),
        coverImage: z.string().optional(),
        categoryId: z.number().optional(),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const article = await db.getArticleById(input.id);
        if (!article) throw new TRPCError({ code: "NOT_FOUND" });
        if (article.authorId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const { id, tags, ...rest } = input;
        await db.updateArticle(id, { ...rest, tags: tags ? JSON.stringify(tags) : undefined });
        return { success: true };
      }),

    // 管理员审核
    review: adminProcedure
      .input(z.object({
        id: z.number(),
        action: z.enum(["approve", "reject"]),
        rejectReason: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const status = input.action === "approve" ? "published" : "rejected";
        await db.updateArticle(input.id, {
          status,
          rejectReason: input.rejectReason,
          publishedAt: status === "published" ? new Date() : undefined,
        });
        await db.createAuditLog({
          adminId: ctx.user.id,
          action: `article_${input.action}`,
          targetType: "article",
          targetId: input.id,
          remark: input.rejectReason,
        });
        return { success: true };
      }),

    // 上下架
    toggleStatus: adminProcedure
      .input(z.object({ id: z.number(), status: z.enum(["published", "offline"]) }))
      .mutation(async ({ ctx, input }) => {
        await db.updateArticle(input.id, { status: input.status });
        await db.createAuditLog({
          adminId: ctx.user.id,
          action: `article_${input.status}`,
          targetType: "article",
          targetId: input.id,
        });
        return { success: true };
      }),

    // 置顶
    togglePin: adminProcedure
      .input(z.object({ id: z.number(), isPinned: z.boolean() }))
      .mutation(async ({ input }) => {
        await db.updateArticle(input.id, { isPinned: input.isPinned });
        return { success: true };
      }),

    categories: publicProcedure.query(async () => {
      return db.getArticleCategories();
    }),

    createCategory: adminProcedure
      .input(z.object({ name: z.string(), slug: z.string(), description: z.string().optional() }))
      .mutation(async ({ input }) => {
        await db.createArticleCategory(input);
        return { success: true };
      }),
  }),

  // ============================================================
  // 社交模块
  // ============================================================
  social: router({
    // 评论
    comments: publicProcedure
      .input(z.object({ articleId: z.number(), page: z.number().default(1), limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return db.getComments(input.articleId, input.page, input.limit);
      }),

    addComment: protectedProcedure
      .input(z.object({
        articleId: z.number(),
        content: z.string().min(1).max(1000),
        parentId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const check = await db.checkSensitiveWords(input.content);
        if (check.level === "block") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "评论包含违规内容，已被拦截" });
        }
        await db.createComment({
          ...input,
          authorId: ctx.user.id,
          isFiltered: check.hasSensitive,
          filterReason: check.words.join(","),
        });
        return { success: true };
      }),

    deleteComment: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // 权限校验在db层处理
        const { getDb } = await import("./db");
        const dbConn = await getDb();
        if (!dbConn) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { comments: commentsTable } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        await dbConn.update(commentsTable).set({ status: "deleted" }).where(eq(commentsTable.id, input.id));
        return { success: true };
      }),

    // 点赞
    like: protectedProcedure
      .input(z.object({
        targetType: z.enum(["article", "comment", "report", "course"]),
        targetId: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.toggleLike(ctx.user.id, input.targetType, input.targetId);
      }),

    checkLiked: protectedProcedure
      .input(z.object({ targetType: z.string(), targetId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.checkLiked(ctx.user.id, input.targetType, input.targetId);
      }),

    // 关注
    follow: protectedProcedure
      .input(z.object({ followingId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.id === input.followingId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "不能关注自己" });
        }
        return db.toggleFollow(ctx.user.id, input.followingId);
      }),

    followStats: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return db.getFollowStats(input.userId);
      }),

    // 私信
    messages: protectedProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(20) }))
      .query(async ({ ctx, input }) => {
        return db.getMessages(ctx.user.id, input.page, input.limit);
      }),

    sendMessage: protectedProcedure
      .input(z.object({ receiverId: z.number(), content: z.string().min(1).max(2000) }))
      .mutation(async ({ ctx, input }) => {
        const check = await db.checkSensitiveWords(input.content);
        if (check.level === "block") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "私信包含违规内容" });
        }
        await db.sendMessage({
          senderId: ctx.user.id,
          receiverId: input.receiverId,
          content: input.content,
          isFiltered: check.hasSensitive,
          filterReason: check.words.join(","),
        });
        return { success: true };
      }),
  }),

  // ============================================================
  // 研报模块
  // ============================================================
  report: router({
    list: publicProcedure
      .input(z.object({
        page: z.number().default(1),
        limit: z.number().default(10),
        category: z.string().optional(),
        keyword: z.string().optional(),
        isPaid: z.boolean().optional(),
        status: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const status = input.status || "published";
        return db.getReports({ ...input, status });
      }),

    detail: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const report = await db.getReportById(input.id);
        if (!report || report.status !== "published") throw new TRPCError({ code: "NOT_FOUND" });
        // 增加浏览量
        const { getDb } = await import("./db");
        const dbConn = await getDb();
        if (dbConn) {
          const { reports: reportsTable } = await import("../drizzle/schema");
          const { eq } = await import("drizzle-orm");
          const { sql } = await import("drizzle-orm");
          await dbConn.update(reportsTable).set({ viewCount: sql`viewCount + 1` }).where(eq(reportsTable.id, input.id));
        }
        return report;
      }),

    create: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        summary: z.string().optional(),
        fileUrl: z.string(),
        fileKey: z.string(),
        fileType: z.enum(["pdf", "word"]).default("pdf"),
        fileSize: z.number().optional(),
        coverImage: z.string().optional(),
        institution: z.string().optional(),
        category: z.enum(["macro", "industry", "stock", "strategy", "fixed_income"]).default("macro"),
        tags: z.array(z.string()).optional(),
        isPaid: z.boolean().default(false),
        price: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createReport({
          ...input,
          tags: input.tags ? JSON.stringify(input.tags) : undefined,
          authorId: ctx.user.id,
          status: "published",
          publishedAt: new Date(),
        });
        return { success: true };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        summary: z.string().optional(),
        category: z.string().optional(),
        isPaid: z.boolean().optional(),
        price: z.string().optional(),
        status: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateReport(id, data as any);
        return { success: true };
      }),

    // 下载权限校验
    checkDownload: protectedProcedure
      .input(z.object({ reportId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const report = await db.getReportById(input.reportId);
        if (!report) throw new TRPCError({ code: "NOT_FOUND" });
        if (report.isPaid && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "该研报需要付费后才能下载" });
        }
        await db.recordReportDownload(ctx.user.id, input.reportId);
        return { success: true, fileUrl: report.fileUrl, title: report.title };
      }),

    // 收藏
    favorite: protectedProcedure
      .input(z.object({ reportId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.toggleReportFavorite(ctx.user.id, input.reportId);
      }),

    // 记录阅读时长
    recordReadTime: protectedProcedure
      .input(z.object({ reportId: z.number(), duration: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.recordReportReadLog(ctx.user.id, input.reportId, input.duration);
        return { success: true };
      }),
  }),

  // ============================================================
  // 课程模块
  // ============================================================
  course: router({
    list: publicProcedure
      .input(z.object({
        page: z.number().default(1),
        limit: z.number().default(10),
        category: z.string().optional(),
        keyword: z.string().optional(),
        status: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const status = input.status || "published";
        return db.getCourses({ ...input, status });
      }),

    detail: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const course = await db.getCourseById(input.id);
        if (!course || course.status !== "published") throw new TRPCError({ code: "NOT_FOUND" });
        const chapters = await db.getCourseChapters(input.id);
        return { ...course, chapters };
      }),

    create: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        coverImage: z.string().optional(),
        instructorId: z.number(),
        category: z.enum(["finance", "fund", "stock", "risk", "crypto", "forex"]).default("finance"),
        type: z.enum(["video", "graphic"]).default("video"),
        price: z.string().default("0.00"),
        originalPrice: z.string().optional(),
        isFree: z.boolean().default(false),
        hasExam: z.boolean().default(false),
        hasCertificate: z.boolean().default(false),
        refundPolicy: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createCourse({ ...input, status: "published", publishedAt: new Date() });
        return { success: true };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        price: z.string().optional(),
        status: z.string().optional(),
        category: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCourse(id, data as any);
        return { success: true };
      }),

    // 购买课程
    purchase: protectedProcedure
      .input(z.object({ courseId: z.number(), promoCode: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const course = await db.getCourseById(input.courseId);
        if (!course) throw new TRPCError({ code: "NOT_FOUND" });
        const alreadyPurchased = await db.checkCoursePurchased(ctx.user.id, input.courseId);
        if (alreadyPurchased) throw new TRPCError({ code: "BAD_REQUEST", message: "已购买该课程" });
        await db.purchaseCourse(ctx.user.id, input.courseId, course.price || "0.00", undefined, input.promoCode);
        return { success: true };
      }),

    // 检查购买状态
    checkPurchase: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ ctx, input }) => {
        const purchased = await db.checkCoursePurchased(ctx.user.id, input.courseId);
        return { purchased };
      }),

    // 保存学习进度
    saveProgress: protectedProcedure
      .input(z.object({
        courseId: z.number(),
        chapterId: z.number(),
        progress: z.number().min(0).max(100),
        watchedDuration: z.number().default(0),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.saveCourseProgress(ctx.user.id, input.courseId, input.chapterId, input.progress, input.watchedDuration);
        return { success: true };
      }),

    // 获取学习进度
    getProgress: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const { courseProgress } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");
        const dbConn = await getDb();
        if (!dbConn) return [];
        return dbConn.select().from(courseProgress).where(and(eq(courseProgress.userId, ctx.user.id), eq(courseProgress.courseId, input.courseId)));
      }),

    // 考试题目
    examQuestions: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ ctx, input }) => {
        const purchased = await db.checkCoursePurchased(ctx.user.id, input.courseId);
        const course = await db.getCourseById(input.courseId);
        if (!purchased && !course?.isFree) throw new TRPCError({ code: "FORBIDDEN", message: "请先购买课程" });
        const questions = await db.getExamQuestions(input.courseId);
        // 隐藏答案
        return questions.map(({ answer, ...q }) => q);
      }),

    // 提交考试
    submitExam: protectedProcedure
      .input(z.object({
        courseId: z.number(),
        answers: z.record(z.string(), z.array(z.string())),
        duration: z.number().default(0),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.submitExam(ctx.user.id, input.courseId, input.answers, input.duration);
        // 通过考试则颁发证书
        if (result.isPassed) {
          const course = await db.getCourseById(input.courseId);
          if (course?.hasCertificate) {
            await db.issueCertificate(ctx.user.id, input.courseId, result.examRecordId);
          }
        }
        return result;
      }),

    // 获取证书
    certificate: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const { certificates } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");
        const dbConn = await getDb();
        if (!dbConn) return null;
        const result = await dbConn.select().from(certificates).where(and(eq(certificates.userId, ctx.user.id), eq(certificates.courseId, input.courseId))).limit(1);
        return result[0] || null;
      }),

    // 课程评价
    reviews: publicProcedure
      .input(z.object({ courseId: z.number(), page: z.number().default(1) }))
      .query(async ({ input }) => {
        return db.getCourseReviews(input.courseId, input.page);
      }),

    submitReview: protectedProcedure
      .input(z.object({ courseId: z.number(), rating: z.number().min(1).max(5), content: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const purchased = await db.checkCoursePurchased(ctx.user.id, input.courseId);
        if (!purchased) throw new TRPCError({ code: "FORBIDDEN", message: "请先购买课程后再评价" });
        await db.submitCourseReview(ctx.user.id, input.courseId, input.rating, input.content);
        return { success: true };
      }),

    // 退款
    refund: protectedProcedure
      .input(z.object({ courseId: z.number(), reason: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        await db.refundCourse(ctx.user.id, input.courseId, input.reason);
        return { success: true };
      }),

    // 讲师列表
    instructors: publicProcedure
      .input(z.object({ page: z.number().default(1) }))
      .query(async ({ input }) => {
        return db.getInstructors(input.page);
      }),

    createInstructor: adminProcedure
      .input(z.object({
        userId: z.number(),
        realName: z.string(),
        title: z.string().optional(),
        organization: z.string().optional(),
        bio: z.string().optional(),
        expertise: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createInstructor({
          ...input,
          expertise: input.expertise ? JSON.stringify(input.expertise) : undefined,
        });
        return { success: true };
      }),

    chapters: publicProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ input }) => {
        return db.getCourseChapters(input.courseId);
      }),

    addChapter: adminProcedure
      .input(z.object({
        courseId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        videoUrl: z.string().optional(),
        content: z.string().optional(),
        duration: z.number().optional(),
        sortOrder: z.number().default(0),
        isFree: z.boolean().default(false),
      }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { courseChapters } = await import("../drizzle/schema");
        const dbConn = await getDb();
        if (!dbConn) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await dbConn.insert(courseChapters).values(input);
        return { success: true };
      }),
  }),

  // ============================================================
  // 渠道合作模块
  // ============================================================
  channel: router({
    // 申请入驻
    submitApplication: protectedProcedure
      .input(z.object({
        companyName: z.string().min(1),
        contactName: z.string().min(1),
        contactPhone: z.string().min(11),
        contactEmail: z.string().email(),
        channelType: z.enum(["broker", "bank", "media", "other"]).default("other"),
        businessLicense: z.string().optional(),
        description: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const existing = await db.getChannelByUserId(ctx.user.id);
        if (existing) throw new TRPCError({ code: "BAD_REQUEST", message: "您已提交过入驻申请" });
        await db.createChannel({ ...input, userId: ctx.user.id });
        return { success: true };
      }),

    // 我的渠道信息
    myChannel: protectedProcedure.query(async ({ ctx }) => {
      return db.getChannelByUserId(ctx.user.id);
    }),

    // 管理员审核
    review: adminProcedure
      .input(z.object({
        id: z.number(),
        action: z.enum(["approve", "reject"]),
        rejectReason: z.string().optional(),
        commissionRate: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const status = input.action === "approve" ? "approved" : "rejected";
        await db.updateChannel(input.id, {
          status,
          rejectReason: input.rejectReason,
          commissionRate: input.commissionRate,
          approvedAt: status === "approved" ? new Date() : undefined,
        });
        // 审批通过后更新用户角色为channel
        if (status === "approved") {
          const channel = await db.getChannelById(input.id);
          if (channel) await db.updateUserRole(channel.userId, "channel");
        }
        await db.createAuditLog({
          adminId: ctx.user.id,
          action: `channel_${input.action}`,
          targetType: "channel",
          targetId: input.id,
          remark: input.rejectReason,
        });
        return { success: true };
      }),

    // 生成推广链接
    createPromoLink: channelProcedure
      .input(z.object({
        targetType: z.enum(["course", "report", "platform"]).default("platform"),
        targetId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const channel = await db.getChannelByUserId(ctx.user.id);
        if (!channel || channel.status !== "approved") {
          throw new TRPCError({ code: "FORBIDDEN", message: "渠道未审核通过" });
        }
        return db.createPromoLink(channel.id, input.targetType, input.targetId);
      }),

    // 推广链接列表
    promoLinks: channelProcedure.query(async ({ ctx }) => {
      const channel = await db.getChannelByUserId(ctx.user.id);
      if (!channel) return [];
      return db.getPromoLinks(channel.id);
    }),

    // 结算记录
    settlements: channelProcedure
      .input(z.object({ page: z.number().default(1) }))
      .query(async ({ ctx, input }) => {
        const channel = await db.getChannelByUserId(ctx.user.id);
        if (!channel) return { data: [], total: 0 };
        return db.getChannelSettlements(channel.id, input.page);
      }),

    // 管理员获取所有渠道
    adminList: adminProcedure
      .input(z.object({ page: z.number().default(1), status: z.string().optional() }))
      .query(async ({ input }) => {
        return db.getChannels(input);
      }),

    // 配置分成比例
    setCommission: adminProcedure
      .input(z.object({ channelId: z.number(), commissionRate: z.string() }))
      .mutation(async ({ input }) => {
        await db.updateChannel(input.channelId, { commissionRate: input.commissionRate });
        return { success: true };
      }),
  }),

  // ============================================================
  // 管理员模块
  // ============================================================
  admin: router({
    // 仪表盘统计
    dashboard: adminProcedure.query(async () => {
      return db.getDashboardStats();
    }),

    // 用户管理
    users: adminProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return db.getAllUsers(input.page, input.limit);
      }),

    updateUserStatus: adminProcedure
      .input(z.object({ userId: z.number(), status: z.enum(["active", "banned", "pending"]) }))
      .mutation(async ({ input }) => {
        await db.updateUserStatus(input.userId, input.status);
        return { success: true };
      }),

    updateUserRole: adminProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["user", "admin", "channel"]) }))
      .mutation(async ({ input }) => {
        await db.updateUserRole(input.userId, input.role);
        return { success: true };
      }),

    // 审核日志
    auditLogs: adminProcedure
      .input(z.object({ page: z.number().default(1) }))
      .query(async ({ input }) => {
        return db.getAuditLogs(input.page);
      }),

    // 敏感词管理
    sensitiveWords: adminProcedure.query(async () => {
      return db.getSensitiveWords();
    }),

    addSensitiveWord: adminProcedure
      .input(z.object({
        word: z.string().min(1),
        category: z.enum(["finance", "political", "obscene", "fraud", "other"]).default("finance"),
        level: z.enum(["block", "review", "warn"]).default("block"),
      }))
      .mutation(async ({ input }) => {
        await db.addSensitiveWord(input.word, input.category, input.level);
        return { success: true };
      }),

    deleteSensitiveWord: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { sensitiveWords } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const dbConn = await getDb();
        if (!dbConn) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await dbConn.delete(sensitiveWords).where(eq(sensitiveWords.id, input.id));
        return { success: true };
      }),

    // 待审核文章
    pendingArticles: adminProcedure
      .input(z.object({ page: z.number().default(1) }))
      .query(async ({ input }) => {
        return db.getArticles({ page: input.page, status: "pending" });
      }),

    // 待审核渠道
    pendingChannels: adminProcedure
      .input(z.object({ page: z.number().default(1) }))
      .query(async ({ input }) => {
        return db.getChannels({ page: input.page, status: "pending" });
      }),

    // AI生成示例数据
    generateSampleData: adminProcedure
      .input(z.object({ type: z.enum(["articles", "reports", "courses"]), count: z.number().min(1).max(10).default(3) }))
      .mutation(async ({ ctx, input }) => {
        const prompts: Record<string, string> = {
          articles: `生成${input.count}篇金融资讯文章，以JSON数组格式返回，每篇包含：title(标题), summary(摘要100字), content(正文500字), tags(标签数组)。内容涵盖股市、基金、债券、宏观经济等主题。`,
          reports: `生成${input.count}份金融研报摘要，以JSON数组格式返回，每份包含：title(标题), summary(摘要200字), institution(机构名), category(macro/industry/stock之一)。`,
          courses: `生成${input.count}个金融课程信息，以JSON数组格式返回，每个包含：title(课程名), description(描述200字), category(finance/fund/stock/risk之一), price(价格字符串如"199.00")。`,
        };

        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是金融内容生成专家，请生成专业的金融内容，以合法合规为前提，不包含任何违规理财话术或虚假信息。" },
            { role: "user", content: prompts[input.type] },
          ],
          response_format: { type: "json_schema", json_schema: { name: "finance_data", strict: false, schema: { type: "object", properties: { data: { type: "array" } } } } },
        });

        const rawContent = response.choices[0]?.message?.content;
        const content = typeof rawContent === 'string' ? rawContent : JSON.stringify(rawContent);
        if (!content) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "AI生成失败" });

        let parsed: any;
        try {
          parsed = JSON.parse(content);
        } catch {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "AI返回格式错误" });
        }

        const items = parsed.data || parsed;
        if (!Array.isArray(items)) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "数据格式错误" });

        if (input.type === "articles") {
          for (const item of items) {
            await db.createArticle({
              title: item.title,
              summary: item.summary,
              content: item.content,
              tags: JSON.stringify(item.tags || []),
              authorId: ctx.user.id,
              status: "published",
              publishedAt: new Date(),
            });
          }
        } else if (input.type === "reports") {
          for (const item of items) {
            await db.createReport({
              title: item.title,
              summary: item.summary,
              institution: item.institution,
              category: item.category || "macro",
              fileUrl: "https://example.com/sample.pdf",
              fileKey: `sample-${Date.now()}.pdf`,
              fileType: "pdf",
              authorId: ctx.user.id,
              status: "published",
              publishedAt: new Date(),
            });
          }
        } else if (input.type === "courses") {
          // 需要先有讲师
          const instructorList = await db.getInstructors(1, 1);
          if (instructorList.data.length === 0) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "请先创建讲师" });
          }
          const instructorId = instructorList.data[0].id;
          for (const item of items) {
            await db.createCourse({
              title: item.title,
              description: item.description,
              category: item.category || "finance",
              price: item.price || "0.00",
              instructorId,
              status: "published",
              publishedAt: new Date(),
            });
          }
        }

        return { success: true, count: items.length };
      }),

    // 爬虫文章管理
    crawledArticles: adminProcedure
      .input(z.object({ page: z.number().default(1) }))
      .query(async ({ input }) => {
        return db.getCrawledArticles(input.page);
      }),

    importCrawledArticle: adminProcedure
      .input(z.object({ crawledId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const articleId = await db.importCrawledArticle(input.crawledId, ctx.user.id);
        return { success: true, articleId };
      }),

    // 爬虫触发（真实爬取新浪财经 + AI改写）
    crawlArticles: adminProcedure
      .input(z.object({ count: z.number().min(1).max(20).default(5) }).optional())
      .mutation(async ({ input }) => {
        const fetchCount = input?.count ?? 5;
        // Step 1: 爬取新浪财经文章列表
        const listResp = await fetch(
          `https://feed.mix.sina.com.cn/api/roll/get?pageid=153&lid=2509&k=&num=${fetchCount * 2}&page=1&r=${Math.random()}`,
          { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' } }
        );
        if (!listResp.ok) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "爬取列表失败" });
        const listData: any = await listResp.json();
        const rawArticles: any[] = (listData?.result?.data || []).slice(0, fetchCount);
        if (rawArticles.length === 0) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "未获取到文章" });

        const saved: string[] = [];
        for (const raw of rawArticles) {
          try {
            // Step 2: 爬取文章正文
            let originalContent = raw.intro || raw.summary || raw.title;
            if (raw.url) {
              try {
                const artResp = await fetch(raw.url, {
                  headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://finance.sina.com.cn/',
                  }
                });
                if (artResp.ok) {
                  const html = await artResp.text();
                  // 提取#artibody正文
                  const bodyMatch = html.match(/<div[^>]+id=["']artibody["'][^>]*>([\s\S]*?)<\/div>/i);
                  if (bodyMatch) {
                    const stripped = bodyMatch[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
                    if (stripped.length > 100) originalContent = stripped.slice(0, 2000);
                  }
                }
              } catch { /* 正文爬取失败则使用摘要 */ }
            }

            // Step 3: AI改写内容（调整用词句式，风格类似三分钟学财经）
            const rewriteResp = await invokeLLM({
              messages: [
                {
                  role: "system",
                  content: `你是一个金融内容改写专家。请将用户提供的金融资讯改写成「三分钟学财经」风格：
- 用词通俗易懂，避开专业术语堆砂
- 句式简洁，多用短句，每句不超过20字
- 开头用一句话抗住读者
- 内容分炳点阐述，每炳一个要点
- 结尾用一句话总结
- 不得包含违规理财话术或敏感金融词汇
- 长度控制在300-500字
- 返回格式JSON: {"title": "改写后标题", "content": "改写后正文", "summary": "摘要100字内"}`
                },
                {
                  role: "user",
                  content: `原始标题：${raw.title}\n\n原始内容：${originalContent}`
                }
              ],
              response_format: { type: "json_schema", json_schema: { name: "rewrite_result", strict: false, schema: { type: "object", properties: { title: { type: "string" }, content: { type: "string" }, summary: { type: "string" } }, required: ["title", "content", "summary"] } } }
            });

            const rawMsg = rewriteResp.choices[0]?.message?.content;
            const msgStr = typeof rawMsg === 'string' ? rawMsg : JSON.stringify(rawMsg);
            let rewritten: { title: string; content: string; summary: string };
            try {
              rewritten = JSON.parse(msgStr);
            } catch {
              rewritten = { title: raw.title, content: originalContent, summary: raw.intro || '' };
            }

            // Step 4: 保存到爬虫文章表
            await db.saveCrawledArticle({
              title: rewritten.title || raw.title,
              content: rewritten.content,
              summary: rewritten.summary,
              author: raw.media_name || "三分钟学财经",
              sourceUrl: raw.url || `https://finance.sina.com.cn/s/${raw.docid}`,
              originalTitle: raw.title,
              publishedAt: new Date(),
            });
            saved.push(rewritten.title || raw.title);
          } catch (err) {
            console.error('[Crawler] Failed to process article:', raw.title, err);
          }
        }

        return { success: true, count: saved.length, titles: saved };
      }),
  }),

  // ============================================================
  // AI深度学习模块
  // ============================================================
  ai: router({
    // 智能推荐（基于用户行为数据）
    recommend: protectedProcedure
      .input(z.object({
        type: z.enum(["article", "report", "course"]).default("article"),
        limit: z.number().default(6),
      }))
      .query(async ({ ctx, input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是金融平台的AI智能推荐引擎，基于用户行为数据进行个性化推荐。" },
            { role: "user", content: `用户ID: ${ctx.user.id}，用户名: ${ctx.user.name}。请为该用户推荐${input.limit}个${input.type === 'article' ? '金融资讯文章' : input.type === 'report' ? '金融研报' : '金融课程'}。返回JSON数组，每项包含: id(随机1-100), title(标题), reason(推荐理由), score(匹配度 0-100), tags(标签数组)` },
          ],
          response_format: { type: "json_schema", json_schema: { name: "recommendations", strict: false, schema: { type: "object", properties: { data: { type: "array" } } } } },
        });
        const raw = response.choices[0]?.message?.content;
        const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
        try {
          const parsed = JSON.parse(str);
          return { success: true, data: parsed.data || parsed };
        } catch {
          return { success: false, data: [] };
        }
      }),

    // 情感分析
    sentimentAnalysis: publicProcedure
      .input(z.object({ text: z.string().min(1).max(2000) }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是金融市场情感分析专家。对给定文本进行情感分析，返回情感倒向、强度和关键词。" },
            { role: "user", content: `分析以下金融文本的情感倒向：\n\n${input.text}\n\n返回JSON: {"sentiment": "positive/negative/neutral", "score": 0-100, "confidence": 0-100, "keywords": ["关键词"], "summary": "分析总结", "riskLevel": "low/medium/high"}` },
          ],
          response_format: { type: "json_schema", json_schema: { name: "sentiment_result", strict: false, schema: { type: "object", properties: { sentiment: { type: "string" }, score: { type: "number" }, confidence: { type: "number" }, keywords: { type: "array" }, summary: { type: "string" }, riskLevel: { type: "string" } }, required: ["sentiment", "score"] } } },
        });
        const raw = response.choices[0]?.message?.content;
        const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
        try { return JSON.parse(str); } catch { return { sentiment: "neutral", score: 50, confidence: 60, keywords: [], summary: "分析失败", riskLevel: "medium" }; }
      }),

    // 风险预测
    riskPrediction: protectedProcedure
      .input(z.object({
        assets: z.string().describe("资产组合描述"),
        investmentHorizon: z.enum(["short", "medium", "long"]).default("medium"),
        riskTolerance: z.enum(["conservative", "moderate", "aggressive"]).default("moderate"),
      }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是专业的金融风险分析师，基于用户资产组合和投资偏好进行风险评估。" },
            { role: "user", content: `资产组合: ${input.assets}\n投资期限: ${input.investmentHorizon}\n风险偏好: ${input.riskTolerance}\n\n请进行风险评估，返回JSON: {"riskLevel": "low/medium/high/very_high", "riskScore": 0-100, "volatilityEstimate": "预估波动幅", "maxDrawdown": "最大回撤预估", "suggestions": ["建议列表"], "assetAllocation": [{"asset": "资产名", "ratio": 0-100, "reason": "理由"}], "summary": "风险总结"}` },
          ],
          response_format: { type: "json_schema", json_schema: { name: "risk_prediction", strict: false, schema: { type: "object", properties: { riskLevel: { type: "string" }, riskScore: { type: "number" }, suggestions: { type: "array" }, summary: { type: "string" } }, required: ["riskLevel", "riskScore"] } } },
        });
        const raw = response.choices[0]?.message?.content;
        const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
        try { return JSON.parse(str); } catch { return { riskLevel: "medium", riskScore: 50, suggestions: [], summary: "分析失败" }; }
      }),

    // 用户画像分析
    userProfile: protectedProcedure.query(async ({ ctx }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "你是金融用户画像分析师，基于用户行为数据生成用户画像。" },
          { role: "user", content: `用户ID: ${ctx.user.id}，用户名: ${ctx.user.name}，注册时间: ${ctx.user.createdAt}\n请分析该用户的金融兴趣画像，返回JSON: {"investorType": "投资者类型", "riskProfile": "风险偏好", "interests": ["兴趣标签"], "activeLevel": "low/medium/high", "preferredContent": ["偏好内容类型"], "learningProgress": 0-100, "insights": ["用户洞察"], "nextSteps": ["建议行动"]}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "user_profile", strict: false, schema: { type: "object", properties: { investorType: { type: "string" }, riskProfile: { type: "string" }, interests: { type: "array" }, insights: { type: "array" } }, required: ["investorType"] } } },
      });
      const raw = response.choices[0]?.message?.content;
      const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
      try { return JSON.parse(str); } catch { return { investorType: "成长型投资者", riskProfile: "稳健型", interests: ["基金", "股票"], insights: [] }; }
    }),

    // 市场趋势分析
    marketTrend: publicProcedure
      .input(z.object({ topic: z.string().default("当前金融市场") }))
      .query(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是金融市场分析师，具备深度的宏观经测和行业研究能力。" },
            { role: "user", content: `分析当前「${input.topic}」的市场趋势，返回JSON: {"trend": "bullish/bearish/neutral", "confidence": 0-100, "hotTopics": ["热点话题"], "keyIndicators": [{"name": "指标名", "value": "当前值", "signal": "positive/negative/neutral"}], "riskFactors": ["风险因素"], "opportunities": ["机遇分析"], "summary": "趋势总结", "nextWeekOutlook": "下周展望"}` },
          ],
          response_format: { type: "json_schema", json_schema: { name: "market_trend", strict: false, schema: { type: "object", properties: { trend: { type: "string" }, confidence: { type: "number" }, hotTopics: { type: "array" }, summary: { type: "string" } }, required: ["trend"] } } },
        });
        const raw = response.choices[0]?.message?.content;
        const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
        try { return JSON.parse(str); } catch { return { trend: "neutral", confidence: 60, hotTopics: [], summary: "分析失败" }; }
      }),

    // 内容摘要生成
    generateSummary: publicProcedure
      .input(z.object({ content: z.string().min(2).max(5000), type: z.enum(["article", "report"]).default("article") }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是金融内容摘要专家，擅长提炼核心观点。" },
            { role: "user", content: `请为以下${input.type === 'report' ? '金融研报' : '金融资讯'}生成简明摘要：\n\n${input.content}\n\n返回JSON: {"summary": "摘要150字内", "keyPoints": ["要点列表"], "tags": ["标签"], "readTime": "预估阅读时间"}` },
          ],
          response_format: { type: "json_schema", json_schema: { name: "summary_result", strict: false, schema: { type: "object", properties: { summary: { type: "string" }, keyPoints: { type: "array" }, tags: { type: "array" }, readTime: { type: "string" } }, required: ["summary"] } } },
        });
        const raw = response.choices[0]?.message?.content;
        const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
        try { return JSON.parse(str); } catch { return { summary: "摘要生成失败", keyPoints: [], tags: [], readTime: "3分钟" }; }
      }),

    // 智能问答（金融知识库）
    askFinance: publicProcedure
      .input(z.object({ question: z.string().min(2).max(500) }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "你是一个专业的金融知识顾问，擅长用通俗易懂的语言解释复杂的金融概念。回答要准确、实用、简洁，不超过300字。" },
            { role: "user", content: input.question },
          ],
        });
        const raw = response.choices[0]?.message?.content;
        return { answer: typeof raw === 'string' ? raw : JSON.stringify(raw) };
      }),

    // 获取AI分析看板数据
    dashboard: publicProcedure.query(async () => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "你是金融数据分析师，生成市场分析看板数据。" },
          { role: "user", content: "生成当前金融市场分析看板数据，返回JSON: {\"marketSentiment\": \"bullish/bearish/neutral\", \"sentimentScore\": 0-100, \"hotSectors\": [{\"name\": \"行业名\", \"change\": \"+/-X.X%\", \"trend\": \"up/down\"}], \"riskWarnings\": [\"风险提示\"], \"opportunities\": [\"机遇\"], \"aiInsights\": [\"洞察\"], \"dataUpdatedAt\": \"ISO时间\"}" },
        ],
        response_format: { type: "json_schema", json_schema: { name: "ai_dashboard", strict: false, schema: { type: "object", properties: { marketSentiment: { type: "string" }, sentimentScore: { type: "number" }, hotSectors: { type: "array" }, riskWarnings: { type: "array" }, opportunities: { type: "array" }, aiInsights: { type: "array" } }, required: ["marketSentiment"] } } },
      });
      const raw = response.choices[0]?.message?.content;
      const str = typeof raw === 'string' ? raw : JSON.stringify(raw);
      try { return JSON.parse(str); } catch { return { marketSentiment: "neutral", sentimentScore: 50, hotSectors: [], riskWarnings: [], opportunities: [], aiInsights: [] }; }
    }),
  }),

  // ============================================================
  // 量化金融系统
  // ============================================================
  quant: quantRouter,

  // ============================================================
  // AI 金融助手
  // ============================================================
  aiAssistant: aiAssistantRouter,
});

export type AppRouter = typeof appRouter;
