import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import * as quantDb from "./quantDb";
import { fetchRealQuotesBatch, getYahooSymbol, getAllMarketStatuses, getMarketStatus, fetchRealQuote } from "../services/realMarketData";
import { getRefreshStatus, refreshAllMarketQuotes, getAvailabilityHistory } from "../services/scheduledRefresh";
import { generateMarketNews } from "../services/newsService";
import { getDb } from "../db";
import { marketQuotes } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { nanoid } from "nanoid";

// 管理员权限
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "需要管理员权限" });
  return next({ ctx });
});

export const quantRouter = router({
  // ============================================================
  // 交易账户管理
  // ============================================================
  account: router({
    list: protectedProcedure.query(({ ctx }) => quantDb.listTradingAccounts(ctx.user.id)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => quantDb.getTradingAccount(input.id)),
    create: protectedProcedure.input(z.object({
      accountName: z.string().min(1),
      broker: z.string().min(1),
      market: z.enum(["a_share", "us_stock", "hk_stock", "futures", "crypto", "forex", "global"]),
      accountType: z.enum(["live", "paper"]).default("paper"),
      balance: z.string().default("1000000.0000"),
      currency: z.string().default("CNY"),
    })).mutation(async ({ ctx, input }) => {
      const id = await quantDb.createTradingAccount({ ...input, userId: ctx.user.id });
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "account_change", targetType: "trading_account", targetId: id,
        detail: JSON.stringify({ action: "create", ...input }),
      });
      return { id };
    }),
  }),

  // ============================================================
  // 全球行情数据
  // ============================================================
  market: router({
    quotes: publicProcedure.input(z.object({
      market: z.string().optional(),
      search: z.string().optional(),
      limit: z.number().optional(),
    }).optional()).query(({ input }) => quantDb.listMarketQuotes(input?.market, input?.search, input?.limit)),

    kline: publicProcedure.input(z.object({
      symbol: z.string(),
      market: z.string(),
      period: z.string().default("1d"),
      limit: z.number().optional(),
    })).query(({ input }) => quantDb.getKlineData(input.symbol, input.market, input.period, input.limit)),

    // 实时行情模拟 tick（每次调用随机波动所有行情价格）
    tick: publicProcedure.mutation(() => quantDb.simulateRealtimeQuotes()),

    // 获取所有市场交易状态
    marketStatus: publicProcedure.query(() => getAllMarketStatuses()),

    // 获取单个市场状态
    singleMarketStatus: publicProcedure.input(z.object({ market: z.string() })).query(({ input }) => getMarketStatus(input.market)),

    // 获取定时刷新状态
    refreshStatus: publicProcedure.query(() => getRefreshStatus()),

    // 24小时可用性历史记录
    availabilityHistory: publicProcedure.query(() => getAvailabilityHistory()),

    // 系统健康状态（含退避信息、数据新鲜度）
    systemHealth: publicProcedure.query(async () => {
      const refresh = getRefreshStatus();
      const db = await getDb();
      let totalQuotes = 0;
      let freshQuotes = 0; // 1小时内更新的
      let staleQuotes = 0; // 超过1小时未更新
      if (db) {
        const allQ = await db.select({ symbol: marketQuotes.symbol }).from(marketQuotes);
        totalQuotes = allQ.length;
        // 简单估算：如果最近一次刷新成功更新了数据，则认为数据新鲜
        if (refresh.lastResult && refresh.lastResult.updated > 0) {
          freshQuotes = refresh.lastResult.updated;
          staleQuotes = totalQuotes - freshQuotes;
        } else {
          staleQuotes = totalQuotes;
        }
      }
      const now = new Date();
      const lastRefresh = refresh.lastRefreshTime ? new Date(refresh.lastRefreshTime) : null;
      const minutesSinceRefresh = lastRefresh ? Math.round((now.getTime() - lastRefresh.getTime()) / 60000) : null;
      let dataFreshness: 'fresh' | 'stale' | 'outdated' | 'unknown' = 'unknown';
      if (minutesSinceRefresh === null) dataFreshness = 'unknown';
      else if (minutesSinceRefresh <= 10) dataFreshness = 'fresh';
      else if (minutesSinceRefresh <= 30) dataFreshness = 'stale';
      else dataFreshness = 'outdated';
      return {
        status: refresh.backoff.quotaExhausted ? 'degraded' : (dataFreshness === 'outdated' ? 'warning' : 'healthy'),
        dataFreshness,
        minutesSinceRefresh,
        totalQuotes,
        freshQuotes,
        staleQuotes,
        isRefreshing: refresh.isRefreshing,
        backoff: refresh.backoff,
        lastRefreshTime: refresh.lastRefreshTime,
        lastResult: refresh.lastResult,
      };
    }),

    // 手动触发全量刷新
    manualRefresh: adminProcedure.mutation(async () => {
      const result = await refreshAllMarketQuotes();
      return result;
    }),

    // 刷新真实行情数据（从 Yahoo Finance 获取并更新数据库）
    refreshRealData: publicProcedure.input(z.object({
      market: z.string().optional(),
    }).optional()).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

      // 获取需要刷新的品种
      const allQuotes = await quantDb.listMarketQuotes(input?.market, undefined, 300);
      const items = allQuotes
        .filter(q => getYahooSymbol(q.symbol, q.market) !== null)
        .map(q => ({ dbSymbol: q.symbol, market: q.market }));

      if (items.length === 0) return { updated: 0, message: "没有可刷新的品种" };

      const realData = await fetchRealQuotesBatch(items);
      let updated = 0;

      for (const [key, data] of Array.from(realData.entries())) {
        const [symbol, market] = key.split("|");
        try {
          await db.update(marketQuotes).set({
            lastPrice: data.lastPrice.toFixed(4),
            openPrice: data.openPrice.toFixed(4),
            highPrice: data.highPrice.toFixed(4),
            lowPrice: data.lowPrice.toFixed(4),
            prevClose: data.prevClose.toFixed(4),
            change: data.changeVal.toFixed(4),
            changePercent: data.changePercent.toFixed(2),
            volume: data.volume,
            turnover: data.turnover.toFixed(4),
          }).where(
            and(eq(marketQuotes.symbol, symbol), eq(marketQuotes.market, market as any))
          );
          updated++;
        } catch (e) {
          console.error(`[RefreshRealData] Failed to update ${symbol}:`, e);
        }
      }

      return { updated, total: items.length, message: `成功刷新 ${updated}/${items.length} 条行情数据` };
    }),

    // 获取单个品种的真实行情（实时从 Yahoo Finance 获取）
    realQuote: publicProcedure.input(z.object({
      symbol: z.string(),
      market: z.string(),
    })).query(async ({ input }) => {
      const yahooSymbol = getYahooSymbol(input.symbol, input.market);
      if (!yahooSymbol) return null;
      return fetchRealQuote(yahooSymbol);
    }),

    // AI生成模拟行情数据（覆盖A股/美股/港股/全球）
    generateQuotes: adminProcedure.mutation(async () => {
      const markets = [
        { market: "a_share", exchange: "SSE", stocks: [
          { symbol: "600519", name: "贵州茅台", sector: "白酒", base: 1680 },
          { symbol: "601318", name: "中国平安", sector: "保险", base: 45 },
          { symbol: "600036", name: "招商银行", sector: "银行", base: 32 },
          { symbol: "000858", name: "五粮液", sector: "白酒", base: 145 },
          { symbol: "002594", name: "比亚迪", sector: "新能源汽车", base: 230 },
          { symbol: "600900", name: "长江电力", sector: "电力", base: 28 },
          { symbol: "601012", name: "隆基绿能", sector: "光伏", base: 22 },
          { symbol: "000001", name: "平安银行", sector: "银行", base: 11 },
          { symbol: "600276", name: "恒瑞医药", sector: "医药", base: 42 },
          { symbol: "002475", name: "立讯精密", sector: "电子", base: 32 },
        ]},
        { market: "us_stock", exchange: "NASDAQ", stocks: [
          { symbol: "AAPL", name: "苹果公司", sector: "科技", base: 178 },
          { symbol: "MSFT", name: "微软", sector: "科技", base: 415 },
          { symbol: "GOOGL", name: "谷歌", sector: "科技", base: 155 },
          { symbol: "AMZN", name: "亚马逊", sector: "电商", base: 185 },
          { symbol: "NVDA", name: "英伟达", sector: "芯片", base: 875 },
          { symbol: "TSLA", name: "特斯拉", sector: "新能源汽车", base: 245 },
          { symbol: "META", name: "Meta", sector: "社交", base: 505 },
          { symbol: "BRK.B", name: "伯克希尔B", sector: "金融", base: 410 },
        ]},
        { market: "hk_stock", exchange: "HKEX", stocks: [
          { symbol: "00700", name: "腾讯控股", sector: "科技", base: 320 },
          { symbol: "09988", name: "阿里巴巴-W", sector: "电商", base: 78 },
          { symbol: "03690", name: "美团-W", sector: "互联网", base: 115 },
          { symbol: "01810", name: "小米集团-W", sector: "科技", base: 18 },
          { symbol: "09618", name: "京东集团-SW", sector: "电商", base: 105 },
          { symbol: "00005", name: "汇丰控股", sector: "银行", base: 62 },
        ]},
        { market: "index", exchange: "GLOBAL", stocks: [
          { symbol: "000001.SH", name: "上证指数", sector: "指数", base: 3150 },
          { symbol: "399001.SZ", name: "深证成指", sector: "指数", base: 10200 },
          { symbol: "399006.SZ", name: "创业板指", sector: "指数", base: 2050 },
          { symbol: "DJI", name: "道琼斯指数", sector: "指数", base: 39200 },
          { symbol: "SPX", name: "标普500", sector: "指数", base: 5200 },
          { symbol: "IXIC", name: "纳斯达克", sector: "指数", base: 16400 },
          { symbol: "HSI", name: "恒生指数", sector: "指数", base: 17500 },
        ]},
      ];

      let count = 0;
      for (const m of markets) {
        for (const s of m.stocks) {
          const change = (Math.random() - 0.48) * s.base * 0.06;
          const lastPrice = +(s.base + change).toFixed(4);
          const prevClose = +s.base.toFixed(4);
          const changePercent = +((change / s.base) * 100).toFixed(4);
          await quantDb.upsertMarketQuote({
            symbol: s.symbol, name: s.name, market: m.market as any, exchange: m.exchange,
            lastPrice: lastPrice.toString(), prevClose: prevClose.toString(),
            openPrice: (+(s.base + (Math.random() - 0.5) * s.base * 0.02).toFixed(4)).toString(),
            highPrice: (+(lastPrice * (1 + Math.random() * 0.02)).toFixed(4)).toString(),
            lowPrice: (+(lastPrice * (1 - Math.random() * 0.02)).toFixed(4)).toString(),
            change: change.toFixed(4), changePercent: changePercent.toString(),
            volume: Math.floor(Math.random() * 50000000),
            turnover: (Math.random() * 5000000000).toFixed(4),
            sector: s.sector,
            listingType: "secondary",
          });
          count++;
        }
      }
      return { count, message: `成功生成${count}条行情数据` };
    }),

    // AI生成IPO数据
    generateIPOs: adminProcedure.mutation(async () => {
      const ipos = [
        { symbol: "688XXX", companyName: "芯联集成电路", market: "a_share", exchange: "SSE", ipoPrice: "15.80", ipoShares: 200000000, totalRaised: "3160000000", ipoDate: "2026-04-15", status: "upcoming" as const, industry: "半导体", underwriter: "中金公司", description: "国内领先的模拟芯片设计企业" },
        { symbol: "AIXX", companyName: "DeepAI Technologies", market: "us_stock", exchange: "NASDAQ", ipoPrice: "22.00", ipoShares: 50000000, totalRaised: "1100000000", ipoDate: "2026-04-20", status: "upcoming" as const, industry: "人工智能", underwriter: "Goldman Sachs", description: "AI大模型基础设施提供商" },
        { symbol: "02XXX", companyName: "智驾科技", market: "hk_stock", exchange: "HKEX", ipoPrice: "38.50", ipoShares: 100000000, totalRaised: "3850000000", ipoDate: "2026-04-10", status: "open" as const, industry: "自动驾驶", underwriter: "摩根士丹利", description: "L4级自动驾驶解决方案提供商" },
        { symbol: "688YYY", companyName: "量子通信科技", market: "a_share", exchange: "SSE", ipoPrice: "42.60", ipoShares: 80000000, totalRaised: "3408000000", ipoDate: "2026-03-28", status: "listed" as const, industry: "量子通信", underwriter: "中信证券", description: "量子密钥分发设备及解决方案" },
        { symbol: "EVXX", companyName: "GreenPower Motors", market: "us_stock", exchange: "NYSE", ipoPrice: "18.50", ipoShares: 30000000, totalRaised: "555000000", ipoDate: "2026-05-01", status: "upcoming" as const, industry: "新能源", underwriter: "JP Morgan", description: "固态电池技术领先企业" },
      ];
      let count = 0;
      for (const ipo of ipos) {
        await quantDb.createIPO(ipo);
        count++;
      }
      return { count, message: `成功生成${count}条IPO数据` };
    }),
  }),

  // ============================================================
  // 市场快讯
  // ============================================================
  news: router({
    latest: publicProcedure.query(() => generateMarketNews()),
  }),

  // ============================================================
  // 自选股管理
  // ============================================================
  watchlist: router({
    // 获取自选股列表（带行情数据）
    list: protectedProcedure.query(({ ctx }) => quantDb.getWatchlistWithQuotes(ctx.user.id)),

    // 添加自选股
    add: protectedProcedure.input(z.object({
      symbol: z.string().min(1),
      name: z.string().optional(),
      market: z.string().min(1),
      note: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      const result = await quantDb.addToWatchlist({
        userId: ctx.user.id,
        symbol: input.symbol,
        name: input.name,
        market: input.market,
        note: input.note,
      });
      if (result.exists) {
        return { success: true, message: "该品种已在自选列表中", id: result.id };
      }
      return { success: true, message: "已添加到自选", id: result.id };
    }),

    // 删除自选股（按ID）
    remove: protectedProcedure.input(z.object({
      id: z.number(),
    })).mutation(async ({ ctx, input }) => {
      await quantDb.removeFromWatchlist(ctx.user.id, input.id);
      return { success: true, message: "已从自选中移除" };
    }),

    // 删除自选股（按 symbol + market）
    removeBySymbol: protectedProcedure.input(z.object({
      symbol: z.string(),
      market: z.string(),
    })).mutation(async ({ ctx, input }) => {
      await quantDb.removeFromWatchlistBySymbol(ctx.user.id, input.symbol, input.market);
      return { success: true, message: "已从自选中移除" };
    }),

    // 检查是否在自选中
    check: protectedProcedure.input(z.object({
      symbol: z.string(),
      market: z.string(),
    })).query(async ({ ctx, input }) => {
      const list = await quantDb.listWatchlist(ctx.user.id);
      const found = list.find(item => item.symbol === input.symbol && item.market === input.market);
      return { inWatchlist: !!found, id: found?.id || null };
    }),

    // 自选组合收益统计
    portfolioStats: protectedProcedure.query(({ ctx }) => quantDb.getWatchlistPortfolioStats(ctx.user.id)),
  }),

  // ============================================================
  // 大盘指数
  // ============================================================
  indices: router({
    // 获取核心大盘指数
    main: publicProcedure.query(() => quantDb.getMainIndices()),
    // 指数分时数据
    intraday: publicProcedure.input(z.object({
      symbol: z.string(),
    })).query(({ input }) => quantDb.getIndexIntradayData(input.symbol)),
  }),

  // ============================================================
  // 价格预警
  // ============================================================
  priceAlert: router({
    list: protectedProcedure.query(({ ctx }) => quantDb.listPriceAlerts(ctx.user.id)),
    create: protectedProcedure.input(z.object({
      symbol: z.string().min(1),
      name: z.string().optional(),
      market: z.string().min(1),
      alertType: z.enum(["change_percent_above", "change_percent_below", "price_above", "price_below"]),
      threshold: z.string().min(1),
      cooldownMinutes: z.number().optional(),
    })).mutation(async ({ ctx, input }) => {
      const id = await quantDb.createPriceAlert({ ...input, userId: ctx.user.id });
      return { id, success: true, message: "预警已创建" };
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      isEnabled: z.boolean().optional(),
      threshold: z.string().optional(),
      cooldownMinutes: z.number().optional(),
    })).mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await quantDb.updatePriceAlert(id, ctx.user.id, data);
      return { success: true };
    }),
    delete: protectedProcedure.input(z.object({
      id: z.number(),
    })).mutation(async ({ ctx, input }) => {
      await quantDb.deletePriceAlert(input.id, ctx.user.id);
      return { success: true, message: "预警已删除" };
    }),
  }),

  // ============================================================
  // 板块热力图
  // ============================================================
  sectorHeatmap: router({
    data: publicProcedure.query(() => quantDb.getSectorHeatmap()),
  }),

  // ============================================================
  // 策略管理
  // ============================================================
  strategy: router({
    list: protectedProcedure.input(z.object({
      isPublic: z.boolean().optional(),
      status: z.string().optional(),
    }).optional()).query(({ ctx, input }) => quantDb.listStrategies(ctx.user.id, input?.isPublic, input?.status)),

    publicList: publicProcedure.query(() => quantDb.listStrategies(undefined, true, undefined)),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => quantDb.getStrategy(input.id)),

    create: protectedProcedure.input(z.object({
      name: z.string().min(1),
      description: z.string().optional(),
      strategyType: z.enum(["trend", "mean_reversion", "arbitrage", "momentum", "value", "ml_based", "hft", "custom"]),
      applicableMarkets: z.string().optional(),
      code: z.string().optional(),
      parameters: z.string().optional(),
      riskLevel: z.enum(["conservative", "moderate", "aggressive"]).optional(),
    })).mutation(async ({ ctx, input }) => {
      const id = await quantDb.createStrategy({ ...input, userId: ctx.user.id });
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "strategy_modify", targetType: "strategy", targetId: id,
        detail: JSON.stringify({ action: "create", name: input.name }),
      });
      return { id };
    }),

    updateStatus: protectedProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["draft", "backtesting", "paper_trading", "live", "paused", "stopped", "archived"]),
    })).mutation(async ({ ctx, input }) => {
      await quantDb.updateStrategy(input.id, { status: input.status });
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "strategy_modify", targetType: "strategy", targetId: input.id,
        detail: JSON.stringify({ action: "status_change", newStatus: input.status }),
      });
      return { success: true };
    }),

    // AI生成策略代码
    aiGenerate: protectedProcedure.input(z.object({
      description: z.string().min(1),
      strategyType: z.string(),
      market: z.string(),
    })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "你是量化策略开发专家。根据用户描述生成完整的量化交易策略，包括策略逻辑、入场条件、出场条件、止损止盈规则、仓位管理。用中文回复，格式化为Markdown。" },
          { role: "user", content: `生成一个${input.strategyType}类型的量化策略，适用于${input.market}市场。策略描述：${input.description}。请包含：1.策略概述 2.核心逻辑 3.入场信号 4.出场信号 5.止损止盈 6.仓位管理 7.风险控制 8.伪代码实现` },
        ],
      });
      return { code: response.choices[0]?.message?.content || "" };
    }),
  }),

  // ============================================================
  // 交易执行（含风控检查）
  // ============================================================
  order: router({
    list: protectedProcedure.input(z.object({
      accountId: z.number().optional(),
      status: z.string().optional(),
      market: z.string().optional(),
      limit: z.number().optional(),
    }).optional()).query(({ ctx, input }) => quantDb.listOrders(ctx.user.id, input)),

    // 下单（含风控前置检查）
    submit: protectedProcedure.input(z.object({
      accountId: z.number(),
      strategyId: z.number().optional(),
      symbol: z.string(),
      market: z.string(),
      orderType: z.enum(["market", "limit", "stop", "stop_limit"]),
      side: z.enum(["buy", "sell"]),
      price: z.string().optional(),
      quantity: z.string(),
    })).mutation(async ({ ctx, input }) => {
      // 1. 幂等ID生成
      const idempotentId = `${ctx.user.id}-${input.symbol}-${Date.now()}-${nanoid(8)}`;

      // 2. 风控前置检查（独立、不可绕过）
      const rules = await quantDb.listRiskRules(input.market);
      const riskResults: { passed: boolean; details: string[] } = { passed: true, details: [] };

      for (const rule of rules) {
        if (!rule.isEnabled) continue;
        const threshold = rule.thresholdValue ? parseFloat(rule.thresholdValue) : 0;
        const orderAmount = parseFloat(input.quantity) * (input.price ? parseFloat(input.price) : 0);

        switch (rule.ruleType) {
          case "max_order_amount":
            if (orderAmount > threshold) {
              riskResults.details.push(`[${rule.name}] 订单金额${orderAmount}超过阈值${threshold}`);
              if (rule.action === "block" && rule.isMandatory) riskResults.passed = false;
            }
            break;
          case "frequency_limit":
            // 检查最近1分钟下单频率
            const recentOrders = await quantDb.listOrders(ctx.user.id, { limit: 10 });
            const recentCount = recentOrders.filter(o => {
              const diff = Date.now() - new Date(o.createdAt).getTime();
              return diff < 60000;
            }).length;
            if (recentCount >= threshold) {
              riskResults.details.push(`[${rule.name}] 1分钟内下单${recentCount}次超过限制${threshold}`);
              if (rule.action === "block") riskResults.passed = false;
            }
            break;
          case "large_order_alert":
            if (orderAmount > threshold) {
              riskResults.details.push(`[${rule.name}] 大额订单预警: ${orderAmount}`);
              // 仅告警，不拦截
            }
            break;
        }
      }

      // 3. 风控不通过则拦截
      if (!riskResults.passed) {
        await quantDb.createRiskLog({
          userId: ctx.user.id, triggerType: "blocked",
          triggerDetail: JSON.stringify(riskResults.details),
          market: input.market, symbol: input.symbol,
          orderAmount: (parseFloat(input.quantity) * (input.price ? parseFloat(input.price) : 0)).toString(),
          riskScore: 90,
        });
        throw new TRPCError({ code: "FORBIDDEN", message: `风控拦截: ${riskResults.details.join("; ")}` });
      }

      // 4. 创建订单
      const orderId = await quantDb.createOrder({
        idempotentId, userId: ctx.user.id, accountId: input.accountId,
        strategyId: input.strategyId, symbol: input.symbol, market: input.market,
        orderType: input.orderType, side: input.side, price: input.price,
        quantity: input.quantity, riskCheckPassed: true,
        riskCheckDetail: JSON.stringify(riskResults.details),
      });

      // 5. 模拟成交（实际应对接券商API）
      const fillPrice = input.price || "0";
      const slippage = (parseFloat(fillPrice) * 0.001).toFixed(4); // 模拟0.1%滑点
      const commission = (parseFloat(input.quantity) * parseFloat(fillPrice) * 0.0003).toFixed(4); // 万三手续费
      const stampDuty = input.side === "sell" ? (parseFloat(input.quantity) * parseFloat(fillPrice) * 0.001).toFixed(4) : "0.0000"; // 卖出印花税千一

      await quantDb.updateOrder(orderId, {
        orderStatus: "filled", filledQuantity: input.quantity,
        filledPrice: fillPrice, slippage, commission, stampDuty,
        submittedAt: new Date(), filledAt: new Date(),
      });

      // 6. 更新持仓
      await quantDb.upsertPosition({
        userId: ctx.user.id, accountId: input.accountId,
        symbol: input.symbol, market: input.market,
        side: input.side === "buy" ? "long" : "short",
        quantity: input.quantity, avgCost: fillPrice,
      });

      // 7. 合规留痕
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "order_submit", targetType: "order", targetId: orderId,
        detail: JSON.stringify({ ...input, idempotentId, fillPrice, commission, stampDuty }),
        isCompliant: true,
      });

      return { orderId, idempotentId, status: "filled", fillPrice, commission, slippage, stampDuty };
    }),

    // 撤单
    cancel: protectedProcedure.input(z.object({ orderId: z.number() })).mutation(async ({ ctx, input }) => {
      await quantDb.updateOrder(input.orderId, { orderStatus: "cancelled", cancelledAt: new Date() });
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "order_cancel", targetType: "order", targetId: input.orderId,
        detail: JSON.stringify({ orderId: input.orderId }),
      });
      return { success: true };
    }),
  }),

  // ============================================================
  // 持仓管理
  // ============================================================
  position: router({
    list: protectedProcedure.input(z.object({
      accountId: z.number().optional(),
    }).optional()).query(({ ctx, input }) => quantDb.listPositions(ctx.user.id, input?.accountId)),
  }),

  // ============================================================
  // 风控引擎（独立模块，不可绕过）
  // ============================================================
  risk: router({
    rules: protectedProcedure.input(z.object({ market: z.string().optional() }).optional())
      .query(({ input }) => quantDb.listRiskRules(input?.market)),

    createRule: adminProcedure.input(z.object({
      name: z.string().min(1),
      description: z.string().optional(),
      ruleType: z.string(),
      market: z.string().optional(),
      thresholdValue: z.string().optional(),
      thresholdConfig: z.string().optional(),
      action: z.enum(["block", "alert", "review"]).optional(),
      priority: z.number().optional(),
      isMandatory: z.boolean().optional(),
    })).mutation(async ({ ctx, input }) => {
      const id = await quantDb.createRiskRule({ ...input, createdBy: ctx.user.id } as any);
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "risk_rule_change", targetType: "risk_rule", targetId: id,
        detail: JSON.stringify({ action: "create", ...input }),
      });
      return { id };
    }),

    updateRule: adminProcedure.input(z.object({
      id: z.number(),
      isEnabled: z.boolean().optional(),
      thresholdValue: z.string().optional(),
      action: z.enum(["block", "alert", "review"]).optional(),
    })).mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await quantDb.updateRiskRule(id, data);
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "risk_rule_change", targetType: "risk_rule", targetId: id,
        detail: JSON.stringify({ action: "update", ...data }),
      });
      return { success: true };
    }),

    logs: protectedProcedure.input(z.object({
      market: z.string().optional(),
      limit: z.number().optional(),
    }).optional()).query(({ ctx, input }) => quantDb.listRiskLogs({ userId: ctx.user.id, ...input })),

    // 一键紧急停止（一键断网+清仓+暂停所有策略）
    emergencyStop: protectedProcedure.mutation(async ({ ctx }) => {
      // 暂停所有运行中的策略
      const strategies = await quantDb.listStrategies(ctx.user.id, undefined, "live");
      for (const s of strategies) {
        await quantDb.updateStrategy(s.id, { status: "paused" });
      }
      // 记录风控日志
      await quantDb.createRiskLog({
        userId: ctx.user.id, triggerType: "emergency_stop",
        triggerDetail: JSON.stringify({ stoppedStrategies: strategies.length }),
        riskScore: 100,
      });
      // 合规留痕
      await quantDb.createComplianceLog({
        userId: ctx.user.id, operatorName: ctx.user.name || "unknown",
        actionType: "emergency_stop",
        detail: JSON.stringify({ stoppedStrategies: strategies.length, timestamp: new Date().toISOString() }),
      });
      return { success: true, stoppedStrategies: strategies.length };
    }),
  }),

  // ============================================================
  // 回测系统
  // ============================================================
  backtest: router({
    list: protectedProcedure.input(z.object({
      strategyId: z.number().optional(),
    }).optional()).query(({ ctx, input }) => quantDb.listBacktests(ctx.user.id, input?.strategyId)),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => quantDb.getBacktest(input.id)),

    trades: protectedProcedure.input(z.object({ backtestId: z.number() })).query(({ input }) => quantDb.listBacktestTrades(input.backtestId)),

    // 执行回测（AI模拟）
    run: protectedProcedure.input(z.object({
      strategyId: z.number(),
      name: z.string(),
      market: z.string(),
      symbols: z.string().optional(),
      startDate: z.string(),
      endDate: z.string(),
      initialCapital: z.string().default("1000000"),
      slippageValue: z.string().optional(),
      commissionRate: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      const backtestId = await quantDb.createBacktest({
        userId: ctx.user.id, ...input,
      });

      // 使用AI生成回测结果（模拟真实回测引擎）
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "你是量化回测引擎。根据策略参数生成合理的回测结果数据。必须包含滑点和手续费的影响。返回JSON格式。" },
          { role: "user", content: `回测参数: 市场=${input.market}, 标的=${input.symbols || "全市场"}, 时间=${input.startDate}至${input.endDate}, 初始资金=${input.initialCapital}, 滑点=${input.slippageValue || "0.001"}, 手续费率=${input.commissionRate || "0.0003"}。生成回测结果JSON: {"finalCapital":"数字","totalReturn":"百分比","annualReturn":"百分比","maxDrawdown":"百分比","sharpeRatio":"数字","winRate":"百分比","totalTrades":数字,"winTrades":数字,"lossTrades":数字,"avgWin":"百分比","avgLoss":"百分比","equityCurve":[{"date":"YYYY-MM-DD","value":数字}],"monthlyReturns":[{"month":"YYYY-MM","return":"百分比"}]}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "backtest_result", strict: false, schema: { type: "object", properties: { finalCapital: { type: "string" }, totalReturn: { type: "string" }, annualReturn: { type: "string" }, maxDrawdown: { type: "string" }, sharpeRatio: { type: "string" }, winRate: { type: "string" }, totalTrades: { type: "number" }, winTrades: { type: "number" }, lossTrades: { type: "number" } }, required: ["finalCapital", "totalReturn"] } } },
      });

      let result: any = {};
      try {
        const raw = response.choices[0]?.message?.content;
        result = JSON.parse(typeof raw === "string" ? raw : JSON.stringify(raw));
      } catch { result = { finalCapital: input.initialCapital, totalReturn: "0", totalTrades: 0 }; }

      await quantDb.updateBacktest(backtestId, {
        status: "completed",
        finalCapital: result.finalCapital,
        totalReturn: result.totalReturn,
        annualReturn: result.annualReturn,
        maxDrawdown: result.maxDrawdown,
        sharpeRatio: result.sharpeRatio,
        winRate: result.winRate,
        totalTrades: result.totalTrades || 0,
        winTrades: result.winTrades || 0,
        lossTrades: result.lossTrades || 0,
        avgWin: result.avgWin,
        avgLoss: result.avgLoss,
        equityCurve: JSON.stringify(result.equityCurve || []),
        monthlyReturns: JSON.stringify(result.monthlyReturns || []),
        completedAt: new Date(),
      });

      return { backtestId, ...result };
    }),
  }),

  // ============================================================
  // 合规审计
  // ============================================================
  compliance: router({
    logs: protectedProcedure.input(z.object({
      actionType: z.string().optional(),
      limit: z.number().optional(),
    }).optional()).query(({ ctx, input }) => {
      if (ctx.user.role === "admin") return quantDb.listComplianceAudit(input);
      return quantDb.listComplianceAudit({ ...input, userId: ctx.user.id });
    }),
  }),

  // ============================================================
  // 监控告警
  // ============================================================
  monitor: router({
    alerts: protectedProcedure.input(z.object({
      severity: z.string().optional(),
      isResolved: z.boolean().optional(),
      limit: z.number().optional(),
    }).optional()).query(({ input }) => quantDb.listAlerts(input)),

    resolveAlert: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      await quantDb.resolveAlert(input.id, ctx.user.id);
      return { success: true };
    }),

    // 系统健康检查
    health: publicProcedure.query(async () => {
      return {
        status: "healthy",
        services: {
          database: "running",
          tradingEngine: "running",
          riskEngine: "running",
          marketData: "running",
          backtestEngine: "idle",
        },
        uptime: process.uptime(),
        memoryUsage: process.memoryUsage(),
        timestamp: new Date().toISOString(),
      };
    }),
  }),

  // ============================================================
  // IPO/一级市场
  // ============================================================
  ipo: router({
    list: publicProcedure.input(z.object({
      status: z.string().optional(),
      market: z.string().optional(),
    }).optional()).query(({ input }) => quantDb.listIPOs(input?.status, input?.market)),
  }),

  // ============================================================
  // 量化统计看板
  // ============================================================
  stats: protectedProcedure.query(({ ctx }) => quantDb.getQuantStats(ctx.user.id)),

  adminStats: adminProcedure.query(() => quantDb.getQuantStats()),

  // ============================================================
  // AI量化分析
  // ============================================================
  aiAnalysis: router({
    // 市场趋势预测
    marketTrend: publicProcedure.input(z.object({ market: z.string(), symbol: z.string().optional() })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "你是资深量化分析师，基于市场数据提供专业的趋势分析。注意：这仅为AI分析参考，不构成投资建议。" },
          { role: "user", content: `分析${input.market}市场${input.symbol ? `中${input.symbol}标的` : ""}的当前趋势，返回JSON: {"trend":"bullish/bearish/neutral","confidence":0-100,"signals":[{"type":"技术指标名","signal":"买入/卖出/中性","detail":"说明"}],"keyLevels":{"support":"支撑位","resistance":"阻力位"},"riskFactors":["风险因素"],"summary":"总结分析"}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "market_trend", strict: false, schema: { type: "object", properties: { trend: { type: "string" }, confidence: { type: "number" }, signals: { type: "array" }, summary: { type: "string" } }, required: ["trend", "summary"] } } },
      });
      const raw = response.choices[0]?.message?.content;
      try { return JSON.parse(typeof raw === "string" ? raw : "{}"); } catch { return { trend: "neutral", confidence: 50, signals: [], summary: "分析暂不可用" }; }
    }),

    // 策略回测建议
    strategyAdvice: protectedProcedure.input(z.object({ strategyDescription: z.string() })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "你是量化策略优化专家，提供策略改进建议。" },
          { role: "user", content: `分析以下策略并提供优化建议：${input.strategyDescription}。返回JSON: {"overallScore":0-100,"strengths":["优点"],"weaknesses":["弱点"],"suggestions":["优化建议"],"riskWarnings":["风险提示"],"backtestRecommendations":{"samplePeriod":"建议回测周期","outOfSample":"样本外测试建议","stressTest":"压力测试建议"}}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "strategy_advice", strict: false, schema: { type: "object", properties: { overallScore: { type: "number" }, strengths: { type: "array" }, weaknesses: { type: "array" }, suggestions: { type: "array" } }, required: ["overallScore"] } } },
      });
      const raw = response.choices[0]?.message?.content;
      try { return JSON.parse(typeof raw === "string" ? raw : "{}"); } catch { return { overallScore: 50, strengths: [], weaknesses: [], suggestions: ["暂无建议"] }; }
    }),
  }),
});
