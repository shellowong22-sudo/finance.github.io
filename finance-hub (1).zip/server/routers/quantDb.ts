import { eq, desc, and, or, sql, gte, lte, like, inArray, asc } from "drizzle-orm";
import { getDb } from "../db";
import {
  tradingAccounts, marketQuotes, klineData, quantStrategies,
  quantOrders, positions, riskRules, riskLogs,
  backtestRecords, backtestTrades, complianceAudit, monitorAlerts, ipoInfo,
  userWatchlist,
  priceAlerts,
} from "../../drizzle/schema";

// ============================================================
// 交易账户
// ============================================================
export async function listTradingAccounts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tradingAccounts).where(eq(tradingAccounts.userId, userId)).orderBy(desc(tradingAccounts.createdAt));
}

export async function getTradingAccount(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(tradingAccounts).where(eq(tradingAccounts.id, id)).limit(1);
  return rows[0];
}

export async function createTradingAccount(data: {
  userId: number; accountName: string; broker: string;
  market: "a_share" | "us_stock" | "hk_stock" | "futures" | "crypto" | "forex" | "global";
  accountType: "live" | "paper"; balance: string; currency: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(tradingAccounts).values({
    ...data,
    availableBalance: data.balance,
  });
  return (result as any)[0].insertId;
}

// ============================================================
// 市场行情
// ============================================================
export async function listMarketQuotes(market?: string, search?: string, limit = 200) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (market && market !== "all") conditions.push(eq(marketQuotes.market, market as any));
  if (search) conditions.push(or(like(marketQuotes.symbol, `%${search}%`), like(marketQuotes.name, `%${search}%`)));
  return db.select().from(marketQuotes)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(marketQuotes.updatedAt))
    .limit(limit);
}

export async function upsertMarketQuote(data: {
  symbol: string; name: string; market: string; exchange?: string;
  lastPrice: string; openPrice?: string; highPrice?: string; lowPrice?: string;
  prevClose?: string; change?: string; changePercent?: string;
  volume?: number; turnover?: string; marketCap?: string;
  pe?: string; pb?: string; sector?: string;
  listingType?: "primary" | "secondary";
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const existing = await db.select().from(marketQuotes).where(
    and(eq(marketQuotes.symbol, data.symbol), eq(marketQuotes.market, data.market as any))
  ).limit(1);
  if (existing.length > 0) {
    await db.update(marketQuotes).set(data as any).where(eq(marketQuotes.id, existing[0].id));
    return existing[0].id;
  } else {
    const result = await db.insert(marketQuotes).values(data as any);
    return (result as any)[0].insertId;
  }
}

export async function getKlineData(symbol: string, market: string, period: string, limit = 200) {
  const db = await getDb();
  if (!db) return [];

  // K线表中 A 股 symbol 带后缀(.SH/.SZ)，需要做映射
  let klineSymbol = symbol;
  if (market === 'a_share' || market === 'fund' || market === 'bond') {
    // 如果 symbol 不带后缀，尝试添加后缀
    if (!symbol.includes('.')) {
      // 上海：6开头、5开头(ETF)、0开头(国债)、1开头(转债/逆回购)
      // 深圳：0开头、3开头、1开头(部分)
      const code = symbol.replace(/\D/g, '');
      if (code.startsWith('6') || code.startsWith('5') || code.startsWith('11') || code.startsWith('01') || code.startsWith('20')) {
        klineSymbol = `${symbol}.SH`;
      } else if (code.startsWith('0') || code.startsWith('3') || code.startsWith('12') || code.startsWith('13') || code.startsWith('15') || code.startsWith('16')) {
        klineSymbol = `${symbol}.SZ`;
      }
    }
  } else if (market === 'hk_stock') {
    // 港股 K 线表中可能不带 .HK 后缀
    if (!symbol.includes('.HK')) {
      klineSymbol = symbol;
    } else {
      klineSymbol = symbol; // 保持原样
    }
  }

  // 先尝试精确匹配
  let results = await db.select().from(klineData)
    .where(and(eq(klineData.symbol, klineSymbol), eq(klineData.market, market), eq(klineData.period, period as any)))
    .orderBy(desc(klineData.timestamp))
    .limit(limit);

  // 如果没找到，尝试模糊匹配（symbol 前缀）
  if (results.length === 0 && klineSymbol !== symbol) {
    results = await db.select().from(klineData)
      .where(and(eq(klineData.symbol, symbol), eq(klineData.market, market), eq(klineData.period, period as any)))
      .orderBy(desc(klineData.timestamp))
      .limit(limit);
  }

  // 如果还没找到，尝试 like 匹配
  if (results.length === 0) {
    const baseSymbol = symbol.replace(/\.(SH|SZ|HK)$/i, '');
    results = await db.select().from(klineData)
      .where(and(like(klineData.symbol, `${baseSymbol}%`), eq(klineData.market, market), eq(klineData.period, period as any)))
      .orderBy(desc(klineData.timestamp))
      .limit(limit);
  }

  return results;
}

// ============================================================
// 实时行情模拟
// ============================================================
export async function simulateRealtimeQuotes() {
  const db = await getDb();
  if (!db) return [];
  const allQuotes = await db.select().from(marketQuotes).orderBy(desc(marketQuotes.updatedAt));
  const updates = [];
  for (const q of allQuotes) {
    const lastPrice = parseFloat(q.lastPrice);
    const volatility = 0.002 + Math.random() * 0.003; // 0.2%-0.5% per tick
    const direction = Math.random() > 0.5 ? 1 : -1;
    const change = lastPrice * volatility * direction;
    const newPrice = +(lastPrice + change).toFixed(4);
    const prevClose = parseFloat(q.prevClose || q.lastPrice);
    const totalChange = +(newPrice - prevClose).toFixed(4);
    const changePercent = +((totalChange / prevClose) * 100).toFixed(2);
    const newHigh = Math.max(parseFloat(q.highPrice || "0"), newPrice);
    const newLow = Math.min(parseFloat(q.lowPrice || "999999"), newPrice);
    const volumeAdd = Math.floor(Math.random() * 50000 + 10000);
    const newVolume = (q.volume || 0) + volumeAdd;
    const turnoverAdd = volumeAdd * newPrice;
    const newTurnover = +(parseFloat(q.turnover || "0") + turnoverAdd).toFixed(4);
    await db.update(marketQuotes).set({
      lastPrice: String(newPrice),
      highPrice: String(newHigh.toFixed(4)),
      lowPrice: String(newLow.toFixed(4)),
      change: String(totalChange),
      changePercent: String(changePercent),
      volume: newVolume,
      turnover: String(newTurnover),
    }).where(eq(marketQuotes.id, q.id));
    updates.push({ id: q.id, symbol: q.symbol, oldPrice: lastPrice, newPrice, changePercent });
  }
  return updates;
}

// ============================================================
// 交易策略
// ============================================================
export async function listStrategies(userId?: number, isPublic?: boolean, status?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (userId) conditions.push(eq(quantStrategies.userId, userId));
  if (isPublic !== undefined) conditions.push(eq(quantStrategies.isPublic, isPublic));
  if (status) conditions.push(eq(quantStrategies.status, status as any));
  return db.select().from(quantStrategies)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(quantStrategies.updatedAt));
}

export async function getStrategy(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(quantStrategies).where(eq(quantStrategies.id, id)).limit(1);
  return rows[0];
}

export async function createStrategy(data: {
  userId: number; name: string; description?: string;
  strategyType: "trend" | "mean_reversion" | "arbitrage" | "momentum" | "value" | "ml_based" | "hft" | "custom";
  applicableMarkets?: string; code?: string; parameters?: string;
  riskLevel?: "conservative" | "moderate" | "aggressive";
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(quantStrategies).values(data as any);
  return (result as any)[0].insertId;
}

export async function updateStrategy(id: number, data: Record<string, any>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(quantStrategies).set(data).where(eq(quantStrategies.id, id));
}

// ============================================================
// 交易订单
// ============================================================
export async function listOrders(userId: number, filters?: { accountId?: number; status?: string; market?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(quantOrders.userId, userId)];
  if (filters?.accountId) conditions.push(eq(quantOrders.accountId, filters.accountId));
  if (filters?.status) conditions.push(eq(quantOrders.orderStatus, filters.status as any));
  if (filters?.market) conditions.push(eq(quantOrders.market, filters.market));
  return db.select().from(quantOrders)
    .where(and(...conditions))
    .orderBy(desc(quantOrders.createdAt))
    .limit(filters?.limit || 100);
}

export async function createOrder(data: {
  idempotentId: string; userId: number; accountId: number; strategyId?: number;
  symbol: string; market: string; orderType: "market" | "limit" | "stop" | "stop_limit";
  side: "buy" | "sell"; price?: string; quantity: string;
  riskCheckPassed: boolean; riskCheckDetail?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(quantOrders).values(data as any);
  return (result as any)[0].insertId;
}

export async function updateOrder(id: number, data: Record<string, any>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(quantOrders).set(data).where(eq(quantOrders.id, id));
}

// ============================================================
// 持仓
// ============================================================
export async function listPositions(userId: number, accountId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(positions.userId, userId)];
  if (accountId) conditions.push(eq(positions.accountId, accountId));
  return db.select().from(positions).where(and(...conditions)).orderBy(desc(positions.marketValue));
}

export async function upsertPosition(data: {
  userId: number; accountId: number; symbol: string; symbolName?: string;
  market: string; side: "long" | "short"; quantity: string; avgCost: string;
  currentPrice?: string; marketValue?: string; unrealizedPnl?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const existing = await db.select().from(positions).where(
    and(eq(positions.userId, data.userId), eq(positions.accountId, data.accountId),
      eq(positions.symbol, data.symbol), eq(positions.side, data.side))
  ).limit(1);
  if (existing.length > 0) {
    await db.update(positions).set(data as any).where(eq(positions.id, existing[0].id));
    return existing[0].id;
  } else {
    const result = await db.insert(positions).values(data as any);
    return (result as any)[0].insertId;
  }
}

// ============================================================
// 风控规则
// ============================================================
export async function listRiskRules(market?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (market && market !== "all") {
    conditions.push(sql`(${riskRules.market} = ${market} OR ${riskRules.market} = 'all')`);
  }
  return db.select().from(riskRules)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(asc(riskRules.priority));
}

export async function createRiskRule(data: {
  name: string; description?: string;
  ruleType: string; market?: string;
  thresholdValue?: string; thresholdConfig?: string;
  action?: "block" | "alert" | "review";
  priority?: number; isMandatory?: boolean; createdBy: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(riskRules).values(data as any);
  return (result as any)[0].insertId;
}

export async function updateRiskRule(id: number, data: Record<string, any>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(riskRules).set(data).where(eq(riskRules.id, id));
}

export async function listRiskLogs(filters?: { userId?: number; market?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.userId) conditions.push(eq(riskLogs.userId, filters.userId));
  if (filters?.market) conditions.push(eq(riskLogs.market, filters.market));
  return db.select().from(riskLogs)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(riskLogs.createdAt))
    .limit(filters?.limit || 100);
}

export async function createRiskLog(data: {
  userId: number; ruleId?: number; ruleName?: string; orderId?: number;
  triggerType: "blocked" | "alerted" | "reviewed" | "emergency_stop";
  triggerDetail?: string; market?: string; symbol?: string;
  orderAmount?: string; riskScore?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(riskLogs).values(data as any);
  return (result as any)[0].insertId;
}

// ============================================================
// 回测
// ============================================================
export async function listBacktests(userId: number, strategyId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(backtestRecords.userId, userId)];
  if (strategyId) conditions.push(eq(backtestRecords.strategyId, strategyId));
  return db.select().from(backtestRecords).where(and(...conditions)).orderBy(desc(backtestRecords.createdAt));
}

export async function getBacktest(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(backtestRecords).where(eq(backtestRecords.id, id)).limit(1);
  return rows[0];
}

export async function createBacktest(data: {
  userId: number; strategyId: number; name: string; market: string;
  symbols?: string; startDate: string; endDate: string;
  initialCapital: string; slippageModel?: string; slippageValue?: string;
  commissionRate?: string; stampDutyRate?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(backtestRecords).values(data as any);
  return (result as any)[0].insertId;
}

export async function updateBacktest(id: number, data: Record<string, any>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(backtestRecords).set(data).where(eq(backtestRecords.id, id));
}

export async function listBacktestTrades(backtestId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(backtestTrades).where(eq(backtestTrades.backtestId, backtestId)).orderBy(asc(backtestTrades.tradeTimestamp));
}

// ============================================================
// 合规审计
// ============================================================
export async function listComplianceAudit(filters?: { userId?: number; actionType?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.userId) conditions.push(eq(complianceAudit.userId, filters.userId));
  if (filters?.actionType) conditions.push(eq(complianceAudit.actionType, filters.actionType as any));
  return db.select().from(complianceAudit)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(complianceAudit.createdAt))
    .limit(filters?.limit || 200);
}

export async function createComplianceLog(data: {
  userId: number; operatorName: string;
  actionType: "order_submit" | "order_cancel" | "strategy_modify" | "risk_rule_change" | "account_change" | "emergency_stop" | "data_export" | "config_change" | "login" | "logout";
  targetType?: string; targetId?: number; detail?: string;
  ipAddress?: string; userAgent?: string; isCompliant?: boolean; complianceNote?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(complianceAudit).values(data as any);
  return (result as any)[0].insertId;
}

// ============================================================
// 监控告警
// ============================================================
export async function listAlerts(filters?: { severity?: string; isResolved?: boolean; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.severity) conditions.push(eq(monitorAlerts.severity, filters.severity as any));
  if (filters?.isResolved !== undefined) conditions.push(eq(monitorAlerts.isResolved, filters.isResolved));
  return db.select().from(monitorAlerts)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(monitorAlerts.createdAt))
    .limit(filters?.limit || 100);
}

export async function createAlert(data: {
  alertType: string; severity?: string; title: string; message: string;
  source?: string; metric?: string; currentValue?: string; thresholdValue?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(monitorAlerts).values(data as any);
  return (result as any)[0].insertId;
}

export async function resolveAlert(id: number, resolvedBy: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(monitorAlerts).set({ isResolved: true, resolvedBy, resolvedAt: new Date() }).where(eq(monitorAlerts.id, id));
}

// ============================================================
// IPO/一级市场
// ============================================================
export async function listIPOs(status?: string, market?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (status) conditions.push(eq(ipoInfo.status, status as any));
  if (market) conditions.push(eq(ipoInfo.market, market));
  return db.select().from(ipoInfo)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(ipoInfo.createdAt));
}

export async function createIPO(data: {
  symbol: string; companyName: string; market: string; exchange?: string;
  ipoPrice?: string; ipoShares?: number; totalRaised?: string;
  ipoDate?: string; listingDate?: string; status?: string;
  industry?: string; underwriter?: string; description?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(ipoInfo).values(data as any);
  return (result as any)[0].insertId;
}

// ============================================================
// 自选股管理
// ============================================================
export async function listWatchlist(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userWatchlist)
    .where(eq(userWatchlist.userId, userId))
    .orderBy(asc(userWatchlist.sortOrder), desc(userWatchlist.createdAt));
}

export async function addToWatchlist(data: {
  userId: number; symbol: string; name?: string; market: string; note?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Check if already exists
  const existing = await db.select().from(userWatchlist).where(
    and(eq(userWatchlist.userId, data.userId), eq(userWatchlist.symbol, data.symbol), eq(userWatchlist.market, data.market))
  ).limit(1);
  if (existing.length > 0) return { id: existing[0].id, exists: true };
  // Get max sortOrder
  const maxSort = await db.select({ max: sql<number>`COALESCE(MAX(${userWatchlist.sortOrder}), 0)` })
    .from(userWatchlist).where(eq(userWatchlist.userId, data.userId));
  const sortOrder = (maxSort[0]?.max || 0) + 1;
  const result = await db.insert(userWatchlist).values({ ...data, sortOrder });
  return { id: (result as any)[0].insertId, exists: false };
}

export async function removeFromWatchlist(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(userWatchlist).where(
    and(eq(userWatchlist.id, id), eq(userWatchlist.userId, userId))
  );
}

export async function removeFromWatchlistBySymbol(userId: number, symbol: string, market: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(userWatchlist).where(
    and(eq(userWatchlist.userId, userId), eq(userWatchlist.symbol, symbol), eq(userWatchlist.market, market))
  );
}

export async function getWatchlistWithQuotes(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const watchItems = await db.select().from(userWatchlist)
    .where(eq(userWatchlist.userId, userId))
    .orderBy(asc(userWatchlist.sortOrder), desc(userWatchlist.createdAt));
  if (watchItems.length === 0) return [];
  // Get quote data for each watchlist item
  const results = [];
  for (const item of watchItems) {
    const quotes = await db.select().from(marketQuotes).where(
      and(eq(marketQuotes.symbol, item.symbol), eq(marketQuotes.market, item.market as any))
    ).limit(1);
    results.push({
      ...item,
      quote: quotes[0] || null,
    });
  }
  return results;
}

// ============================================================
// 大盘指数查询
// ============================================================
export async function getMainIndices() {
  const db = await getDb();
  if (!db) return [];
  // 核心指数列表
  const coreSymbols = [
    "000001.SH", "399001.SZ", "399006.SZ",  // 上证、深证、创业板
    "HSI",                                    // 恒生
    "DJI", "SPX", "IXIC",                    // 美股三大指数
    "N225", "FTSE", "GDAXI",                 // 日经、富时、DAX
  ];
  const results = [];
  for (const sym of coreSymbols) {
    const rows = await db.select().from(marketQuotes).where(
      and(eq(marketQuotes.symbol, sym), eq(marketQuotes.market, "index"))
    ).limit(1);
    if (rows[0]) results.push(rows[0]);
  }
  return results;
}

// ============================================================
// 量化统计
// ============================================================
export async function getQuantStats(userId?: number) {
  const db = await getDb();
  if (!db) return { totalAccounts: 0, totalStrategies: 0, totalOrders: 0, activeAlerts: 0, totalPositions: 0 };
  const conditions = userId ? [eq(tradingAccounts.userId, userId)] : [];
  const accounts = await db.select({ count: sql<number>`count(*)` }).from(tradingAccounts).where(conditions.length > 0 ? and(...conditions) : undefined);
  const strategies = await db.select({ count: sql<number>`count(*)` }).from(quantStrategies).where(userId ? eq(quantStrategies.userId, userId) : undefined);
  const orders = await db.select({ count: sql<number>`count(*)` }).from(quantOrders).where(userId ? eq(quantOrders.userId, userId) : undefined);
  const alerts = await db.select({ count: sql<number>`count(*)` }).from(monitorAlerts).where(eq(monitorAlerts.isResolved, false));
  const pos = await db.select({ count: sql<number>`count(*)` }).from(positions).where(userId ? eq(positions.userId, userId) : undefined);
  return {
    totalAccounts: accounts[0]?.count || 0,
    totalStrategies: strategies[0]?.count || 0,
    totalOrders: orders[0]?.count || 0,
    activeAlerts: alerts[0]?.count || 0,
    totalPositions: pos[0]?.count || 0,
  };
}

// ============================================================
// 价格预警
// ============================================================
export async function listPriceAlerts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(priceAlerts)
    .where(eq(priceAlerts.userId, userId))
    .orderBy(desc(priceAlerts.createdAt));
}

export async function createPriceAlert(data: {
  userId: number; symbol: string; name?: string; market: string;
  alertType: "change_percent_above" | "change_percent_below" | "price_above" | "price_below";
  threshold: string; cooldownMinutes?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(priceAlerts).values({
    userId: data.userId,
    symbol: data.symbol,
    name: data.name,
    market: data.market,
    alertType: data.alertType,
    threshold: data.threshold,
    cooldownMinutes: data.cooldownMinutes || 30,
  });
  return (result as any)[0].insertId;
}

export async function updatePriceAlert(id: number, userId: number, data: { isEnabled?: boolean; threshold?: string; cooldownMinutes?: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(priceAlerts).set(data).where(and(eq(priceAlerts.id, id), eq(priceAlerts.userId, userId)));
}

export async function deletePriceAlert(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(priceAlerts).where(and(eq(priceAlerts.id, id), eq(priceAlerts.userId, userId)));
}

// ============================================================
// 板块聚合（热力图数据）
// ============================================================
export async function getSectorHeatmap() {
  const db = await getDb();
  if (!db) return [];
  // 获取所有有sector的股票（排除指数、外汇、加密）
  const rows = await db.select({
    sector: marketQuotes.sector,
    symbol: marketQuotes.symbol,
    name: marketQuotes.name,
    market: marketQuotes.market,
    lastPrice: marketQuotes.lastPrice,
    changePercent: marketQuotes.changePercent,
    volume: marketQuotes.volume,
    marketCap: marketQuotes.marketCap,
    turnover: marketQuotes.turnover,
  }).from(marketQuotes).where(
    and(
      sql`${marketQuotes.sector} IS NOT NULL AND ${marketQuotes.sector} != ''`,
      sql`${marketQuotes.market} NOT IN ('index', 'forex', 'crypto')`
    )
  );

  // 按板块聚合
  const sectorMap = new Map<string, {
    sector: string;
    stockCount: number;
    avgChangePercent: number;
    totalVolume: number;
    totalTurnover: number;
    upCount: number;
    downCount: number;
    flatCount: number;
    stocks: Array<{ symbol: string; name: string; market: string; changePercent: number; lastPrice: number }>;
  }>();

  for (const row of rows) {
    const sector = row.sector || "其他";
    if (!sectorMap.has(sector)) {
      sectorMap.set(sector, {
        sector,
        stockCount: 0,
        avgChangePercent: 0,
        totalVolume: 0,
        totalTurnover: 0,
        upCount: 0,
        downCount: 0,
        flatCount: 0,
        stocks: [],
      });
    }
    const s = sectorMap.get(sector)!;
    const changePct = parseFloat(row.changePercent || "0");
    s.stockCount++;
    s.avgChangePercent += changePct;
    s.totalVolume += row.volume || 0;
    s.totalTurnover += parseFloat(row.turnover || "0");
    if (changePct > 0) s.upCount++;
    else if (changePct < 0) s.downCount++;
    else s.flatCount++;
    s.stocks.push({
      symbol: row.symbol,
      name: row.name,
      market: row.market,
      changePercent: changePct,
      lastPrice: parseFloat(row.lastPrice),
    });
  }

  // 计算平均值并排序
  const result = Array.from(sectorMap.values()).map(s => ({
    ...s,
    avgChangePercent: s.stockCount > 0 ? +(s.avgChangePercent / s.stockCount).toFixed(2) : 0,
    stocks: s.stocks.sort((a, b) => b.changePercent - a.changePercent),  // Return all stocks sorted by change%
  }));

  return result.sort((a, b) => b.stockCount - a.stockCount);
}

// ============================================================
// 指数分时数据（生成模拟分时曲线）
// ============================================================
export async function getIndexIntradayData(symbol: string) {
  const db = await getDb();
  if (!db) return [];

  // 获取当前价格
  const rows = await db.select().from(marketQuotes).where(
    and(eq(marketQuotes.symbol, symbol), eq(marketQuotes.market, "index"))
  ).limit(1);

  if (!rows[0]) return [];

  const quote = rows[0];
  const lastPrice = parseFloat(quote.lastPrice);
  const prevClose = parseFloat(quote.prevClose || quote.lastPrice);
  const changePct = parseFloat(quote.changePercent || "0");

  // 生成当日分时数据（基于当前价格和涨跌幅模拟）
  const now = new Date();
  const points: Array<{ time: string; price: number; volume: number }> = [];
  const totalMinutes = 240; // 4小时交易时间

  // 使用确定性种子生成一致的模拟数据
  const seed = symbol.split('').reduce((a, c) => a + c.charCodeAt(0), 0) + now.getDate();
  let pseudoRandom = seed;
  const nextRand = () => {
    pseudoRandom = (pseudoRandom * 1103515245 + 12345) & 0x7fffffff;
    return (pseudoRandom / 0x7fffffff);
  };

  for (let i = 0; i <= totalMinutes; i += 2) {
    const progress = i / totalMinutes;
    // 从昨收价开始，逐步走向当前价
    const targetDelta = (lastPrice - prevClose) * progress;
    const noise = (nextRand() - 0.5) * prevClose * 0.003; // 0.3% noise
    const price = prevClose + targetDelta + noise;
    const vol = Math.floor(1000000 + nextRand() * 5000000);

    const hour = Math.floor(i / 60) + 9;
    const minute = (i % 60) + 30;
    const h = hour + Math.floor(minute / 60);
    const m = minute % 60;
    points.push({
      time: `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`,
      price: +price.toFixed(2),
      volume: vol,
    });
  }

  return points;
}

// ============================================================
// 自选组合收益统计
// ============================================================
export async function getWatchlistPortfolioStats(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const watchItems = await db.select().from(userWatchlist)
    .where(eq(userWatchlist.userId, userId))
    .orderBy(asc(userWatchlist.sortOrder), desc(userWatchlist.createdAt));

  if (watchItems.length === 0) return null;

  // Get quote data for each watchlist item
  const items: Array<{
    symbol: string;
    name: string;
    market: string;
    lastPrice: number;
    prevClose: number;
    changePercent: number;
    change: number;
    volume: number;
    marketCap: number | null;
  }> = [];

  for (const item of watchItems) {
    const quotes = await db.select().from(marketQuotes).where(
      and(eq(marketQuotes.symbol, item.symbol), eq(marketQuotes.market, item.market as any))
    ).limit(1);
    if (quotes[0]) {
      const q = quotes[0];
      const lastPrice = parseFloat(q.lastPrice);
      const prevClose = parseFloat(q.prevClose || q.lastPrice);
      const changePct = parseFloat(q.changePercent || "0");
      const change = parseFloat(q.change || "0");
      items.push({
        symbol: item.symbol,
        name: item.name || q.name,
        market: item.market,
        lastPrice,
        prevClose,
        changePercent: changePct,
        change,
        volume: q.volume || 0,
        marketCap: q.marketCap ? parseFloat(String(q.marketCap)) : null,
      });
    }
  }

  if (items.length === 0) return null;

  // Calculate portfolio stats
  const upCount = items.filter(i => i.changePercent > 0).length;
  const downCount = items.filter(i => i.changePercent < 0).length;
  const flatCount = items.filter(i => i.changePercent === 0).length;
  const avgChangePercent = items.reduce((s, i) => s + i.changePercent, 0) / items.length;
  const maxGainer = items.reduce((max, i) => i.changePercent > max.changePercent ? i : max, items[0]);
  const maxLoser = items.reduce((min, i) => i.changePercent < min.changePercent ? i : min, items[0]);
  const totalVolume = items.reduce((s, i) => s + i.volume, 0);

  // Generate 30-day simulated portfolio performance curve
  const seed = userId * 31 + items.length;
  let pseudoRandom = seed;
  const nextRand = () => {
    pseudoRandom = (pseudoRandom * 1103515245 + 12345) & 0x7fffffff;
    return (pseudoRandom / 0x7fffffff);
  };

  const performanceCurve: Array<{ day: number; value: number }> = [];
  let cumReturn = 0;
  for (let d = -29; d <= 0; d++) {
    const dailyReturn = (nextRand() - 0.48) * 3; // slight positive bias
    cumReturn += dailyReturn;
    performanceCurve.push({ day: d, value: +cumReturn.toFixed(2) });
  }
  // Last point is today's actual avg change
  performanceCurve[performanceCurve.length - 1].value = +avgChangePercent.toFixed(2);

  return {
    totalCount: items.length,
    upCount,
    downCount,
    flatCount,
    avgChangePercent: +avgChangePercent.toFixed(2),
    maxGainer: { symbol: maxGainer.symbol, name: maxGainer.name, changePercent: maxGainer.changePercent },
    maxLoser: { symbol: maxLoser.symbol, name: maxLoser.name, changePercent: maxLoser.changePercent },
    totalVolume,
    performanceCurve,
    items: items.sort((a, b) => b.changePercent - a.changePercent),
  };
}
