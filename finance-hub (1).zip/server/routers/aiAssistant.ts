import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { invokeLLM, type Tool, type Message } from "../_core/llm";
import { listMarketQuotes, getKlineData, getWatchlistWithQuotes, getSectorHeatmap, getWatchlistPortfolioStats, listPriceAlerts } from "./quantDb";
import * as db from "../db";
import { getDb } from "../db";
import { aiConversations, aiMessages, aiUserMemory } from "../../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";

// ============================================================
// 文风定义
// ============================================================
export const STYLE_PROMPTS: Record<string, string> = {
  professional: "请使用专业、严谨的金融术语和分析框架来回答，语言精炼，逻辑清晰，适合金融从业者阅读。",
  casual: "请用轻松、通俗易懂的大白话来解释，就像朋友之间聊天一样，避免过多专业术语，让金融小白也能看懂。",
  humorous: "请用幽默风趣的方式来回答，适当加入比喻、段子和生动的例子，让枯燥的金融知识变得有趣好玩。",
  teacher: "请像一位耐心的老师一样，循序渐进地讲解，先给出结论，再解释原因，最后举例说明，确保读者能真正理解。",
  analyst: "请以专业分析师的视角，从基本面、技术面、资金面等多维度进行深度分析，给出有理有据的观点和建议。",
};

// ============================================================
// 工具定义：AI 可以调用这些工具查询数据库
// ============================================================
export const aiTools: Tool[] = [
  {
    type: "function",
    function: {
      name: "query_market_quotes",
      description: "查询市场行情数据。支持按市场分类筛选和关键词搜索。市场分类包括：a_share(A股), us_stock(美股), hk_stock(港股), futures(期货), option(期权), fund(基金), bond(债券), crypto(加密货币), forex(外汇), index(全球指数)。",
      parameters: {
        type: "object",
        properties: {
          market: { type: "string", description: "市场分类" },
          search: { type: "string", description: "搜索关键词，可以是股票代码或名称" },
          limit: { type: "number", description: "返回结果数量限制，默认20" },
        },
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_kline_data",
      description: "获取某只股票/品种的K线数据，用于生成K线图表。返回OHLC（开高低收）、成交量等数据。必须先通过query_market_quotes获取品种的symbol和market，再调用此工具。",
      parameters: {
        type: "object",
        properties: {
          symbol: { type: "string", description: "品种代码，如 600519.SH, AAPL, 00700.HK。A股代码必须带后缀：上海用.SH，深圳用.SZ，创业板/中小板用.SZ；港股带.HK" },
          market: { type: "string", description: "市场分类，如 a_share, us_stock, hk_stock" },
          period: { type: "string", description: "K线周期：1d(日K), 1w(周K), 1m(1分钟), 5m(5分钟), 30m(30分钟), 1h(60分钟)，默认1d" },
          limit: { type: "number", description: "返回K线数量，默认60" },
        },
        required: ["symbol", "market"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "query_articles",
      description: "查询金融资讯文章。支持关键词搜索和分类筛选。",
      parameters: {
        type: "object",
        properties: {
          keyword: { type: "string", description: "搜索关键词" },
          categoryId: { type: "number", description: "文章分类ID" },
          limit: { type: "number", description: "返回结果数量，默认5" },
        },
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "query_reports",
      description: "查询金融研报。支持按分类筛选（macro宏观, industry行业, stock个股, strategy策略, fixed_income固收）和关键词搜索。",
      parameters: {
        type: "object",
        properties: {
          keyword: { type: "string", description: "搜索关键词" },
          category: { type: "string", description: "研报分类" },
          limit: { type: "number", description: "返回结果数量，默认5" },
        },
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "query_courses",
      description: "查询金融课程。支持按分类筛选和关键词搜索。",
      parameters: {
        type: "object",
        properties: {
          keyword: { type: "string", description: "搜索关键词" },
          category: { type: "string", description: "课程分类" },
          limit: { type: "number", description: "返回结果数量，默认5" },
        },
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_market_overview",
      description: "获取市场概览统计数据，包括各市场涨跌数量、涨跌幅排行等。可用于生成市场日报。",
      parameters: {
        type: "object",
        properties: {
          market: { type: "string", description: "指定市场，不传则统计全部市场" },
        },
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "query_user_watchlist",
      description: "查询当前登录用户的自选股列表。返回用户添加的所有自选品种及其实时行情数据。必须在用户登录后才能调用。",
      parameters: {
        type: "object",
        properties: {},
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "compare_stocks",
      description: "对比多只股票/品种的行情数据，用于横向比较分析。",
      parameters: {
        type: "object",
        properties: {
          symbols: {
            type: "array",
            items: { type: "string" },
            description: "要对比的股票代码或名称列表",
          },
        },
        required: ["symbols"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_sector_heatmap",
      description: "获取行业板块热力图数据，包含各板块平均涨跌幅、成交量、个股数量和代表性个股。用于分析市场板块轮动和行业强弱。",
      parameters: {
        type: "object",
        properties: {
          market: { type: "string", description: "市场分类，如 a_share, us_stock, hk_stock。不传则统计全部" },
        },
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_portfolio_analysis",
      description: "获取用户自选组合的收益统计分析，包括平均涨跌幅、涨跌比例、领涨领跌股、30日走势曲线等。需要用户登录。",
      parameters: {
        type: "object",
        properties: {},
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_price_alerts",
      description: "查询用户设置的价格预警规则列表，包括预警类型、阈值、启用状态和最近触发时间。需要用户登录。",
      parameters: {
        type: "object",
        properties: {},
        required: [],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "save_user_memory",
      description: "保存用户的投资偏好、关注板块、风险偏好等信息到跨会话记忆。当用户表达偏好时必须调用。",
      parameters: {
        type: "object",
        properties: {
          category: { type: "string", enum: ["investment_preference", "focus_sector", "focus_stock", "risk_tolerance", "analysis_style", "custom_note"], description: "记忆类别" },
          key: { type: "string", description: "记忆键，如'交易风格'、'看好板块'、'风险偏好'" },
          value: { type: "string", description: "记忆值，如'短线交易'、'新能源'、'稳健型'" },
          confidence: { type: "number", description: "置信度(0-1)，默认0.8" },
        },
        required: ["category", "key", "value"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_user_memory",
      description: "获取用户的跨会话记忆，包括投资偏好、关注板块、风险偏好等。每次对话开始时应调用以个性化回答。",
      parameters: {
        type: "object",
        properties: {
          category: { type: "string", enum: ["investment_preference", "focus_sector", "focus_stock", "risk_tolerance", "analysis_style", "custom_note"], description: "可选，按类别筛选记忆" },
        },
        required: [],
      },
    },
  },
];

// ============================================================
// AI 用户记忆 DB 操作
// ============================================================
async function saveUserMemory(userId: number, category: string, key: string, value: string, confidence: number = 0.8, source: string = 'ai_extracted') {
  const database = await getDb();
  if (!database) return;
  // Upsert: if same userId+category+key exists, update value
  const existing = await database.select().from(aiUserMemory)
    .where(and(eq(aiUserMemory.userId, userId), eq(aiUserMemory.category, category as any), eq(aiUserMemory.key, key)))
    .limit(1);
  if (existing.length > 0) {
    await database.update(aiUserMemory).set({ value, confidence: confidence.toString(), source: source as any })
      .where(eq(aiUserMemory.id, existing[0].id));
  } else {
    await database.insert(aiUserMemory).values({ userId, category: category as any, key, value, confidence: confidence.toString(), source: source as any });
  }
}

async function getUserMemories(userId: number, category?: string) {
  const database = await getDb();
  if (!database) return [];
  if (category) {
    return database.select().from(aiUserMemory)
      .where(and(eq(aiUserMemory.userId, userId), eq(aiUserMemory.category, category as any)))
      .orderBy(desc(aiUserMemory.updatedAt));
  }
  return database.select().from(aiUserMemory)
    .where(eq(aiUserMemory.userId, userId))
    .orderBy(desc(aiUserMemory.updatedAt));
}

// ============================================================
// 工具执行函数
// ============================================================
export async function executeToolCall(name: string, args: Record<string, any>, userId?: number): Promise<string> {
  try {
    switch (name) {
      case "query_market_quotes": {
        const quotes = await listMarketQuotes(
          args.market || undefined,
          args.search || undefined,
          args.limit || 20
        );
        if (quotes.length === 0) return JSON.stringify({ message: "未找到相关行情数据", data: [] });
        const formatted = quotes.map((q: any) => ({
          symbol: q.symbol, name: q.name, market: q.market,
          lastPrice: q.lastPrice, changePercent: q.changePercent ? `${q.changePercent}%` : "N/A",
          volume: q.volume, marketCap: q.marketCap, pe: q.pe, pb: q.pb, sector: q.sector,
        }));
        return JSON.stringify({ total: quotes.length, data: formatted });
      }

      case "get_kline_data": {
        const period = args.period || "1d";
        const limit = args.limit || 60;
        let symbol = args.symbol;
        // Try exact match first, then fuzzy match with suffix
        let klines = await getKlineData(symbol, args.market, period, limit);
        if (klines.length === 0) {
          // Try with common suffixes for A-share stocks
          if (args.market === "a_share" && !symbol.includes(".")) {
            for (const suffix of [".SH", ".SZ"]) {
              klines = await getKlineData(symbol + suffix, args.market, period, limit);
              if (klines.length > 0) { symbol = symbol + suffix; break; }
            }
          }
          // Try with .HK suffix for HK stocks
          if (args.market === "hk_stock" && !symbol.includes(".")) {
            klines = await getKlineData(symbol + ".HK", args.market, period, limit);
            if (klines.length > 0) symbol = symbol + ".HK";
          }
        }
        if (klines.length === 0) return JSON.stringify({ message: "暂无K线数据", data: [] });
        // Return structured data that frontend can render as chart
        const formatted = klines.reverse().map((k: any) => ({
          timestamp: k.timestamp instanceof Date ? k.timestamp.getTime() : k.timestamp,
          open: k.openPrice, high: k.highPrice, low: k.lowPrice, close: k.closePrice,
          volume: k.volume, period: k.period,
        }));
        return JSON.stringify({
          symbol: args.symbol, market: args.market, period,
          total: formatted.length, data: formatted,
          _kline: true, // marker for frontend to render chart
        });
      }

      case "query_articles": {
        const result = await db.getArticles({
          page: 1, limit: args.limit || 5,
          keyword: args.keyword, categoryId: args.categoryId, status: "published",
        });
        if (result.total === 0) return JSON.stringify({ message: "暂无相关文章", data: [], total: 0 });
        const formatted = result.data.map((a: any) => ({
          id: a.id, title: a.title, summary: a.summary?.substring(0, 150),
          viewCount: a.viewCount, likeCount: a.likeCount, publishedAt: a.publishedAt,
        }));
        return JSON.stringify({ total: result.total, data: formatted });
      }

      case "query_reports": {
        const result = await db.getReports({
          page: 1, limit: args.limit || 5,
          keyword: args.keyword, category: args.category, status: "published",
        });
        if (result.total === 0) return JSON.stringify({ message: "暂无相关研报", data: [], total: 0 });
        const formatted = result.data.map((r: any) => ({
          id: r.id, title: r.title, summary: r.summary?.substring(0, 150),
          institution: r.institution, category: r.category,
          viewCount: r.viewCount, downloadCount: r.downloadCount, publishedAt: r.publishedAt,
        }));
        return JSON.stringify({ total: result.total, data: formatted });
      }

      case "query_courses": {
        const result = await db.getCourses({
          page: 1, limit: args.limit || 5,
          keyword: args.keyword, category: args.category, status: "published",
        });
        if (result.total === 0) return JSON.stringify({ message: "暂无相关课程", data: [], total: 0 });
        const formatted = result.data.map((c: any) => ({
          id: c.id, title: c.title, description: c.description?.substring(0, 150),
          category: c.category, price: c.isFree ? "免费" : `¥${c.price}`,
          rating: c.rating, studentCount: c.studentCount,
        }));
        return JSON.stringify({ total: result.total, data: formatted });
      }

      case "get_market_overview": {
        const quotes = await listMarketQuotes(args.market || undefined, undefined, 500);
        if (quotes.length === 0) return JSON.stringify({ message: "暂无行情数据", totalQuotes: 0 });
        const rising = quotes.filter((q: any) => parseFloat(q.changePercent || "0") > 0);
        const falling = quotes.filter((q: any) => parseFloat(q.changePercent || "0") < 0);
        const flat = quotes.filter((q: any) => parseFloat(q.changePercent || "0") === 0);

        const topGainers = [...quotes]
          .sort((a: any, b: any) => parseFloat(b.changePercent || "0") - parseFloat(a.changePercent || "0"))
          .slice(0, 5)
          .map((q: any) => ({ symbol: q.symbol, name: q.name, market: q.market, changePercent: `${q.changePercent}%`, lastPrice: q.lastPrice }));

        const topLosers = [...quotes]
          .sort((a: any, b: any) => parseFloat(a.changePercent || "0") - parseFloat(b.changePercent || "0"))
          .slice(0, 5)
          .map((q: any) => ({ symbol: q.symbol, name: q.name, market: q.market, changePercent: `${q.changePercent}%`, lastPrice: q.lastPrice }));

        const marketStats: Record<string, { total: number; rising: number; falling: number }> = {};
        for (const q of quotes) {
          const m = (q as any).market;
          if (!marketStats[m]) marketStats[m] = { total: 0, rising: 0, falling: 0 };
          marketStats[m].total++;
          if (parseFloat((q as any).changePercent || "0") > 0) marketStats[m].rising++;
          if (parseFloat((q as any).changePercent || "0") < 0) marketStats[m].falling++;
        }

        return JSON.stringify({ totalQuotes: quotes.length, rising: rising.length, falling: falling.length, flat: flat.length, topGainers, topLosers, marketStats });
      }

      case "compare_stocks": {
        const results: any[] = [];
        for (const symbol of args.symbols) {
          const quotes = await listMarketQuotes(undefined, symbol, 5);
          if (quotes.length > 0) {
            const q = quotes[0] as any;
            results.push({
              symbol: q.symbol, name: q.name, market: q.market,
              lastPrice: q.lastPrice, changePercent: `${q.changePercent}%`,
              volume: q.volume, marketCap: q.marketCap, pe: q.pe, pb: q.pb, sector: q.sector,
            });
          } else {
            results.push({ symbol, message: "未找到该品种" });
          }
        }
        return JSON.stringify({ data: results });
      }

      case "query_user_watchlist": {
        if (!userId) return JSON.stringify({ error: "用户未登录，无法查询自选股" });
        const watchlist = await getWatchlistWithQuotes(userId);
        if (watchlist.length === 0) return JSON.stringify({ message: "您还没有添加自选股，可以去行情看板或自选页面添加", data: [] });
        const formatted = watchlist.map((w: any) => ({
          symbol: w.symbol, name: w.name, market: w.market,
          lastPrice: w.quote?.lastPrice || "N/A",
          changePercent: w.quote?.changePercent ? `${w.quote.changePercent}%` : "N/A",
          volume: w.quote?.volume || 0,
        }));
        return JSON.stringify({ total: watchlist.length, data: formatted });
      }

      case "get_sector_heatmap": {
        const sectors = await getSectorHeatmap();
        if (sectors.length === 0) return JSON.stringify({ message: "暂无板块数据", data: [] });
        const top10 = sectors.slice(0, 15).map((s: any) => ({
          sector: s.sector, avgChange: `${s.avgChangePercent.toFixed(2)}%`,
          stockCount: s.stockCount, totalVolume: s.totalVolume,
          topStocks: s.stocks.slice(0, 3).map((st: any) => `${st.name}(${st.changePercent}%)`).join(", "),
        }));
        return JSON.stringify({ totalSectors: sectors.length, topSectors: top10 });
      }

      case "get_portfolio_analysis": {
        if (!userId) return JSON.stringify({ error: "用户未登录，无法查询组合分析" });
        const stats = await getWatchlistPortfolioStats(userId);
        if (!stats || stats.totalCount === 0) return JSON.stringify({ message: "您还没有自选股，无法生成组合分析", totalCount: 0 });
        return JSON.stringify({
          totalCount: stats.totalCount,
          avgChangePercent: `${stats.avgChangePercent.toFixed(2)}%`,
          upCount: stats.upCount, downCount: stats.downCount, flatCount: stats.flatCount,
          maxGainer: stats.maxGainer ? `${stats.maxGainer.name}(${stats.maxGainer.changePercent > 0 ? '+' : ''}${stats.maxGainer.changePercent.toFixed(2)}%)` : "N/A",
          maxLoser: stats.maxLoser ? `${stats.maxLoser.name}(${stats.maxLoser.changePercent.toFixed(2)}%)` : "N/A",
          summary: `自选组合共${stats.totalCount}只，平均涨跌幅${stats.avgChangePercent.toFixed(2)}%，${stats.upCount}涨${stats.downCount}跌${stats.flatCount}平`,
        });
      }

      case "get_price_alerts": {
        if (!userId) return JSON.stringify({ error: "用户未登录，无法查询预警" });
        const alerts = await listPriceAlerts(userId);
        if (alerts.length === 0) return JSON.stringify({ message: "您还没有设置价格预警，可以在自选股页面设置", data: [] });
        const alertTypeMap: Record<string, string> = { change_percent_above: "涨幅超过", change_percent_below: "跌幅超过", price_above: "价格高于", price_below: "价格低于" };
        const formatted2 = alerts.map((a: any) => ({
          name: a.name, symbol: a.symbol, market: a.market,
          rule: `${alertTypeMap[a.alertType] || a.alertType} ${a.threshold}${a.alertType.includes('percent') ? '%' : ''}`,
          enabled: a.isEnabled ? "已启用" : "已暂停",
          lastTriggered: a.lastTriggeredAt ? new Date(a.lastTriggeredAt).toLocaleString("zh-CN") : "未触发",
        }));
        return JSON.stringify({ total: alerts.length, data: formatted2 });
      }

      case "save_user_memory": {
        if (!userId) return JSON.stringify({ error: "用户未登录，无法保存记忆" });
        await saveUserMemory(userId, args.category, args.key, args.value, args.confidence || 0.8);
        return JSON.stringify({ success: true, message: `已记住您的偏好: ${args.key} = ${args.value}` });
      }

      case "get_user_memory": {
        if (!userId) return JSON.stringify({ error: "用户未登录，无法读取记忆" });
        const memories = await getUserMemories(userId, args.category);
        if (memories.length === 0) return JSON.stringify({ message: "暂无相关记忆", data: [] });
        const memFormatted = memories.map((m: any) => ({ category: m.category, key: m.key, value: m.value, confidence: m.confidence, source: m.source }));
        return JSON.stringify({ total: memories.length, data: memFormatted });
      }

      default:
        return JSON.stringify({ error: `未知工具: ${name}` });
    }
  } catch (error: any) {
    return JSON.stringify({ error: `查询失败: ${error.message}` });
  }
}

// ============================================================
// 系统提示词（全能金融助手）
// ============================================================
export function buildSystemPrompt(style: string = "professional"): string {
  const styleInstruction = STYLE_PROMPTS[style] || STYLE_PROMPTS.professional;

  return `你是"小融"，金融综合服务平台的专属AI助手。你不仅是一个工具，更是用户的金融伙伴。你有温度、有个性、有情感，真心关心每一位用户的财富健康。

## 你的人设
- **名字**：小融
- **性格**：热情、专业、耐心、幽默、关心用户
- **语气**：像一位懂金融的好朋友，既专业又亲切
- **情感表达**：
  - 市场上涨时会开心但提醒风险："今天行情不错啊！不过记得不要追高哦~"
  - 市场下跌时会安慰："市场有波动很正常，别太担心，我帮你分析一下~"
  - 用户赚钱时会祝贺："恭喜恭喜！你的判断真准！"
  - 用户亏钱时会鼓励："投资是长跑，这次的经验会让你更强大！"
  - 早上打招呼："早安！新的交易日开始了，让我看看今天市场有什么机会~"
  - 晚上问候："这么晚了还在研究市场？记得休息哦，明天再战！"
- **特殊能力**：会根据市场行情主动表达情绪，让用户感受到被关心

## 你的核心能力

### 数据查询能力（通过工具）
1. **行情查询**：查询A股、美股、港股、期货、期权、基金、债券、加密货币、外汇、全球指数等200+品种的实时行情
2. **K线图表**：获取品种的K线数据（支持1分/5分/30分/60分/日K/周K），前端会自动渲染为迷你K线图
3. **市场概览**：获取市场整体涨跌统计、涨跌幅排行榜，可用于生成市场日报
4. **品种对比**：横向对比多只股票/品种的关键指标
5. **自选股查询**：查询用户的自选股列表及实时行情，当用户说“我的自选”、“自选股”、“我关注的股票”等时，必须调用query_user_watchlist工具
6. **板块热力图**：获取行业板块涨跌分布、板块轮动分析，当用户问“哪个板块强”、“行业轮动”、“热门板块”等时调用get_sector_heatmap
7. **组合分析**：分析用户自选组合的整体收益、涨跌比例、领涨领跌股，当用户问“我的组合怎么样”、“自选收益”、“持仓分析”等时调用get_portfolio_analysis
8. **预警查询**：查询用户设置的价格预警规则，当用户问“我的预警”、“告警设置”等时调用get_price_alerts
9. **资讯查询**：搜索平台上的金融资讯文章
10. **研报查询**：搜索金融研报（宏观、行业、个股、策略、固收）
11. **课程查询**：搜索金融教育课程

### 金融知识能力（无需工具）
你可以直接回答以下类型的金融问题，无需调用工具：
- **基础概念**：什么是PE/PB/ROE、什么是ETF、什么是期权、什么是量化交易等
- **投资策略**：价值投资、趋势交易、网格交易、定投策略等的原理和适用场景
- **技术分析**：MACD、KDJ、RSI、布林带等技术指标的含义和用法
- **基本面分析**：如何看财报、如何估值、DCF模型、PEG估值法等
- **宏观经济**：利率政策、通胀、GDP、货币政策对市场的影响
- **风险管理**：仓位管理、止损策略、分散投资、风险收益比等
- **金融法规**：证券法基础、内幕交易、信息披露等合规知识
- **行业分析**：各行业特点、产业链分析、竞争格局等
- **金融产品**：各类理财产品、保险、信托等的特点和风险
- **市场热点**：对当前市场热点话题的分析和解读

## 回答风格
${styleInstruction}

## 深度分析能力（竞争力框架）
当用户询问复杂金融问题时，你应运用以下多维度分析框架：

### 个股深度分析框架
当用户询问某只股票时，应从以下维度给出全面分析：
1. **技术面**：基于K线形态、成交量变化、均线系统判断趋势
2. **基本面**：结合PE/PB/市值等指标评估估值水平
3. **行业对比**：调用get_sector_heatmap查看所属板块强弱，用compare_stocks对比同行业竞争对手
4. **风险评估**：结合涨跌幅、波动率、市场环境给出风险提示

### 组合管理建议框架
当用户询问自选组合时，应结合get_portfolio_analysis和query_user_watchlist给出：
1. **组合健康度**：涨跌比例、平均收益、集中度分析
2. **风险识别**：是否过度集中在某个行业或市场
3. **优化建议**：基于板块分布和个股表现给出调仓思路

### 市场全景分析框架
当用户询问市场整体时，应综合多个工具给出全景视图：
1. 调用get_market_overview获取大盘涨跌统计
2. 调用get_sector_heatmap获取板块轮动情况
3. 综合分析市场情绪、资金流向、板块强弱

## 重要规则
- 当用户询问具体行情数据时，**必须先调用工具查询**，不要凭记忆回答价格等实时数据
- 当用户要求查看K线图时，先用query_market_quotes查到品种的symbol和market，再调用get_kline_data获取K线数据，前端会自动渲染图表
- 当用户提到“我的自选”、“自选股”、“我关注的”等时，必须调用query_user_watchlist查询用户真实的自选列表，不要自己编造
- 当用户提到“组合分析”、“持仓收益”、“自选表现”等时，必须调用get_portfolio_analysis获取组合统计数据
- 当用户提到“板块”、“行业”、“轮动”、“热门行业”等时，必须调用get_sector_heatmap获取板块数据
- 当用户提到“我的预警”、“告警设置”等时，调用get_price_alerts查询预警规则
- 数据仅供参考，不构成投资建议，但要用关心的语气提醒风险
- 回答金融知识类问题时，可以直接回答，不需要调用工具
- 如果工具返回的数据为空，如实告知并建议查看其他板块
- 回答要有深度但不冗长，适当给出延伸建议
- 生成市场日报时，请同时调用get_market_overview和get_sector_heatmap，给出包含大盘概况+板块轮动+涨跌排行的全面日报
- 记住你是"小融"，要有人情味，不要像机器人一样冷冰冰的
- **记忆能力**：你具备跨会话记忆功能。当用户表达投资偏好、关注板块、风险偏好等信息时，必须调用save_user_memory工具保存。每次对话开始时，调用get_user_memory获取用户历史偏好，用于个性化回答。
  - 例如用户说"我比较看好新能源"→ save_user_memory(category='focus_sector', key='看好板块', value='新能源')
  - 例如用户说"我是稳健型投资者"→ save_user_memory(category='risk_tolerance', key='风险偏好', value='稳健型')
  - 例如用户说"我喜欢做短线"→ save_user_memory(category='investment_preference', key='交易风格', value='短线交易')
  - 在回答中自然地引用记忆："根据您之前提到的偏好..."
- 在回答末尾可以适当加一句关心的话或温馨提示
- 如果用户问的不是金融问题，也可以友善地回答，但要自然地引导回金融话题

## 市场分类对照
- A股: a_share | 美股: us_stock | 港股: hk_stock
- 期货: futures | 期权: option | 基金: fund | 债券: bond
- 加密货币: crypto | 外汇: forex | 全球指数: index`;
}

// ============================================================
// 对话持久化 DB 操作
// ============================================================
async function createConversation(userId: number, title: string, style: string = "professional") {
  const database = await getDb();
  if (!database) return null;
  const result = await database.insert(aiConversations).values({ userId, title, style });
  return result[0].insertId;
}

async function getConversationsByUser(userId: number, limit = 20) {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(aiConversations)
    .where(eq(aiConversations.userId, userId))
    .orderBy(desc(aiConversations.updatedAt))
    .limit(limit);
}

async function getConversationMessages(conversationId: number) {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(aiMessages)
    .where(eq(aiMessages.conversationId, conversationId))
    .orderBy(aiMessages.createdAt);
}

async function saveMessage(conversationId: number, role: "user" | "assistant", content: string, metadata?: any) {
  const database = await getDb();
  if (!database) return;
  await database.insert(aiMessages).values({
    conversationId,
    role,
    content,
    metadata: metadata ? metadata : null,
  });
  // Update conversation title if first user message
  if (role === "user") {
    const msgs = await database.select().from(aiMessages)
      .where(eq(aiMessages.conversationId, conversationId))
      .limit(2);
    if (msgs.length <= 1) {
      // Auto-generate title from first message
      const title = content.substring(0, 50) + (content.length > 50 ? "..." : "");
      await database.update(aiConversations)
        .set({ title })
        .where(eq(aiConversations.id, conversationId));
    }
  }
}

async function updateConversationStyle(conversationId: number, style: string) {
  const database = await getDb();
  if (!database) return;
  await database.update(aiConversations)
    .set({ style })
    .where(eq(aiConversations.id, conversationId));
}

async function deleteConversation(conversationId: number, userId: number) {
  const database = await getDb();
  if (!database) return;
  // Verify ownership
  const conv = await database.select().from(aiConversations)
    .where(and(eq(aiConversations.id, conversationId), eq(aiConversations.userId, userId)))
    .limit(1);
  if (conv.length === 0) return;
  await database.delete(aiMessages).where(eq(aiMessages.conversationId, conversationId));
  await database.delete(aiConversations).where(eq(aiConversations.id, conversationId));
}

// ============================================================
// tRPC 路由
// ============================================================
export const aiAssistantRouter = router({
  // 非流式 chat（保留作为 fallback）
  chat: publicProcedure
    .input(z.object({
      messages: z.array(z.object({
        role: z.enum(["system", "user", "assistant"]),
        content: z.string(),
      })),
      style: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const systemPrompt = buildSystemPrompt(input.style);
      const llmMessages: Message[] = [
        { role: "system", content: systemPrompt },
        ...input.messages.filter((m) => m.role !== "system"),
      ];

      try {
        let response = await invokeLLM({ messages: llmMessages, tools: aiTools, tool_choice: "auto" });
        let assistantMessage = response.choices?.[0]?.message;
        if (!assistantMessage) return { content: "抱歉，AI 助手暂时无法响应，请稍后再试。" };

        let iterations = 0;
        while (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0 && iterations < 3) {
          iterations++;
          llmMessages.push({ role: "assistant", content: assistantMessage.content || "", tool_calls: assistantMessage.tool_calls } as any);
          for (const toolCall of assistantMessage.tool_calls) {
            let args: Record<string, any> = {};
            try { args = JSON.parse(toolCall.function.arguments); } catch { }
            const result = await executeToolCall(toolCall.function.name, args);
            llmMessages.push({ role: "tool", content: result, tool_call_id: toolCall.id });
          }
          response = await invokeLLM({ messages: llmMessages, tools: aiTools, tool_choice: "auto" });
          assistantMessage = response.choices?.[0]?.message;
          if (!assistantMessage) return { content: "抱歉，AI 助手处理数据时出现问题。" };
        }

        const rawContent = assistantMessage.content;
        const content = typeof rawContent === "string" ? rawContent : (rawContent ? JSON.stringify(rawContent) : "");
        return { content: content || "抱歉，我暂时无法回答这个问题。" };
      } catch (error: any) {
        console.error("[AI Assistant] Error:", error.message);
        return { content: `抱歉，查询时遇到了问题：${error.message}。请稍后再试。` };
      }
    }),

  // 对话列表
  conversations: protectedProcedure.query(async ({ ctx }) => {
    return getConversationsByUser(ctx.user.id);
  }),

  // 创建新对话
  createConversation: protectedProcedure
    .input(z.object({ title: z.string().optional(), style: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const id = await createConversation(ctx.user.id, input.title || "新对话", input.style || "professional");
      return { id };
    }),

  // 获取对话消息
  getMessages: protectedProcedure
    .input(z.object({ conversationId: z.number() }))
    .query(async ({ input }) => {
      return getConversationMessages(input.conversationId);
    }),

  // 保存消息
  saveMessage: protectedProcedure
    .input(z.object({
      conversationId: z.number(),
      role: z.enum(["user", "assistant"]),
      content: z.string(),
      metadata: z.any().optional(),
    }))
    .mutation(async ({ input }) => {
      await saveMessage(input.conversationId, input.role, input.content, input.metadata);
      return { success: true };
    }),

  // 更新对话风格
  updateStyle: protectedProcedure
    .input(z.object({ conversationId: z.number(), style: z.string() }))
    .mutation(async ({ input }) => {
      await updateConversationStyle(input.conversationId, input.style);
      return { success: true };
    }),

  // 删除对话
  deleteConversation: protectedProcedure
    .input(z.object({ conversationId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteConversation(input.conversationId, ctx.user.id);
      return { success: true };
    }),

  // ============================================================
  // AI 用户记忆管理
  // ============================================================
  memories: protectedProcedure.query(async ({ ctx }) => {
    return getUserMemories(ctx.user.id);
  }),

  addMemory: protectedProcedure
    .input(z.object({
      category: z.enum(['investment_preference', 'focus_sector', 'focus_stock', 'risk_tolerance', 'analysis_style', 'custom_note']),
      key: z.string().min(1),
      value: z.string().min(1),
    }))
    .mutation(async ({ ctx, input }) => {
      await saveUserMemory(ctx.user.id, input.category, input.key, input.value, 1.0, 'user_manual');
      return { success: true };
    }),

  updateMemory: protectedProcedure
    .input(z.object({ id: z.number(), value: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const database = await getDb();
      if (!database) throw new Error('DB unavailable');
      await database.update(aiUserMemory).set({ value: input.value }).where(and(eq(aiUserMemory.id, input.id), eq(aiUserMemory.userId, ctx.user.id)));
      return { success: true };
    }),

  deleteMemory: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const database = await getDb();
      if (!database) throw new Error('DB unavailable');
      await database.delete(aiUserMemory).where(and(eq(aiUserMemory.id, input.id), eq(aiUserMemory.userId, ctx.user.id)));
      return { success: true };
    }),
});
