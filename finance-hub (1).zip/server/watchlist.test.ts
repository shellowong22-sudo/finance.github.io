import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the database module
vi.mock("../drizzle/schema", () => ({
  userWatchlist: { id: "id", userId: "userId", symbol: "symbol", name: "name", market: "market", createdAt: "createdAt" },
  marketQuotes: { symbol: "symbol", market: "market" },
}));

vi.mock("./db", () => ({
  getDb: vi.fn(),
}));

describe("Watchlist Feature", () => {
  describe("Data validation", () => {
    it("should validate watchlist add input requires symbol, name, market", () => {
      const validInput = { symbol: "600519.SH", name: "贵州茅台", market: "a_share" };
      expect(validInput.symbol).toBeTruthy();
      expect(validInput.name).toBeTruthy();
      expect(validInput.market).toBeTruthy();
    });

    it("should validate watchlist remove input requires id", () => {
      const validInput = { id: 1 };
      expect(validInput.id).toBeGreaterThan(0);
    });

    it("should validate market types are correct", () => {
      const validMarkets = ["a_share", "us_stock", "hk_stock", "futures", "option", "fund", "bond", "crypto", "forex", "index"];
      expect(validMarkets).toContain("a_share");
      expect(validMarkets).toContain("us_stock");
      expect(validMarkets).toContain("hk_stock");
      expect(validMarkets).toContain("crypto");
    });
  });

  describe("Index overview", () => {
    it("should define main index symbols", () => {
      const mainIndexSymbols = [
        "000001.SH", "399001.SZ", "399006.SZ", "HSI", "DJI",
        "SPX", "IXIC", "N225", "FTSE", "GDAXI",
      ];
      expect(mainIndexSymbols).toHaveLength(10);
      expect(mainIndexSymbols).toContain("000001.SH"); // 上证指数
      expect(mainIndexSymbols).toContain("HSI"); // 恒生指数
      expect(mainIndexSymbols).toContain("DJI"); // 道琼斯
    });
  });

  describe("News service", () => {
    it("should generate news from market data format", () => {
      // Simulate a market quote for news generation
      const mockQuote = {
        symbol: "600519.SH",
        name: "贵州茅台",
        market: "a_share",
        lastPrice: "1800.00",
        changePercent: "3.50",
        volume: 50000,
      };

      // News should contain symbol info
      expect(mockQuote.name).toBeTruthy();
      expect(parseFloat(mockQuote.changePercent)).toBeGreaterThan(0);
    });
  });

  describe("Scheduled refresh", () => {
    it("should have correct refresh interval of 5 minutes", () => {
      const REFRESH_INTERVAL_MS = 300 * 1000; // 5 minutes in ms
      expect(REFRESH_INTERVAL_MS).toBe(300000);
    });
  });

  describe("AI tool integration", () => {
    it("should include watchlist tool in AI tools", async () => {
      // Import the actual tools
      const { aiTools } = await import("./routers/aiAssistant");
      const toolNames = aiTools.map((t: any) => t.function.name);
      expect(toolNames).toContain("query_user_watchlist");
    });

    it("should include watchlist capability in system prompt", async () => {
      const { buildSystemPrompt } = await import("./routers/aiAssistant");
      const prompt = buildSystemPrompt();
      expect(prompt).toContain("自选股");
      expect(prompt).toContain("query_user_watchlist");
    });
  });
});
