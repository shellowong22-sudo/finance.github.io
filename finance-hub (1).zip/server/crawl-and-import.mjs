/**
 * 金融文章爬虫 + AI改写 + 导入数据库脚本
 * 
 * 功能：
 * 1. 爬取新浪财经真实金融文章
 * 2. AI改写：同义词替换、口语化大白话、数字英文保持不变
 * 3. 加入金融模型分析（CAPM、DCF、技术指标等）
 * 4. 导入articles表（已发布状态）
 */

import 'dotenv/config';
import mysql from 'mysql2/promise';
import axios from 'axios';
import * as cheerio from 'cheerio';

const DATABASE_URL = process.env.DATABASE_URL;
const FORGE_API_URL = process.env.BUILT_IN_FORGE_API_URL;
const FORGE_API_KEY = process.env.BUILT_IN_FORGE_API_KEY;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL 未设置');
  process.exit(1);
}

// ============================================================
// 1. 爬取新浪财经文章列表
// ============================================================
async function crawlSinaFinanceList() {
  console.log('📡 正在爬取新浪财经文章列表...');
  const articles = [];
  
  // 多个频道爬取
  const urls = [
    'https://finance.sina.com.cn/stock/',
    'https://finance.sina.com.cn/money/',
    'https://finance.sina.com.cn/china/',
    'https://finance.sina.com.cn/world/',
  ];
  
  for (const url of urls) {
    try {
      const resp = await axios.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        timeout: 15000,
        responseType: 'arraybuffer',
      });
      const html = new TextDecoder('utf-8').decode(resp.data);
      const $ = cheerio.load(html);
      
      $('a').each((_, el) => {
        const href = $(el).attr('href') || '';
        const title = $(el).text().trim();
        if (
          href.includes('finance.sina.com.cn/') &&
          href.includes('.shtml') &&
          title.length >= 8 &&
          title.length <= 80 &&
          !title.includes('视频') &&
          !title.includes('直播') &&
          !title.includes('图片')
        ) {
          articles.push({ title, url: href.startsWith('//') ? 'https:' + href : href });
        }
      });
    } catch (e) {
      console.warn(`⚠️ 爬取 ${url} 失败: ${e.message}`);
    }
  }
  
  // 去重
  const seen = new Set();
  const unique = articles.filter(a => {
    if (seen.has(a.url)) return false;
    seen.add(a.url);
    return true;
  });
  
  console.log(`✅ 找到 ${unique.length} 篇文章链接`);
  return unique.slice(0, 20); // 取前20篇
}

// ============================================================
// 2. 爬取文章正文
// ============================================================
async function crawlArticleContent(url) {
  try {
    const resp = await axios.get(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      timeout: 15000,
      responseType: 'arraybuffer',
    });
    const html = new TextDecoder('utf-8').decode(resp.data);
    const $ = cheerio.load(html);
    
    // 移除脚本和样式
    $('script, style, iframe, .ad, .advertisement').remove();
    
    // 新浪财经文章正文选择器
    let content = '';
    const selectors = ['#artibody', '.article-content', '.art_t', '#article_content', '.article'];
    for (const sel of selectors) {
      const el = $(sel);
      if (el.length && el.text().trim().length > 100) {
        content = el.text().trim();
        break;
      }
    }
    
    if (!content || content.length < 100) {
      // 尝试获取所有段落
      const paragraphs = [];
      $('p').each((_, el) => {
        const text = $(el).text().trim();
        if (text.length > 20 && !text.includes('责任编辑') && !text.includes('海量资讯')) {
          paragraphs.push(text);
        }
      });
      content = paragraphs.join('\n\n');
    }
    
    return content.length > 100 ? content : null;
  } catch (e) {
    console.warn(`⚠️ 爬取正文失败: ${e.message}`);
    return null;
  }
}

// ============================================================
// 3. AI改写 + 金融模型分析
// ============================================================
async function aiRewriteArticle(title, content) {
  if (!FORGE_API_URL || !FORGE_API_KEY) {
    console.warn('⚠️ AI API未配置，跳过改写');
    return null;
  }
  
  const systemPrompt = `你是一位资深金融科普作者，写作风格类似"三分钟学财经"——用大白话、口语化的方式讲解金融知识，让普通人也能看懂。

你的改写规则：
1. **同义词替换**：把原文中的书面语、专业术语换成通俗易懂的说法。例如：
   - "流动性收紧" → "市场上的钱变少了"
   - "估值修复" → "股价从低位慢慢涨回来"
   - "宏观经济承压" → "整体经济形势不太好"
   - "货币政策宽松" → "央行放水，让市场上的钱多起来"
   - "利好出尽" → "好消息都出完了，后面可能没啥涨的动力了"
   - "技术性回调" → "涨多了歇一歇，正常的"
2. **数字和英文保持不变**：所有数字（如3.5%、10000点、2026年）和英文（如GDP、CPI、ETF、A股）原样保留，不做任何修改
3. **口语化表达**：像跟朋友聊天一样写，可以用"说白了"、"简单来说"、"举个例子"、"你想啊"这类口头语
4. **加入金融模型分析**：在文章适当位置插入1-2段金融模型解读，用大白话解释。可以用的模型包括：
   - CAPM模型：用来算一只股票应该值多少钱，风险越大回报应该越高
   - DCF折现模型：把未来能赚的钱折算成今天值多少
   - PE/PB估值法：看股价贵不贵的简单方法
   - 技术指标分析：MACD金叉死叉、KDJ超买超卖、均线系统
   - 行为金融学：为什么散户总是追涨杀跌
   - 资产配置理论：鸡蛋不要放在一个篮子里
5. **保持信息准确**：核心事实、数据不能改，只改表达方式
6. **文章结构**：开头用一句话勾住读者，中间分段讲清楚，结尾给个总结或建议

输出格式要求：
- 返回JSON格式：{"title": "改写后的标题", "content": "改写后的正文", "summary": "一句话摘要", "category": "分类", "tags": "标签1,标签2,标签3"}
- category从以下选择：宏观经济、股票市场、基金理财、债券市场、外汇市场、期货市场、金融科技、投资教育、政策解读、行业分析
- 正文用\\n\\n分段`;

  const userPrompt = `请改写以下金融文章，记住：数字和英文保持不变，用词要通俗易懂、大白话、口语化，并加入金融模型分析。

原标题：${title}

原文内容：
${content.substring(0, 3000)}`;

  try {
    const resp = await axios.post(
      `${FORGE_API_URL}/v1/chat/completions`,
      {
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'rewritten_article',
            strict: true,
            schema: {
              type: 'object',
              properties: {
                title: { type: 'string', description: '改写后的标题' },
                content: { type: 'string', description: '改写后的正文' },
                summary: { type: 'string', description: '一句话摘要' },
                category: { type: 'string', description: '文章分类' },
                tags: { type: 'string', description: '标签，逗号分隔' },
              },
              required: ['title', 'content', 'summary', 'category', 'tags'],
              additionalProperties: false,
            },
          },
        },
      },
      {
        headers: {
          Authorization: `Bearer ${FORGE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        timeout: 60000,
      }
    );
    
    const text = resp.data?.choices?.[0]?.message?.content;
    if (text) {
      return JSON.parse(text);
    }
    return null;
  } catch (e) {
    console.warn(`⚠️ AI改写失败: ${e.message}`);
    return null;
  }
}

// ============================================================
// 4. 导入数据库
// ============================================================
async function importToDatabase(articles) {
  console.log(`\n📥 正在将 ${articles.length} 篇文章导入数据库...`);
  
  const conn = await mysql.createConnection(DATABASE_URL);
  
  let successCount = 0;
  for (const article of articles) {
    try {
      // 检查是否已存在同标题文章
      const [existing] = await conn.execute(
        'SELECT id FROM articles WHERE title = ? LIMIT 1',
        [article.title]
      );
      if (existing.length > 0) {
        console.log(`⏭️ 跳过已存在: ${article.title.substring(0, 30)}...`);
        continue;
      }
      
      // 查找或创建分类
      let categoryId = null;
      if (article.category) {
        const [cats] = await conn.execute(
          'SELECT id FROM article_categories WHERE name = ? LIMIT 1',
          [article.category]
        );
        if (cats.length > 0) {
          categoryId = cats[0].id;
        } else {
          // 生成slug：用拼音或随机字符串
          const catSlug = 'cat-' + Date.now() + '-' + Math.random().toString(36).substring(2, 8);
          const [result] = await conn.execute(
            'INSERT INTO article_categories (name, slug, description) VALUES (?, ?, ?)',
            [article.category, catSlug, `${article.category}相关资讯`]
          );
          categoryId = result.insertId;
        }
      }
      
      // 插入文章（已发布状态）
      await conn.execute(
        `INSERT INTO articles (title, content, summary, authorId, categoryId, status, tags, viewCount, publishedAt, createdAt, updatedAt)
         VALUES (?, ?, ?, 1, ?, 'published', ?, FLOOR(RAND() * 5000) + 100, NOW(), NOW(), NOW())`,
        [
          article.title,
          article.content,
          article.summary || article.title,
          categoryId,
          article.tags || '金融,资讯',
        ]
      );
      successCount++;
      console.log(`✅ [${successCount}] 导入成功: ${article.title.substring(0, 40)}...`);
    } catch (e) {
      console.warn(`⚠️ 导入失败: ${e.message}`);
    }
  }
  
  await conn.end();
  console.log(`\n🎉 导入完成！成功 ${successCount}/${articles.length} 篇`);
  return successCount;
}

// ============================================================
// 主流程
// ============================================================
async function main() {
  console.log('='.repeat(60));
  console.log('🚀 金融文章爬虫 + AI改写 + 导入系统');
  console.log('='.repeat(60));
  
  // Step 1: 爬取文章列表
  const articleLinks = await crawlSinaFinanceList();
  if (articleLinks.length === 0) {
    console.error('❌ 未找到任何文章，退出');
    process.exit(1);
  }
  
  // Step 2: 爬取正文 + AI改写
  const rewrittenArticles = [];
  for (let i = 0; i < articleLinks.length; i++) {
    const link = articleLinks[i];
    console.log(`\n📖 [${i + 1}/${articleLinks.length}] 处理: ${link.title.substring(0, 40)}...`);
    
    // 爬取正文
    const content = await crawlArticleContent(link.url);
    if (!content) {
      console.log('  ⏭️ 正文为空，跳过');
      continue;
    }
    console.log(`  📝 正文长度: ${content.length} 字`);
    
    // AI改写
    console.log('  🤖 AI改写中（同义词替换+口语化+金融模型分析）...');
    const rewritten = await aiRewriteArticle(link.title, content);
    if (rewritten) {
      rewrittenArticles.push(rewritten);
      console.log(`  ✅ 改写完成: ${rewritten.title.substring(0, 40)}...`);
      console.log(`  📊 分类: ${rewritten.category} | 标签: ${rewritten.tags}`);
    } else {
      console.log('  ⚠️ AI改写失败，跳过');
    }
    
    // 控制请求频率
    await new Promise(r => setTimeout(r, 2000));
    
    // 达到10篇就够了
    if (rewrittenArticles.length >= 10) {
      console.log('\n✅ 已收集10篇改写文章，开始导入');
      break;
    }
  }
  
  if (rewrittenArticles.length === 0) {
    console.error('❌ 没有成功改写的文章');
    process.exit(1);
  }
  
  // Step 3: 导入数据库
  const count = await importToDatabase(rewrittenArticles);
  
  console.log('\n' + '='.repeat(60));
  console.log(`🎉 全部完成！共导入 ${count} 篇AI改写的金融资讯文章`);
  console.log('📌 文章特点：同义词替换、口语化大白话、数字英文不变、含金融模型分析');
  console.log('='.repeat(60));
}

main().catch(e => {
  console.error('❌ 执行失败:', e);
  process.exit(1);
});
