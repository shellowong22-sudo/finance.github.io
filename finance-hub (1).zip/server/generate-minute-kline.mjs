import mysql from "mysql2/promise";

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 15 stocks with K-line data
const stocks = [
  { symbol: "600519.SH", market: "a_share", basePrice: 1752, volatility: 0.008 },
  { symbol: "000858.SZ", market: "a_share", basePrice: 129, volatility: 0.012 },
  { symbol: "002475.SZ", market: "a_share", basePrice: 31, volatility: 0.015 },
  { symbol: "002594.SZ", market: "a_share", basePrice: 279, volatility: 0.010 },
  { symbol: "300750.SZ", market: "a_share", basePrice: 200, volatility: 0.013 },
  { symbol: "600036.SH", market: "a_share", basePrice: 34, volatility: 0.009 },
  { symbol: "601318.SH", market: "a_share", basePrice: 48, volatility: 0.010 },
  { symbol: "601899.SH", market: "a_share", basePrice: 19, volatility: 0.014 },
  { symbol: "00700.HK", market: "hk_stock", basePrice: 380, volatility: 0.011 },
  { symbol: "01810.HK", market: "hk_stock", basePrice: 19, volatility: 0.016 },
  { symbol: "09988.HK", market: "hk_stock", basePrice: 82, volatility: 0.013 },
  { symbol: "AAPL", market: "us_stock", basePrice: 204, volatility: 0.009 },
  { symbol: "MSFT", market: "us_stock", basePrice: 413, volatility: 0.008 },
  { symbol: "NVDA", market: "us_stock", basePrice: 861, volatility: 0.015 },
  { symbol: "TSLA", market: "us_stock", basePrice: 176, volatility: 0.018 },
];

// Trading hours by market
function getTradingMinutes(market, period) {
  // A-share: 9:30-11:30, 13:00-15:00 = 240 min/day
  // HK: 9:30-12:00, 13:00-16:00 = 330 min/day
  // US: 9:30-16:00 = 390 min/day
  const minutesPerDay = market === "a_share" ? 240 : market === "hk_stock" ? 330 : 390;
  const periodMinutes = { "1m": 1, "5m": 5, "30m": 30, "1h": 60 };
  return Math.floor(minutesPerDay / periodMinutes[period]);
}

// Generate realistic OHLCV data with random walk
function generateKlineData(stock, period, numDays) {
  const barsPerDay = getTradingMinutes(stock.market, period);
  const periodMinutes = { "1m": 1, "5m": 5, "30m": 30, "1h": 60 };
  const pMin = periodMinutes[period];
  
  // Scale volatility by period
  const volScale = Math.sqrt(pMin);
  const vol = stock.volatility * volScale;
  
  const rows = [];
  let price = stock.basePrice;
  
  // Start from numDays ago
  const now = new Date("2026-04-02T15:00:00+08:00");
  
  for (let d = numDays - 1; d >= 0; d--) {
    const dayDate = new Date(now);
    dayDate.setDate(dayDate.getDate() - d);
    
    // Skip weekends
    const dow = dayDate.getDay();
    if (dow === 0 || dow === 6) continue;
    
    // Trading sessions
    let sessions;
    if (stock.market === "a_share") {
      sessions = [
        { startHour: 9, startMin: 30, endHour: 11, endMin: 30 },
        { startHour: 13, startMin: 0, endHour: 15, endMin: 0 },
      ];
    } else if (stock.market === "hk_stock") {
      sessions = [
        { startHour: 9, startMin: 30, endHour: 12, endMin: 0 },
        { startHour: 13, startMin: 0, endHour: 16, endMin: 0 },
      ];
    } else {
      // US stock - use EST hours but store as UTC-equivalent timestamps
      sessions = [
        { startHour: 9, startMin: 30, endHour: 16, endMin: 0 },
      ];
    }
    
    for (const session of sessions) {
      let h = session.startHour;
      let m = session.startMin;
      
      while (h < session.endHour || (h === session.endHour && m < session.endMin)) {
        // Random walk
        const drift = (Math.random() - 0.5) * 2 * vol * price;
        const open = +price.toFixed(2);
        const intraVol = vol * 0.6;
        const high = +(open + Math.abs(drift) + Math.random() * intraVol * price).toFixed(2);
        const low = +(open - Math.abs(drift) - Math.random() * intraVol * price).toFixed(2);
        const close = +(open + drift).toFixed(2);
        
        price = close > 0 ? close : open; // Ensure positive
        
        // Volume scales with period and price level
        const baseVol = stock.basePrice > 500 ? 5000 : stock.basePrice > 100 ? 20000 : 80000;
        const volume = Math.floor(baseVol * pMin * (0.5 + Math.random()));
        const turnover = +(volume * ((open + close) / 2)).toFixed(2);
        
        // Build timestamp
        const ts = new Date(dayDate);
        ts.setHours(h, m, 0, 0);
        const timestamp = ts.getTime();
        
        rows.push([
          stock.symbol, stock.market, period,
          Math.min(open, high).toFixed(4),
          Math.max(open, close, high).toFixed(4),
          Math.min(open, close, low).toFixed(4),
          close.toFixed(4),
          volume,
          turnover.toFixed(4),
          timestamp,
        ]);
        
        m += pMin;
        while (m >= 60) { m -= 60; h++; }
      }
    }
  }
  
  return rows;
}

// Batch insert helper
async function batchInsert(rows) {
  if (rows.length === 0) return;
  const batchSize = 500;
  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    const placeholders = batch.map(() => "(?,?,?,?,?,?,?,?,?,?)").join(",");
    const values = batch.flat();
    await conn.execute(
      `INSERT INTO kline_data (symbol, market, period, openPrice, highPrice, lowPrice, closePrice, volume, turnover, timestamp) VALUES ${placeholders}`,
      values
    );
  }
}

// Period configs: { period, numDays }
const periodConfigs = [
  { period: "1m", numDays: 2 },    // ~480 bars per stock
  { period: "5m", numDays: 5 },    // ~240 bars per stock
  { period: "30m", numDays: 20 },  // ~160 bars per stock
  { period: "1h", numDays: 20 },   // ~80 bars per stock
];

console.log("开始生成分钟级K线数据...");

let totalRows = 0;
for (const config of periodConfigs) {
  let periodRows = 0;
  for (const stock of stocks) {
    const rows = generateKlineData(stock, config.period, config.numDays);
    await batchInsert(rows);
    periodRows += rows.length;
    process.stdout.write(".");
  }
  totalRows += periodRows;
  console.log(`\n${config.period}: ${periodRows} 条数据已插入`);
}

console.log(`\n总计插入 ${totalRows} 条分钟级K线数据`);

// Verify
const [counts] = await conn.execute(
  "SELECT period, COUNT(*) as cnt FROM kline_data WHERE period IN ('1m','5m','30m','1h') GROUP BY period ORDER BY period"
);
console.log("验证结果:", JSON.stringify(counts));

await conn.end();
console.log("完成！");
