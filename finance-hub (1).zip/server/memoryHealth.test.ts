import { describe, it, expect, vi, beforeEach } from "vitest";

// ============================================================
// 1. Exponential Backoff Strategy Tests
// ============================================================
describe("Exponential Backoff Strategy", () => {
  it("should define backoff levels with increasing intervals", () => {
    // Backoff levels: 5min -> 10min -> 20min -> 30min -> 60min
    const BACKOFF_INTERVALS = [5 * 60 * 1000, 10 * 60 * 1000, 20 * 60 * 1000, 30 * 60 * 1000, 60 * 60 * 1000];
    expect(BACKOFF_INTERVALS).toHaveLength(5);
    for (let i = 1; i < BACKOFF_INTERVALS.length; i++) {
      expect(BACKOFF_INTERVALS[i]).toBeGreaterThan(BACKOFF_INTERVALS[i - 1]);
    }
  });

  it("should cap backoff level at max level", () => {
    const MAX_BACKOFF_LEVEL = 4;
    let level = 0;
    // Simulate 10 consecutive failures
    for (let i = 0; i < 10; i++) {
      level = Math.min(level + 1, MAX_BACKOFF_LEVEL);
    }
    expect(level).toBe(MAX_BACKOFF_LEVEL);
  });

  it("should reset backoff on successful refresh", () => {
    let level = 3;
    let consecutiveFailures = 5;
    // Simulate success
    level = 0;
    consecutiveFailures = 0;
    expect(level).toBe(0);
    expect(consecutiveFailures).toBe(0);
  });

  it("should detect quota exhaustion from error messages", () => {
    const quotaErrors = [
      "usage exhausted",
      "rate limit exceeded",
      "quota exceeded",
      "too many requests",
    ];
    const isQuotaError = (msg: string) => quotaErrors.some(e => msg.toLowerCase().includes(e));
    
    expect(isQuotaError("your account has hit a usage exhausted")).toBe(true);
    expect(isQuotaError("Rate Limit Exceeded")).toBe(true);
    expect(isQuotaError("Network timeout")).toBe(false);
  });
});

// ============================================================
// 2. System Health Status Tests
// ============================================================
describe("System Health Status", () => {
  it("should return healthy when data is fresh and no backoff", () => {
    const getStatus = (minutesSinceRefresh: number, backoffLevel: number) => {
      if (backoffLevel >= 3) return "warning";
      if (minutesSinceRefresh > 30 || backoffLevel >= 1) return "degraded";
      return "healthy";
    };

    expect(getStatus(2, 0)).toBe("healthy");
    expect(getStatus(5, 0)).toBe("healthy");
  });

  it("should return degraded when data is stale or backoff is active", () => {
    const getStatus = (minutesSinceRefresh: number, backoffLevel: number) => {
      if (backoffLevel >= 3) return "warning";
      if (minutesSinceRefresh > 30 || backoffLevel >= 1) return "degraded";
      return "healthy";
    };

    expect(getStatus(35, 0)).toBe("degraded");
    expect(getStatus(5, 1)).toBe("degraded");
  });

  it("should return warning when backoff level is high", () => {
    const getStatus = (minutesSinceRefresh: number, backoffLevel: number) => {
      if (backoffLevel >= 3) return "warning";
      if (minutesSinceRefresh > 30 || backoffLevel >= 1) return "degraded";
      return "healthy";
    };

    expect(getStatus(5, 3)).toBe("warning");
    expect(getStatus(60, 4)).toBe("warning");
  });

  it("should determine data freshness correctly", () => {
    const getFreshness = (minutes: number | null) => {
      if (minutes === null) return "unknown";
      if (minutes <= 10) return "fresh";
      if (minutes <= 30) return "stale";
      return "outdated";
    };

    expect(getFreshness(null)).toBe("unknown");
    expect(getFreshness(5)).toBe("fresh");
    expect(getFreshness(15)).toBe("stale");
    expect(getFreshness(60)).toBe("outdated");
  });
});

// ============================================================
// 3. AI User Memory Tests
// ============================================================
describe("AI User Memory", () => {
  it("should validate memory categories", () => {
    const validCategories = [
      "investment_preference",
      "focus_sector",
      "focus_stock",
      "risk_tolerance",
      "analysis_style",
      "custom_note",
    ];

    expect(validCategories).toContain("investment_preference");
    expect(validCategories).toContain("focus_sector");
    expect(validCategories).toContain("risk_tolerance");
    expect(validCategories).not.toContain("invalid_category");
  });

  it("should support upsert logic for memory", () => {
    // Simulate upsert: if same key exists, update; otherwise insert
    const memories: Array<{ category: string; key: string; value: string }> = [];
    
    const upsert = (category: string, key: string, value: string) => {
      const idx = memories.findIndex(m => m.category === category && m.key === key);
      if (idx >= 0) {
        memories[idx].value = value;
      } else {
        memories.push({ category, key, value });
      }
    };

    upsert("focus_sector", "看好板块", "新能源");
    expect(memories).toHaveLength(1);
    expect(memories[0].value).toBe("新能源");

    upsert("focus_sector", "看好板块", "半导体");
    expect(memories).toHaveLength(1);
    expect(memories[0].value).toBe("半导体");

    upsert("risk_tolerance", "风险偏好", "稳健型");
    expect(memories).toHaveLength(2);
  });

  it("should filter memories by category", () => {
    const memories = [
      { category: "focus_sector", key: "看好板块", value: "新能源" },
      { category: "risk_tolerance", key: "风险偏好", value: "稳健型" },
      { category: "focus_sector", key: "看好板块2", value: "半导体" },
      { category: "investment_preference", key: "交易风格", value: "短线" },
    ];

    const filtered = memories.filter(m => m.category === "focus_sector");
    expect(filtered).toHaveLength(2);
    expect(filtered[0].value).toBe("新能源");
    expect(filtered[1].value).toBe("半导体");
  });

  it("should support memory source tracking", () => {
    const sources = ["ai_extracted", "user_manual"];
    
    const aiMemory = { source: "ai_extracted", key: "看好板块", value: "新能源" };
    const userMemory = { source: "user_manual", key: "风险偏好", value: "激进型" };
    
    expect(sources).toContain(aiMemory.source);
    expect(sources).toContain(userMemory.source);
  });

  it("should format memory for AI system prompt injection", () => {
    const memories = [
      { category: "focus_sector", key: "看好板块", value: "新能源" },
      { category: "risk_tolerance", key: "风险偏好", value: "稳健型" },
    ];

    const formatted = memories.map(m => `${m.key}: ${m.value}`).join("; ");
    expect(formatted).toBe("看好板块: 新能源; 风险偏好: 稳健型");
    expect(formatted).toContain("新能源");
    expect(formatted).toContain("稳健型");
  });
});

// ============================================================
// 4. Tool Name Map Tests
// ============================================================
describe("Tool Name Map", () => {
  it("should include memory tools in the map", () => {
    const TOOL_NAME_MAP: Record<string, string> = {
      query_market_quotes: "行情数据",
      get_kline_data: "K线图表",
      save_user_memory: "记忆存储",
      get_user_memory: "记忆读取",
    };

    expect(TOOL_NAME_MAP.save_user_memory).toBe("记忆存储");
    expect(TOOL_NAME_MAP.get_user_memory).toBe("记忆读取");
  });
});
