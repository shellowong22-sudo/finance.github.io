import { Router, Request, Response } from "express";
import { invokeLLMStream, type StreamChunk } from "../_core/llmStream";
import { aiTools, executeToolCall, buildSystemPrompt } from "../routers/aiAssistant";
import type { Message } from "../_core/llm";
import { sdk } from "../_core/sdk";

const router = Router();

/**
 * SSE endpoint for AI assistant streaming.
 * POST /api/ai-assistant/stream
 * Body: { messages: [{ role, content }], style?: string, conversationId?: number }
 *
 * SSE events:
 * - data: {"type":"content","text":"..."} — content delta
 * - data: {"type":"tool_start","name":"..."} — tool call started (for UI status)
 * - data: {"type":"tool_end","name":"...","success":true} — tool call completed
 * - data: {"type":"kline","data":{...}} — K-line data for chart rendering
 * - data: {"type":"done"} — stream finished
 * - data: {"type":"error","message":"..."} — error
 */
router.post("/api/ai-assistant/stream", async (req: Request, res: Response) => {
  // Set SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const sendEvent = (data: Record<string, unknown>) => {
    if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    }
  };

  try {
    const { messages, style } = req.body;
    // Extract userId from JWT cookie for watchlist queries
    let userId: number | undefined;
    try {
      const sessionUser = await sdk.authenticateRequest(req);
      userId = sessionUser?.id;
    } catch { /* not logged in */ }
    if (!messages || !Array.isArray(messages)) {
      sendEvent({ type: "error", message: "Invalid request: messages required" });
      res.end();
      return;
    }

    // Build LLM messages with dynamic system prompt based on style
    const systemPrompt = buildSystemPrompt(style || "professional");
    const llmMessages: Message[] = [
      { role: "system", content: systemPrompt },
      ...messages
        .filter((m: any) => m.role !== "system")
        .map((m: any) => ({ role: m.role, content: m.content })),
    ];

    const MAX_ITERATIONS = 5;

    for (let iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
      console.log(`[AI Stream] Iteration ${iteration + 1}, messages count: ${llmMessages.length}`);

      let hasToolCalls = false;
      let accumulatedContent = "";

      for await (const chunk of invokeLLMStream({
        messages: llmMessages,
        tools: aiTools,
        tool_choice: "auto",
      })) {
        switch (chunk.type) {
          case "content_delta":
            accumulatedContent += chunk.content;
            sendEvent({ type: "content", text: chunk.content });
            break;

          case "tool_calls": {
            hasToolCalls = true;
            console.log(`[AI Stream] Tool calls received:`, chunk.toolCalls.map(tc => tc.function.name));

            // Add assistant message with tool_calls to context
            llmMessages.push({
              role: "assistant",
              content: accumulatedContent || "",
              // @ts-ignore
              tool_calls: chunk.toolCalls,
            } as any);

            // Execute each tool call
            for (const toolCall of chunk.toolCalls) {
              sendEvent({ type: "tool_start", name: toolCall.function.name });

              let args: Record<string, any> = {};
              try {
                args = JSON.parse(toolCall.function.arguments);
              } catch { /* empty args */ }

              console.log(`[AI Stream] Executing tool: ${toolCall.function.name}`, args);
              const result = await executeToolCall(toolCall.function.name, args, userId);
              console.log(`[AI Stream] Tool result length: ${result.length}`);

              // If this is K-line data, send it as a separate event for chart rendering
              try {
                const parsed = JSON.parse(result);
                console.log(`[AI Stream] Parsed tool result: _kline=${parsed._kline}, data_length=${parsed.data?.length}`);
                if (parsed._kline && parsed.data && parsed.data.length > 0) {
                  console.log(`[AI Stream] Sending kline event for ${parsed.symbol}`);
                  sendEvent({
                    type: "kline",
                    data: {
                      symbol: parsed.symbol,
                      market: parsed.market,
                      period: parsed.period,
                      klineData: parsed.data,
                    },
                  });
                }
              } catch (e) { console.log(`[AI Stream] Parse error:`, e); }

              llmMessages.push({
                role: "tool",
                content: result,
                tool_call_id: toolCall.id,
              });

              sendEvent({ type: "tool_end", name: toolCall.function.name, success: true });
            }

            // Reset accumulated content for next iteration
            accumulatedContent = "";
            break;
          }

          case "error":
            console.error(`[AI Stream] Error from LLM:`, chunk.error);
            sendEvent({ type: "error", message: chunk.error });
            res.end();
            return;

          case "done":
            console.log(`[AI Stream] Stream done. hasToolCalls: ${hasToolCalls}, content length: ${accumulatedContent.length}`);
            // If no tool calls in this iteration, we're done
            if (!hasToolCalls) {
              sendEvent({ type: "done" });
              res.end();
              return;
            }
            // Otherwise, continue to next iteration to get final answer
            break;
        }
      }

      // If the for-await loop ended without tool_calls, we're done
      if (!hasToolCalls) {
        sendEvent({ type: "done" });
        res.end();
        return;
      }

      console.log(`[AI Stream] Continuing to iteration ${iteration + 2} after tool calls`);
    }

    // Max iterations reached
    console.log("[AI Stream] Max iterations reached");
    sendEvent({ type: "done" });
    res.end();
  } catch (error: any) {
    console.error("[AI Stream] Error:", error);
    sendEvent({ type: "error", message: error.message || "Internal server error" });
    if (!res.writableEnded) res.end();
  }
});

export default router;
