import { Router } from "express";
import { storagePut } from "../storage";
import { transcribeAudio } from "../_core/voiceTranscription";
import { ENV } from "../_core/env";
import { nanoid } from "nanoid";

const voiceRouter = Router();

// ============================================================
// POST /api/voice/transcribe - 语音转文字
// 接收 base64 编码的音频数据，上传到 S3，然后调用 Whisper 转文字
// ============================================================
voiceRouter.post("/api/voice/transcribe", async (req, res) => {
  try {
    const { audioData, mimeType = "audio/webm" } = req.body;

    if (!audioData) {
      return res.status(400).json({ error: "缺少音频数据" });
    }

    // Decode base64 audio
    const audioBuffer = Buffer.from(audioData, "base64");

    // Check file size (16MB limit)
    const sizeMB = audioBuffer.length / (1024 * 1024);
    if (sizeMB > 16) {
      return res.status(400).json({ error: "音频文件过大，最大支持 16MB" });
    }

    // Upload to S3
    const ext = mimeType.includes("webm") ? "webm" : mimeType.includes("mp3") ? "mp3" : "wav";
    const fileKey = `voice/${nanoid()}.${ext}`;
    const { url: audioUrl } = await storagePut(fileKey, audioBuffer, mimeType);

    // Transcribe
    const result = await transcribeAudio({
      audioUrl,
      language: "zh",
      prompt: "金融相关对话，可能包含股票代码、基金名称、金融术语",
    });

    if ("error" in result) {
      return res.status(500).json({ error: result.error, code: result.code });
    }

    return res.json({
      text: result.text,
      language: result.language,
      duration: result.duration,
    });
  } catch (error: any) {
    console.error("[Voice Transcribe] Error:", error.message);
    return res.status(500).json({ error: "语音识别失败，请稍后再试" });
  }
});

// ============================================================
// POST /api/voice/tts - 文字转语音（TTS）
// 使用 Forge API 的 TTS 端点生成语音
// ============================================================
voiceRouter.post("/api/voice/tts", async (req, res) => {
  try {
    const { text, voice = "alloy", speed = 1.0 } = req.body;

    if (!text) {
      return res.status(400).json({ error: "缺少文本内容" });
    }

    // Truncate text to reasonable length for TTS
    const truncatedText = text.substring(0, 2000);

    const baseUrl = ENV.forgeApiUrl?.replace(/\/+$/, "");
    const apiKey = ENV.forgeApiKey;

    if (!baseUrl || !apiKey) {
      return res.status(500).json({ error: "TTS 服务未配置" });
    }

    const ttsResponse = await fetch(`${baseUrl}/v1/audio/speech`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "tts-1",
        input: truncatedText,
        voice,
        speed,
        response_format: "mp3",
      }),
    });

    if (!ttsResponse.ok) {
      const errText = await ttsResponse.text().catch(() => "");
      console.error("[TTS] API error:", ttsResponse.status, errText);
      return res.status(500).json({ error: "语音合成失败" });
    }

    // Stream the audio response back
    const audioBuffer = Buffer.from(await ttsResponse.arrayBuffer());

    // Upload to S3 for URL access
    const fileKey = `tts/${nanoid()}.mp3`;
    const { url: audioUrl } = await storagePut(fileKey, audioBuffer, "audio/mpeg");

    return res.json({ audioUrl, duration: null });
  } catch (error: any) {
    console.error("[TTS] Error:", error.message);
    return res.status(500).json({ error: "语音合成失败，请稍后再试" });
  }
});

export default voiceRouter;
