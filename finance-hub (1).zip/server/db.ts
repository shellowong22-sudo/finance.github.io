import { and, desc, eq, ilike, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2";
import {
  InsertUser,
  articleCategories,
  articles,
  auditLogs,
  certificates,
  channelSettlements,
  channels,
  comments,
  courseChapters,
  coursePurchases,
  courseProgress,
  courseReviews,
  courses,
  crawledArticles,
  examQuestions,
  examRecords,
  follows,
  instructors,
  likes,
  messages,
  promoLinks,
  reportDownloads,
  reportFavorites,
  reportReadLogs,
  reports,
  sensitiveWords,
  userStats,
  users,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;
let _pool: mysql.Pool | null = null;

function createDbPool() {
  if (_pool) {
    try { _pool.end(); } catch {}
  }
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) return null;
  _pool = mysql.createPool({
    uri: dbUrl,
    waitForConnections: true,
    connectionLimit: 10,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
  });
  _db = drizzle(_pool);
  return _db;
}

export async function getDb() {
  if (!_db) {
    try {
      createDbPool();
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Reset DB connection pool (call on ECONNRESET or similar errors)
 */
export function resetDbConnection() {
  console.log("[Database] Resetting connection pool...");
  _db = null;
  if (_pool) {
    try { _pool.end(); } catch {}
    _pool = null;
  }
}

// ============================================================
// 用户相关
// ============================================================
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required");
  const db = await getDb();
  if (!db) return;

  const { ENV } = await import("./_core/env");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }

  if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getAllUsers(page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db.select().from(users).orderBy(desc(users.createdAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(users);
  return { data, total: Number(count) };
}

export async function updateUserStatus(userId: number, status: "active" | "banned" | "pending") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ status }).where(eq(users.id, userId));
}

export async function updateUserRole(userId: number, role: "user" | "admin" | "channel") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ============================================================
// 文章相关
// ============================================================
export async function getArticles(opts: {
  page?: number;
  limit?: number;
  status?: string;
  keyword?: string;
  categoryId?: number;
  isTop?: boolean;
}) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const { page = 1, limit = 10, status, keyword, categoryId, isTop } = opts;
  const offset = (page - 1) * limit;

  const conditions = [];
  if (status) conditions.push(eq(articles.status, status as any));
  if (keyword) conditions.push(or(like(articles.title, `%${keyword}%`), like(articles.summary, `%${keyword}%`)));
  if (categoryId) conditions.push(eq(articles.categoryId, categoryId));
  if (isTop !== undefined) conditions.push(eq(articles.isTop, isTop));

  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const data = await db.select().from(articles).where(where).orderBy(desc(articles.isPinned), desc(articles.publishedAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(articles).where(where);
  return { data, total: Number(count) };
}

export async function getArticleById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
  return result[0];
}

export async function createArticle(data: typeof articles.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(articles).values(data);
  return result;
}

export async function updateArticle(id: number, data: Partial<typeof articles.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(articles).set(data).where(eq(articles.id, id));
}

export async function incrementArticleView(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(articles).set({ viewCount: sql`viewCount + 1` }).where(eq(articles.id, id));
}

// ============================================================
// 评论相关
// ============================================================
export async function getComments(articleId: number, page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db
    .select()
    .from(comments)
    .where(and(eq(comments.articleId, articleId), eq(comments.status, "active")))
    .orderBy(desc(comments.createdAt))
    .limit(limit)
    .offset(offset);
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(comments)
    .where(and(eq(comments.articleId, articleId), eq(comments.status, "active")));
  return { data, total: Number(count) };
}

export async function createComment(data: typeof comments.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(comments).values(data);
}

// ============================================================
// 点赞相关
// ============================================================
export async function toggleLike(userId: number, targetType: string, targetId: number) {
  const db = await getDb();
  if (!db) return { liked: false };
  const existing = await db
    .select()
    .from(likes)
    .where(and(eq(likes.userId, userId), eq(likes.targetType, targetType as any), eq(likes.targetId, targetId)))
    .limit(1);
  if (existing.length > 0) {
    await db.delete(likes).where(eq(likes.id, existing[0].id));
    return { liked: false };
  } else {
    await db.insert(likes).values({ userId, targetType: targetType as any, targetId });
    return { liked: true };
  }
}

export async function checkLiked(userId: number, targetType: string, targetId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select()
    .from(likes)
    .where(and(eq(likes.userId, userId), eq(likes.targetType, targetType as any), eq(likes.targetId, targetId)))
    .limit(1);
  return result.length > 0;
}

// ============================================================
// 关注相关
// ============================================================
export async function toggleFollow(followerId: number, followingId: number) {
  const db = await getDb();
  if (!db) return { followed: false };
  const existing = await db
    .select()
    .from(follows)
    .where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)))
    .limit(1);
  if (existing.length > 0) {
    await db.delete(follows).where(eq(follows.id, existing[0].id));
    return { followed: false };
  } else {
    await db.insert(follows).values({ followerId, followingId });
    return { followed: true };
  }
}

export async function getFollowStats(userId: number) {
  const db = await getDb();
  if (!db) return { followers: 0, following: 0 };
  const [{ followers }] = await db.select({ followers: sql<number>`count(*)` }).from(follows).where(eq(follows.followingId, userId));
  const [{ following }] = await db.select({ following: sql<number>`count(*)` }).from(follows).where(eq(follows.followerId, userId));
  return { followers: Number(followers), following: Number(following) };
}

// ============================================================
// 私信相关
// ============================================================
export async function getMessages(userId: number, page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db
    .select()
    .from(messages)
    .where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)))
    .orderBy(desc(messages.createdAt))
    .limit(limit)
    .offset(offset);
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(messages)
    .where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)));
  return { data, total: Number(count) };
}

export async function sendMessage(data: typeof messages.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(messages).values(data);
}

// ============================================================
// 研报相关
// ============================================================
export async function getReports(opts: {
  page?: number;
  limit?: number;
  status?: string;
  category?: string;
  keyword?: string;
  isPaid?: boolean;
}) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const { page = 1, limit = 10, status, category, keyword, isPaid } = opts;
  const offset = (page - 1) * limit;

  const conditions = [];
  if (status) conditions.push(eq(reports.status, status as any));
  if (category) conditions.push(eq(reports.category, category as any));
  if (keyword) conditions.push(like(reports.title, `%${keyword}%`));
  if (isPaid !== undefined) conditions.push(eq(reports.isPaid, isPaid));

  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const data = await db.select().from(reports).where(where).orderBy(desc(reports.publishedAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(reports).where(where);
  return { data, total: Number(count) };
}

export async function getReportById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(reports).where(eq(reports.id, id)).limit(1);
  return result[0];
}

export async function createReport(data: typeof reports.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(reports).values(data);
}

export async function updateReport(id: number, data: Partial<typeof reports.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(reports).set(data).where(eq(reports.id, id));
}

export async function checkReportPurchased(userId: number, reportId: number) {
  // 研报购买通过likes表模拟，实际应有单独的report_purchases表
  return false;
}

export async function toggleReportFavorite(userId: number, reportId: number) {
  const db = await getDb();
  if (!db) return { favorited: false };
  const existing = await db
    .select()
    .from(reportFavorites)
    .where(and(eq(reportFavorites.userId, userId), eq(reportFavorites.reportId, reportId)))
    .limit(1);
  if (existing.length > 0) {
    await db.delete(reportFavorites).where(eq(reportFavorites.id, existing[0].id));
    await db.update(reports).set({ favoriteCount: sql`favoriteCount - 1` }).where(eq(reports.id, reportId));
    return { favorited: false };
  } else {
    await db.insert(reportFavorites).values({ userId, reportId });
    await db.update(reports).set({ favoriteCount: sql`favoriteCount + 1` }).where(eq(reports.id, reportId));
    return { favorited: true };
  }
}

export async function recordReportDownload(userId: number, reportId: number, ipAddress?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(reportDownloads).values({ userId, reportId, ipAddress });
  await db.update(reports).set({ downloadCount: sql`downloadCount + 1` }).where(eq(reports.id, reportId));
}

export async function recordReportReadLog(userId: number, reportId: number, duration: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(reportReadLogs).values({ userId, reportId, duration });
  await db.update(reports).set({ totalReadDuration: sql`totalReadDuration + ${duration}` }).where(eq(reports.id, reportId));
}

// ============================================================
// 课程相关
// ============================================================
export async function getCourses(opts: {
  page?: number;
  limit?: number;
  status?: string;
  category?: string;
  keyword?: string;
}) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const { page = 1, limit = 10, status, category, keyword } = opts;
  const offset = (page - 1) * limit;

  const conditions = [];
  if (status) conditions.push(eq(courses.status, status as any));
  if (category) conditions.push(eq(courses.category, category as any));
  if (keyword) conditions.push(like(courses.title, `%${keyword}%`));

  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const data = await db.select().from(courses).where(where).orderBy(desc(courses.publishedAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(courses).where(where);
  return { data, total: Number(count) };
}

export async function getCourseById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(courses).where(eq(courses.id, id)).limit(1);
  return result[0];
}

export async function createCourse(data: typeof courses.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(courses).values(data);
}

export async function updateCourse(id: number, data: Partial<typeof courses.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(courses).set(data).where(eq(courses.id, id));
}

export async function checkCoursePurchased(userId: number, courseId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select()
    .from(coursePurchases)
    .where(and(eq(coursePurchases.userId, userId), eq(coursePurchases.courseId, courseId), eq(coursePurchases.status, "active")))
    .limit(1);
  return result.length > 0;
}

export async function purchaseCourse(userId: number, courseId: number, price: string, channelId?: number, promoCode?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(coursePurchases).values({ userId, courseId, price, channelId, promoCode });
  await db.update(courses).set({ studentCount: sql`studentCount + 1` }).where(eq(courses.id, courseId));
}

export async function getCourseChapters(courseId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(courseChapters).where(eq(courseChapters.courseId, courseId)).orderBy(courseChapters.sortOrder);
}

export async function saveCourseProgress(userId: number, courseId: number, chapterId: number, progress: number, watchedDuration: number) {
  const db = await getDb();
  if (!db) return;
  const existing = await db
    .select()
    .from(courseProgress)
    .where(and(eq(courseProgress.userId, userId), eq(courseProgress.chapterId, chapterId)))
    .limit(1);
  if (existing.length > 0) {
    await db
      .update(courseProgress)
      .set({ progress, watchedDuration, isCompleted: progress >= 100, lastWatchedAt: new Date() })
      .where(eq(courseProgress.id, existing[0].id));
  } else {
    await db.insert(courseProgress).values({ userId, courseId, chapterId, progress, watchedDuration, isCompleted: progress >= 100 });
  }
}

export async function getExamQuestions(courseId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(examQuestions).where(eq(examQuestions.courseId, courseId)).orderBy(examQuestions.sortOrder);
}

export async function submitExam(userId: number, courseId: number, answers: Record<string, string[]>, duration: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const questions = await getExamQuestions(courseId);
  let score = 0;
  let totalScore = 0;
  for (const q of questions) {
    totalScore += q.score;
    const correctAnswers: string[] = JSON.parse(q.answer);
    const userAnswers = answers[q.id] || [];
    if (JSON.stringify(userAnswers.sort()) === JSON.stringify(correctAnswers.sort())) {
      score += q.score;
    }
  }
  const isPassed = score >= 60;
  const result = await db.insert(examRecords).values({
    userId,
    courseId,
    answers: JSON.stringify(answers),
    score,
    totalScore,
    isPassed,
    passScore: 60,
    duration,
  });
  return { score, totalScore, isPassed, examRecordId: (result as any).insertId };
}

export async function issueCertificate(userId: number, courseId: number, examRecordId?: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db
    .select()
    .from(certificates)
    .where(and(eq(certificates.userId, userId), eq(certificates.courseId, courseId)))
    .limit(1);
  if (existing.length > 0) return existing[0];
  const certificateNo = `CERT-${Date.now()}-${userId}-${courseId}`;
  await db.insert(certificates).values({ userId, courseId, examRecordId, certificateNo });
  const result = await db.select().from(certificates).where(eq(certificates.certificateNo, certificateNo)).limit(1);
  return result[0];
}

export async function getCourseReviews(courseId: number, page = 1, limit = 10) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db
    .select()
    .from(courseReviews)
    .where(and(eq(courseReviews.courseId, courseId), eq(courseReviews.status, "active")))
    .orderBy(desc(courseReviews.createdAt))
    .limit(limit)
    .offset(offset);
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(courseReviews)
    .where(and(eq(courseReviews.courseId, courseId), eq(courseReviews.status, "active")));
  return { data, total: Number(count) };
}

export async function submitCourseReview(userId: number, courseId: number, rating: number, content?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(courseReviews).values({ userId, courseId, rating, content });
  // 更新课程评分
  const [{ avg }] = await db
    .select({ avg: sql<number>`avg(rating)` })
    .from(courseReviews)
    .where(eq(courseReviews.courseId, courseId));
  const [{ cnt }] = await db
    .select({ cnt: sql<number>`count(*)` })
    .from(courseReviews)
    .where(eq(courseReviews.courseId, courseId));
  await db.update(courses).set({ rating: String(Number(avg).toFixed(2)) as any, ratingCount: Number(cnt) }).where(eq(courses.id, courseId));
}

export async function refundCourse(userId: number, courseId: number, reason: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const purchase = await db
    .select()
    .from(coursePurchases)
    .where(and(eq(coursePurchases.userId, userId), eq(coursePurchases.courseId, courseId), eq(coursePurchases.status, "active")))
    .limit(1);
  if (purchase.length === 0) throw new Error("No active purchase found");
  await db
    .update(coursePurchases)
    .set({ status: "refunded", refundReason: reason, refundedAt: new Date() })
    .where(eq(coursePurchases.id, purchase[0].id));
  await db.update(courses).set({ studentCount: sql`studentCount - 1` }).where(eq(courses.id, courseId));
}

// ============================================================
// 渠道合作相关
// ============================================================
export async function getChannels(opts: { page?: number; limit?: number; status?: string }) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const { page = 1, limit = 10, status } = opts;
  const offset = (page - 1) * limit;
  const where = status ? eq(channels.status, status as any) : undefined;
  const data = await db.select().from(channels).where(where).orderBy(desc(channels.createdAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(channels).where(where);
  return { data, total: Number(count) };
}

export async function getChannelById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(channels).where(eq(channels.id, id)).limit(1);
  return result[0];
}

export async function getChannelByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(channels).where(eq(channels.userId, userId)).limit(1);
  return result[0];
}

export async function createChannel(data: typeof channels.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(channels).values(data);
}

export async function updateChannel(id: number, data: Partial<typeof channels.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(channels).set(data).where(eq(channels.id, id));
}

export async function createPromoLink(channelId: number, targetType: string, targetId?: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const code = `CH${channelId}-${Date.now().toString(36).toUpperCase()}`;
  await db.insert(promoLinks).values({ channelId, code, targetType: targetType as any, targetId });
  const result = await db.select().from(promoLinks).where(eq(promoLinks.code, code)).limit(1);
  return result[0];
}

export async function getPromoLinks(channelId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(promoLinks).where(eq(promoLinks.channelId, channelId)).orderBy(desc(promoLinks.createdAt));
}

export async function getChannelSettlements(channelId: number, page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db
    .select()
    .from(channelSettlements)
    .where(eq(channelSettlements.channelId, channelId))
    .orderBy(desc(channelSettlements.createdAt))
    .limit(limit)
    .offset(offset);
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(channelSettlements)
    .where(eq(channelSettlements.channelId, channelId));
  return { data, total: Number(count) };
}

// ============================================================
// 敏感词过滤
// ============================================================
export async function getSensitiveWords() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sensitiveWords);
}

export async function checkSensitiveWords(content: string): Promise<{ hasSensitive: boolean; words: string[]; level: string }> {
  const db = await getDb();
  if (!db) return { hasSensitive: false, words: [], level: "none" };
  const wordList = await db.select().from(sensitiveWords);
  const found: string[] = [];
  let maxLevel = "none";
  for (const sw of wordList) {
    if (content.includes(sw.word)) {
      found.push(sw.word);
      if (sw.level === "block") maxLevel = "block";
      else if (sw.level === "review" && maxLevel !== "block") maxLevel = "review";
      else if (sw.level === "warn" && maxLevel === "none") maxLevel = "warn";
    }
  }
  return { hasSensitive: found.length > 0, words: found, level: maxLevel };
}

export async function addSensitiveWord(word: string, category: string, level: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(sensitiveWords).values({ word, category: category as any, level: level as any });
}

// ============================================================
// 讲师相关
// ============================================================
export async function getInstructors(page = 1, limit = 10) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db.select().from(instructors).where(eq(instructors.status, "active")).orderBy(desc(instructors.courseCount)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(instructors).where(eq(instructors.status, "active"));
  return { data, total: Number(count) };
}

export async function createInstructor(data: typeof instructors.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(instructors).values(data);
}

// ============================================================
// 管理员统计
// ============================================================
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return {};
  const [{ totalUsers }] = await db.select({ totalUsers: sql<number>`count(*)` }).from(users);
  const [{ totalArticles }] = await db.select({ totalArticles: sql<number>`count(*)` }).from(articles).where(eq(articles.status, "published"));
  const [{ totalReports }] = await db.select({ totalReports: sql<number>`count(*)` }).from(reports).where(eq(reports.status, "published"));
  const [{ totalCourses }] = await db.select({ totalCourses: sql<number>`count(*)` }).from(courses).where(eq(courses.status, "published"));
  const [{ pendingArticles }] = await db.select({ pendingArticles: sql<number>`count(*)` }).from(articles).where(eq(articles.status, "pending"));
  const [{ pendingChannels }] = await db.select({ pendingChannels: sql<number>`count(*)` }).from(channels).where(eq(channels.status, "pending"));
  const [{ totalRevenue }] = await db.select({ totalRevenue: sql<number>`sum(price)` }).from(coursePurchases).where(eq(coursePurchases.status, "active"));
  return {
    totalUsers: Number(totalUsers),
    totalArticles: Number(totalArticles),
    totalReports: Number(totalReports),
    totalCourses: Number(totalCourses),
    pendingArticles: Number(pendingArticles),
    pendingChannels: Number(pendingChannels),
    totalRevenue: Number(totalRevenue) || 0,
  };
}

export async function getAuditLogs(page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(auditLogs);
  return { data, total: Number(count) };
}

export async function createAuditLog(data: typeof auditLogs.$inferInsert) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values(data);
}

// ============================================================
// 文章分类
// ============================================================
export async function getArticleCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(articleCategories).orderBy(articleCategories.sortOrder);
}

export async function createArticleCategory(data: typeof articleCategories.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(articleCategories).values(data);
}

// ============================================================
// 爬虫文章
// ============================================================
export async function getCrawledArticles(page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  const offset = (page - 1) * limit;
  const data = await db.select().from(crawledArticles).orderBy(desc(crawledArticles.createdAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(crawledArticles);
  return { data, total: Number(count) };
}

export async function saveCrawledArticle(data: typeof crawledArticles.$inferInsert) {
  const db = await getDb();
  if (!db) return;
  await db.insert(crawledArticles).values(data);
}

export async function importCrawledArticle(crawledId: number, authorId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [crawled] = await db.select().from(crawledArticles).where(eq(crawledArticles.id, crawledId)).limit(1);
  if (!crawled) throw new Error("Crawled article not found");
  const result = await db.insert(articles).values({
    title: crawled.title,
    content: crawled.content,
    authorId,
    status: "pending",
    publishedAt: crawled.publishedAt,
  });
  const insertId = (result as any).insertId;
  await db.update(crawledArticles).set({ isImported: true, importedArticleId: insertId }).where(eq(crawledArticles.id, crawledId));
  return insertId;
}
