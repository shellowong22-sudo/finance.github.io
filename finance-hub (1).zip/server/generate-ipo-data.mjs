/**
 * IPO模拟数据生成脚本
 */
import mysql from 'mysql2/promise';

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  const ipos = [
    {
      symbol: '688XXX.SH', companyName: '芯联集成电路制造', market: 'a_share', exchange: '上交所科创板',
      ipoPrice: 5.69, ipoShares: 1700000000, totalRaised: 9673000000,
      ipoDate: '2026-03-15', listingDate: '2026-03-25', status: 'listed',
      industry: '半导体', underwriter: '中信证券、海通证券',
      description: '国内领先的晶圆代工企业，专注于功率半导体和模拟IC制造，产品广泛应用于新能源汽车、光伏储能等领域。',
      subStart: '2026-03-15 09:00:00', subEnd: '2026-03-17 15:00:00'
    },
    {
      symbol: '301XXX.SZ', companyName: '智元机器人科技', market: 'a_share', exchange: '深交所创业板',
      ipoPrice: 45.68, ipoShares: 50000000, totalRaised: 2284000000,
      ipoDate: '2026-03-20', listingDate: '2026-03-28', status: 'listed',
      industry: '人工智能', underwriter: '华泰联合证券',
      description: '具身智能机器人领军企业，研发通用人形机器人平台，已获多轮顶级资本投资。',
      subStart: '2026-03-20 09:00:00', subEnd: '2026-03-22 15:00:00'
    },
    {
      symbol: '09XXX.HK', companyName: '商汤科技B类', market: 'hk_stock', exchange: '港交所主板',
      ipoPrice: 2.35, ipoShares: 800000000, totalRaised: 1880000000,
      ipoDate: '2026-03-18', listingDate: '2026-03-26', status: 'listed',
      industry: '人工智能', underwriter: '高盛、摩根士丹利',
      description: '亚洲领先的AI软件公司，专注于计算机视觉和深度学习技术，服务智慧城市、智慧商业等场景。',
      subStart: '2026-03-18 09:00:00', subEnd: '2026-03-20 15:00:00'
    },
    {
      symbol: '301YYY.SZ', companyName: '极氪智能科技', market: 'a_share', exchange: '深交所创业板',
      ipoPrice: 15.80, ipoShares: 120000000, totalRaised: 1896000000,
      ipoDate: '2026-03-22', listingDate: '2026-04-01', status: 'listed',
      industry: '新能源汽车', underwriter: '中金公司、招商证券',
      description: '吉利旗下高端纯电品牌，聚焦智能电动汽车研发制造，产品线覆盖轿车、SUV、MPV。',
      subStart: '2026-03-22 09:00:00', subEnd: '2026-03-24 15:00:00'
    },
    {
      symbol: '688YYY.SH', companyName: '中芯国际B股', market: 'a_share', exchange: '上交所科创板',
      ipoPrice: 28.50, ipoShares: 200000000, totalRaised: 5700000000,
      ipoDate: '2026-03-25', listingDate: '2026-04-02', status: 'listed',
      industry: '半导体', underwriter: '中信证券、国泰君安',
      description: '中国大陆技术最先进的集成电路晶圆代工企业，提供14nm至28nm制程的芯片制造服务。',
      subStart: '2026-03-25 09:00:00', subEnd: '2026-03-27 15:00:00'
    },
    {
      symbol: '688ZZZ.SH', companyName: '地平线智能驾驶', market: 'a_share', exchange: '上交所科创板',
      ipoPrice: 38.50, ipoShares: 80000000, totalRaised: 3080000000,
      ipoDate: '2026-04-05', listingDate: '2026-04-15', status: 'upcoming',
      industry: '智能驾驶', underwriter: '中信建投、摩根大通',
      description: '国内领先的智能驾驶计算方案提供商，自研征程系列车规级AI芯片，已获多家主流车企定点。',
      subStart: '2026-04-05 09:00:00', subEnd: '2026-04-07 15:00:00'
    },
    {
      symbol: '301ZZZ.SZ', companyName: '月之暗面科技', market: 'a_share', exchange: '深交所创业板',
      ipoPrice: null, ipoShares: 60000000, totalRaised: null,
      ipoDate: '2026-04-10', listingDate: '2026-04-20', status: 'upcoming',
      industry: '大模型', underwriter: '高盛高华、华泰联合',
      description: 'Kimi大模型开发商，专注于长文本理解和多模态AI，用户量突破1亿，估值超30亿美元。',
      subStart: '2026-04-10 09:00:00', subEnd: '2026-04-12 15:00:00'
    },
    {
      symbol: '688AAA.SH', companyName: '壁仞科技', market: 'a_share', exchange: '上交所科创板',
      ipoPrice: null, ipoShares: 100000000, totalRaised: null,
      ipoDate: '2026-04-08', listingDate: null, status: 'open',
      industry: 'GPU芯片', underwriter: '中金公司',
      description: '国产高性能GPU芯片设计企业，产品对标NVIDIA A100，已完成多款通用GPU芯片流片。',
      subStart: '2026-04-01 09:00:00', subEnd: '2026-04-08 15:00:00'
    },
    {
      symbol: '02XXX.HK', companyName: '字节跳动国际', market: 'hk_stock', exchange: '港交所主板',
      ipoPrice: null, ipoShares: 500000000, totalRaised: null,
      ipoDate: '2026-05-01', listingDate: null, status: 'upcoming',
      industry: '互联网', underwriter: '高盛、摩根士丹利、中金',
      description: 'TikTok母公司，全球最大的短视频平台运营商，业务覆盖内容分发、电商、企业服务等领域。',
      subStart: null, subEnd: null
    },
    {
      symbol: '688BBB.SH', companyName: '蔚来半导体', market: 'a_share', exchange: '上交所科创板',
      ipoPrice: 22.80, ipoShares: 150000000, totalRaised: 3420000000,
      ipoDate: '2026-04-02', listingDate: '2026-04-10', status: 'open',
      industry: '汽车芯片', underwriter: '海通证券、瑞银',
      description: '蔚来旗下自动驾驶芯片公司，自研"神玑"系列智驾芯片，算力达1000+ TOPS。',
      subStart: '2026-04-02 09:00:00', subEnd: '2026-04-04 15:00:00'
    },
  ];

  for (const ipo of ipos) {
    await conn.execute(
      `INSERT INTO ipo_info (symbol, companyName, market, exchange, ipoPrice, ipoShares, totalRaised, ipoDate, listingDate, status, industry, underwriter, description, subscriptionStart, subscriptionEnd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [ipo.symbol, ipo.companyName, ipo.market, ipo.exchange, ipo.ipoPrice, ipo.ipoShares, ipo.totalRaised, ipo.ipoDate, ipo.listingDate, ipo.status, ipo.industry, ipo.underwriter, ipo.description, ipo.subStart, ipo.subEnd]
    );
  }

  console.log(`✅ 成功插入 ${ipos.length} 条IPO数据`);
  await conn.end();
}

main().catch(err => { console.error('失败:', err); process.exit(1); });
