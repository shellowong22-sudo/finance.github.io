/**
 * 批量刷新真实行情数据脚本
 * 从 Yahoo Finance API 获取真实数据并更新数据库
 */
import mysql2 from 'mysql2/promise';
import 'dotenv/config';

const API_URL = process.env.BUILT_IN_FORGE_API_URL;
const API_KEY = process.env.BUILT_IN_FORGE_API_KEY;

async function callDataApi(apiId, options = {}) {
  const resp = await fetch(`${API_URL}/webdevtoken.v1.WebDevService/CallApi`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${API_KEY}` },
    body: JSON.stringify({ apiId, ...options }),
  });
  if (!resp.ok) throw new Error(`API error: ${resp.status}`);
  const data = await resp.json();
  return data.jsonData ? JSON.parse(data.jsonData) : data;
}

// Yahoo Finance symbol 映射
const YAHOO_MAP = {
  a_share: {
    "600519": "600519.SS", "601318": "601318.SS", "600036": "600036.SS",
    "000858": "000858.SZ", "002594": "002594.SZ", "600900": "600900.SS",
    "601012": "601012.SS", "000001": "000001.SZ", "600276": "600276.SS",
    "002475": "002475.SZ", "300750": "300750.SZ", "601888": "601888.SS",
    "601398": "601398.SS", "601288": "601288.SS", "600030": "600030.SS",
    "601166": "601166.SS", "300059": "300059.SZ", "002415": "002415.SZ",
    "600887": "600887.SS", "000333": "000333.SZ", "600690": "600690.SS",
    "601857": "601857.SS", "600028": "600028.SS", "601668": "601668.SS",
    "601899": "601899.SS", "601919": "601919.SS", "600585": "600585.SS",
    "600309": "600309.SS", "600438": "600438.SS", "600809": "600809.SS",
    "300760": "300760.SZ", "300274": "300274.SZ", "300124": "300124.SZ",
    "300015": "300015.SZ", "002714": "002714.SZ", "002371": "002371.SZ",
    "002352": "002352.SZ", "002304": "002304.SZ", "002230": "002230.SZ",
    "002142": "002142.SZ", "002049": "002049.SZ", "000725": "000725.SZ",
    "000568": "000568.SZ", "000002": "000002.SZ", "603259": "603259.SS",
    "688012": "688012.SS", "688036": "688036.SS", "688111": "688111.SS",
    "688981": "688981.SS", "600050": "600050.SS",
  },
  us_stock: {
    "AAPL": "AAPL", "MSFT": "MSFT", "GOOGL": "GOOGL", "AMZN": "AMZN",
    "NVDA": "NVDA", "TSLA": "TSLA", "META": "META", "BRK.B": "BRK-B",
    "JPM": "JPM", "V": "V", "JNJ": "JNJ", "UNH": "UNH",
    "HD": "HD", "PG": "PG", "MA": "MA", "DIS": "DIS",
    "NFLX": "NFLX", "INTC": "INTC", "AMD": "AMD", "CRM": "CRM",
    "AVGO": "AVGO", "COST": "COST", "LLY": "LLY", "ABBV": "ABBV",
    "XOM": "XOM", "BABA": "BABA", "PDD": "PDD", "NIO": "NIO",
    "COIN": "COIN", "PLTR": "PLTR",
  },
  hk_stock: {
    "00700.HK": "0700.HK", "09988.HK": "9988.HK", "01810.HK": "1810.HK",
    "03690.HK": "3690.HK", "02318.HK": "2318.HK", "00941.HK": "0941.HK",
    "01299.HK": "1299.HK", "00388.HK": "0388.HK", "00005.HK": "0005.HK",
    "02020.HK": "2020.HK", "01211.HK": "1211.HK", "09618.HK": "9618.HK",
    "09999.HK": "9999.HK", "09626.HK": "9626.HK", "06618.HK": "6618.HK",
    "02269.HK": "2269.HK", "01024.HK": "1024.HK", "02015.HK": "2015.HK",
    "00981.HK": "0981.HK", "01347.HK": "1347.HK",
  },
  index: {
    "000001.SH": "000001.SS", "000016.SH": "000016.SS", "000300.SH": "000300.SS",
    "399001.SZ": "399001.SZ", "399006.SZ": "399006.SZ",
    "DJI": "^DJI", "SPX": "^GSPC", "IXIC": "^IXIC",
    "HSI": "^HSI", "HSTECH": "^HSTECH",
    "N225": "^N225", "FTSE": "^FTSE", "GDAXI": "^GDAXI",
    "FCHI": "^FCHI", "AORD": "^AORD",
  },
  forex: {
    "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X", "USDJPY": "USDJPY=X",
    "USDCNY": "USDCNY=X", "USDCHF": "USDCHF=X", "USDCAD": "USDCAD=X",
    "AUDUSD": "AUDUSD=X", "NZDUSD": "NZDUSD=X", "EURGBP": "EURGBP=X",
    "EURJPY": "EURJPY=X",
  },
  crypto: {
    "BTCUSDT": "BTC-USD", "ETHUSDT": "ETH-USD", "BNBUSDT": "BNB-USD",
    "SOLUSDT": "SOL-USD", "XRPUSDT": "XRP-USD", "DOGEUSDT": "DOGE-USD",
    "ADAUSDT": "ADA-USD", "DOTUSDT": "DOT-USD", "AVAXUSDT": "AVAX-USD",
    "LINKUSDT": "LINK-USD",
  },
  fund: {
    "510050": "510050.SS", "510300": "510300.SS", "510500": "510500.SS",
    "512010": "512010.SS", "512100": "512100.SS", "512690": "512690.SS",
    "512880": "512880.SS", "513050": "513050.SS", "513100": "513100.SS",
    "515790": "515790.SS", "518880": "518880.SS",
    "159915": "159915.SZ", "159919": "159919.SZ", "159941": "159941.SZ",
    "159985": "159985.SZ",
  },
};

async function fetchQuote(yahooSymbol) {
  try {
    const result = await callDataApi("YahooFinance/get_stock_chart", {
      query: { symbol: yahooSymbol, interval: "1d", range: "1d" }
    });
    const meta = result?.chart?.result?.[0]?.meta;
    if (!meta) return null;
    const quotes = result.chart.result[0].indicators?.quote?.[0];
    const timestamps = result.chart.result[0].timestamp;

    let open = meta.regularMarketPrice;
    let high = meta.regularMarketDayHigh || meta.regularMarketPrice;
    let low = meta.regularMarketDayLow || meta.regularMarketPrice;
    let volume = meta.regularMarketVolume || 0;

    if (quotes && timestamps && timestamps.length > 0) {
      const i = timestamps.length - 1;
      if (quotes.open?.[i]) open = quotes.open[i];
      if (quotes.high?.[i]) high = quotes.high[i];
      if (quotes.low?.[i]) low = quotes.low[i];
      if (quotes.volume?.[i]) volume = quotes.volume[i];
    }

    const prevClose = meta.chartPreviousClose || meta.regularMarketPrice;
    const lastPrice = meta.regularMarketPrice;
    const changeVal = lastPrice - prevClose;
    const changePercent = prevClose > 0 ? (changeVal / prevClose) * 100 : 0;

    return { lastPrice, open, high, low, prevClose, changeVal, changePercent, volume, turnover: lastPrice * volume };
  } catch (e) {
    console.error(`  ✗ ${yahooSymbol}: ${e.message}`);
    return null;
  }
}

async function main() {
  const conn = await mysql2.createConnection(process.env.DATABASE_URL);
  let totalUpdated = 0;
  let totalFailed = 0;

  for (const [market, symbolMap] of Object.entries(YAHOO_MAP)) {
    console.log(`\n=== ${market} (${Object.keys(symbolMap).length} symbols) ===`);
    const symbols = Object.entries(symbolMap);

    for (let i = 0; i < symbols.length; i += 5) {
      const batch = symbols.slice(i, i + 5);
      const results = await Promise.all(batch.map(async ([dbSymbol, yahooSymbol]) => {
        const data = await fetchQuote(yahooSymbol);
        return { dbSymbol, data };
      }));

      for (const { dbSymbol, data } of results) {
        if (!data) {
          totalFailed++;
          continue;
        }
        try {
          await conn.execute(
            `UPDATE market_quotes SET lastPrice=?, openPrice=?, highPrice=?, lowPrice=?, prevClose=?, changeVal=?, changePercent=?, volume=?, turnover=?, updatedAt=NOW() WHERE symbol=? AND market=?`,
            [
              data.lastPrice.toFixed(4), data.open.toFixed(4), data.high.toFixed(4),
              data.low.toFixed(4), data.prevClose.toFixed(4), data.changeVal.toFixed(4),
              data.changePercent.toFixed(2), data.volume, data.turnover.toFixed(4),
              dbSymbol, market
            ]
          );
          console.log(`  ✓ ${dbSymbol}: ${data.lastPrice.toFixed(2)} (${data.changePercent >= 0 ? '+' : ''}${data.changePercent.toFixed(2)}%)`);
          totalUpdated++;
        } catch (e) {
          console.error(`  ✗ ${dbSymbol}: DB error - ${e.message}`);
          totalFailed++;
        }
      }

      if (i + 5 < symbols.length) await new Promise(r => setTimeout(r, 300));
    }
  }

  console.log(`\n========================================`);
  console.log(`总计: 更新 ${totalUpdated} 条, 失败 ${totalFailed} 条`);
  console.log(`========================================`);
  await conn.end();
}

main().catch(console.error);
