/**
 * 扩充全球行情品种数据
 * 增加更多A股蓝筹/热门股、美股科技/中概股、港股、期货、基金、债券等
 */
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 获取已有品种
const [existing] = await conn.query('SELECT symbol, market FROM market_quotes');
const existingSet = new Set(existing.map(r => `${r.symbol}_${r.market}`));

const newAssets = [
  // === 扩充A股（增加30只热门股） ===
  { symbol: "600000", name: "浦发银行", market: "a_share", exchange: "SSE", sector: "银行" },
  { symbol: "600016", name: "民生银行", market: "a_share", exchange: "SSE", sector: "银行" },
  { symbol: "600031", name: "三一重工", market: "a_share", exchange: "SSE", sector: "机械" },
  { symbol: "600048", name: "保利发展", market: "a_share", exchange: "SSE", sector: "房地产" },
  { symbol: "600104", name: "上汽集团", market: "a_share", exchange: "SSE", sector: "汽车" },
  { symbol: "600111", name: "北方稀土", market: "a_share", exchange: "SSE", sector: "有色金属" },
  { symbol: "600150", name: "中国船舶", market: "a_share", exchange: "SSE", sector: "军工" },
  { symbol: "600176", name: "中国巨石", market: "a_share", exchange: "SSE", sector: "建材" },
  { symbol: "600196", name: "复星医药", market: "a_share", exchange: "SSE", sector: "医药" },
  { symbol: "600346", name: "恒力石化", market: "a_share", exchange: "SSE", sector: "化工" },
  { symbol: "600406", name: "国电南瑞", market: "a_share", exchange: "SSE", sector: "电力设备" },
  { symbol: "600570", name: "恒生电子", market: "a_share", exchange: "SSE", sector: "软件" },
  { symbol: "600588", name: "用友网络", market: "a_share", exchange: "SSE", sector: "软件" },
  { symbol: "600745", name: "闻泰科技", market: "a_share", exchange: "SSE", sector: "半导体" },
  { symbol: "600919", name: "江苏银行", market: "a_share", exchange: "SSE", sector: "银行" },
  { symbol: "601009", name: "南京银行", market: "a_share", exchange: "SSE", sector: "银行" },
  { symbol: "601066", name: "中信建投", market: "a_share", exchange: "SSE", sector: "券商" },
  { symbol: "601088", name: "中国神华", market: "a_share", exchange: "SSE", sector: "煤炭" },
  { symbol: "601111", name: "中国国航", market: "a_share", exchange: "SSE", sector: "航空" },
  { symbol: "601225", name: "陕西煤业", market: "a_share", exchange: "SSE", sector: "煤炭" },
  { symbol: "601390", name: "中国中铁", market: "a_share", exchange: "SSE", sector: "建筑" },
  { symbol: "601628", name: "中国人寿", market: "a_share", exchange: "SSE", sector: "保险" },
  { symbol: "601688", name: "华泰证券", market: "a_share", exchange: "SSE", sector: "券商" },
  { symbol: "601766", name: "中国中车", market: "a_share", exchange: "SSE", sector: "轨交" },
  { symbol: "601985", name: "中国核电", market: "a_share", exchange: "SSE", sector: "电力" },
  { symbol: "002001", name: "新和成", market: "a_share", exchange: "SZSE", sector: "化工" },
  { symbol: "002027", name: "分众传媒", market: "a_share", exchange: "SZSE", sector: "传媒" },
  { symbol: "002120", name: "韵达股份", market: "a_share", exchange: "SZSE", sector: "物流" },
  { symbol: "002241", name: "歌尔股份", market: "a_share", exchange: "SZSE", sector: "电子" },
  { symbol: "002460", name: "赣锋锂业", market: "a_share", exchange: "SZSE", sector: "有色金属" },
  { symbol: "300014", name: "亿纬锂能", market: "a_share", exchange: "SZSE", sector: "电池" },
  { symbol: "300122", name: "智飞生物", market: "a_share", exchange: "SZSE", sector: "医药" },
  { symbol: "300308", name: "中际旭创", market: "a_share", exchange: "SZSE", sector: "光通信" },
  { symbol: "300394", name: "天孚通信", market: "a_share", exchange: "SZSE", sector: "光通信" },
  { symbol: "300496", name: "中科创达", market: "a_share", exchange: "SZSE", sector: "软件" },
  // === 扩充美股（增加20只） ===
  { symbol: "PYPL", name: "PayPal", market: "us_stock", exchange: "NASDAQ", sector: "金融科技" },
  { symbol: "SQ", name: "Block", market: "us_stock", exchange: "NYSE", sector: "金融科技" },
  { symbol: "UBER", name: "Uber", market: "us_stock", exchange: "NYSE", sector: "出行" },
  { symbol: "ABNB", name: "Airbnb", market: "us_stock", exchange: "NASDAQ", sector: "旅游" },
  { symbol: "SNOW", name: "Snowflake", market: "us_stock", exchange: "NYSE", sector: "云计算" },
  { symbol: "SHOP", name: "Shopify", market: "us_stock", exchange: "NYSE", sector: "电商" },
  { symbol: "ROKU", name: "Roku", market: "us_stock", exchange: "NASDAQ", sector: "流媒体" },
  { symbol: "ZM", name: "Zoom", market: "us_stock", exchange: "NASDAQ", sector: "通信" },
  { symbol: "SNAP", name: "Snap", market: "us_stock", exchange: "NYSE", sector: "社交" },
  { symbol: "RBLX", name: "Roblox", market: "us_stock", exchange: "NYSE", sector: "游戏" },
  { symbol: "MRVL", name: "Marvell", market: "us_stock", exchange: "NASDAQ", sector: "半导体" },
  { symbol: "MU", name: "Micron", market: "us_stock", exchange: "NASDAQ", sector: "半导体" },
  { symbol: "QCOM", name: "Qualcomm", market: "us_stock", exchange: "NASDAQ", sector: "半导体" },
  { symbol: "ORCL", name: "Oracle", market: "us_stock", exchange: "NYSE", sector: "软件" },
  { symbol: "IBM", name: "IBM", market: "us_stock", exchange: "NYSE", sector: "科技" },
  { symbol: "BA", name: "Boeing", market: "us_stock", exchange: "NYSE", sector: "航空" },
  { symbol: "GS", name: "Goldman Sachs", market: "us_stock", exchange: "NYSE", sector: "投行" },
  { symbol: "MS", name: "Morgan Stanley", market: "us_stock", exchange: "NYSE", sector: "投行" },
  { symbol: "LI", name: "理想汽车", market: "us_stock", exchange: "NASDAQ", sector: "中概股" },
  { symbol: "XPEV", name: "小鹏汽车", market: "us_stock", exchange: "NYSE", sector: "中概股" },
  // === 扩充港股（增加15只） ===
  { symbol: "00001.HK", name: "长和", market: "hk_stock", exchange: "HKEX", sector: "综合" },
  { symbol: "00003.HK", name: "香港中华煤气", market: "hk_stock", exchange: "HKEX", sector: "公用事业" },
  { symbol: "00006.HK", name: "电能实业", market: "hk_stock", exchange: "HKEX", sector: "公用事业" },
  { symbol: "00011.HK", name: "恒生银行", market: "hk_stock", exchange: "HKEX", sector: "银行" },
  { symbol: "00016.HK", name: "新鸿基地产", market: "hk_stock", exchange: "HKEX", sector: "房地产" },
  { symbol: "00027.HK", name: "银河娱乐", market: "hk_stock", exchange: "HKEX", sector: "博彩" },
  { symbol: "00066.HK", name: "港铁公司", market: "hk_stock", exchange: "HKEX", sector: "交通" },
  { symbol: "00175.HK", name: "吉利汽车", market: "hk_stock", exchange: "HKEX", sector: "汽车" },
  { symbol: "00241.HK", name: "阿里健康", market: "hk_stock", exchange: "HKEX", sector: "医药" },
  { symbol: "00285.HK", name: "比亚迪电子", market: "hk_stock", exchange: "HKEX", sector: "电子" },
  { symbol: "00772.HK", name: "阅文集团", market: "hk_stock", exchange: "HKEX", sector: "传媒" },
  { symbol: "01177.HK", name: "中国生物制药", market: "hk_stock", exchange: "HKEX", sector: "医药" },
  { symbol: "01928.HK", name: "金沙中国", market: "hk_stock", exchange: "HKEX", sector: "博彩" },
  { symbol: "02382.HK", name: "舜宇光学", market: "hk_stock", exchange: "HKEX", sector: "光学" },
  { symbol: "06060.HK", name: "众安在线", market: "hk_stock", exchange: "HKEX", sector: "保险" },
  // === 扩充基金（增加10只） ===
  { symbol: "510050", name: "上证50ETF", market: "fund", exchange: "SSE", sector: "指数基金" },
  { symbol: "510300", name: "沪深300ETF", market: "fund", exchange: "SSE", sector: "指数基金" },
  { symbol: "510500", name: "中证500ETF", market: "fund", exchange: "SSE", sector: "指数基金" },
  { symbol: "159915", name: "创业板ETF", market: "fund", exchange: "SZSE", sector: "指数基金" },
  { symbol: "159919", name: "沪深300ETF(深)", market: "fund", exchange: "SZSE", sector: "指数基金" },
  { symbol: "513100", name: "纳指ETF", market: "fund", exchange: "SSE", sector: "跨境基金" },
  { symbol: "513050", name: "中概互联ETF", market: "fund", exchange: "SSE", sector: "跨境基金" },
  { symbol: "518880", name: "黄金ETF", market: "fund", exchange: "SSE", sector: "商品基金" },
  { symbol: "159941", name: "纳指ETF(深)", market: "fund", exchange: "SZSE", sector: "跨境基金" },
  { symbol: "512690", name: "酒ETF", market: "fund", exchange: "SSE", sector: "行业基金" },
];

let inserted = 0;
for (const asset of newAssets) {
  const key = `${asset.symbol}_${asset.market}`;
  if (existingSet.has(key)) {
    continue;
  }
  // 使用合理的默认价格
  const defaultPrice = asset.market === 'a_share' ? (10 + Math.random() * 90).toFixed(2) :
    asset.market === 'us_stock' ? (50 + Math.random() * 200).toFixed(2) :
    asset.market === 'hk_stock' ? (10 + Math.random() * 100).toFixed(2) :
    asset.market === 'fund' ? (1 + Math.random() * 5).toFixed(4) :
    (10 + Math.random() * 50).toFixed(2);
  
  await conn.query(
    `INSERT INTO market_quotes (symbol, name, market, exchange, lastPrice, openPrice, highPrice, lowPrice, prevClose, changeVal, changePercent, volume, turnover, marketCap, pe, pb, sector, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '0.00', '0.00', 0, '0', '0', '0', '0', ?, NOW())`,
    [asset.symbol, asset.name, asset.market, asset.exchange, defaultPrice, defaultPrice, defaultPrice, defaultPrice, defaultPrice, asset.sector]
  );
  inserted++;
}

console.log(`新增 ${inserted} 个品种`);

// 查看最终分布
const [dist] = await conn.query('SELECT market, COUNT(*) as cnt FROM market_quotes GROUP BY market ORDER BY cnt DESC');
console.log('=== 最终品种分布 ===');
let total = 0;
dist.forEach(r => { console.log(`${r.market}: ${r.cnt}`); total += Number(r.cnt); });
console.log(`总计: ${total}`);

await conn.end();
