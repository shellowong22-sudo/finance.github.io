/**
 * 量化交易系统 - 修复脚本（补充回测+合规+告警数据）
 * 前8个表已成功生成，本脚本只生成剩余4个表的数据
 */

import mysql from 'mysql2/promise';

const rand = (min, max) => Math.random() * (max - min) + min;
const randInt = (min, max) => Math.floor(rand(min, max + 1));
const pick = (arr) => arr[randInt(0, arr.length - 1)];
const decimal = (val, digits = 4) => parseFloat(val.toFixed(digits));

function dateStr(daysAgo) {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
}

function timestamp(daysAgo) {
  return Date.now() - daysAgo * 86400000 + randInt(0, 86400000);
}

const A_SHARES = [
  { symbol: '600519.SH', name: '贵州茅台', price: 1680 },
  { symbol: '300750.SZ', name: '宁德时代', price: 198 },
  { symbol: '601318.SH', name: '中国平安', price: 48.5 },
  { symbol: '000858.SZ', name: '五粮液', price: 135 },
  { symbol: '002594.SZ', name: '比亚迪', price: 268 },
  { symbol: '600036.SH', name: '招商银行', price: 35.2 },
  { symbol: '601899.SH', name: '紫金矿业', price: 18.6 },
  { symbol: '002475.SZ', name: '立讯精密', price: 32.8 },
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  // 获取已有的策略ID
  const [strategies] = await conn.execute('SELECT id, name FROM quant_strategies ORDER BY id');
  console.log(`找到 ${strategies.length} 个策略`);

  // ========== 9. 回测记录 ==========
  console.log('🔄 [9/12] 生成回测记录数据...');
  
  const backtestNames = [
    '双均线交叉-2024年度回测', 'MACD动量-科技股回测', '布林带均值回归-蓝筹回测',
    '跨市场套利-AH股回测', '价值因子-全A选股回测', 'AI深度学习-预测回测',
    '网格交易-震荡行情回测', '海龟法则-趋势回测', '统计套利-银行配对回测',
    '高频做市-期货回测', '多因子Alpha-月度回测', '事件驱动-财报季回测',
    '双均线交叉-半年回测', 'MACD动量-港股回测', '价值因子-大盘股回测'
  ];

  const backtestIds = [];
  for (let i = 0; i < 15; i++) {
    const strategyId = strategies[i % strategies.length].id;
    const startDays = randInt(365, 1095);
    const endDays = randInt(0, 30);
    const initialCapital = pick([500000, 1000000, 2000000, 5000000]);
    const totalReturn = decimal(rand(-10, 60), 2);
    const finalCapital = decimal(initialCapital * (1 + totalReturn / 100), 2);
    const isCompleted = i < 12;
    const status = isCompleted ? 'completed' : (i === 12 ? 'running' : 'failed');
    const totalTrades = randInt(50, 500);
    const winTrades = Math.floor(totalTrades * rand(0.35, 0.7));
    
    // 生成收益曲线
    const equityCurve = [];
    let equity = initialCapital;
    for (let d = 0; d < 24; d++) {
      equity *= (1 + rand(-3, 4) / 100);
      equityCurve.push(decimal(equity, 0));
    }
    
    const monthlyReturns = [];
    for (let m = 0; m < 12; m++) {
      monthlyReturns.push(decimal(rand(-8, 12), 2));
    }

    const completedAtClause = isCompleted ? ', completedAt' : '';
    const completedAtValue = isCompleted ? ', NOW() - INTERVAL ? DAY' : '';
    
    const params = [
      strategyId, backtestNames[i], i < 8 ? 'a_share' : (i < 11 ? 'us_stock' : 'hk_stock'),
      JSON.stringify(A_SHARES.slice(0, randInt(3, 6)).map(a => a.symbol)),
      dateStr(startDays), dateStr(endDays), initialCapital,
      status,
      isCompleted ? finalCapital : null,
      isCompleted ? totalReturn : null,
      isCompleted ? decimal(totalReturn * rand(0.5, 1.2), 2) : null,
      isCompleted ? decimal(rand(5, 25), 2) : null,
      isCompleted ? decimal(rand(0.5, 3.0), 2) : null,
      isCompleted ? decimal(rand(0.6, 3.5), 2) : null,
      isCompleted ? decimal(rand(0.3, 2.5), 2) : null,
      isCompleted ? decimal(winTrades / totalTrades * 100, 2) : null,
      isCompleted ? decimal(rand(1.0, 3.0), 2) : null,
      isCompleted ? totalTrades : 0,
      isCompleted ? winTrades : 0,
      isCompleted ? totalTrades - winTrades : 0,
      isCompleted ? decimal(rand(500, 5000), 2) : null,
      isCompleted ? decimal(rand(300, 3000), 2) : null,
      JSON.stringify(equityCurve),
      JSON.stringify(monthlyReturns),
      randInt(1, 30)
    ];
    
    if (isCompleted) {
      params.push(randInt(0, 5));
    }

    const sql = `INSERT INTO backtest_records (userId, strategyId, name, market, symbols, startDate, endDate, initialCapital, slippageModel, slippageValue, commissionRate, stampDutyRate, status, finalCapital, totalReturn, annualReturn, maxDrawdown, sharpeRatio, sortinoRatio, calmarRatio, winRate, profitFactor, totalTrades, winTrades, lossTrades, avgWin, avgLoss, equityCurve, monthlyReturns, startedAt${completedAtClause}) VALUES (1, ?, ?, ?, ?, ?, ?, ?, 'fixed', 0.001, 0.0003, 0.001, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? DAY${completedAtValue})`;
    
    const [result] = await conn.execute(sql, params);
    backtestIds.push(result.insertId);
  }
  console.log(`  ✅ 插入 ${backtestIds.length} 条回测记录`);

  // ========== 10. 回测交易 ==========
  console.log('📝 [10/12] 生成回测交易数据...');
  
  let btTradeCount = 0;
  for (const btId of backtestIds.slice(0, 10)) {
    const numTrades = randInt(15, 40);
    for (let t = 0; t < numTrades; t++) {
      const stock = pick(A_SHARES);
      const side = t % 2 === 0 ? 'buy' : 'sell';
      const price = decimal(stock.price * (1 + rand(-10, 10) / 100), 2);
      const qty = randInt(100, 2000);
      const pnl = side === 'sell' ? decimal(rand(-3000, 8000), 2) : 0;
      
      await conn.execute(
        `INSERT INTO backtest_trades (backtestId, symbol, side, price, quantity, commission, slippage, pnl, pnlPercent, holdingPeriod, tradeTimestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [btId, stock.symbol, side, price, qty, decimal(price * qty * 0.0003, 2), decimal(rand(0, 1), 4), pnl, pnl !== 0 ? decimal(pnl / (price * qty) * 100, 2) : 0, side === 'sell' ? randInt(1, 30) : 0, timestamp(randInt(30, 365))]
      );
      btTradeCount++;
    }
  }
  console.log(`  ✅ 插入 ${btTradeCount} 条回测交易记录`);

  // ========== 11. 合规审计 ==========
  console.log('📜 [11/12] 生成合规审计数据...');
  
  const auditActions = ['order_submit', 'order_cancel', 'strategy_modify', 'risk_rule_change', 'account_change', 'emergency_stop', 'data_export', 'config_change', 'login', 'logout'];
  const auditDetails = [
    '提交买入订单：贵州茅台 1000股 限价1680.00',
    '撤销未成交订单 #12345',
    '修改策略参数：止损比例从5%调整为3%',
    '更新风控规则：单笔最大下单金额从50万调整为80万',
    '新增交易账户：美股交易账户（Interactive Brokers）',
    '触发紧急停止：全市场暂停交易',
    '导出近30天交易记录（CSV格式）',
    '修改系统配置：启用夜盘交易模式',
    '管理员登录系统',
    '管理员退出系统',
  ];
  
  let auditCount = 0;
  for (let i = 0; i < 50; i++) {
    const actionIdx = randInt(0, auditActions.length - 1);
    const isCompliant = randInt(0, 9) > 0 ? 1 : 0;
    
    await conn.execute(
      `INSERT INTO compliance_audit (userId, operatorName, actionType, targetType, targetId, detail, ipAddress, isCompliant, complianceNote, createdAt) VALUES (1, 'Manus管理员', ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? DAY)`,
      [auditActions[actionIdx], pick(['order', 'strategy', 'rule', 'account', 'system']), randInt(1, 100),
       auditDetails[actionIdx], `192.168.${randInt(1, 255)}.${randInt(1, 255)}`,
       isCompliant, isCompliant ? '操作符合合规要求' : '操作存在合规风险，已记录并通知风控部门',
       randInt(0, 60)]
    );
    auditCount++;
  }
  console.log(`  ✅ 插入 ${auditCount} 条合规审计记录`);

  // ========== 12. 监控告警 ==========
  console.log('🔔 [12/12] 生成监控告警数据...');
  
  const alerts = [
    { type: 'high_latency', severity: 'medium', title: '行情数据延迟升高', msg: 'A股行情数据延迟从50ms升至350ms，超过200ms阈值', source: '行情服务', metric: 'latency_ms', current: '350', threshold: '200' },
    { type: 'order_failure', severity: 'high', title: '订单提交失败率异常', msg: '近5分钟订单提交失败率达到12%，超过5%阈值', source: '交易引擎', metric: 'failure_rate', current: '12%', threshold: '5%' },
    { type: 'risk_trigger', severity: 'critical', title: '风控规则触发：日内亏损超限', msg: 'A股主力账户日内亏损达到48,500元，接近50,000元上限', source: '风控引擎', metric: 'daily_loss', current: '48500', threshold: '50000' },
    { type: 'cpu_overload', severity: 'medium', title: 'CPU使用率过高', msg: '回测服务器CPU使用率达到92%，超过85%阈值', source: '回测服务', metric: 'cpu_usage', current: '92%', threshold: '85%' },
    { type: 'memory_overload', severity: 'high', title: '内存使用率告警', msg: '交易引擎内存使用率达到88%，建议扩容', source: '交易引擎', metric: 'memory_usage', current: '88%', threshold: '80%' },
    { type: 'data_anomaly', severity: 'medium', title: 'K线数据异常', msg: '检测到贵州茅台(600519.SH)日K线数据缺失3根', source: '数据服务', metric: 'missing_bars', current: '3', threshold: '0' },
    { type: 'network_issue', severity: 'high', title: '券商API连接中断', msg: '中信证券交易API连接超时，已自动重连3次', source: '通道管理', metric: 'connection_status', current: 'disconnected', threshold: 'connected' },
    { type: 'service_down', severity: 'critical', title: '风控引擎服务异常', msg: '风控引擎进程异常退出，已自动重启', source: '风控引擎', metric: 'process_status', current: 'crashed', threshold: 'running' },
    { type: 'compliance_violation', severity: 'high', title: '合规检查未通过', msg: '策略"高频做市策略"未通过合规审查，存在潜在市场操纵风险', source: '合规系统', metric: 'compliance_check', current: 'failed', threshold: 'passed' },
    { type: 'security_breach', severity: 'critical', title: '异常登录检测', msg: '检测到来自未知IP(103.45.67.89)的登录尝试，已自动拦截', source: '安全系统', metric: 'login_attempt', current: 'blocked', threshold: 'normal' },
    { type: 'disk_full', severity: 'medium', title: '磁盘空间不足', msg: '日志存储磁盘使用率达到78%，建议清理历史日志', source: '运维监控', metric: 'disk_usage', current: '78%', threshold: '75%' },
    { type: 'high_latency', severity: 'low', title: '回测任务排队等待', msg: '当前有5个回测任务在排队等待，预计等待时间15分钟', source: '回测服务', metric: 'queue_length', current: '5', threshold: '3' },
  ];
  
  for (const a of alerts) {
    const isResolved = randInt(0, 1);
    const isAcked = randInt(0, 1);
    await conn.execute(
      `INSERT INTO monitor_alerts (alertType, severity, title, message, source, metric, currentValue, thresholdValue, isResolved, resolvedBy, resolvedAt, acknowledgedBy, acknowledgedAt, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? DAY)`,
      [a.type, a.severity, a.title, a.msg, a.source, a.metric, a.current, a.threshold, isResolved, isResolved ? 1 : null, isResolved ? new Date() : null, isAcked ? 1 : null, isAcked ? new Date() : null, randInt(0, 14)]
    );
  }
  console.log(`  ✅ 插入 ${alerts.length} 条监控告警`);

  await conn.end();

  console.log('\n============================================================');
  console.log('🎉 剩余数据生成完成！');
  console.log(`🔄 回测记录: ${backtestIds.length} 条`);
  console.log(`📝 回测交易: ${btTradeCount} 条`);
  console.log(`📜 合规审计: ${auditCount} 条`);
  console.log(`🔔 监控告警: ${alerts.length} 条`);
  console.log('============================================================');
}

main().catch(err => {
  console.error('脚本执行失败:', err);
  process.exit(1);
});
