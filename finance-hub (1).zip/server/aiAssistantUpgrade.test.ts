import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { STYLE_PROMPTS, buildSystemPrompt, aiTools, executeToolCall } from "./routers/aiAssistant";

// ============================================================
// Helper: create auth context
// ============================================================
function createAuthContext() {
  const user = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user" as const,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };

  return { ctx, user };
}

// ============================================================
// Tests
// ============================================================
describe("AI Assistant Upgrade - Style System", () => {
  it("has all 5 style options defined", () => {
    expect(Object.keys(STYLE_PROMPTS)).toHaveLength(5);
    expect(STYLE_PROMPTS).toHaveProperty("professional");
    expect(STYLE_PROMPTS).toHaveProperty("casual");
    expect(STYLE_PROMPTS).toHaveProperty("humorous");
    expect(STYLE_PROMPTS).toHaveProperty("teacher");
    expect(STYLE_PROMPTS).toHaveProperty("analyst");
  });

  it("buildSystemPrompt includes style-specific text", () => {
    const professional = buildSystemPrompt("professional");
    expect(professional).toContain("专业");

    const casual = buildSystemPrompt("casual");
    expect(casual).toContain("通俗");

    const humorous = buildSystemPrompt("humorous");
    expect(humorous).toContain("幽默");
  });

  it("buildSystemPrompt falls back to professional for unknown style", () => {
    const result = buildSystemPrompt("unknown_style");
    expect(result).toContain("专业");
  });
});

describe("AI Assistant Upgrade - Tools", () => {
  it("has get_kline_data tool defined", () => {
    const klineTool = aiTools.find((t) => t.function.name === "get_kline_data");
    expect(klineTool).toBeDefined();
    expect(klineTool!.function.parameters.properties).toHaveProperty("symbol");
    expect(klineTool!.function.parameters.properties).toHaveProperty("market");
    expect(klineTool!.function.parameters.properties).toHaveProperty("period");
  });

  it("has all 7 tools defined", () => {
    expect(aiTools.length).toBeGreaterThanOrEqual(6);
    const toolNames = aiTools.map((t) => t.function.name);
    expect(toolNames).toContain("query_market_quotes");
    expect(toolNames).toContain("get_kline_data");
    expect(toolNames).toContain("query_articles");
    expect(toolNames).toContain("query_reports");
    expect(toolNames).toContain("query_courses");
  });

  it("executeToolCall returns error for unknown tool", async () => {
    const result = await executeToolCall("unknown_tool", {});
    expect(result).toContain("未知工具");
  });
});

describe("AI Assistant Upgrade - Conversation Persistence", () => {
  it("createConversation procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.aiAssistant.createConversation).toBeDefined();
  });

  it("conversations list procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.aiAssistant.conversations).toBeDefined();
  });

  it("saveMessage procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.aiAssistant.saveMessage).toBeDefined();
  });

  it("deleteConversation procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.aiAssistant.deleteConversation).toBeDefined();
  });

  it("updateStyle procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.aiAssistant.updateStyle).toBeDefined();
  });

  it("getMessages procedure exists", () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.aiAssistant.getMessages).toBeDefined();
  });
});
