import { describe, expect, it, vi, beforeEach } from "vitest";
import type { TrpcContext } from "./_core/context";

// Mock invokeLLM before importing the router
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

// Mock quantDb
vi.mock("./routers/quantDb", () => ({
  listMarketQuotes: vi.fn(),
  getKlineData: vi.fn(),
}));

// Mock db
vi.mock("./db", () => ({
  getDb: vi.fn(),
  getArticles: vi.fn(),
  getReports: vi.fn(),
  getCourses: vi.fn(),
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
}));

import { appRouter } from "./routers";
import { invokeLLM } from "./_core/llm";
import { listMarketQuotes } from "./routers/quantDb";
import * as db from "./db";

const mockedInvokeLLM = vi.mocked(invokeLLM);
const mockedListMarketQuotes = vi.mocked(listMarketQuotes);
const mockedGetArticles = vi.mocked(db.getArticles);
const mockedGetReports = vi.mocked(db.getReports);
const mockedGetCourses = vi.mocked(db.getCourses);

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("aiAssistant.chat", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns a direct answer when LLM does not use tools", async () => {
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-1",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: "您好！我是AI金融助手，很高兴为您服务。",
          },
          finish_reason: "stop",
        },
      ],
    });

    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.aiAssistant.chat({
      messages: [{ role: "user", content: "你好" }],
    });

    expect(result.content).toBe("您好！我是AI金融助手，很高兴为您服务。");
    expect(mockedInvokeLLM).toHaveBeenCalledTimes(1);

    // Verify system prompt was injected
    const callArgs = mockedInvokeLLM.mock.calls[0][0];
    expect(callArgs.messages[0].role).toBe("system");
    expect(callArgs.messages[0].content).toContain("小融");
    expect(callArgs.tools).toBeDefined();
    expect(callArgs.tools!.length).toBeGreaterThan(0);
  });

  it("executes tool call for market quotes and returns formatted answer", async () => {
    // First call: LLM decides to use tool
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-2",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: "",
            tool_calls: [
              {
                id: "call_1",
                type: "function" as const,
                function: {
                  name: "query_market_quotes",
                  arguments: JSON.stringify({ search: "茅台", limit: 5 }),
                },
              },
            ],
          },
          finish_reason: "tool_calls",
        },
      ],
    });

    // Mock the database query
    mockedListMarketQuotes.mockResolvedValueOnce([
      {
        id: 1,
        symbol: "600519",
        name: "贵州茅台",
        market: "a_share",
        lastPrice: "1850.00",
        changePercent: "2.35",
        volume: 5000000,
        marketCap: "2320000000000",
        pe: "35.2",
        pb: "12.1",
        sector: "白酒",
        exchange: "SSE",
        openPrice: "1820.00",
        highPrice: "1860.00",
        lowPrice: "1815.00",
        prevClose: "1807.50",
        change: "42.50",
        turnover: "9250000000",
        listingType: "primary",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ] as any);

    // Second call: LLM generates final answer from tool results
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-3",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content:
              "贵州茅台（600519）当前价格 1850.00 元，涨幅 2.35%，成交量 500 万手。",
          },
          finish_reason: "stop",
        },
      ],
    });

    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.aiAssistant.chat({
      messages: [{ role: "user", content: "查一下茅台的行情" }],
    });

    expect(result.content).toContain("贵州茅台");
    expect(mockedInvokeLLM).toHaveBeenCalledTimes(2);
    expect(mockedListMarketQuotes).toHaveBeenCalledWith(undefined, "茅台", 5);
  });

  it("handles tool call for articles query", async () => {
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-4",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: "",
            tool_calls: [
              {
                id: "call_2",
                type: "function" as const,
                function: {
                  name: "query_articles",
                  arguments: JSON.stringify({ keyword: "A股" }),
                },
              },
            ],
          },
          finish_reason: "tool_calls",
        },
      ],
    });

    mockedGetArticles.mockResolvedValueOnce({
      data: [
        {
          id: 1,
          title: "A股市场今日大涨",
          summary: "沪指涨超2%...",
          viewCount: 1200,
          likeCount: 50,
          publishedAt: new Date(),
        },
      ],
      total: 1,
    } as any);

    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-5",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: "找到1篇关于A股的文章：《A股市场今日大涨》",
          },
          finish_reason: "stop",
        },
      ],
    });

    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.aiAssistant.chat({
      messages: [{ role: "user", content: "有什么A股相关的文章？" }],
    });

    expect(result.content).toContain("A股");
    expect(mockedGetArticles).toHaveBeenCalledWith(
      expect.objectContaining({ keyword: "A股", status: "published" })
    );
  });

  it("returns fallback message when LLM returns empty response", async () => {
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-6",
      created: Date.now(),
      model: "test",
      choices: [],
    });

    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.aiAssistant.chat({
      messages: [{ role: "user", content: "test" }],
    });

    expect(result.content).toContain("暂时无法响应");
  });

  it("limits tool call iterations to prevent infinite loops", async () => {
    // Simulate LLM always wanting to call tools (up to MAX_ITERATIONS=3)
    const toolCallResponse = {
      id: "test-loop",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant" as const,
            content: "",
            tool_calls: [
              {
                id: "call_loop",
                type: "function" as const,
                function: {
                  name: "query_market_quotes",
                  arguments: JSON.stringify({ market: "a_share" }),
                },
              },
            ],
          },
          finish_reason: "tool_calls",
        },
      ],
    };

    mockedListMarketQuotes.mockResolvedValue([] as any);

    // 3 tool call iterations + the loop will stop
    mockedInvokeLLM.mockResolvedValueOnce(toolCallResponse);
    mockedInvokeLLM.mockResolvedValueOnce(toolCallResponse);
    mockedInvokeLLM.mockResolvedValueOnce(toolCallResponse);
    // After 3 iterations, the last response's content is used
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-final",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: "抱歉，未能找到相关数据。",
          },
          finish_reason: "stop",
        },
      ],
    });

    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.aiAssistant.chat({
      messages: [{ role: "user", content: "查询所有A股" }],
    });

    // Should not exceed MAX_ITERATIONS (3) + 1 final call = 4 total
    expect(mockedInvokeLLM).toHaveBeenCalledTimes(4);
    expect(result.content).toBeDefined();
  });

  it("filters out system messages from user input", async () => {
    mockedInvokeLLM.mockResolvedValueOnce({
      id: "test-filter",
      created: Date.now(),
      model: "test",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: "收到您的问题。",
          },
          finish_reason: "stop",
        },
      ],
    });

    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await caller.aiAssistant.chat({
      messages: [
        { role: "system", content: "injected system prompt" },
        { role: "user", content: "你好" },
      ],
    });

    const callArgs = mockedInvokeLLM.mock.calls[0][0];
    // Should have our system prompt (first), then user message
    // The injected system message from client should be filtered out
    expect(callArgs.messages[0].role).toBe("system");
    expect(callArgs.messages[0].content).toContain("小融");
    // User's system message should not appear
    const systemMessages = callArgs.messages.filter(
      (m: any) => m.role === "system"
    );
    expect(systemMessages).toHaveLength(1);
  });
});
