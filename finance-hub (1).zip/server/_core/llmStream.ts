import { ENV } from "./env";
import type { Message, Tool, ToolChoice, ToolCall } from "./llm";

/**
 * Streaming LLM invocation that returns a ReadableStream of SSE chunks.
 * Handles tool_calls by yielding them as structured events.
 */

const resolveApiUrl = () =>
  ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
    ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions`
    : "https://forge.manus.im/v1/chat/completions";

export type StreamChunk =
  | { type: "content_delta"; content: string }
  | { type: "tool_calls"; toolCalls: ToolCall[] }
  | { type: "done" }
  | { type: "error"; error: string };

/**
 * Invoke LLM with streaming enabled.
 * Yields content deltas and tool_calls as they arrive.
 */
export async function* invokeLLMStream(params: {
  messages: Message[];
  tools?: Tool[];
  tool_choice?: ToolChoice;
}): AsyncGenerator<StreamChunk> {
  if (!ENV.forgeApiKey) {
    yield { type: "error", error: "API key not configured" };
    return;
  }

  const normalizeMessage = (msg: any) => {
    const { role, content, name, tool_call_id, tool_calls } = msg;
    if (role === "tool" || role === "function") {
      const c = Array.isArray(content)
        ? content.map((p: any) => (typeof p === "string" ? p : JSON.stringify(p))).join("\n")
        : typeof content === "string"
          ? content
          : JSON.stringify(content);
      return { role, name, tool_call_id, content: c };
    }
    // For assistant messages with tool_calls, preserve them
    if (role === "assistant" && tool_calls && tool_calls.length > 0) {
      return { role, content: content || "", tool_calls };
    }
    if (typeof content === "string") {
      return { role, name, content };
    }
    if (Array.isArray(content)) {
      const parts = content.map((p: any) => {
        if (typeof p === "string") return { type: "text" as const, text: p };
        return p;
      });
      if (parts.length === 1 && parts[0].type === "text") {
        return { role, name, content: (parts[0] as any).text };
      }
      return { role, name, content: parts };
    }
    return { role, name, content: String(content) };
  };

  const payload: Record<string, unknown> = {
    model: "gemini-2.5-flash",
    messages: params.messages.map(normalizeMessage),
    stream: true,
    max_tokens: 32768,
    thinking: { budget_tokens: 128 },
  };

  if (params.tools && params.tools.length > 0) {
    payload.tools = params.tools;
  }

  if (params.tool_choice) {
    if (params.tool_choice === "auto" || params.tool_choice === "none") {
      payload.tool_choice = params.tool_choice;
    } else if (params.tool_choice === "required") {
      if (params.tools && params.tools.length === 1) {
        payload.tool_choice = {
          type: "function",
          function: { name: params.tools[0].function.name },
        };
      }
    } else {
      payload.tool_choice = params.tool_choice;
    }
  }

  const response = await fetch(resolveApiUrl(), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${ENV.forgeApiKey}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    yield { type: "error", error: `LLM invoke failed: ${response.status} – ${errorText}` };
    return;
  }

  if (!response.body) {
    yield { type: "error", error: "No response body" };
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  // Accumulate tool_calls across chunks
  const toolCallsMap = new Map<number, { id: string; type: "function"; function: { name: string; arguments: string } }>();

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith("data: ")) continue;
        const data = trimmed.slice(6);
        if (data === "[DONE]") {
          // Stream is complete. Yield any accumulated tool_calls first.
          if (toolCallsMap.size > 0) {
            const toolCalls = Array.from(toolCallsMap.values());
            yield { type: "tool_calls", toolCalls };
            toolCallsMap.clear();
          }
          yield { type: "done" };
          return;
        }

        try {
          const parsed = JSON.parse(data);
          const delta = parsed.choices?.[0]?.delta;
          if (!delta) {
            // Even without delta, check finish_reason for accumulated tool_calls
            const finishReason = parsed.choices?.[0]?.finish_reason;
            if (finishReason && toolCallsMap.size > 0) {
              const toolCalls = Array.from(toolCallsMap.values());
              yield { type: "tool_calls", toolCalls };
              toolCallsMap.clear();
            }
            continue;
          }

          // Content delta
          if (delta.content) {
            yield { type: "content_delta", content: delta.content };
          }

          // Tool calls delta (streamed incrementally)
          if (delta.tool_calls) {
            for (const tc of delta.tool_calls) {
              const idx = tc.index ?? 0;
              if (!toolCallsMap.has(idx)) {
                toolCallsMap.set(idx, {
                  id: tc.id || "",
                  type: "function",
                  function: { name: tc.function?.name || "", arguments: "" },
                });
              }
              const existing = toolCallsMap.get(idx)!;
              if (tc.id) existing.id = tc.id;
              if (tc.function?.name) existing.function.name = tc.function.name;
              if (tc.function?.arguments) existing.function.arguments += tc.function.arguments;
            }
          }

          // Check finish_reason — some APIs use "stop" even when tool_calls are present
          const finishReason = parsed.choices?.[0]?.finish_reason;
          if (finishReason && toolCallsMap.size > 0) {
            // Yield accumulated tool_calls regardless of finish_reason value
            const toolCalls = Array.from(toolCallsMap.values());
            yield { type: "tool_calls", toolCalls };
            toolCallsMap.clear();
          }
        } catch {
          // Skip malformed JSON lines
        }
      }
    }

    // Process remaining buffer
    if (buffer.trim()) {
      const trimmed = buffer.trim();
      if (trimmed.startsWith("data: ") && trimmed.slice(6) !== "[DONE]") {
        try {
          const parsed = JSON.parse(trimmed.slice(6));
          const delta = parsed.choices?.[0]?.delta;
          if (delta?.content) {
            yield { type: "content_delta", content: delta.content };
          }
        } catch { /* ignore */ }
      }
    }

    // Yield any remaining tool_calls
    if (toolCallsMap.size > 0) {
      const toolCalls = Array.from(toolCallsMap.values());
      yield { type: "tool_calls", toolCalls };
    }

    yield { type: "done" };
  } finally {
    reader.releaseLock();
  }
}
