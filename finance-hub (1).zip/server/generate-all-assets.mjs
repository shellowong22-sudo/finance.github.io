/**
 * 全品种行情数据生成脚本
 * 覆盖：A股、美股、港股、期货、期权、基金、债券、外汇、加密货币、全球指数
 */
import mysql from "mysql2/promise";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Read DATABASE_URL from environment variable
const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) { console.error("DATABASE_URL not found in env"); process.exit(1); }

const url = new URL(dbUrl);
const conn = await mysql.createConnection({
  host: url.hostname, port: parseInt(url.port || "3306"),
  user: url.username, password: decodeURIComponent(url.password),
  database: url.pathname.slice(1),
  ssl: { rejectUnauthorized: true },
});

console.log("✅ Connected to database");

// Clear existing quotes
await conn.execute("DELETE FROM market_quotes");
console.log("🗑️ Cleared existing market_quotes");

// ============================================================
// A股 (50只)
// ============================================================
const aShares = [
  { symbol: "600519", name: "贵州茅台", sector: "白酒", price: 1756.00, pe: 28.5, pb: 9.2, marketCap: 22050 },
  { symbol: "601318", name: "中国平安", sector: "保险", price: 48.32, pe: 8.2, pb: 1.1, marketCap: 8820 },
  { symbol: "600036", name: "招商银行", sector: "银行", price: 35.68, pe: 6.5, pb: 1.0, marketCap: 8980 },
  { symbol: "002594", name: "比亚迪", sector: "新能源汽车", price: 268.50, pe: 22.3, pb: 4.8, marketCap: 7810 },
  { symbol: "300750", name: "宁德时代", sector: "锂电池", price: 198.40, pe: 18.6, pb: 5.2, marketCap: 8650 },
  { symbol: "601899", name: "紫金矿业", sector: "有色金属", price: 16.85, pe: 12.4, pb: 3.5, marketCap: 4450 },
  { symbol: "000858", name: "五粮液", sector: "白酒", price: 148.20, pe: 20.1, pb: 5.8, marketCap: 5750 },
  { symbol: "002475", name: "立讯精密", sector: "消费电子", price: 38.45, pe: 25.3, pb: 6.1, marketCap: 2780 },
  { symbol: "600900", name: "长江电力", sector: "电力", price: 28.90, pe: 22.8, pb: 4.2, marketCap: 7050 },
  { symbol: "601012", name: "隆基绿能", sector: "光伏", price: 22.15, pe: 15.2, pb: 2.8, marketCap: 1680 },
  { symbol: "000333", name: "美的集团", sector: "家电", price: 68.50, pe: 12.8, pb: 3.6, marketCap: 4780 },
  { symbol: "600276", name: "恒瑞医药", sector: "医药", price: 45.30, pe: 42.5, pb: 7.8, marketCap: 2890 },
  { symbol: "601166", name: "兴业银行", sector: "银行", price: 18.25, pe: 5.2, pb: 0.6, marketCap: 3790 },
  { symbol: "000001", name: "平安银行", sector: "银行", price: 12.45, pe: 5.8, pb: 0.7, marketCap: 2420 },
  { symbol: "600030", name: "中信证券", sector: "证券", price: 22.80, pe: 18.5, pb: 1.5, marketCap: 3380 },
  { symbol: "601398", name: "工商银行", sector: "银行", price: 5.82, pe: 5.5, pb: 0.6, marketCap: 20850 },
  { symbol: "601288", name: "农业银行", sector: "银行", price: 4.15, pe: 5.1, pb: 0.5, marketCap: 14520 },
  { symbol: "600028", name: "中国石化", sector: "石油化工", price: 5.98, pe: 8.8, pb: 0.8, marketCap: 7240 },
  { symbol: "601857", name: "中国石油", sector: "石油化工", price: 8.92, pe: 9.2, pb: 0.9, marketCap: 16320 },
  { symbol: "600809", name: "山西汾酒", sector: "白酒", price: 215.60, pe: 32.5, pb: 10.2, marketCap: 2630 },
  { symbol: "002714", name: "牧原股份", sector: "养殖", price: 42.80, pe: -15.2, pb: 3.2, marketCap: 2340 },
  { symbol: "300059", name: "东方财富", sector: "互联网金融", price: 16.75, pe: 28.5, pb: 4.5, marketCap: 2650 },
  { symbol: "688981", name: "中芯国际", sector: "半导体", price: 52.30, pe: 85.2, pb: 2.1, marketCap: 4150 },
  { symbol: "688012", name: "中微公司", sector: "半导体设备", price: 148.50, pe: 65.3, pb: 8.5, marketCap: 890 },
  { symbol: "300760", name: "迈瑞医疗", sector: "医疗器械", price: 285.40, pe: 35.2, pb: 12.5, marketCap: 3460 },
  { symbol: "002415", name: "海康威视", sector: "安防", price: 32.60, pe: 22.8, pb: 5.2, marketCap: 3050 },
  { symbol: "600887", name: "伊利股份", sector: "乳制品", price: 28.90, pe: 18.5, pb: 4.8, marketCap: 1850 },
  { symbol: "000568", name: "泸州老窖", sector: "白酒", price: 168.30, pe: 22.1, pb: 7.5, marketCap: 2480 },
  { symbol: "601888", name: "中国中免", sector: "免税", price: 78.50, pe: 32.5, pb: 5.8, marketCap: 1620 },
  { symbol: "002304", name: "洋河股份", sector: "白酒", price: 98.60, pe: 15.8, pb: 3.2, marketCap: 1480 },
  { symbol: "600585", name: "海螺水泥", sector: "建材", price: 25.40, pe: 8.5, pb: 1.2, marketCap: 1350 },
  { symbol: "601668", name: "中国建筑", sector: "建筑", price: 6.85, pe: 4.8, pb: 0.7, marketCap: 2870 },
  { symbol: "600050", name: "中国联通", sector: "通信", price: 5.42, pe: 15.2, pb: 1.1, marketCap: 1680 },
  { symbol: "000725", name: "京东方A", sector: "面板", price: 4.58, pe: 22.5, pb: 1.5, marketCap: 1590 },
  { symbol: "002230", name: "科大讯飞", sector: "人工智能", price: 52.80, pe: 125.0, pb: 6.8, marketCap: 1220 },
  { symbol: "688111", name: "金山办公", sector: "软件", price: 328.50, pe: 85.2, pb: 18.5, marketCap: 1510 },
  { symbol: "300124", name: "汇川技术", sector: "工控", price: 62.30, pe: 35.8, pb: 8.2, marketCap: 1650 },
  { symbol: "002352", name: "顺丰控股", sector: "物流", price: 42.15, pe: 28.5, pb: 2.8, marketCap: 2050 },
  { symbol: "600309", name: "万华化学", sector: "化工", price: 82.40, pe: 15.2, pb: 3.5, marketCap: 2580 },
  { symbol: "002049", name: "紫光国微", sector: "芯片", price: 128.50, pe: 42.5, pb: 8.2, marketCap: 780 },
  { symbol: "603259", name: "药明康德", sector: "CXO", price: 52.80, pe: 18.5, pb: 3.2, marketCap: 1560 },
  { symbol: "688036", name: "传音控股", sector: "手机", price: 85.20, pe: 15.8, pb: 4.5, marketCap: 680 },
  { symbol: "300274", name: "阳光电源", sector: "光伏逆变器", price: 78.50, pe: 18.2, pb: 5.8, marketCap: 1180 },
  { symbol: "002371", name: "北方华创", sector: "半导体设备", price: 285.60, pe: 55.2, pb: 12.5, marketCap: 1520 },
  { symbol: "600438", name: "通威股份", sector: "光伏硅料", price: 25.80, pe: 8.5, pb: 1.8, marketCap: 1160 },
  { symbol: "601919", name: "中远海控", sector: "航运", price: 12.85, pe: 5.2, pb: 1.2, marketCap: 2050 },
  { symbol: "000002", name: "万科A", sector: "房地产", price: 8.52, pe: -8.5, pb: 0.5, marketCap: 1020 },
  { symbol: "600690", name: "海尔智家", sector: "家电", price: 28.50, pe: 14.5, pb: 2.8, marketCap: 2680 },
  { symbol: "002142", name: "宁波银行", sector: "银行", price: 25.80, pe: 6.2, pb: 1.0, marketCap: 1700 },
  { symbol: "300015", name: "爱尔眼科", sector: "医疗服务", price: 12.85, pe: 42.5, pb: 6.8, marketCap: 720 },
];

// ============================================================
// 美股 (30只)
// ============================================================
const usStocks = [
  { symbol: "AAPL", name: "苹果 Apple", sector: "科技", price: 178.50, pe: 28.5, pb: 45.2, marketCap: 27800 },
  { symbol: "MSFT", name: "微软 Microsoft", sector: "科技", price: 425.80, pe: 35.2, pb: 12.8, marketCap: 31600 },
  { symbol: "NVDA", name: "英伟达 NVIDIA", sector: "半导体", price: 875.50, pe: 65.8, pb: 52.3, marketCap: 21500 },
  { symbol: "TSLA", name: "特斯拉 Tesla", sector: "新能源汽车", price: 185.20, pe: 52.3, pb: 12.5, marketCap: 5890 },
  { symbol: "GOOGL", name: "谷歌 Alphabet", sector: "科技", price: 155.80, pe: 25.2, pb: 6.8, marketCap: 19200 },
  { symbol: "AMZN", name: "亚马逊 Amazon", sector: "电商/云", price: 185.40, pe: 58.5, pb: 8.5, marketCap: 19100 },
  { symbol: "META", name: "Meta Platforms", sector: "社交", price: 505.20, pe: 28.5, pb: 8.2, marketCap: 12800 },
  { symbol: "BRK.B", name: "伯克希尔B Berkshire", sector: "多元金融", price: 418.50, pe: 9.2, pb: 1.5, marketCap: 8950 },
  { symbol: "LLY", name: "礼来 Eli Lilly", sector: "医药", price: 785.20, pe: 125.0, pb: 52.8, marketCap: 7450 },
  { symbol: "JPM", name: "摩根大通 JPMorgan", sector: "银行", price: 198.50, pe: 11.5, pb: 1.8, marketCap: 5720 },
  { symbol: "V", name: "Visa", sector: "支付", price: 278.50, pe: 32.5, pb: 15.2, marketCap: 5680 },
  { symbol: "UNH", name: "联合健康 UnitedHealth", sector: "医疗保险", price: 528.50, pe: 22.8, pb: 6.5, marketCap: 4890 },
  { symbol: "AVGO", name: "博通 Broadcom", sector: "半导体", price: 1385.20, pe: 32.5, pb: 12.8, marketCap: 6450 },
  { symbol: "XOM", name: "埃克森美孚 Exxon", sector: "石油", price: 108.50, pe: 12.5, pb: 2.1, marketCap: 4580 },
  { symbol: "MA", name: "万事达 Mastercard", sector: "支付", price: 458.50, pe: 35.8, pb: 58.5, marketCap: 4280 },
  { symbol: "HD", name: "家得宝 Home Depot", sector: "零售", price: 365.20, pe: 25.2, pb: 185.0, marketCap: 3650 },
  { symbol: "COST", name: "好市多 Costco", sector: "零售", price: 728.50, pe: 48.5, pb: 15.2, marketCap: 3230 },
  { symbol: "PG", name: "宝洁 P&G", sector: "日用消费", price: 162.50, pe: 25.8, pb: 8.2, marketCap: 3820 },
  { symbol: "JNJ", name: "强生 J&J", sector: "医药", price: 158.50, pe: 18.5, pb: 5.8, marketCap: 3820 },
  { symbol: "ABBV", name: "艾伯维 AbbVie", sector: "生物制药", price: 178.50, pe: 18.2, pb: -12.5, marketCap: 3150 },
  { symbol: "CRM", name: "Salesforce", sector: "云计算", price: 268.50, pe: 48.5, pb: 4.5, marketCap: 2580 },
  { symbol: "AMD", name: "AMD", sector: "半导体", price: 165.80, pe: 42.5, pb: 4.2, marketCap: 2680 },
  { symbol: "NFLX", name: "奈飞 Netflix", sector: "流媒体", price: 628.50, pe: 42.5, pb: 15.2, marketCap: 2720 },
  { symbol: "INTC", name: "英特尔 Intel", sector: "半导体", price: 32.50, pe: -15.2, pb: 1.2, marketCap: 1380 },
  { symbol: "DIS", name: "迪士尼 Disney", sector: "娱乐", price: 112.50, pe: 68.5, pb: 2.1, marketCap: 2050 },
  { symbol: "BABA", name: "阿里巴巴ADR", sector: "电商", price: 85.20, pe: 12.5, pb: 1.8, marketCap: 2150 },
  { symbol: "PDD", name: "拼多多ADR", sector: "电商", price: 128.50, pe: 15.8, pb: 5.2, marketCap: 1780 },
  { symbol: "NIO", name: "蔚来ADR", sector: "新能源汽车", price: 5.85, pe: -8.5, pb: 2.8, marketCap: 120 },
  { symbol: "COIN", name: "Coinbase", sector: "加密交易所", price: 225.50, pe: 35.2, pb: 8.5, marketCap: 550 },
  { symbol: "PLTR", name: "Palantir", sector: "大数据/AI", price: 22.50, pe: 185.0, pb: 18.5, marketCap: 480 },
];

// ============================================================
// 港股 (20只)
// ============================================================
const hkStocks = [
  { symbol: "00700.HK", name: "腾讯控股", sector: "互联网", price: 378.80, pe: 22.5, pb: 4.8, marketCap: 36200 },
  { symbol: "09988.HK", name: "阿里巴巴-SW", sector: "电商", price: 82.50, pe: 12.8, pb: 1.6, marketCap: 16850 },
  { symbol: "01810.HK", name: "小米集团-W", sector: "消费电子", price: 18.50, pe: 22.5, pb: 3.2, marketCap: 4620 },
  { symbol: "03690.HK", name: "美团-W", sector: "本地生活", price: 128.50, pe: 32.5, pb: 5.8, marketCap: 7980 },
  { symbol: "09618.HK", name: "京东集团-SW", sector: "电商", price: 128.50, pe: 12.5, pb: 1.8, marketCap: 4050 },
  { symbol: "09999.HK", name: "网易-S", sector: "游戏", price: 158.50, pe: 15.8, pb: 4.2, marketCap: 5120 },
  { symbol: "01024.HK", name: "快手-W", sector: "短视频", price: 52.80, pe: 28.5, pb: 2.8, marketCap: 2280 },
  { symbol: "02318.HK", name: "中国平安", sector: "保险", price: 42.50, pe: 7.8, pb: 0.9, marketCap: 7680 },
  { symbol: "00941.HK", name: "中国移动", sector: "通信", price: 72.50, pe: 12.5, pb: 1.5, marketCap: 15520 },
  { symbol: "00388.HK", name: "香港交易所", sector: "金融基础设施", price: 285.50, pe: 32.5, pb: 8.5, marketCap: 3620 },
  { symbol: "02020.HK", name: "安踏体育", sector: "运动品牌", price: 85.20, pe: 22.5, pb: 6.8, marketCap: 2380 },
  { symbol: "01211.HK", name: "比亚迪股份", sector: "新能源汽车", price: 258.50, pe: 22.8, pb: 4.5, marketCap: 7520 },
  { symbol: "00005.HK", name: "汇丰控股", sector: "银行", price: 65.80, pe: 8.5, pb: 0.9, marketCap: 12850 },
  { symbol: "01299.HK", name: "友邦保险", sector: "保险", price: 58.50, pe: 15.2, pb: 2.1, marketCap: 6850 },
  { symbol: "02269.HK", name: "药明生物", sector: "CXO", price: 18.50, pe: 25.8, pb: 2.8, marketCap: 780 },
  { symbol: "09626.HK", name: "哔哩哔哩-SW", sector: "视频社区", price: 128.50, pe: -42.5, pb: 2.5, marketCap: 520 },
  { symbol: "00981.HK", name: "中芯国际", sector: "半导体", price: 28.50, pe: 85.2, pb: 1.8, marketCap: 2250 },
  { symbol: "06618.HK", name: "京东健康", sector: "医疗健康", price: 32.50, pe: 42.5, pb: 2.8, marketCap: 1050 },
  { symbol: "01347.HK", name: "华虹半导体", sector: "半导体", price: 28.80, pe: 32.5, pb: 1.5, marketCap: 380 },
  { symbol: "02015.HK", name: "理想汽车-W", sector: "新能源汽车", price: 128.50, pe: 35.2, pb: 5.8, marketCap: 2680 },
];

// ============================================================
// 期货 (25个品种)
// ============================================================
const futures = [
  { symbol: "AU2406", name: "沪金2406", sector: "贵金属", price: 558.20, exchange: "SHFE" },
  { symbol: "AG2406", name: "沪银2406", sector: "贵金属", price: 7285.00, exchange: "SHFE" },
  { symbol: "CU2406", name: "沪铜2406", sector: "有色金属", price: 78520.00, exchange: "SHFE" },
  { symbol: "AL2406", name: "沪铝2406", sector: "有色金属", price: 20350.00, exchange: "SHFE" },
  { symbol: "ZN2406", name: "沪锌2406", sector: "有色金属", price: 22850.00, exchange: "SHFE" },
  { symbol: "NI2406", name: "沪镍2406", sector: "有色金属", price: 138500.00, exchange: "SHFE" },
  { symbol: "RB2410", name: "螺纹钢2410", sector: "黑色系", price: 3685.00, exchange: "SHFE" },
  { symbol: "HC2410", name: "热卷2410", sector: "黑色系", price: 3820.00, exchange: "SHFE" },
  { symbol: "I2409", name: "铁矿石2409", sector: "黑色系", price: 825.50, exchange: "DCE" },
  { symbol: "J2409", name: "焦炭2409", sector: "黑色系", price: 2285.00, exchange: "DCE" },
  { symbol: "JM2409", name: "焦煤2409", sector: "黑色系", price: 1685.00, exchange: "DCE" },
  { symbol: "SC2406", name: "原油2406", sector: "能源", price: 628.50, exchange: "INE" },
  { symbol: "FU2409", name: "燃料油2409", sector: "能源", price: 3285.00, exchange: "SHFE" },
  { symbol: "LU2409", name: "低硫燃油2409", sector: "能源", price: 4125.00, exchange: "INE" },
  { symbol: "A2409", name: "豆一2409", sector: "农产品", price: 4850.00, exchange: "DCE" },
  { symbol: "M2409", name: "豆粕2409", sector: "农产品", price: 3285.00, exchange: "DCE" },
  { symbol: "Y2409", name: "豆油2409", sector: "农产品", price: 7850.00, exchange: "DCE" },
  { symbol: "P2409", name: "棕榈油2409", sector: "农产品", price: 7520.00, exchange: "DCE" },
  { symbol: "C2409", name: "玉米2409", sector: "农产品", price: 2485.00, exchange: "DCE" },
  { symbol: "CF2409", name: "棉花2409", sector: "农产品", price: 15280.00, exchange: "CZCE" },
  { symbol: "SR2409", name: "白糖2409", sector: "农产品", price: 6520.00, exchange: "CZCE" },
  { symbol: "TA2409", name: "PTA2409", sector: "化工", price: 5850.00, exchange: "CZCE" },
  { symbol: "MA2409", name: "甲醇2409", sector: "化工", price: 2485.00, exchange: "CZCE" },
  { symbol: "PP2409", name: "聚丙烯2409", sector: "化工", price: 7285.00, exchange: "DCE" },
  { symbol: "RU2409", name: "天然橡胶2409", sector: "化工", price: 14850.00, exchange: "SHFE" },
];

// ============================================================
// 期权 (15个品种)
// ============================================================
const options = [
  { symbol: "510050C2406M03200", name: "50ETF购6月3200", sector: "ETF期权", price: 0.1285, exchange: "SSE" },
  { symbol: "510050P2406M03200", name: "50ETF沽6月3200", sector: "ETF期权", price: 0.0528, exchange: "SSE" },
  { symbol: "510050C2406M03300", name: "50ETF购6月3300", sector: "ETF期权", price: 0.0685, exchange: "SSE" },
  { symbol: "510050P2406M03300", name: "50ETF沽6月3300", sector: "ETF期权", price: 0.1125, exchange: "SSE" },
  { symbol: "510300C2406M04000", name: "300ETF购6月4000", sector: "ETF期权", price: 0.1520, exchange: "SSE" },
  { symbol: "510300P2406M04000", name: "300ETF沽6月4000", sector: "ETF期权", price: 0.0685, exchange: "SSE" },
  { symbol: "IO2406-C-4000", name: "沪深300指数购6月4000", sector: "指数期权", price: 125.80, exchange: "CFFEX" },
  { symbol: "IO2406-P-4000", name: "沪深300指数沽6月4000", sector: "指数期权", price: 58.50, exchange: "CFFEX" },
  { symbol: "MO2406-C-3000", name: "中证1000指数购6月3000", sector: "指数期权", price: 85.20, exchange: "CFFEX" },
  { symbol: "MO2406-P-3000", name: "中证1000指数沽6月3000", sector: "指数期权", price: 42.50, exchange: "CFFEX" },
  { symbol: "CU2406C78000", name: "铜期权购6月78000", sector: "商品期权", price: 1850.00, exchange: "SHFE" },
  { symbol: "CU2406P78000", name: "铜期权沽6月78000", sector: "商品期权", price: 520.00, exchange: "SHFE" },
  { symbol: "AU2406C560", name: "黄金期权购6月560", sector: "商品期权", price: 8.50, exchange: "SHFE" },
  { symbol: "M2409-C-3300", name: "豆粕期权购9月3300", sector: "商品期权", price: 85.50, exchange: "DCE" },
  { symbol: "SR2409C6500", name: "白糖期权购9月6500", sector: "商品期权", price: 128.50, exchange: "CZCE" },
];

// ============================================================
// 基金 (15只)
// ============================================================
const funds = [
  { symbol: "510050", name: "华夏上证50ETF", sector: "宽基ETF", price: 3.185, exchange: "SSE" },
  { symbol: "510300", name: "华泰柏瑞沪深300ETF", sector: "宽基ETF", price: 3.985, exchange: "SSE" },
  { symbol: "159919", name: "嘉实沪深300ETF", sector: "宽基ETF", price: 3.952, exchange: "SZSE" },
  { symbol: "510500", name: "南方中证500ETF", sector: "宽基ETF", price: 5.825, exchange: "SSE" },
  { symbol: "159915", name: "易方达创业板ETF", sector: "宽基ETF", price: 1.285, exchange: "SZSE" },
  { symbol: "512100", name: "南方中证1000ETF", sector: "宽基ETF", price: 1.125, exchange: "SSE" },
  { symbol: "512880", name: "国泰证券ETF", sector: "行业ETF", price: 0.985, exchange: "SSE" },
  { symbol: "515790", name: "光伏ETF", sector: "行业ETF", price: 0.628, exchange: "SSE" },
  { symbol: "512690", name: "酒ETF", sector: "行业ETF", price: 0.852, exchange: "SSE" },
  { symbol: "512010", name: "医药ETF", sector: "行业ETF", price: 0.425, exchange: "SSE" },
  { symbol: "159941", name: "纳指ETF", sector: "跨境ETF", price: 1.685, exchange: "SZSE" },
  { symbol: "513100", name: "纳斯达克100ETF", sector: "跨境ETF", price: 1.825, exchange: "SSE" },
  { symbol: "513050", name: "中概互联网ETF", sector: "跨境ETF", price: 0.785, exchange: "SSE" },
  { symbol: "518880", name: "华安黄金ETF", sector: "商品ETF", price: 5.520, exchange: "SSE" },
  { symbol: "159985", name: "豆粕ETF", sector: "商品ETF", price: 1.285, exchange: "SZSE" },
];

// ============================================================
// 债券 (10只)
// ============================================================
const bonds = [
  { symbol: "019733", name: "24国债01", sector: "国债", price: 100.25, exchange: "SSE" },
  { symbol: "019738", name: "24国债06", sector: "国债", price: 99.85, exchange: "SSE" },
  { symbol: "019741", name: "24国债09", sector: "国债", price: 100.52, exchange: "SSE" },
  { symbol: "113050", name: "南银转债", sector: "可转债", price: 118.50, exchange: "SSE" },
  { symbol: "127060", name: "牧原转债", sector: "可转债", price: 125.80, exchange: "SZSE" },
  { symbol: "123136", name: "宁德转债", sector: "可转债", price: 142.50, exchange: "SZSE" },
  { symbol: "110085", name: "中信转债", sector: "可转债", price: 108.20, exchange: "SSE" },
  { symbol: "128135", name: "科达转债", sector: "可转债", price: 132.50, exchange: "SZSE" },
  { symbol: "204001", name: "GC001国债逆回购", sector: "逆回购", price: 1.85, exchange: "SSE" },
  { symbol: "131810", name: "R-001深市逆回购", sector: "逆回购", price: 1.92, exchange: "SZSE" },
];

// ============================================================
// 全球指数 (15个)
// ============================================================
const indices = [
  { symbol: "000001.SH", name: "上证指数", sector: "A股指数", price: 3185.50, exchange: "SSE" },
  { symbol: "399001.SZ", name: "深证成指", sector: "A股指数", price: 10285.50, exchange: "SZSE" },
  { symbol: "399006.SZ", name: "创业板指", sector: "A股指数", price: 1985.50, exchange: "SZSE" },
  { symbol: "000016.SH", name: "上证50", sector: "A股指数", price: 2685.50, exchange: "SSE" },
  { symbol: "000300.SH", name: "沪深300", sector: "A股指数", price: 3785.50, exchange: "SSE" },
  { symbol: "HSI", name: "恒生指数", sector: "港股指数", price: 18285.50, exchange: "HKEX" },
  { symbol: "HSTECH", name: "恒生科技指数", sector: "港股指数", price: 4285.50, exchange: "HKEX" },
  { symbol: "DJI", name: "道琼斯工业指数", sector: "美股指数", price: 39285.50, exchange: "NYSE" },
  { symbol: "IXIC", name: "纳斯达克综合指数", sector: "美股指数", price: 16285.50, exchange: "NASDAQ" },
  { symbol: "SPX", name: "标普500指数", sector: "美股指数", price: 5285.50, exchange: "NYSE" },
  { symbol: "N225", name: "日经225指数", sector: "亚太指数", price: 39850.50, exchange: "TSE" },
  { symbol: "GDAXI", name: "德国DAX指数", sector: "欧洲指数", price: 18285.50, exchange: "XETR" },
  { symbol: "FTSE", name: "英国富时100指数", sector: "欧洲指数", price: 8185.50, exchange: "LSE" },
  { symbol: "FCHI", name: "法国CAC40指数", sector: "欧洲指数", price: 8085.50, exchange: "PAR" },
  { symbol: "AORD", name: "澳大利亚ASX200", sector: "亚太指数", price: 7850.50, exchange: "ASX" },
];

// ============================================================
// 外汇 (10对)
// ============================================================
const forex = [
  { symbol: "USDCNY", name: "美元/人民币", sector: "主要货币对", price: 7.2485, exchange: "CFETS" },
  { symbol: "EURUSD", name: "欧元/美元", sector: "主要货币对", price: 1.0852, exchange: "FX" },
  { symbol: "GBPUSD", name: "英镑/美元", sector: "主要货币对", price: 1.2685, exchange: "FX" },
  { symbol: "USDJPY", name: "美元/日元", sector: "主要货币对", price: 151.85, exchange: "FX" },
  { symbol: "AUDUSD", name: "澳元/美元", sector: "主要货币对", price: 0.6585, exchange: "FX" },
  { symbol: "USDCHF", name: "美元/瑞郎", sector: "主要货币对", price: 0.8825, exchange: "FX" },
  { symbol: "USDCAD", name: "美元/加元", sector: "主要货币对", price: 1.3585, exchange: "FX" },
  { symbol: "NZDUSD", name: "纽元/美元", sector: "主要货币对", price: 0.6085, exchange: "FX" },
  { symbol: "EURGBP", name: "欧元/英镑", sector: "交叉货币对", price: 0.8552, exchange: "FX" },
  { symbol: "EURJPY", name: "欧元/日元", sector: "交叉货币对", price: 164.85, exchange: "FX" },
];

// ============================================================
// 加密货币 (10个)
// ============================================================
const crypto = [
  { symbol: "BTCUSDT", name: "比特币 Bitcoin", sector: "主流币", price: 68520.50, exchange: "BINANCE" },
  { symbol: "ETHUSDT", name: "以太坊 Ethereum", sector: "主流币", price: 3485.20, exchange: "BINANCE" },
  { symbol: "BNBUSDT", name: "币安币 BNB", sector: "平台币", price: 585.50, exchange: "BINANCE" },
  { symbol: "SOLUSDT", name: "Solana", sector: "公链", price: 178.50, exchange: "BINANCE" },
  { symbol: "XRPUSDT", name: "瑞波币 XRP", sector: "支付", price: 0.5285, exchange: "BINANCE" },
  { symbol: "ADAUSDT", name: "卡尔达诺 Cardano", sector: "公链", price: 0.4585, exchange: "BINANCE" },
  { symbol: "DOGEUSDT", name: "狗狗币 Dogecoin", sector: "Meme", price: 0.1585, exchange: "BINANCE" },
  { symbol: "DOTUSDT", name: "波卡 Polkadot", sector: "跨链", price: 7.285, exchange: "BINANCE" },
  { symbol: "AVAXUSDT", name: "Avalanche", sector: "公链", price: 38.50, exchange: "BINANCE" },
  { symbol: "LINKUSDT", name: "Chainlink", sector: "预言机", price: 15.85, exchange: "BINANCE" },
];

// ============================================================
// Helper: insert quotes
// ============================================================
async function insertQuotes(items, market, defaultExchange) {
  for (const item of items) {
    const prevClose = item.price * (1 + (Math.random() - 0.5) * 0.04);
    const change = item.price - prevClose;
    const changePercent = (change / prevClose * 100);
    const volume = Math.floor(Math.random() * 50000000 + 1000000);
    const turnover = volume * item.price;
    const marketCap = item.marketCap ? item.marketCap * 1e8 : null;

    await conn.execute(
      `INSERT INTO market_quotes (symbol, name, market, exchange, lastPrice, openPrice, highPrice, lowPrice, prevClose, changeVal, changePercent, volume, turnover, marketCap, pe, pb, sector, listingType)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'secondary')`,
      [
        item.symbol,
        item.name,
        market,
        item.exchange || defaultExchange,
        item.price.toFixed(4),
        (item.price * (1 + (Math.random() - 0.5) * 0.01)).toFixed(4),
        (item.price * (1 + Math.random() * 0.03)).toFixed(4),
        (item.price * (1 - Math.random() * 0.03)).toFixed(4),
        prevClose.toFixed(4),
        change.toFixed(4),
        changePercent.toFixed(4),
        volume,
        turnover.toFixed(4),
        marketCap ? marketCap.toFixed(4) : null,
        item.pe || null,
        item.pb || null,
        item.sector,
      ]
    );
  }
}

console.log("📊 Inserting A股 (50)...");
await insertQuotes(aShares, "a_share", "SSE");
console.log("📊 Inserting 美股 (30)...");
await insertQuotes(usStocks, "us_stock", "NYSE");
console.log("📊 Inserting 港股 (20)...");
await insertQuotes(hkStocks, "hk_stock", "HKEX");
console.log("📊 Inserting 期货 (25)...");
await insertQuotes(futures, "futures", "SHFE");
console.log("📊 Inserting 期权 (15)...");
// Need to handle options - they don't have pe/pb/marketCap
for (const item of options) {
  const prevClose = item.price * (1 + (Math.random() - 0.5) * 0.1);
  const change = item.price - prevClose;
  const changePercent = (change / prevClose * 100);
  const volume = Math.floor(Math.random() * 500000 + 10000);
  await conn.execute(
    `INSERT INTO market_quotes (symbol, name, market, exchange, lastPrice, openPrice, highPrice, lowPrice, prevClose, changeVal, changePercent, volume, turnover, sector, listingType)
     VALUES (?, ?, 'option', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'secondary')`,
    [
      item.symbol, item.name, item.exchange,
      item.price.toFixed(4),
      (item.price * (1 + (Math.random() - 0.5) * 0.02)).toFixed(4),
      (item.price * (1 + Math.random() * 0.05)).toFixed(4),
      (item.price * (1 - Math.random() * 0.05)).toFixed(4),
      prevClose.toFixed(4),
      change.toFixed(4), changePercent.toFixed(4),
      volume, (volume * item.price).toFixed(4), item.sector,
    ]
  );
}
console.log("📊 Inserting 基金 (15)...");
await insertQuotes(funds.map(f => ({ ...f, pe: null, pb: null, marketCap: null })), "fund", "SSE");
console.log("📊 Inserting 债券 (10)...");
await insertQuotes(bonds.map(b => ({ ...b, pe: null, pb: null, marketCap: null })), "bond", "SSE");
console.log("📊 Inserting 全球指数 (15)...");
await insertQuotes(indices.map(i => ({ ...i, pe: null, pb: null, marketCap: null })), "index", "");
console.log("📊 Inserting 外汇 (10)...");
await insertQuotes(forex.map(f => ({ ...f, pe: null, pb: null, marketCap: null })), "forex", "FX");
console.log("📊 Inserting 加密货币 (10)...");
await insertQuotes(crypto.map(c => ({ ...c, pe: null, pb: null, marketCap: null })), "crypto", "BINANCE");

// Verify
const [rows] = await conn.execute("SELECT market, COUNT(*) as cnt FROM market_quotes GROUP BY market ORDER BY cnt DESC");
console.log("\n✅ 全品种数据导入完成！");
console.log("各市场品种数量：");
for (const r of rows) {
  console.log(`  ${r.market}: ${r.cnt} 个品种`);
}
const [total] = await conn.execute("SELECT COUNT(*) as total FROM market_quotes");
console.log(`\n📈 总计: ${total[0].total} 个品种`);

await conn.end();
console.log("🎉 Done!");
