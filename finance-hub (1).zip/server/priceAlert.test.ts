import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock database
vi.mock("./db", () => ({
  db: {
    select: vi.fn().mockReturnThis(),
    from: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnThis(),
    orderBy: vi.fn().mockReturnThis(),
    limit: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    values: vi.fn().mockReturnThis(),
    update: vi.fn().mockReturnThis(),
    set: vi.fn().mockReturnThis(),
    delete: vi.fn().mockReturnThis(),
    execute: vi.fn().mockResolvedValue([]),
  },
}));

describe("Price Alert Service", () => {
  it("should define alert types correctly", () => {
    const validTypes = ["change_percent_above", "change_percent_below", "price_above", "price_below"];
    expect(validTypes).toHaveLength(4);
    expect(validTypes).toContain("change_percent_above");
    expect(validTypes).toContain("price_below");
  });

  it("should validate threshold values", () => {
    const threshold = "5.00";
    const parsed = parseFloat(threshold);
    expect(parsed).toBe(5);
    expect(isNaN(parsed)).toBe(false);
  });

  it("should validate cooldown minutes", () => {
    const validCooldowns = [5, 15, 30, 60, 240, 1440];
    for (const cd of validCooldowns) {
      expect(cd).toBeGreaterThanOrEqual(5);
      expect(cd).toBeLessThanOrEqual(1440);
    }
  });
});

describe("Sector Heatmap Logic", () => {
  it("should aggregate stocks by sector correctly", () => {
    const stocks = [
      { sector: "科技", changePercent: 2.5, volume: 1000 },
      { sector: "科技", changePercent: -1.0, volume: 2000 },
      { sector: "银行", changePercent: 0.5, volume: 3000 },
    ];

    const sectorMap = new Map<string, { total: number; count: number; volume: number }>();
    for (const s of stocks) {
      const existing = sectorMap.get(s.sector) || { total: 0, count: 0, volume: 0 };
      existing.total += s.changePercent;
      existing.count += 1;
      existing.volume += s.volume;
      sectorMap.set(s.sector, existing);
    }

    const techSector = sectorMap.get("科技")!;
    expect(techSector.count).toBe(2);
    expect(techSector.total / techSector.count).toBeCloseTo(0.75);
    expect(techSector.volume).toBe(3000);

    const bankSector = sectorMap.get("银行")!;
    expect(bankSector.count).toBe(1);
    expect(bankSector.total / bankSector.count).toBeCloseTo(0.5);
  });

  it("should sort sectors by stock count for treemap layout", () => {
    const sectors = [
      { sector: "科技", stockCount: 15 },
      { sector: "银行", stockCount: 8 },
      { sector: "医药", stockCount: 12 },
    ];

    const sorted = [...sectors].sort((a, b) => b.stockCount - a.stockCount);
    expect(sorted[0].sector).toBe("科技");
    expect(sorted[1].sector).toBe("医药");
    expect(sorted[2].sector).toBe("银行");
  });

  it("should calculate heat color based on change percent", () => {
    function getHeatLevel(pct: number): string {
      if (pct >= 5) return "strong_up";
      if (pct >= 3) return "up";
      if (pct >= 1) return "mild_up";
      if (pct > -1) return "flat";
      if (pct > -3) return "mild_down";
      if (pct > -5) return "down";
      return "strong_down";
    }

    expect(getHeatLevel(6)).toBe("strong_up");
    expect(getHeatLevel(3.5)).toBe("up");
    expect(getHeatLevel(1.5)).toBe("mild_up");
    expect(getHeatLevel(0)).toBe("flat");
    expect(getHeatLevel(-2)).toBe("mild_down");
    expect(getHeatLevel(-4)).toBe("down");
    expect(getHeatLevel(-6)).toBe("strong_down");
  });
});

describe("Index Intraday Data", () => {
  it("should generate intraday data points with correct structure", () => {
    // Simulate intraday data generation
    const basePrice = 3150;
    const points: Array<{ time: string; price: number; volume: number }> = [];
    
    for (let i = 0; i < 120; i++) {
      const hour = 9 + Math.floor((i * 2 + 30) / 60);
      const minute = (i * 2 + 30) % 60;
      const time = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      const price = basePrice + (Math.random() - 0.5) * 50;
      const volume = Math.floor(Math.random() * 10000000);
      points.push({ time, price, volume });
    }

    expect(points.length).toBe(120);
    expect(points[0].time).toBe("09:30");
    
    for (const p of points) {
      expect(p.price).toBeGreaterThan(0);
      expect(p.volume).toBeGreaterThanOrEqual(0);
      expect(p.time).toMatch(/^\d{2}:\d{2}$/);
    }
  });

  it("should generate sparkline SVG path from price data", () => {
    const prices = [100, 102, 99, 103, 101, 105];
    const minP = Math.min(...prices);
    const maxP = Math.max(...prices);
    const range = maxP - minP;
    
    expect(range).toBe(6);
    expect(minP).toBe(99);
    expect(maxP).toBe(105);

    // Generate path points
    const w = 120;
    const h = 32;
    const padding = 2;
    const pathPoints = prices.map((p, i) => {
      const x = padding + (i / (prices.length - 1)) * (w - 2 * padding);
      const y = padding + (1 - (p - minP) / range) * (h - 2 * padding);
      return { x, y };
    });

    expect(pathPoints.length).toBe(6);
    // First point should be at x=padding
    expect(pathPoints[0].x).toBe(2);
    // Last point should be near w-padding
    expect(pathPoints[pathPoints.length - 1].x).toBeCloseTo(118);
    // Min price should be at bottom (high y)
    const minPricePoint = pathPoints[2]; // price 99
    expect(minPricePoint.y).toBeCloseTo(30); // near bottom
    // Max price should be at top (low y)
    const maxPricePoint = pathPoints[5]; // price 105
    expect(maxPricePoint.y).toBeCloseTo(2); // near top
  });
});

describe("Price Alert Check Logic", () => {
  it("should trigger alert when change percent exceeds threshold", () => {
    const alert = { alertType: "change_percent_above", threshold: "5.00", isEnabled: true };
    const quote = { changePercent: "6.50" };

    const changePct = Math.abs(parseFloat(quote.changePercent));
    const threshold = parseFloat(alert.threshold);

    if (alert.alertType === "change_percent_above") {
      expect(changePct > threshold).toBe(true);
    }
  });

  it("should not trigger alert when below threshold", () => {
    const alert = { alertType: "change_percent_above", threshold: "5.00", isEnabled: true };
    const quote = { changePercent: "3.20" };

    const changePct = Math.abs(parseFloat(quote.changePercent));
    const threshold = parseFloat(alert.threshold);

    if (alert.alertType === "change_percent_above") {
      expect(changePct > threshold).toBe(false);
    }
  });

  it("should respect cooldown period", () => {
    const now = Date.now();
    const lastTriggered = now - 10 * 60 * 1000; // 10 minutes ago
    const cooldownMinutes = 30;

    const cooldownMs = cooldownMinutes * 60 * 1000;
    const canTrigger = (now - lastTriggered) >= cooldownMs;

    expect(canTrigger).toBe(false); // 10 min < 30 min cooldown
  });

  it("should trigger after cooldown expires", () => {
    const now = Date.now();
    const lastTriggered = now - 60 * 60 * 1000; // 60 minutes ago
    const cooldownMinutes = 30;

    const cooldownMs = cooldownMinutes * 60 * 1000;
    const canTrigger = (now - lastTriggered) >= cooldownMs;

    expect(canTrigger).toBe(true); // 60 min >= 30 min cooldown
  });

  it("should check price_above and price_below correctly", () => {
    const priceAboveAlert = { alertType: "price_above", threshold: "100.00" };
    const priceBelowAlert = { alertType: "price_below", threshold: "50.00" };
    const currentPrice = 110;

    // price_above: trigger when price > threshold
    expect(currentPrice > parseFloat(priceAboveAlert.threshold)).toBe(true);
    // price_below: trigger when price < threshold
    expect(currentPrice < parseFloat(priceBelowAlert.threshold)).toBe(false);
  });
});
