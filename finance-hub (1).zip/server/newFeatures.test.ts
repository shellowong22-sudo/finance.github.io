import { describe, it, expect, vi } from "vitest";

// ============================================================
// Portfolio Stats Tests
// ============================================================
describe("Portfolio Stats", () => {
  it("should calculate portfolio stats from watchlist with quotes", () => {
    // Simulate portfolio calculation logic
    const watchlistItems = [
      { symbol: "600519.SS", name: "贵州茅台", latestPrice: 1800, changePercent: 2.5, volume: 50000 },
      { symbol: "000858.SZ", name: "五粮液", latestPrice: 160, changePercent: -1.2, volume: 80000 },
      { symbol: "601318.SS", name: "中国平安", latestPrice: 45, changePercent: 0.8, volume: 120000 },
    ];

    const totalItems = watchlistItems.length;
    expect(totalItems).toBe(3);

    const avgChange = watchlistItems.reduce((sum, item) => sum + item.changePercent, 0) / totalItems;
    expect(avgChange).toBeCloseTo(0.7, 1);

    const gainers = watchlistItems.filter(i => i.changePercent > 0).length;
    const losers = watchlistItems.filter(i => i.changePercent < 0).length;
    expect(gainers).toBe(2);
    expect(losers).toBe(1);

    const maxGainer = watchlistItems.reduce((max, i) => i.changePercent > max.changePercent ? i : max);
    expect(maxGainer.symbol).toBe("600519.SS");

    const maxLoser = watchlistItems.reduce((min, i) => i.changePercent < min.changePercent ? i : min);
    expect(maxLoser.symbol).toBe("000858.SZ");
  });

  it("should handle empty watchlist gracefully", () => {
    const watchlistItems: any[] = [];
    const totalItems = watchlistItems.length;
    expect(totalItems).toBe(0);

    const avgChange = totalItems > 0 ? watchlistItems.reduce((sum: number, item: any) => sum + item.changePercent, 0) / totalItems : 0;
    expect(avgChange).toBe(0);
  });

  it("should handle all-gainers portfolio", () => {
    const items = [
      { changePercent: 3.5 },
      { changePercent: 1.2 },
      { changePercent: 0.1 },
    ];
    const gainers = items.filter(i => i.changePercent > 0).length;
    const losers = items.filter(i => i.changePercent < 0).length;
    expect(gainers).toBe(3);
    expect(losers).toBe(0);
  });
});

// ============================================================
// Sector Heatmap Expansion Tests
// ============================================================
describe("Sector Heatmap Stock Expansion", () => {
  it("should return stocks within a sector", () => {
    const sectorData = {
      name: "科技",
      avgChange: 2.1,
      stockCount: 15,
      totalVolume: 5000000,
      stocks: [
        { symbol: "AAPL", name: "苹果", changePercent: 3.2, latestPrice: 180 },
        { symbol: "MSFT", name: "微软", changePercent: 1.5, latestPrice: 420 },
        { symbol: "GOOGL", name: "谷歌", changePercent: -0.5, latestPrice: 170 },
      ],
    };

    expect(sectorData.stocks.length).toBeGreaterThan(0);
    expect(sectorData.stocks[0].symbol).toBe("AAPL");
  });

  it("should sort stocks by changePercent descending", () => {
    const stocks = [
      { symbol: "A", changePercent: -1.5 },
      { symbol: "B", changePercent: 3.2 },
      { symbol: "C", changePercent: 0.8 },
    ];

    const sorted = [...stocks].sort((a, b) => b.changePercent - a.changePercent);
    expect(sorted[0].symbol).toBe("B");
    expect(sorted[sorted.length - 1].symbol).toBe("A");
  });

  it("should map changePercent to color correctly", () => {
    const getColor = (change: number): string => {
      if (change >= 5) return "deep-green";
      if (change >= 2) return "green";
      if (change > 0) return "light-green";
      if (change === 0) return "neutral";
      if (change > -2) return "light-red";
      if (change > -5) return "red";
      return "deep-red";
    };

    expect(getColor(7)).toBe("deep-green");
    expect(getColor(3)).toBe("green");
    expect(getColor(0.5)).toBe("light-green");
    expect(getColor(0)).toBe("neutral");
    expect(getColor(-1)).toBe("light-red");
    expect(getColor(-3)).toBe("red");
    expect(getColor(-6)).toBe("deep-red");
  });

  it("should handle sector with no stocks", () => {
    const sector = { name: "未分类", avgChange: 0, stockCount: 0, stocks: [] };
    expect(sector.stocks.length).toBe(0);
    expect(sector.stockCount).toBe(0);
  });
});

// ============================================================
// Index K-line Click Navigation Tests
// ============================================================
describe("Index Card K-line Navigation", () => {
  it("should map index names to correct symbols", () => {
    const indexNameMap: Record<string, string> = {
      "上证指数": "000001.SS",
      "深证成指": "399001.SZ",
      "创业板指": "399006.SZ",
      "恒生指数": "^HSI",
      "道琼斯": "^DJI",
      "标普500": "^GSPC",
      "纳斯达克": "^IXIC",
      "日经225": "^N225",
      "富时100": "^FTSE",
      "德国DAX": "^GDAXI",
    };

    expect(indexNameMap["上证指数"]).toBe("000001.SS");
    expect(indexNameMap["道琼斯"]).toBe("^DJI");
    expect(indexNameMap["恒生指数"]).toBe("^HSI");
    expect(Object.keys(indexNameMap).length).toBe(10);
  });

  it("should include index symbols in klineSymbols list", () => {
    const klineSymbols = [
      "600519.SS", "000858.SZ", // regular stocks
      "000001.SS", "399001.SZ", "^DJI", "^GSPC", // indices
    ];

    expect(klineSymbols.includes("000001.SS")).toBe(true);
    expect(klineSymbols.includes("^DJI")).toBe(true);
  });

  it("should generate valid sparkline SVG path from data points", () => {
    const dataPoints = [100, 102, 101, 103, 105, 104, 106];
    const width = 120;
    const height = 40;
    const min = Math.min(...dataPoints);
    const max = Math.max(...dataPoints);
    const range = max - min || 1;

    const points = dataPoints.map((v, i) => {
      const x = (i / (dataPoints.length - 1)) * width;
      const y = height - ((v - min) / range) * height;
      return `${x},${y}`;
    });

    const path = `M${points.join(" L")}`;
    expect(path).toContain("M");
    expect(path).toContain("L");
    expect(path.split("L").length).toBe(dataPoints.length);
  });
});

// ============================================================
// AI Module Upgrade Tests
// ============================================================
describe("AI Module Competitiveness Framework", () => {
  it("should have all 6 competitiveness pillars defined", () => {
    const pillars = [
      "数据壁垒", "模型效率", "降本增效",
      "场景独占", "多模态融合", "生态绑定",
    ];
    expect(pillars.length).toBe(6);
    expect(pillars).toContain("数据壁垒");
    expect(pillars).toContain("多模态融合");
  });

  it("should have 12 AI tool capabilities", () => {
    const tools = [
      "行情查询", "K线分析", "板块热力图", "组合分析",
      "价格预警", "情感分析", "风险预测", "智能推荐",
      "内容摘要", "智能问答", "用户画像", "市场趋势",
    ];
    expect(tools.length).toBe(12);
  });

  it("should validate sentiment analysis output format", () => {
    const mockResult = {
      sentiment: "positive",
      score: 75,
      confidence: 85,
      keywords: ["利好", "增长"],
      summary: "市场情绪偏正面",
      riskLevel: "low",
    };

    expect(["positive", "negative", "neutral"]).toContain(mockResult.sentiment);
    expect(mockResult.score).toBeGreaterThanOrEqual(0);
    expect(mockResult.score).toBeLessThanOrEqual(100);
    expect(mockResult.confidence).toBeGreaterThanOrEqual(0);
    expect(mockResult.confidence).toBeLessThanOrEqual(100);
    expect(["low", "medium", "high"]).toContain(mockResult.riskLevel);
  });

  it("should validate risk prediction output format", () => {
    const mockResult = {
      riskLevel: "medium",
      riskScore: 55,
      suggestions: ["分散投资", "增加债券配比"],
      summary: "中等风险水平",
      assetAllocation: [
        { asset: "股票", ratio: 50, reason: "增长潜力" },
        { asset: "债券", ratio: 30, reason: "稳定收益" },
        { asset: "现金", ratio: 20, reason: "流动性" },
      ],
    };

    expect(["low", "medium", "high", "very_high"]).toContain(mockResult.riskLevel);
    expect(mockResult.riskScore).toBeGreaterThanOrEqual(0);
    expect(mockResult.riskScore).toBeLessThanOrEqual(100);
    const totalRatio = mockResult.assetAllocation.reduce((sum, a) => sum + a.ratio, 0);
    expect(totalRatio).toBe(100);
  });
});
