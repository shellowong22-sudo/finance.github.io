import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
  bigint,
  json,
} from "drizzle-orm/mysql-core";

// ============================================================
// 用户表
// ============================================================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }), // 存储脱敏后的手机号
  avatar: text("avatar"),
  bio: text("bio"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "channel"]).default("user").notNull(),
  status: mysqlEnum("status", ["active", "banned", "pending"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============================================================
// 文章分类表
// ============================================================
export const articleCategories = mysqlTable("article_categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 文章表
// ============================================================
export const articles = mysqlTable("articles", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  summary: text("summary"),
  content: text("content").notNull(),
  coverImage: text("coverImage"),
  authorId: int("authorId").notNull(),
  categoryId: int("categoryId"),
  tags: text("tags"), // JSON array of strings
  status: mysqlEnum("status", ["draft", "pending", "published", "rejected", "offline"]).default("draft").notNull(),
  isTop: boolean("isTop").default(false).notNull(),
  isPinned: boolean("isPinned").default(false).notNull(),
  viewCount: int("viewCount").default(0).notNull(),
  likeCount: int("likeCount").default(0).notNull(),
  commentCount: int("commentCount").default(0).notNull(),
  shareCount: int("shareCount").default(0).notNull(),
  rejectReason: text("rejectReason"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 评论表
// ============================================================
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  content: text("content").notNull(),
  authorId: int("authorId").notNull(),
  articleId: int("articleId"),
  parentId: int("parentId"), // 回复评论
  status: mysqlEnum("status", ["active", "hidden", "deleted"]).default("active").notNull(),
  likeCount: int("likeCount").default(0).notNull(),
  isFiltered: boolean("isFiltered").default(false).notNull(), // 违规过滤标记
  filterReason: text("filterReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 点赞表
// ============================================================
export const likes = mysqlTable("likes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  targetType: mysqlEnum("targetType", ["article", "comment", "report", "course"]).notNull(),
  targetId: int("targetId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 关注表
// ============================================================
export const follows = mysqlTable("follows", {
  id: int("id").autoincrement().primaryKey(),
  followerId: int("followerId").notNull(),
  followingId: int("followingId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 私信表
// ============================================================
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  receiverId: int("receiverId").notNull(),
  content: text("content").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  isFiltered: boolean("isFiltered").default(false).notNull(),
  filterReason: text("filterReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 研报表
// ============================================================
export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  summary: text("summary"),
  fileUrl: text("fileUrl").notNull(),
  fileKey: text("fileKey").notNull(),
  fileType: mysqlEnum("fileType", ["pdf", "word"]).default("pdf").notNull(),
  fileSize: int("fileSize").default(0),
  coverImage: text("coverImage"),
  authorId: int("authorId").notNull(),
  institution: varchar("institution", { length: 200 }), // 发布机构
  category: mysqlEnum("category", ["macro", "industry", "stock", "strategy", "fixed_income"]).default("macro").notNull(),
  tags: text("tags"),
  isPaid: boolean("isPaid").default(false).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).default("0.00"),
  status: mysqlEnum("status", ["draft", "published", "offline"]).default("draft").notNull(),
  viewCount: int("viewCount").default(0).notNull(),
  downloadCount: int("downloadCount").default(0).notNull(),
  favoriteCount: int("favoriteCount").default(0).notNull(),
  totalReadDuration: bigint("totalReadDuration", { mode: "number" }).default(0), // 总阅读时长(秒)
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 研报收藏表
// ============================================================
export const reportFavorites = mysqlTable("report_favorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  reportId: int("reportId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 研报下载记录表
// ============================================================
export const reportDownloads = mysqlTable("report_downloads", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  reportId: int("reportId").notNull(),
  downloadedAt: timestamp("downloadedAt").defaultNow().notNull(),
  ipAddress: varchar("ipAddress", { length: 64 }),
});

// ============================================================
// 研报阅读时长记录表
// ============================================================
export const reportReadLogs = mysqlTable("report_read_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  reportId: int("reportId").notNull(),
  duration: int("duration").default(0).notNull(), // 本次阅读时长(秒)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 讲师表
// ============================================================
export const instructors = mysqlTable("instructors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  realName: varchar("realName", { length: 100 }).notNull(),
  title: varchar("title", { length: 200 }), // 职称
  organization: varchar("organization", { length: 200 }),
  bio: text("bio"),
  avatar: text("avatar"),
  expertise: text("expertise"), // JSON array
  courseCount: int("courseCount").default(0).notNull(),
  studentCount: int("studentCount").default(0).notNull(),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("5.00"),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 课程表
// ============================================================
export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  coverImage: text("coverImage"),
  instructorId: int("instructorId").notNull(),
  category: mysqlEnum("category", ["finance", "fund", "stock", "risk", "crypto", "forex"]).default("finance").notNull(),
  type: mysqlEnum("type", ["video", "graphic"]).default("video").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).default("0.00"),
  originalPrice: decimal("originalPrice", { precision: 10, scale: 2 }),
  isFree: boolean("isFree").default(false).notNull(),
  status: mysqlEnum("status", ["draft", "published", "offline"]).default("draft").notNull(),
  totalDuration: int("totalDuration").default(0), // 总时长(分钟)
  chapterCount: int("chapterCount").default(0).notNull(),
  studentCount: int("studentCount").default(0).notNull(),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("5.00"),
  ratingCount: int("ratingCount").default(0).notNull(),
  hasExam: boolean("hasExam").default(false).notNull(),
  hasCertificate: boolean("hasCertificate").default(false).notNull(),
  refundPolicy: text("refundPolicy"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 课程章节表
// ============================================================
export const courseChapters = mysqlTable("course_chapters", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  videoUrl: text("videoUrl"),
  content: text("content"), // 图文内容
  duration: int("duration").default(0), // 时长(分钟)
  sortOrder: int("sortOrder").default(0).notNull(),
  isFree: boolean("isFree").default(false).notNull(), // 是否免费试看
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 课程购买记录表
// ============================================================
export const coursePurchases = mysqlTable("course_purchases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["active", "refunded", "expired"]).default("active").notNull(),
  refundReason: text("refundReason"),
  refundedAt: timestamp("refundedAt"),
  channelId: int("channelId"), // 渠道来源
  promoCode: varchar("promoCode", { length: 100 }),
  purchasedAt: timestamp("purchasedAt").defaultNow().notNull(),
});

// ============================================================
// 课程学习进度表
// ============================================================
export const courseProgress = mysqlTable("course_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  chapterId: int("chapterId").notNull(),
  progress: int("progress").default(0).notNull(), // 0-100 百分比
  watchedDuration: int("watchedDuration").default(0), // 已观看时长(秒)
  isCompleted: boolean("isCompleted").default(false).notNull(),
  lastWatchedAt: timestamp("lastWatchedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 考试题目表
// ============================================================
export const examQuestions = mysqlTable("exam_questions", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  question: text("question").notNull(),
  type: mysqlEnum("type", ["single", "multiple", "truefalse"]).default("single").notNull(),
  options: text("options").notNull(), // JSON array
  answer: text("answer").notNull(), // JSON array of correct answers
  explanation: text("explanation"),
  score: int("score").default(10).notNull(),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 考试记录表
// ============================================================
export const examRecords = mysqlTable("exam_records", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  answers: text("answers").notNull(), // JSON
  score: int("score").default(0).notNull(),
  totalScore: int("totalScore").default(100).notNull(),
  isPassed: boolean("isPassed").default(false).notNull(),
  passScore: int("passScore").default(60).notNull(),
  duration: int("duration").default(0), // 考试用时(秒)
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
});

// ============================================================
// 证书表
// ============================================================
export const certificates = mysqlTable("certificates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  examRecordId: int("examRecordId"),
  certificateNo: varchar("certificateNo", { length: 100 }).notNull().unique(),
  certificateUrl: text("certificateUrl"),
  issuedAt: timestamp("issuedAt").defaultNow().notNull(),
});

// ============================================================
// 课程评价表
// ============================================================
export const courseReviews = mysqlTable("course_reviews", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  rating: int("rating").default(5).notNull(), // 1-5
  content: text("content"),
  status: mysqlEnum("status", ["active", "hidden"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 渠道合作表
// ============================================================
export const channels = mysqlTable("channels", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  companyName: varchar("companyName", { length: 200 }).notNull(),
  contactName: varchar("contactName", { length: 100 }).notNull(),
  contactPhone: varchar("contactPhone", { length: 20 }).notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }).notNull(),
  channelType: mysqlEnum("channelType", ["broker", "bank", "media", "other"]).default("other").notNull(),
  businessLicense: text("businessLicense"), // 营业执照URL
  qualificationDocs: text("qualificationDocs"), // JSON array of doc URLs
  description: text("description"),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "suspended"]).default("pending").notNull(),
  rejectReason: text("rejectReason"),
  commissionRate: decimal("commissionRate", { precision: 5, scale: 2 }).default("0.00"), // 分成比例%
  contractUrl: text("contractUrl"),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 推广链接表
// ============================================================
export const promoLinks = mysqlTable("promo_links", {
  id: int("id").autoincrement().primaryKey(),
  channelId: int("channelId").notNull(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  targetType: mysqlEnum("targetType", ["course", "report", "platform"]).default("platform").notNull(),
  targetId: int("targetId"),
  clickCount: int("clickCount").default(0).notNull(),
  convertCount: int("convertCount").default(0).notNull(),
  revenue: decimal("revenue", { precision: 12, scale: 2 }).default("0.00"),
  isActive: boolean("isActive").default(true).notNull(),
  expiredAt: timestamp("expiredAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 渠道订单结算表
// ============================================================
export const channelSettlements = mysqlTable("channel_settlements", {
  id: int("id").autoincrement().primaryKey(),
  channelId: int("channelId").notNull(),
  orderId: int("orderId").notNull(), // 关联课程购买记录
  orderAmount: decimal("orderAmount", { precision: 10, scale: 2 }).notNull(),
  commissionRate: decimal("commissionRate", { precision: 5, scale: 2 }).notNull(),
  commissionAmount: decimal("commissionAmount", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "settled", "cancelled"]).default("pending").notNull(),
  settledAt: timestamp("settledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 敏感词表
// ============================================================
export const sensitiveWords = mysqlTable("sensitive_words", {
  id: int("id").autoincrement().primaryKey(),
  word: varchar("word", { length: 200 }).notNull().unique(),
  category: mysqlEnum("category", ["finance", "political", "obscene", "fraud", "other"]).default("finance").notNull(),
  level: mysqlEnum("level", ["block", "review", "warn"]).default("block").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 审核日志表
// ============================================================
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  targetType: varchar("targetType", { length: 50 }).notNull(),
  targetId: int("targetId").notNull(),
  beforeData: text("beforeData"), // JSON
  afterData: text("afterData"), // JSON
  remark: text("remark"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 用户行为统计表（日维度）
// ============================================================
export const userStats = mysqlTable("user_stats", {
  id: int("id").autoincrement().primaryKey(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  newUsers: int("newUsers").default(0).notNull(),
  activeUsers: int("activeUsers").default(0).notNull(),
  articleViews: int("articleViews").default(0).notNull(),
  reportDownloads: int("reportDownloads").default(0).notNull(),
  courseEnrollments: int("courseEnrollments").default(0).notNull(),
  revenue: decimal("revenue", { precision: 12, scale: 2 }).default("0.00"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 爬虫文章来源表
// ============================================================
export const crawledArticles = mysqlTable("crawled_articles", {
  id: int("id").autoincrement().primaryKey(),
  sourceUrl: text("sourceUrl").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  originalTitle: varchar("originalTitle", { length: 500 }),
  content: text("content").notNull(),
  summary: text("summary"),
  author: varchar("author", { length: 100 }),
  publishedAt: timestamp("publishedAt"),
  isImported: boolean("isImported").default(false).notNull(),
  importedArticleId: int("importedArticleId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - 交易账户表
// ============================================================
export const tradingAccounts = mysqlTable("trading_accounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  accountName: varchar("accountName", { length: 200 }).notNull(),
  broker: varchar("broker", { length: 200 }).notNull(), // 券商名称
  market: mysqlEnum("market", ["a_share", "us_stock", "hk_stock", "futures", "option", "fund", "bond", "crypto", "forex", "global"]).notNull(),
  accountType: mysqlEnum("accountType", ["live", "paper"]).default("paper").notNull(), // 实盘/模拟
  // 使用Decimal精度，禁止float/double
  balance: decimal("balance", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  availableBalance: decimal("availableBalance", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  frozenBalance: decimal("frozenBalance", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  totalPnl: decimal("totalPnl", { precision: 20, scale: 4 }).default("0.0000").notNull(), // 总盈亏
  todayPnl: decimal("todayPnl", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  currency: varchar("currency", { length: 10 }).default("CNY").notNull(),
  apiKeyEncrypted: text("apiKeyEncrypted"), // 加密存储API密钥
  apiSecretEncrypted: text("apiSecretEncrypted"),
  status: mysqlEnum("status", ["active", "disabled", "suspended"]).default("active").notNull(),
  riskLevel: mysqlEnum("riskLevel", ["low", "medium", "high", "critical"]).default("low").notNull(),
  lastSyncAt: timestamp("lastSyncAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 量化金融系统 - 市场行情表
// ============================================================
export const marketQuotes = mysqlTable("market_quotes", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull(), // 股票代码
  name: varchar("name", { length: 200 }).notNull(),
  market: mysqlEnum("market", ["a_share", "us_stock", "hk_stock", "futures", "option", "fund", "bond", "crypto", "forex", "index"]).notNull(),
  exchange: varchar("exchange", { length: 50 }), // 交易所 (SSE/SZSE/NYSE/NASDAQ/HKEX)
  // 全部使用Decimal精度
  lastPrice: decimal("lastPrice", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  openPrice: decimal("openPrice", { precision: 20, scale: 4 }).default("0.0000"),
  highPrice: decimal("highPrice", { precision: 20, scale: 4 }).default("0.0000"),
  lowPrice: decimal("lowPrice", { precision: 20, scale: 4 }).default("0.0000"),
  prevClose: decimal("prevClose", { precision: 20, scale: 4 }).default("0.0000"),
  change: decimal("changeVal", { precision: 20, scale: 4 }).default("0.0000"),
  changePercent: decimal("changePercent", { precision: 10, scale: 4 }).default("0.0000"),
  volume: bigint("volume", { mode: "number" }).default(0),
  turnover: decimal("turnover", { precision: 20, scale: 4 }).default("0.0000"), // 成交额
  marketCap: decimal("marketCap", { precision: 24, scale: 4 }), // 市值
  pe: decimal("pe", { precision: 12, scale: 4 }), // 市盈率
  pb: decimal("pb", { precision: 12, scale: 4 }), // 市净率
  sector: varchar("sector", { length: 100 }), // 所属板块
  listingType: mysqlEnum("listingType", ["primary", "secondary"]).default("secondary").notNull(), // 一级/二级市场
  ipoDate: varchar("ipoDate", { length: 10 }), // IPO日期
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 量化金融系统 - K线数据表
// ============================================================
export const klineData = mysqlTable("kline_data", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  market: varchar("market", { length: 20 }).notNull(),
  period: varchar("period", { length: 10 }).notNull(),
  openPrice: decimal("openPrice", { precision: 20, scale: 4 }).notNull(),
  highPrice: decimal("highPrice", { precision: 20, scale: 4 }).notNull(),
  lowPrice: decimal("lowPrice", { precision: 20, scale: 4 }).notNull(),
  closePrice: decimal("closePrice", { precision: 20, scale: 4 }).notNull(),
  volume: bigint("volume", { mode: "number" }).default(0).notNull(),
  turnover: decimal("turnover", { precision: 20, scale: 4 }).default("0.0000"),
  timestamp: bigint("timestamp", { mode: "number" }).notNull(), // Unix毫秒时间戳
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - 交易策略表
// ============================================================
export const quantStrategies = mysqlTable("quant_strategies", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  strategyType: mysqlEnum("strategyType", ["trend", "mean_reversion", "arbitrage", "momentum", "value", "ml_based", "hft", "custom"]).notNull(),
  applicableMarkets: text("applicableMarkets"), // JSON: ["a_share", "us_stock"]
  code: text("code"), // 策略代码/逻辑描述
  parameters: text("parameters"), // JSON: 策略参数
  status: mysqlEnum("status", ["draft", "backtesting", "paper_trading", "live", "paused", "stopped", "archived"]).default("draft").notNull(),
  riskLevel: mysqlEnum("riskLevel", ["conservative", "moderate", "aggressive"]).default("moderate").notNull(),
  // 绩效指标
  totalReturn: decimal("totalReturn", { precision: 12, scale: 4 }).default("0.0000"),
  annualReturn: decimal("annualReturn", { precision: 12, scale: 4 }).default("0.0000"),
  maxDrawdown: decimal("maxDrawdown", { precision: 12, scale: 4 }).default("0.0000"),
  sharpeRatio: decimal("sharpeRatio", { precision: 8, scale: 4 }).default("0.0000"),
  winRate: decimal("winRate", { precision: 8, scale: 4 }).default("0.0000"),
  totalTrades: int("totalTrades").default(0).notNull(),
  isPublic: boolean("isPublic").default(false).notNull(), // 是否公开到策略市场
  approvalStatus: mysqlEnum("approvalStatus", ["pending", "approved", "rejected"]).default("pending"),
  complianceCheck: boolean("complianceCheck").default(false).notNull(), // 合规检查通过
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 量化金融系统 - 交易订单表（严格状态机）
// ============================================================
export const quantOrders = mysqlTable("quant_orders", {
  id: int("id").autoincrement().primaryKey(),
  idempotentId: varchar("idempotentId", { length: 64 }).notNull().unique(), // 幂等ID，防重单
  userId: int("userId").notNull(),
  accountId: int("accountId").notNull(),
  strategyId: int("strategyId"), // 关联策略（手动下单可为空）
  symbol: varchar("symbol", { length: 20 }).notNull(),
  market: varchar("market", { length: 20 }).notNull(),
  // 订单状态机：严格遵循交易所规则
  orderStatus: mysqlEnum("orderStatus", [
    "pending_submit",   // 待提交
    "submitted",        // 已报
    "partial_filled",   // 部分成交
    "filled",           // 全部成交
    "pending_cancel",   // 待撤单
    "cancelled",        // 已撤单
    "rejected",         // 废单
    "error"             // 异常
  ]).default("pending_submit").notNull(),
  orderType: mysqlEnum("orderType", ["market", "limit", "stop", "stop_limit"]).default("limit").notNull(),
  side: mysqlEnum("side", ["buy", "sell"]).notNull(),
  // 全部Decimal精度
  price: decimal("price", { precision: 20, scale: 4 }), // 委托价格（市价单可为空）
  quantity: decimal("quantity", { precision: 20, scale: 4 }).notNull(), // 委托数量
  filledQuantity: decimal("filledQuantity", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  filledPrice: decimal("filledPrice", { precision: 20, scale: 4 }).default("0.0000"), // 成交均价
  commission: decimal("commission", { precision: 12, scale: 4 }).default("0.0000"), // 手续费
  slippage: decimal("slippage", { precision: 12, scale: 4 }).default("0.0000"), // 滑点
  stampDuty: decimal("stampDuty", { precision: 12, scale: 4 }).default("0.0000"), // 印花税
  exchangeOrderId: varchar("exchangeOrderId", { length: 100 }), // 交易所订单号
  riskCheckPassed: boolean("riskCheckPassed").default(false).notNull(), // 风控检查通过
  riskCheckDetail: text("riskCheckDetail"), // 风控检查详情JSON
  errorMessage: text("errorMessage"),
  submittedAt: timestamp("submittedAt"),
  filledAt: timestamp("filledAt"),
  cancelledAt: timestamp("cancelledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 量化金融系统 - 持仓表
// ============================================================
export const positions = mysqlTable("positions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  accountId: int("accountId").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  symbolName: varchar("symbolName", { length: 200 }),
  market: varchar("market", { length: 20 }).notNull(),
  side: mysqlEnum("side", ["long", "short"]).default("long").notNull(),
  quantity: decimal("quantity", { precision: 20, scale: 4 }).notNull(),
  avgCost: decimal("avgCost", { precision: 20, scale: 4 }).notNull(), // 平均成本价
  currentPrice: decimal("currentPrice", { precision: 20, scale: 4 }).default("0.0000"),
  marketValue: decimal("marketValue", { precision: 20, scale: 4 }).default("0.0000"), // 市值
  unrealizedPnl: decimal("unrealizedPnl", { precision: 20, scale: 4 }).default("0.0000"), // 浮动盈亏
  realizedPnl: decimal("realizedPnl", { precision: 20, scale: 4 }).default("0.0000"), // 已实现盈亏
  pnlPercent: decimal("pnlPercent", { precision: 10, scale: 4 }).default("0.0000"), // 盈亏比例
  todayBuyQty: decimal("todayBuyQty", { precision: 20, scale: 4 }).default("0.0000"),
  todaySellQty: decimal("todaySellQty", { precision: 20, scale: 4 }).default("0.0000"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 量化金融系统 - 风控规则表（独立部署，不可绕过）
// ============================================================
export const riskRules = mysqlTable("risk_rules", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  ruleType: mysqlEnum("ruleType", [
    "max_order_amount",      // 单笔最大下单量
    "max_daily_loss",        // 单日最大亏损
    "max_position",          // 总仓位上限
    "max_single_position",   // 单标的持仓上限
    "price_deviation",       // 价格偏离保护
    "frequency_limit",       // 频繁下单限制
    "large_order_alert",     // 超大额订单预警
    "drawdown_limit",        // 回撤限制
    "market_price_protect",  // 市价单保护
    "reverse_position",      // 反向开仓限制
    "custom"                 // 自定义规则
  ]).notNull(),
  market: varchar("market", { length: 20 }).default("all").notNull(), // 适用市场
  thresholdValue: decimal("thresholdValue", { precision: 20, scale: 4 }), // 阈值
  thresholdConfig: text("thresholdConfig"), // JSON: 复杂阈值配置
  action: mysqlEnum("action", ["block", "alert", "review"]).default("block").notNull(), // 触发动作
  priority: int("priority").default(1).notNull(), // 优先级（1最高）
  isEnabled: boolean("isEnabled").default(true).notNull(),
  isMandatory: boolean("isMandatory").default(true).notNull(), // 硬性规则不可绕过
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// 量化金融系统 - 风控日志表
// ============================================================
export const riskLogs = mysqlTable("risk_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  ruleId: int("ruleId"),
  ruleName: varchar("ruleName", { length: 200 }),
  orderId: int("orderId"),
  triggerType: mysqlEnum("triggerType", ["blocked", "alerted", "reviewed", "emergency_stop"]).notNull(),
  triggerDetail: text("triggerDetail"), // JSON: 触发详情
  market: varchar("market", { length: 20 }),
  symbol: varchar("symbol", { length: 20 }),
  orderAmount: decimal("orderAmount", { precision: 20, scale: 4 }),
  riskScore: int("riskScore").default(0), // 风险评分 0-100
  isResolved: boolean("isResolved").default(false).notNull(),
  resolvedBy: int("resolvedBy"),
  resolvedAt: timestamp("resolvedAt"),
  remark: text("remark"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - 回测记录表
// ============================================================
export const backtestRecords = mysqlTable("backtest_records", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  strategyId: int("strategyId").notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  market: varchar("market", { length: 20 }).notNull(),
  symbols: text("symbols"), // JSON: 回测标的列表
  startDate: varchar("startDate", { length: 10 }).notNull(), // YYYY-MM-DD
  endDate: varchar("endDate", { length: 10 }).notNull(),
  initialCapital: decimal("initialCapital", { precision: 20, scale: 4 }).notNull(),
  // 回测参数
  slippageModel: varchar("slippageModel", { length: 50 }).default("fixed"), // 滑点模型
  slippageValue: decimal("slippageValue", { precision: 10, scale: 4 }).default("0.0010"), // 滑点值
  commissionRate: decimal("commissionRate", { precision: 10, scale: 6 }).default("0.000300"), // 手续费率
  stampDutyRate: decimal("stampDutyRate", { precision: 10, scale: 6 }).default("0.001000"), // 印花税率
  // 回测结果
  status: mysqlEnum("status", ["running", "completed", "failed", "cancelled"]).default("running").notNull(),
  finalCapital: decimal("finalCapital", { precision: 20, scale: 4 }),
  totalReturn: decimal("totalReturn", { precision: 12, scale: 4 }),
  annualReturn: decimal("annualReturn", { precision: 12, scale: 4 }),
  maxDrawdown: decimal("maxDrawdown", { precision: 12, scale: 4 }),
  sharpeRatio: decimal("sharpeRatio", { precision: 8, scale: 4 }),
  sortinoRatio: decimal("sortinoRatio", { precision: 8, scale: 4 }),
  calmarRatio: decimal("calmarRatio", { precision: 8, scale: 4 }),
  winRate: decimal("winRate", { precision: 8, scale: 4 }),
  profitFactor: decimal("profitFactor", { precision: 8, scale: 4 }),
  totalTrades: int("totalTrades").default(0),
  winTrades: int("winTrades").default(0),
  lossTrades: int("lossTrades").default(0),
  avgWin: decimal("avgWin", { precision: 12, scale: 4 }),
  avgLoss: decimal("avgLoss", { precision: 12, scale: 4 }),
  equityCurve: text("equityCurve"), // JSON: 权益曲线数据
  drawdownCurve: text("drawdownCurve"), // JSON: 回撤曲线
  monthlyReturns: text("monthlyReturns"), // JSON: 月度收益
  errorMessage: text("errorMessage"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - 回测交易记录表
// ============================================================
export const backtestTrades = mysqlTable("backtest_trades", {
  id: int("id").autoincrement().primaryKey(),
  backtestId: int("backtestId").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  side: mysqlEnum("side", ["buy", "sell"]).notNull(),
  price: decimal("price", { precision: 20, scale: 4 }).notNull(),
  quantity: decimal("quantity", { precision: 20, scale: 4 }).notNull(),
  commission: decimal("commission", { precision: 12, scale: 4 }).default("0.0000"),
  slippage: decimal("slippage", { precision: 12, scale: 4 }).default("0.0000"),
  pnl: decimal("pnl", { precision: 20, scale: 4 }).default("0.0000"),
  pnlPercent: decimal("pnlPercent", { precision: 10, scale: 4 }).default("0.0000"),
  holdingPeriod: int("holdingPeriod").default(0), // 持仓天数
  tradeTimestamp: bigint("tradeTimestamp", { mode: "number" }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - 合规审计表
// ============================================================
export const complianceAudit = mysqlTable("compliance_audit", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  operatorName: varchar("operatorName", { length: 100 }).notNull(), // 实名制
  actionType: mysqlEnum("actionType", [
    "order_submit",      // 下单
    "order_cancel",      // 撤单
    "strategy_modify",   // 策略修改
    "risk_rule_change",  // 风控规则变更
    "account_change",    // 账户变更
    "emergency_stop",    // 紧急停止
    "data_export",       // 数据导出
    "config_change",     // 配置变更
    "login",             // 登录
    "logout"             // 登出
  ]).notNull(),
  targetType: varchar("targetType", { length: 50 }),
  targetId: int("targetId"),
  detail: text("detail"), // JSON: 操作详情
  ipAddress: varchar("ipAddress", { length: 64 }),
  userAgent: text("userAgent"),
  isCompliant: boolean("isCompliant").default(true).notNull(), // 是否合规
  complianceNote: text("complianceNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - 监控告警表
// ============================================================
export const monitorAlerts = mysqlTable("monitor_alerts", {
  id: int("id").autoincrement().primaryKey(),
  alertType: mysqlEnum("alertType", [
    "service_down",       // 服务宕机
    "high_latency",       // 高延迟
    "order_failure",      // 订单失败
    "risk_trigger",       // 风控触发
    "data_anomaly",       // 数据异常
    "network_issue",      // 网络问题
    "cpu_overload",       // CPU过载
    "memory_overload",    // 内存过载
    "disk_full",          // 磁盘满
    "security_breach",    // 安全入侵
    "compliance_violation" // 合规违规
  ]).notNull(),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low"]).default("medium").notNull(),
  title: varchar("title", { length: 300 }).notNull(),
  message: text("message").notNull(),
  source: varchar("source", { length: 100 }), // 告警来源服务
  metric: varchar("metric", { length: 100 }), // 监控指标
  currentValue: varchar("currentValue", { length: 100 }),
  thresholdValue: varchar("thresholdValue", { length: 100 }),
  isResolved: boolean("isResolved").default(false).notNull(),
  resolvedBy: int("resolvedBy"),
  resolvedAt: timestamp("resolvedAt"),
  acknowledgedBy: int("acknowledgedBy"),
  acknowledgedAt: timestamp("acknowledgedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 量化金融系统 - IPO/一级市场信息表
// ============================================================
export const ipoInfo = mysqlTable("ipo_info", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  companyName: varchar("companyName", { length: 300 }).notNull(),
  market: varchar("market", { length: 20 }).notNull(),
  exchange: varchar("exchange", { length: 50 }),
  ipoPrice: decimal("ipoPrice", { precision: 20, scale: 4 }),
  ipoShares: bigint("ipoShares", { mode: "number" }),
  totalRaised: decimal("totalRaised", { precision: 20, scale: 4 }),
  ipoDate: varchar("ipoDate", { length: 10 }),
  listingDate: varchar("listingDate", { length: 10 }),
  status: mysqlEnum("status", ["upcoming", "open", "closed", "listed", "withdrawn"]).default("upcoming").notNull(),
  industry: varchar("industry", { length: 100 }),
  underwriter: varchar("underwriter", { length: 300 }),
  prospectusUrl: text("prospectusUrl"),
  description: text("description"),
  subscriptionStart: timestamp("subscriptionStart"),
  subscriptionEnd: timestamp("subscriptionEnd"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// AI 助手 - 对话会话表
// ============================================================
export const aiConversations = mysqlTable("ai_conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 200 }),
  style: varchar("style", { length: 50 }).default("professional"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// AI 助手 - 对话消息表
// ============================================================
export const aiMessages = mysqlTable("ai_messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  /** JSON metadata: kline data, tool calls info, etc. */
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 自选股表
// ============================================================
export const userWatchlist = mysqlTable("user_watchlist", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  name: varchar("name", { length: 200 }),
  market: varchar("market", { length: 20 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  note: text("note"), // 用户备注
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ============================================================
// 价格预警表
// ============================================================
export const priceAlerts = mysqlTable("price_alerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  name: varchar("name", { length: 200 }),
  market: varchar("market", { length: 20 }).notNull(),
  alertType: mysqlEnum("alertType", [
    "change_percent_above",   // 涨幅超过
    "change_percent_below",   // 跌幅超过
    "price_above",            // 价格高于
    "price_below",            // 价格低于
  ]).notNull(),
  threshold: decimal("threshold", { precision: 20, scale: 4 }).notNull(),
  isEnabled: boolean("isEnabled").default(true).notNull(),
  lastTriggeredAt: timestamp("lastTriggeredAt"),
  triggerCount: int("triggerCount").default(0).notNull(),
  cooldownMinutes: int("cooldownMinutes").default(30).notNull(), // 触发后冷却时间
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ============================================================
// AI 用户记忆表 - 跨会话记忆用户投资偏好和关注板块
// ============================================================
export const aiUserMemory = mysqlTable("ai_user_memory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  category: mysqlEnum("category", [
    "investment_preference",  // 投资偏好（风格、策略）
    "focus_sector",           // 关注板块
    "focus_stock",            // 关注个股
    "risk_tolerance",         // 风险偏好
    "analysis_style",         // 分析风格偏好
    "custom_note",            // 自定义备注
  ]).notNull(),
  key: varchar("key", { length: 100 }).notNull(),   // 记忆键（如 "偏好风格"）
  value: text("value").notNull(),                     // 记忆值（如 "价值投资"）
  confidence: decimal("confidence", { precision: 3, scale: 2 }).default("0.80"), // AI提取的置信度
  source: mysqlEnum("source", ["ai_extracted", "user_manual"]).default("ai_extracted"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
