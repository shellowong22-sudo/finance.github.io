ALTER TABLE `crawled_articles` ADD `originalTitle` varchar(500);--> statement-breakpoint
ALTER TABLE `crawled_articles` ADD `summary` text;