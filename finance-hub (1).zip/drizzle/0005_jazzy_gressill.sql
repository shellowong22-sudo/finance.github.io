CREATE TABLE `user_watchlist` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`name` varchar(200),
	`market` varchar(20) NOT NULL,
	`sortOrder` int DEFAULT 0,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_watchlist_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `kline_data` MODIFY COLUMN `period` varchar(10) NOT NULL;