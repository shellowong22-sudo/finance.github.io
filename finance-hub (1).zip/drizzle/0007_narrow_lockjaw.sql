CREATE TABLE `ai_user_memory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`category` enum('investment_preference','focus_sector','focus_stock','risk_tolerance','analysis_style','custom_note') NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text NOT NULL,
	`confidence` decimal(3,2) DEFAULT '0.80',
	`source` enum('ai_extracted','user_manual') DEFAULT 'ai_extracted',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ai_user_memory_id` PRIMARY KEY(`id`)
);
