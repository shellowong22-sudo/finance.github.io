CREATE TABLE `article_categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`slug` varchar(100) NOT NULL,
	`description` text,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `article_categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `article_categories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`summary` text,
	`content` text NOT NULL,
	`coverImage` text,
	`authorId` int NOT NULL,
	`categoryId` int,
	`tags` text,
	`status` enum('draft','pending','published','rejected','offline') NOT NULL DEFAULT 'draft',
	`isTop` boolean NOT NULL DEFAULT false,
	`isPinned` boolean NOT NULL DEFAULT false,
	`viewCount` int NOT NULL DEFAULT 0,
	`likeCount` int NOT NULL DEFAULT 0,
	`commentCount` int NOT NULL DEFAULT 0,
	`shareCount` int NOT NULL DEFAULT 0,
	`rejectReason` text,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `articles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`adminId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`targetType` varchar(50) NOT NULL,
	`targetId` int NOT NULL,
	`beforeData` text,
	`afterData` text,
	`remark` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `certificates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`examRecordId` int,
	`certificateNo` varchar(100) NOT NULL,
	`certificateUrl` text,
	`issuedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `certificates_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificates_certificateNo_unique` UNIQUE(`certificateNo`)
);
--> statement-breakpoint
CREATE TABLE `channel_settlements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`channelId` int NOT NULL,
	`orderId` int NOT NULL,
	`orderAmount` decimal(10,2) NOT NULL,
	`commissionRate` decimal(5,2) NOT NULL,
	`commissionAmount` decimal(10,2) NOT NULL,
	`status` enum('pending','settled','cancelled') NOT NULL DEFAULT 'pending',
	`settledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `channel_settlements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `channels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`companyName` varchar(200) NOT NULL,
	`contactName` varchar(100) NOT NULL,
	`contactPhone` varchar(20) NOT NULL,
	`contactEmail` varchar(320) NOT NULL,
	`channelType` enum('broker','bank','media','other') NOT NULL DEFAULT 'other',
	`businessLicense` text,
	`qualificationDocs` text,
	`description` text,
	`status` enum('pending','approved','rejected','suspended') NOT NULL DEFAULT 'pending',
	`rejectReason` text,
	`commissionRate` decimal(5,2) DEFAULT '0.00',
	`contractUrl` text,
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `channels_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`content` text NOT NULL,
	`authorId` int NOT NULL,
	`articleId` int,
	`parentId` int,
	`status` enum('active','hidden','deleted') NOT NULL DEFAULT 'active',
	`likeCount` int NOT NULL DEFAULT 0,
	`isFiltered` boolean NOT NULL DEFAULT false,
	`filterReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `comments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `course_chapters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`title` varchar(500) NOT NULL,
	`description` text,
	`videoUrl` text,
	`content` text,
	`duration` int DEFAULT 0,
	`sortOrder` int NOT NULL DEFAULT 0,
	`isFree` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `course_chapters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `course_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`chapterId` int NOT NULL,
	`progress` int NOT NULL DEFAULT 0,
	`watchedDuration` int DEFAULT 0,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`lastWatchedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `course_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `course_purchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`price` decimal(10,2) NOT NULL,
	`status` enum('active','refunded','expired') NOT NULL DEFAULT 'active',
	`refundReason` text,
	`refundedAt` timestamp,
	`channelId` int,
	`promoCode` varchar(100),
	`purchasedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `course_purchases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `course_reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`rating` int NOT NULL DEFAULT 5,
	`content` text,
	`status` enum('active','hidden') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `course_reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `courses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`description` text,
	`coverImage` text,
	`instructorId` int NOT NULL,
	`category` enum('finance','fund','stock','risk','crypto','forex') NOT NULL DEFAULT 'finance',
	`type` enum('video','graphic') NOT NULL DEFAULT 'video',
	`price` decimal(10,2) DEFAULT '0.00',
	`originalPrice` decimal(10,2),
	`isFree` boolean NOT NULL DEFAULT false,
	`status` enum('draft','published','offline') NOT NULL DEFAULT 'draft',
	`totalDuration` int DEFAULT 0,
	`chapterCount` int NOT NULL DEFAULT 0,
	`studentCount` int NOT NULL DEFAULT 0,
	`rating` decimal(3,2) DEFAULT '5.00',
	`ratingCount` int NOT NULL DEFAULT 0,
	`hasExam` boolean NOT NULL DEFAULT false,
	`hasCertificate` boolean NOT NULL DEFAULT false,
	`refundPolicy` text,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `courses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `crawled_articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceUrl` text NOT NULL,
	`title` varchar(500) NOT NULL,
	`content` text NOT NULL,
	`author` varchar(100),
	`publishedAt` timestamp,
	`isImported` boolean NOT NULL DEFAULT false,
	`importedArticleId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `crawled_articles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `exam_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`question` text NOT NULL,
	`type` enum('single','multiple','truefalse') NOT NULL DEFAULT 'single',
	`options` text NOT NULL,
	`answer` text NOT NULL,
	`explanation` text,
	`score` int NOT NULL DEFAULT 10,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exam_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `exam_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`answers` text NOT NULL,
	`score` int NOT NULL DEFAULT 0,
	`totalScore` int NOT NULL DEFAULT 100,
	`isPassed` boolean NOT NULL DEFAULT false,
	`passScore` int NOT NULL DEFAULT 60,
	`duration` int DEFAULT 0,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exam_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `follows` (
	`id` int AUTO_INCREMENT NOT NULL,
	`followerId` int NOT NULL,
	`followingId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `follows_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `instructors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`realName` varchar(100) NOT NULL,
	`title` varchar(200),
	`organization` varchar(200),
	`bio` text,
	`avatar` text,
	`expertise` text,
	`courseCount` int NOT NULL DEFAULT 0,
	`studentCount` int NOT NULL DEFAULT 0,
	`rating` decimal(3,2) DEFAULT '5.00',
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `instructors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `likes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`targetType` enum('article','comment','report','course') NOT NULL,
	`targetId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `likes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`senderId` int NOT NULL,
	`receiverId` int NOT NULL,
	`content` text NOT NULL,
	`isRead` boolean NOT NULL DEFAULT false,
	`isFiltered` boolean NOT NULL DEFAULT false,
	`filterReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `promo_links` (
	`id` int AUTO_INCREMENT NOT NULL,
	`channelId` int NOT NULL,
	`code` varchar(50) NOT NULL,
	`targetType` enum('course','report','platform') NOT NULL DEFAULT 'platform',
	`targetId` int,
	`clickCount` int NOT NULL DEFAULT 0,
	`convertCount` int NOT NULL DEFAULT 0,
	`revenue` decimal(12,2) DEFAULT '0.00',
	`isActive` boolean NOT NULL DEFAULT true,
	`expiredAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `promo_links_id` PRIMARY KEY(`id`),
	CONSTRAINT `promo_links_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `report_downloads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reportId` int NOT NULL,
	`downloadedAt` timestamp NOT NULL DEFAULT (now()),
	`ipAddress` varchar(64),
	CONSTRAINT `report_downloads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `report_favorites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reportId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `report_favorites_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `report_read_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reportId` int NOT NULL,
	`duration` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `report_read_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`summary` text,
	`fileUrl` text NOT NULL,
	`fileKey` text NOT NULL,
	`fileType` enum('pdf','word') NOT NULL DEFAULT 'pdf',
	`fileSize` int DEFAULT 0,
	`coverImage` text,
	`authorId` int NOT NULL,
	`institution` varchar(200),
	`category` enum('macro','industry','stock','strategy','fixed_income') NOT NULL DEFAULT 'macro',
	`tags` text,
	`isPaid` boolean NOT NULL DEFAULT false,
	`price` decimal(10,2) DEFAULT '0.00',
	`status` enum('draft','published','offline') NOT NULL DEFAULT 'draft',
	`viewCount` int NOT NULL DEFAULT 0,
	`downloadCount` int NOT NULL DEFAULT 0,
	`favoriteCount` int NOT NULL DEFAULT 0,
	`totalReadDuration` bigint DEFAULT 0,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sensitive_words` (
	`id` int AUTO_INCREMENT NOT NULL,
	`word` varchar(200) NOT NULL,
	`category` enum('finance','political','obscene','fraud','other') NOT NULL DEFAULT 'finance',
	`level` enum('block','review','warn') NOT NULL DEFAULT 'block',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sensitive_words_id` PRIMARY KEY(`id`),
	CONSTRAINT `sensitive_words_word_unique` UNIQUE(`word`)
);
--> statement-breakpoint
CREATE TABLE `user_stats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` varchar(10) NOT NULL,
	`newUsers` int NOT NULL DEFAULT 0,
	`activeUsers` int NOT NULL DEFAULT 0,
	`articleViews` int NOT NULL DEFAULT 0,
	`reportDownloads` int NOT NULL DEFAULT 0,
	`courseEnrollments` int NOT NULL DEFAULT 0,
	`revenue` decimal(12,2) DEFAULT '0.00',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_stats_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','channel') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `avatar` text;--> statement-breakpoint
ALTER TABLE `users` ADD `bio` text;--> statement-breakpoint
ALTER TABLE `users` ADD `status` enum('active','banned','pending') DEFAULT 'active' NOT NULL;