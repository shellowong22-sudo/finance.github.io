CREATE TABLE `ai_conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(200),
	`style` varchar(50) DEFAULT 'professional',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ai_conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ai_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ai_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `market_quotes` MODIFY COLUMN `market` enum('a_share','us_stock','hk_stock','futures','option','fund','bond','crypto','forex','index') NOT NULL;--> statement-breakpoint
ALTER TABLE `trading_accounts` MODIFY COLUMN `market` enum('a_share','us_stock','hk_stock','futures','option','fund','bond','crypto','forex','global') NOT NULL;